Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _autocompletePlusProvider = require('./autocomplete-plus-provider');

var _autocompletePlusProvider2 = _interopRequireDefault(_autocompletePlusProvider);

var _autocompleteRobotProvider = require('./autocomplete-robot-provider');

var _autocompleteRobotProvider2 = _interopRequireDefault(_autocompleteRobotProvider);

'use babel';
exports['default'] = {
  activate: function activate() {
    var lrf = atom.packages.resolvePackagePath('language-robot-framework');
    if (!lrf) {
      require('atom-package-deps').install('autocomplete-robot-framework', true)['catch'](function (error) {
        console.error('Error occurred while installing dependencies: ' + (error.stack ? error.stack : error));
      });
    }

    return _autocompletePlusProvider2['default'].load();
  },
  deactivate: function deactivate() {
    return _autocompletePlusProvider2['default'].unload();
  },
  getAutocompletePlusProvider: function getAutocompletePlusProvider() {
    return _autocompletePlusProvider2['default'];
  },
  getAutocompleteRobotProvider: function getAutocompleteRobotProvider() {
    return _autocompleteRobotProvider2['default'];
  },
  config: {
    processLibdocFiles: {
      title: 'Scan projects for libdoc xml files',
      type: 'boolean',
      'default': true,
      order: 2
    },
    showLibrarySuggestions: {
      title: 'Show library name suggestions',
      type: 'boolean',
      'default': true,
      order: 3
    },
    removeDotNotation: {
      title: 'Avoid dot notation in suggestions, ie. \'BuiltIn.convhex\' will be suggested as \'Convert To Hex\' instead of \'BuiltIn.Convert To Hex\'',
      type: 'boolean',
      'default': true,
      order: 4
    },
    suggestArguments: {
      title: 'Add arguments after keyword name',
      type: 'boolean',
      'default': true,
      order: 5
    },
    includeDefaultArguments: {
      title: 'Include optional arguments',
      description: 'When disabled all optional arguments will be discarded; ie. \'Log  message\' instead of \'Log  message  level=INFO  html=FALSE...\'',
      type: 'boolean',
      'default': false,
      order: 6
    },
    argumentSeparator: {
      title: 'Argument separator',
      type: 'string',
      'default': '    ',
      order: 7
    },
    excludeDirectories: {
      title: 'Exclude robot resources (comma separated). Excluded resources will not be parsed for keywords.',
      description: 'Specify names of files or directories. Paths are not allowed. Glob expressions are supported.',
      type: 'array',
      'default': [],
      items: {
        type: 'string'
      },
      order: 10
    },
    pythonExecutable: {
      title: 'Python executable',
      type: 'string',
      'default': 'python',
      order: 11
    },
    debug: {
      title: 'Print debug messages in console',
      type: 'boolean',
      'default': false,
      order: 200
    }
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1yb2JvdC1mcmFtZXdvcmsvbGliL21haW4uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O3dDQUNxQyw4QkFBOEI7Ozs7eUNBQzdCLCtCQUErQjs7OztBQUZyRSxXQUFXLENBQUE7cUJBSUk7QUFDYixVQUFRLEVBQUEsb0JBQUc7QUFDVCxRQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLGtCQUFrQixDQUFDLDBCQUEwQixDQUFDLENBQUE7QUFDeEUsUUFBRyxDQUFDLEdBQUcsRUFBQztBQUNOLGFBQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLE9BQU8sQ0FBQyw4QkFBOEIsRUFBRSxJQUFJLENBQUMsU0FDcEUsQ0FBQyxVQUFDLEtBQUssRUFBSztBQUNoQixlQUFPLENBQUMsS0FBSyxxREFBa0QsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQSxDQUFHLENBQUM7T0FDckcsQ0FBQyxDQUFBO0tBQ0g7O0FBRUQsV0FBTyxzQ0FBeUIsSUFBSSxFQUFFLENBQUM7R0FDeEM7QUFDRCxZQUFVLEVBQUEsc0JBQUc7QUFDWCxXQUFPLHNDQUF5QixNQUFNLEVBQUUsQ0FBQztHQUMxQztBQUNELDZCQUEyQixFQUFBLHVDQUFHO0FBQzVCLGlEQUFnQztHQUNqQztBQUNELDhCQUE0QixFQUFBLHdDQUFHO0FBQzdCLGtEQUFpQztHQUNsQztBQUNELFFBQU0sRUFBRTtBQUNOLHNCQUFrQixFQUFFO0FBQ2xCLFdBQUssRUFBRSxvQ0FBb0M7QUFDM0MsVUFBSSxFQUFFLFNBQVM7QUFDZixpQkFBUyxJQUFJO0FBQ2IsV0FBSyxFQUFFLENBQUM7S0FDVDtBQUNELDBCQUFzQixFQUFFO0FBQ3RCLFdBQUssRUFBRSwrQkFBK0I7QUFDdEMsVUFBSSxFQUFFLFNBQVM7QUFDZixpQkFBUyxJQUFJO0FBQ2IsV0FBSyxFQUFFLENBQUM7S0FDVDtBQUNELHFCQUFpQixFQUFFO0FBQ2pCLFdBQUssRUFBRSwwSUFBMEk7QUFDakosVUFBSSxFQUFFLFNBQVM7QUFDZixpQkFBUyxJQUFJO0FBQ2IsV0FBSyxFQUFFLENBQUM7S0FDVDtBQUNELG9CQUFnQixFQUFFO0FBQ2hCLFdBQUssRUFBRSxrQ0FBa0M7QUFDekMsVUFBSSxFQUFFLFNBQVM7QUFDZixpQkFBUyxJQUFJO0FBQ2IsV0FBSyxFQUFFLENBQUM7S0FDVDtBQUNELDJCQUF1QixFQUFFO0FBQ3ZCLFdBQUssRUFBRSw0QkFBNEI7QUFDbkMsaUJBQVcsRUFBRSxxSUFBcUk7QUFDbEosVUFBSSxFQUFFLFNBQVM7QUFDZixpQkFBUyxLQUFLO0FBQ2QsV0FBSyxFQUFFLENBQUM7S0FDVDtBQUNELHFCQUFpQixFQUFFO0FBQ2pCLFdBQUssRUFBRSxvQkFBb0I7QUFDM0IsVUFBSSxFQUFFLFFBQVE7QUFDZCxpQkFBUyxNQUFNO0FBQ2YsV0FBSyxFQUFFLENBQUM7S0FDVDtBQUNELHNCQUFrQixFQUFFO0FBQ2xCLFdBQUssRUFBRSxnR0FBZ0c7QUFDdkcsaUJBQVcsRUFBRSwrRkFBK0Y7QUFDNUcsVUFBSSxFQUFFLE9BQU87QUFDYixpQkFBUyxFQUFFO0FBQ1gsV0FBSyxFQUFFO0FBQ0wsWUFBSSxFQUFFLFFBQVE7T0FDZjtBQUNELFdBQUssRUFBRSxFQUFFO0tBQ1Y7QUFDRCxvQkFBZ0IsRUFBRTtBQUNoQixXQUFLLEVBQUUsbUJBQW1CO0FBQzFCLFVBQUksRUFBRSxRQUFRO0FBQ2QsaUJBQVMsUUFBUTtBQUNqQixXQUFLLEVBQUUsRUFBRTtLQUNWO0FBQ0QsU0FBSyxFQUFFO0FBQ0wsV0FBSyxFQUFFLGlDQUFpQztBQUN4QyxVQUFJLEVBQUUsU0FBUztBQUNmLGlCQUFTLEtBQUs7QUFDZCxXQUFLLEVBQUUsR0FBRztLQUNYO0dBQ0Y7Q0FDRiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy9hdXRvY29tcGxldGUtcm9ib3QtZnJhbWV3b3JrL2xpYi9tYWluLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCdcbmltcG9ydCBhdXRvY29tcGxldGVQbHVzUHJvdmlkZXIgZnJvbSAnLi9hdXRvY29tcGxldGUtcGx1cy1wcm92aWRlcic7XG5pbXBvcnQgYXV0b2NvbXBsZXRlUm9ib3RQcm92aWRlciBmcm9tICcuL2F1dG9jb21wbGV0ZS1yb2JvdC1wcm92aWRlcic7XG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgYWN0aXZhdGUoKSB7XG4gICAgY29uc3QgbHJmID0gYXRvbS5wYWNrYWdlcy5yZXNvbHZlUGFja2FnZVBhdGgoJ2xhbmd1YWdlLXJvYm90LWZyYW1ld29yaycpXG4gICAgaWYoIWxyZil7XG4gICAgICByZXF1aXJlKCdhdG9tLXBhY2thZ2UtZGVwcycpLmluc3RhbGwoJ2F1dG9jb21wbGV0ZS1yb2JvdC1mcmFtZXdvcmsnLCB0cnVlKVxuICAgICAgLmNhdGNoKChlcnJvcikgPT4ge1xuICAgICAgICBjb25zb2xlLmVycm9yKGBFcnJvciBvY2N1cnJlZCB3aGlsZSBpbnN0YWxsaW5nIGRlcGVuZGVuY2llczogJHtlcnJvci5zdGFjayA/IGVycm9yLnN0YWNrIDogZXJyb3J9YCk7XG4gICAgICB9KVxuICAgIH1cblxuICAgIHJldHVybiBhdXRvY29tcGxldGVQbHVzUHJvdmlkZXIubG9hZCgpO1xuICB9LFxuICBkZWFjdGl2YXRlKCkge1xuICAgIHJldHVybiBhdXRvY29tcGxldGVQbHVzUHJvdmlkZXIudW5sb2FkKCk7XG4gIH0sXG4gIGdldEF1dG9jb21wbGV0ZVBsdXNQcm92aWRlcigpIHtcbiAgICByZXR1cm4gYXV0b2NvbXBsZXRlUGx1c1Byb3ZpZGVyO1xuICB9LFxuICBnZXRBdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyKCkge1xuICAgIHJldHVybiBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyO1xuICB9LFxuICBjb25maWc6IHtcbiAgICBwcm9jZXNzTGliZG9jRmlsZXM6IHtcbiAgICAgIHRpdGxlOiAnU2NhbiBwcm9qZWN0cyBmb3IgbGliZG9jIHhtbCBmaWxlcycsXG4gICAgICB0eXBlOiAnYm9vbGVhbicsXG4gICAgICBkZWZhdWx0OiB0cnVlLFxuICAgICAgb3JkZXI6IDJcbiAgICB9LFxuICAgIHNob3dMaWJyYXJ5U3VnZ2VzdGlvbnM6IHtcbiAgICAgIHRpdGxlOiAnU2hvdyBsaWJyYXJ5IG5hbWUgc3VnZ2VzdGlvbnMnLFxuICAgICAgdHlwZTogJ2Jvb2xlYW4nLFxuICAgICAgZGVmYXVsdDogdHJ1ZSxcbiAgICAgIG9yZGVyOiAzXG4gICAgfSxcbiAgICByZW1vdmVEb3ROb3RhdGlvbjoge1xuICAgICAgdGl0bGU6ICdBdm9pZCBkb3Qgbm90YXRpb24gaW4gc3VnZ2VzdGlvbnMsIGllLiBcXCdCdWlsdEluLmNvbnZoZXhcXCcgd2lsbCBiZSBzdWdnZXN0ZWQgYXMgXFwnQ29udmVydCBUbyBIZXhcXCcgaW5zdGVhZCBvZiBcXCdCdWlsdEluLkNvbnZlcnQgVG8gSGV4XFwnJyxcbiAgICAgIHR5cGU6ICdib29sZWFuJyxcbiAgICAgIGRlZmF1bHQ6IHRydWUsXG4gICAgICBvcmRlcjogNFxuICAgIH0sXG4gICAgc3VnZ2VzdEFyZ3VtZW50czoge1xuICAgICAgdGl0bGU6ICdBZGQgYXJndW1lbnRzIGFmdGVyIGtleXdvcmQgbmFtZScsXG4gICAgICB0eXBlOiAnYm9vbGVhbicsXG4gICAgICBkZWZhdWx0OiB0cnVlLFxuICAgICAgb3JkZXI6IDVcbiAgICB9LFxuICAgIGluY2x1ZGVEZWZhdWx0QXJndW1lbnRzOiB7XG4gICAgICB0aXRsZTogJ0luY2x1ZGUgb3B0aW9uYWwgYXJndW1lbnRzJyxcbiAgICAgIGRlc2NyaXB0aW9uOiAnV2hlbiBkaXNhYmxlZCBhbGwgb3B0aW9uYWwgYXJndW1lbnRzIHdpbGwgYmUgZGlzY2FyZGVkOyBpZS4gXFwnTG9nICBtZXNzYWdlXFwnIGluc3RlYWQgb2YgXFwnTG9nICBtZXNzYWdlICBsZXZlbD1JTkZPICBodG1sPUZBTFNFLi4uXFwnJyxcbiAgICAgIHR5cGU6ICdib29sZWFuJyxcbiAgICAgIGRlZmF1bHQ6IGZhbHNlLFxuICAgICAgb3JkZXI6IDZcbiAgICB9LFxuICAgIGFyZ3VtZW50U2VwYXJhdG9yOiB7XG4gICAgICB0aXRsZTogJ0FyZ3VtZW50IHNlcGFyYXRvcicsXG4gICAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICAgIGRlZmF1bHQ6ICcgICAgJyxcbiAgICAgIG9yZGVyOiA3XG4gICAgfSxcbiAgICBleGNsdWRlRGlyZWN0b3JpZXM6IHtcbiAgICAgIHRpdGxlOiAnRXhjbHVkZSByb2JvdCByZXNvdXJjZXMgKGNvbW1hIHNlcGFyYXRlZCkuIEV4Y2x1ZGVkIHJlc291cmNlcyB3aWxsIG5vdCBiZSBwYXJzZWQgZm9yIGtleXdvcmRzLicsXG4gICAgICBkZXNjcmlwdGlvbjogJ1NwZWNpZnkgbmFtZXMgb2YgZmlsZXMgb3IgZGlyZWN0b3JpZXMuIFBhdGhzIGFyZSBub3QgYWxsb3dlZC4gR2xvYiBleHByZXNzaW9ucyBhcmUgc3VwcG9ydGVkLicsXG4gICAgICB0eXBlOiAnYXJyYXknLFxuICAgICAgZGVmYXVsdDogW10sXG4gICAgICBpdGVtczoge1xuICAgICAgICB0eXBlOiAnc3RyaW5nJ1xuICAgICAgfSxcbiAgICAgIG9yZGVyOiAxMFxuICAgIH0sXG4gICAgcHl0aG9uRXhlY3V0YWJsZToge1xuICAgICAgdGl0bGU6ICdQeXRob24gZXhlY3V0YWJsZScsXG4gICAgICB0eXBlOiAnc3RyaW5nJyxcbiAgICAgIGRlZmF1bHQ6ICdweXRob24nLFxuICAgICAgb3JkZXI6IDExXG4gICAgfSxcbiAgICBkZWJ1Zzoge1xuICAgICAgdGl0bGU6ICdQcmludCBkZWJ1ZyBtZXNzYWdlcyBpbiBjb25zb2xlJyxcbiAgICAgIHR5cGU6ICdib29sZWFuJyxcbiAgICAgIGRlZmF1bHQ6IGZhbHNlLFxuICAgICAgb3JkZXI6IDIwMFxuICAgIH1cbiAgfVxufTtcbiJdfQ==