Object.defineProperty(exports, '__esModule', {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _atom = require('atom');

var _config = require('./config');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _uuid = require('uuid');

var _whatwgUrl = require('whatwg-url');

var _deepObjectDiff = require('deep-object-diff');

var X_TERMINAL_BASE_URI = 'x-terminal://';

var XTerminalProfilesSingletonSymbol = Symbol('XTerminalProfilesSingleton sentinel');

var XTerminalProfilesSingleton = (function () {
	function XTerminalProfilesSingleton(symbolCheck) {
		_classCallCheck(this, XTerminalProfilesSingleton);

		if (XTerminalProfilesSingletonSymbol !== symbolCheck) {
			throw new Error('XTerminalProfilesSingleton cannot be instantiated directly.');
		}
		this.emitter = new _atom.Emitter();
		this.profilesConfigPath = _path2['default'].join(_config.configDefaults.userDataPath, 'profiles.json');
		this.profiles = {};
		this.previousBaseProfile = null;
		this.baseProfile = this.getDefaultProfile();
		this.resetBaseProfile();
		this.profilesLoadPromise = null;
		this.reloadProfiles();
	}

	_createClass(XTerminalProfilesSingleton, [{
		key: 'sortProfiles',
		value: function sortProfiles(profiles) {
			var orderedProfiles = {};
			Object.keys(profiles).sort().forEach(function (key) {
				orderedProfiles[key] = profiles[key];
			});
			return orderedProfiles;
		}
	}, {
		key: 'reloadProfiles',
		value: _asyncToGenerator(function* () {
			var resolveLoad = undefined;
			this.profilesLoadPromise = new Promise(function (resolve) {
				resolveLoad = resolve;
			});
			try {
				var data = yield _fsExtra2['default'].readJson(this.profilesConfigPath);
				this.profiles = this.sortProfiles(data);
				this.emitter.emit('did-reload-profiles', this.getSanitizedProfilesData());
				resolveLoad();
			} catch (err) {
				// Create the profiles file.
				yield this.updateProfiles({});
				this.emitter.emit('did-reload-profiles', this.getSanitizedProfilesData());
				resolveLoad();
			}
		})
	}, {
		key: 'onDidReloadProfiles',
		value: function onDidReloadProfiles(callback) {
			return this.emitter.on('did-reload-profiles', callback);
		}
	}, {
		key: 'onDidResetBaseProfile',
		value: function onDidResetBaseProfile(callback) {
			return this.emitter.on('did-reset-base-profile', callback);
		}
	}, {
		key: 'updateProfiles',
		value: _asyncToGenerator(function* (newProfilesConfigData) {
			yield _fsExtra2['default'].ensureDir(_path2['default'].dirname(this.profilesConfigPath));
			newProfilesConfigData = this.sortProfiles(newProfilesConfigData);
			yield _fsExtra2['default'].writeJson(this.profilesConfigPath, newProfilesConfigData);
			this.profiles = newProfilesConfigData;
		})
	}, {
		key: 'deepClone',
		value: function deepClone(data) {
			return JSON.parse(JSON.stringify(data));
		}
	}, {
		key: 'diffProfiles',
		value: function diffProfiles(oldProfile, newProfile) {
			// This method will return added or modified entries.
			var diff = (0, _deepObjectDiff.detailedDiff)(oldProfile, newProfile);
			return _extends({}, diff.added, diff.updated);
		}
	}, {
		key: 'getDefaultProfile',
		value: function getDefaultProfile() {
			var defaultProfile = {};
			for (var data of _config.CONFIG_DATA) {
				if (!data.profileKey) continue;
				defaultProfile[data.profileKey] = data.defaultProfile;
			}
			return defaultProfile;
		}
	}, {
		key: 'getBaseProfile',
		value: function getBaseProfile() {
			return this.deepClone(this.baseProfile);
		}
	}, {
		key: 'resetBaseProfile',
		value: function resetBaseProfile() {
			this.previousBaseProfile = this.deepClone(this.baseProfile);
			this.baseProfile = {};
			for (var data of _config.CONFIG_DATA) {
				if (!data.profileKey) continue;
				this.baseProfile[data.profileKey] = data.toBaseProfile(this.previousBaseProfile[data.profileKey]);
			}
			this.emitter.emit('did-reset-base-profile', this.getBaseProfile());
		}
	}, {
		key: 'sanitizeData',
		value: function sanitizeData(unsanitizedData) {
			if (!unsanitizedData) {
				return {};
			}
			var sanitizedData = {};
			for (var data of _config.CONFIG_DATA) {
				if (!data.profileKey) continue;
				if (data.profileKey in unsanitizedData) {
					sanitizedData[data.profileKey] = unsanitizedData[data.profileKey];
				}
			}

			return this.deepClone(sanitizedData);
		}
	}, {
		key: 'getSanitizedProfilesData',
		value: function getSanitizedProfilesData() {
			var retval = {};
			for (var key in this.profiles) {
				retval[key] = this.sanitizeData(this.profiles[key]);
			}
			return retval;
		}
	}, {
		key: 'getProfiles',
		value: _asyncToGenerator(function* () {
			yield this.profilesLoadPromise;
			return this.getSanitizedProfilesData();
		})
	}, {
		key: 'getProfile',
		value: _asyncToGenerator(function* (profileName) {
			yield this.profilesLoadPromise;
			return _extends({}, this.deepClone(this.baseProfile), this.sanitizeData(this.profiles[profileName] || {}));
		})
	}, {
		key: 'isProfileExists',
		value: _asyncToGenerator(function* (profileName) {
			yield this.profilesLoadPromise;
			return profileName in this.profiles;
		})
	}, {
		key: 'setProfile',
		value: _asyncToGenerator(function* (profileName, data) {
			yield this.profilesLoadPromise;
			var profileData = _extends({}, this.deepClone(this.baseProfile), this.sanitizeData(data));
			var newProfilesConfigData = _extends({}, this.deepClone(this.profiles));
			newProfilesConfigData[profileName] = profileData;
			yield this.updateProfiles(newProfilesConfigData);
		})
	}, {
		key: 'deleteProfile',
		value: _asyncToGenerator(function* (profileName) {
			yield this.profilesLoadPromise;
			var newProfilesConfigData = _extends({}, this.deepClone(this.profiles));
			delete newProfilesConfigData[profileName];
			yield this.updateProfiles(newProfilesConfigData);
		})
	}, {
		key: 'generateNewUri',
		value: function generateNewUri() {
			return X_TERMINAL_BASE_URI + (0, _uuid.v4)() + '/';
		}
	}, {
		key: 'generateNewUrlFromProfileData',
		value: function generateNewUrlFromProfileData(profileData) {
			profileData = this.sanitizeData(profileData);
			var url = new _whatwgUrl.URL(this.generateNewUri());
			for (var data of _config.CONFIG_DATA) {
				if (!data.profileKey) continue;
				if (data.profileKey in profileData) url.searchParams.set(data.profileKey, data.toUrlParam(profileData[data.profileKey]));
			}
			return url;
		}
	}, {
		key: 'createProfileDataFromUri',
		value: function createProfileDataFromUri(uri) {
			var url = new _whatwgUrl.URL(uri);
			var baseProfile = this.getBaseProfile();
			var profileData = {};
			for (var data of _config.CONFIG_DATA) {
				if (!data.profileKey) continue;
				var param = url.searchParams.get(data.profileKey);
				if (param) {
					profileData[data.profileKey] = data.fromUrlParam(param);
				}
				if (!param || !data.checkUrlParam(profileData[data.profileKey])) {
					profileData[data.profileKey] = baseProfile[data.profileKey];
				}
			}
			return profileData;
		}
	}], [{
		key: 'instance',
		get: function get() {
			if (!this[XTerminalProfilesSingletonSymbol]) {
				this[XTerminalProfilesSingletonSymbol] = new XTerminalProfilesSingleton(XTerminalProfilesSingletonSymbol);
			}
			return this[XTerminalProfilesSingletonSymbol];
		}
	}]);

	return XTerminalProfilesSingleton;
})();

exports.X_TERMINAL_BASE_URI = X_TERMINAL_BASE_URI;
exports.XTerminalProfilesSingleton = XTerminalProfilesSingleton;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3Byb2ZpbGVzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CQXFCd0IsTUFBTTs7c0JBRWMsVUFBVTs7dUJBRXZDLFVBQVU7Ozs7b0JBQ1IsTUFBTTs7OztvQkFFTSxNQUFNOzt5QkFDZixZQUFZOzs4QkFDSCxrQkFBa0I7O0FBRS9DLElBQU0sbUJBQW1CLEdBQUcsZUFBZSxDQUFBOztBQUUzQyxJQUFNLGdDQUFnQyxHQUFHLE1BQU0sQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFBOztJQUVoRiwwQkFBMEI7QUFDbkIsVUFEUCwwQkFBMEIsQ0FDbEIsV0FBVyxFQUFFO3dCQURyQiwwQkFBMEI7O0FBRTlCLE1BQUksZ0NBQWdDLEtBQUssV0FBVyxFQUFFO0FBQ3JELFNBQU0sSUFBSSxLQUFLLENBQUMsNkRBQTZELENBQUMsQ0FBQTtHQUM5RTtBQUNELE1BQUksQ0FBQyxPQUFPLEdBQUcsbUJBQWEsQ0FBQTtBQUM1QixNQUFJLENBQUMsa0JBQWtCLEdBQUcsa0JBQUssSUFBSSxDQUFDLHVCQUFlLFlBQVksRUFBRSxlQUFlLENBQUMsQ0FBQTtBQUNqRixNQUFJLENBQUMsUUFBUSxHQUFHLEVBQUUsQ0FBQTtBQUNsQixNQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFBO0FBQy9CLE1BQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUE7QUFDM0MsTUFBSSxDQUFDLGdCQUFnQixFQUFFLENBQUE7QUFDdkIsTUFBSSxDQUFDLG1CQUFtQixHQUFHLElBQUksQ0FBQTtBQUMvQixNQUFJLENBQUMsY0FBYyxFQUFFLENBQUE7RUFDckI7O2NBYkksMEJBQTBCOztTQXNCbEIsc0JBQUMsUUFBUSxFQUFFO0FBQ3ZCLE9BQU0sZUFBZSxHQUFHLEVBQUUsQ0FBQTtBQUMxQixTQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUcsRUFBSztBQUM3QyxtQkFBZSxDQUFDLEdBQUcsQ0FBQyxHQUFHLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUNwQyxDQUFDLENBQUE7QUFDRixVQUFPLGVBQWUsQ0FBQTtHQUN0Qjs7OzJCQUVvQixhQUFHO0FBQ3ZCLE9BQUksV0FBVyxZQUFBLENBQUE7QUFDZixPQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxPQUFPLENBQUMsVUFBQyxPQUFPLEVBQUs7QUFDbkQsZUFBVyxHQUFHLE9BQU8sQ0FBQTtJQUNyQixDQUFDLENBQUE7QUFDRixPQUFJO0FBQ0gsUUFBTSxJQUFJLEdBQUcsTUFBTSxxQkFBRyxRQUFRLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUE7QUFDdkQsUUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3ZDLFFBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLHFCQUFxQixFQUFFLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLENBQUE7QUFDekUsZUFBVyxFQUFFLENBQUE7SUFDYixDQUFDLE9BQU8sR0FBRyxFQUFFOztBQUViLFVBQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUM3QixRQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsd0JBQXdCLEVBQUUsQ0FBQyxDQUFBO0FBQ3pFLGVBQVcsRUFBRSxDQUFBO0lBQ2I7R0FDRDs7O1NBRW1CLDZCQUFDLFFBQVEsRUFBRTtBQUM5QixVQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxDQUFBO0dBQ3ZEOzs7U0FFcUIsK0JBQUMsUUFBUSxFQUFFO0FBQ2hDLFVBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsd0JBQXdCLEVBQUUsUUFBUSxDQUFDLENBQUE7R0FDMUQ7OzsyQkFFb0IsV0FBQyxxQkFBcUIsRUFBRTtBQUM1QyxTQUFNLHFCQUFHLFNBQVMsQ0FBQyxrQkFBSyxPQUFPLENBQUMsSUFBSSxDQUFDLGtCQUFrQixDQUFDLENBQUMsQ0FBQTtBQUN6RCx3QkFBcUIsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLHFCQUFxQixDQUFDLENBQUE7QUFDaEUsU0FBTSxxQkFBRyxTQUFTLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLHFCQUFxQixDQUFDLENBQUE7QUFDbEUsT0FBSSxDQUFDLFFBQVEsR0FBRyxxQkFBcUIsQ0FBQTtHQUNyQzs7O1NBRVMsbUJBQUMsSUFBSSxFQUFFO0FBQ2hCLFVBQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUE7R0FDdkM7OztTQUVZLHNCQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUU7O0FBRXJDLE9BQU0sSUFBSSxHQUFHLGtDQUFhLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQTtBQUNqRCx1QkFDSSxJQUFJLENBQUMsS0FBSyxFQUNWLElBQUksQ0FBQyxPQUFPLEVBQ2Y7R0FDRDs7O1NBRWlCLDZCQUFHO0FBQ3BCLE9BQU0sY0FBYyxHQUFHLEVBQUUsQ0FBQTtBQUN6QixRQUFLLElBQU0sSUFBSSx5QkFBaUI7QUFDL0IsUUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUTtBQUM5QixrQkFBYyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFBO0lBQ3JEO0FBQ0QsVUFBTyxjQUFjLENBQUE7R0FDckI7OztTQUVjLDBCQUFHO0FBQ2pCLFVBQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUE7R0FDdkM7OztTQUVnQiw0QkFBRztBQUNuQixPQUFJLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDM0QsT0FBSSxDQUFDLFdBQVcsR0FBRyxFQUFFLENBQUE7QUFDckIsUUFBSyxJQUFNLElBQUkseUJBQWlCO0FBQy9CLFFBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFNBQVE7QUFDOUIsUUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7SUFDakc7QUFDRCxPQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQTtHQUNsRTs7O1NBRVksc0JBQUMsZUFBZSxFQUFFO0FBQzlCLE9BQUksQ0FBQyxlQUFlLEVBQUU7QUFDckIsV0FBTyxFQUFFLENBQUE7SUFDVDtBQUNELE9BQU0sYUFBYSxHQUFHLEVBQUUsQ0FBQTtBQUN4QixRQUFLLElBQU0sSUFBSSx5QkFBaUI7QUFDL0IsUUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUTtBQUM5QixRQUFJLElBQUksQ0FBQyxVQUFVLElBQUksZUFBZSxFQUFFO0FBQ3ZDLGtCQUFhLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLGVBQWUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7S0FDakU7SUFDRDs7QUFFRCxVQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDLENBQUE7R0FDcEM7OztTQUV3QixvQ0FBRztBQUMzQixPQUFNLE1BQU0sR0FBRyxFQUFFLENBQUE7QUFDakIsUUFBSyxJQUFNLEdBQUcsSUFBSSxJQUFJLENBQUMsUUFBUSxFQUFFO0FBQ2hDLFVBQU0sQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQTtJQUNuRDtBQUNELFVBQU8sTUFBTSxDQUFBO0dBQ2I7OzsyQkFFaUIsYUFBRztBQUNwQixTQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQTtBQUM5QixVQUFPLElBQUksQ0FBQyx3QkFBd0IsRUFBRSxDQUFBO0dBQ3RDOzs7MkJBRWdCLFdBQUMsV0FBVyxFQUFFO0FBQzlCLFNBQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFBO0FBQzlCLHVCQUNJLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUNoQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLElBQUksRUFBRSxDQUFDLEVBQ3REO0dBQ0Q7OzsyQkFFcUIsV0FBQyxXQUFXLEVBQUU7QUFDbkMsU0FBTSxJQUFJLENBQUMsbUJBQW1CLENBQUE7QUFDOUIsVUFBTyxXQUFXLElBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQTtHQUNuQzs7OzJCQUVnQixXQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUU7QUFDcEMsU0FBTSxJQUFJLENBQUMsbUJBQW1CLENBQUE7QUFDOUIsT0FBTSxXQUFXLGdCQUNiLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUNoQyxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUMxQixDQUFBO0FBQ0QsT0FBTSxxQkFBcUIsZ0JBQ3ZCLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUNoQyxDQUFBO0FBQ0Qsd0JBQXFCLENBQUMsV0FBVyxDQUFDLEdBQUcsV0FBVyxDQUFBO0FBQ2hELFNBQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFBO0dBQ2hEOzs7MkJBRW1CLFdBQUMsV0FBVyxFQUFFO0FBQ2pDLFNBQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFBO0FBQzlCLE9BQU0scUJBQXFCLGdCQUN2QixJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FDaEMsQ0FBQTtBQUNELFVBQU8scUJBQXFCLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDekMsU0FBTSxJQUFJLENBQUMsY0FBYyxDQUFDLHFCQUFxQixDQUFDLENBQUE7R0FDaEQ7OztTQUVjLDBCQUFHO0FBQ2pCLFVBQU8sbUJBQW1CLEdBQUcsZUFBUSxHQUFHLEdBQUcsQ0FBQTtHQUMzQzs7O1NBRTZCLHVDQUFDLFdBQVcsRUFBRTtBQUMzQyxjQUFXLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQTtBQUM1QyxPQUFNLEdBQUcsR0FBRyxtQkFBUSxJQUFJLENBQUMsY0FBYyxFQUFFLENBQUMsQ0FBQTtBQUMxQyxRQUFLLElBQU0sSUFBSSx5QkFBaUI7QUFDL0IsUUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUTtBQUM5QixRQUFJLElBQUksQ0FBQyxVQUFVLElBQUksV0FBVyxFQUFFLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUN4SDtBQUNELFVBQU8sR0FBRyxDQUFBO0dBQ1Y7OztTQUV3QixrQ0FBQyxHQUFHLEVBQUU7QUFDOUIsT0FBTSxHQUFHLEdBQUcsbUJBQVEsR0FBRyxDQUFDLENBQUE7QUFDeEIsT0FBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGNBQWMsRUFBRSxDQUFBO0FBQ3pDLE9BQU0sV0FBVyxHQUFHLEVBQUUsQ0FBQTtBQUN0QixRQUFLLElBQU0sSUFBSSx5QkFBaUI7QUFDL0IsUUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUTtBQUM5QixRQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7QUFDbkQsUUFBSSxLQUFLLEVBQUU7QUFDVixnQkFBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFBO0tBQ3ZEO0FBQ0QsUUFBSSxDQUFDLEtBQUssSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxFQUFFO0FBQ2hFLGdCQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7S0FDM0Q7SUFDRDtBQUNELFVBQU8sV0FBVyxDQUFBO0dBQ2xCOzs7T0FoTG1CLGVBQUc7QUFDdEIsT0FBSSxDQUFDLElBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxFQUFFO0FBQzVDLFFBQUksQ0FBQyxnQ0FBZ0MsQ0FBQyxHQUFHLElBQUksMEJBQTBCLENBQUMsZ0NBQWdDLENBQUMsQ0FBQTtJQUN6RztBQUNELFVBQU8sSUFBSSxDQUFDLGdDQUFnQyxDQUFDLENBQUE7R0FDN0M7OztRQXBCSSwwQkFBMEI7OztRQW1NL0IsbUJBQW1CLEdBQW5CLG1CQUFtQjtRQUNuQiwwQkFBMEIsR0FBMUIsMEJBQTBCIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3Byb2ZpbGVzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqIEBiYWJlbCAqL1xuLypcbiAqIENvcHlyaWdodCAyMDE3IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgMjAxNy0yMDE4IEFuZHJlcyBNZWppYSA8YW1lamlhMDA0QGdtYWlsLmNvbT4uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgVXppVGVjaCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIGJ1cy1zdG9wIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzXG4gKiBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGUgXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmVcbiAqIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSxcbiAqIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG9cbiAqIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzby5cbiAqXG4gKiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SIElNUExJRUQsXG4gKiBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQVxuICogUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVFxuICogSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OXG4gKiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEVcbiAqIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuICovXG5cbmltcG9ydCB7IEVtaXR0ZXIgfSBmcm9tICdhdG9tJ1xuXG5pbXBvcnQgeyBjb25maWdEZWZhdWx0cywgQ09ORklHX0RBVEEgfSBmcm9tICcuL2NvbmZpZydcblxuaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJ1xuaW1wb3J0IHBhdGggZnJvbSAncGF0aCdcblxuaW1wb3J0IHsgdjQgYXMgdXVpZHY0IH0gZnJvbSAndXVpZCdcbmltcG9ydCB7IFVSTCB9IGZyb20gJ3doYXR3Zy11cmwnXG5pbXBvcnQgeyBkZXRhaWxlZERpZmYgfSBmcm9tICdkZWVwLW9iamVjdC1kaWZmJ1xuXG5jb25zdCBYX1RFUk1JTkFMX0JBU0VfVVJJID0gJ3gtdGVybWluYWw6Ly8nXG5cbmNvbnN0IFhUZXJtaW5hbFByb2ZpbGVzU2luZ2xldG9uU3ltYm9sID0gU3ltYm9sKCdYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbiBzZW50aW5lbCcpXG5cbmNsYXNzIFhUZXJtaW5hbFByb2ZpbGVzU2luZ2xldG9uIHtcblx0Y29uc3RydWN0b3IgKHN5bWJvbENoZWNrKSB7XG5cdFx0aWYgKFhUZXJtaW5hbFByb2ZpbGVzU2luZ2xldG9uU3ltYm9sICE9PSBzeW1ib2xDaGVjaykge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKCdYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbiBjYW5ub3QgYmUgaW5zdGFudGlhdGVkIGRpcmVjdGx5LicpXG5cdFx0fVxuXHRcdHRoaXMuZW1pdHRlciA9IG5ldyBFbWl0dGVyKClcblx0XHR0aGlzLnByb2ZpbGVzQ29uZmlnUGF0aCA9IHBhdGguam9pbihjb25maWdEZWZhdWx0cy51c2VyRGF0YVBhdGgsICdwcm9maWxlcy5qc29uJylcblx0XHR0aGlzLnByb2ZpbGVzID0ge31cblx0XHR0aGlzLnByZXZpb3VzQmFzZVByb2ZpbGUgPSBudWxsXG5cdFx0dGhpcy5iYXNlUHJvZmlsZSA9IHRoaXMuZ2V0RGVmYXVsdFByb2ZpbGUoKVxuXHRcdHRoaXMucmVzZXRCYXNlUHJvZmlsZSgpXG5cdFx0dGhpcy5wcm9maWxlc0xvYWRQcm9taXNlID0gbnVsbFxuXHRcdHRoaXMucmVsb2FkUHJvZmlsZXMoKVxuXHR9XG5cblx0c3RhdGljIGdldCBpbnN0YW5jZSAoKSB7XG5cdFx0aWYgKCF0aGlzW1hUZXJtaW5hbFByb2ZpbGVzU2luZ2xldG9uU3ltYm9sXSkge1xuXHRcdFx0dGhpc1tYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvblN5bWJvbF0gPSBuZXcgWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24oWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b25TeW1ib2wpXG5cdFx0fVxuXHRcdHJldHVybiB0aGlzW1hUZXJtaW5hbFByb2ZpbGVzU2luZ2xldG9uU3ltYm9sXVxuXHR9XG5cblx0c29ydFByb2ZpbGVzIChwcm9maWxlcykge1xuXHRcdGNvbnN0IG9yZGVyZWRQcm9maWxlcyA9IHt9XG5cdFx0T2JqZWN0LmtleXMocHJvZmlsZXMpLnNvcnQoKS5mb3JFYWNoKChrZXkpID0+IHtcblx0XHRcdG9yZGVyZWRQcm9maWxlc1trZXldID0gcHJvZmlsZXNba2V5XVxuXHRcdH0pXG5cdFx0cmV0dXJuIG9yZGVyZWRQcm9maWxlc1xuXHR9XG5cblx0YXN5bmMgcmVsb2FkUHJvZmlsZXMgKCkge1xuXHRcdGxldCByZXNvbHZlTG9hZFxuXHRcdHRoaXMucHJvZmlsZXNMb2FkUHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlKSA9PiB7XG5cdFx0XHRyZXNvbHZlTG9hZCA9IHJlc29sdmVcblx0XHR9KVxuXHRcdHRyeSB7XG5cdFx0XHRjb25zdCBkYXRhID0gYXdhaXQgZnMucmVhZEpzb24odGhpcy5wcm9maWxlc0NvbmZpZ1BhdGgpXG5cdFx0XHR0aGlzLnByb2ZpbGVzID0gdGhpcy5zb3J0UHJvZmlsZXMoZGF0YSlcblx0XHRcdHRoaXMuZW1pdHRlci5lbWl0KCdkaWQtcmVsb2FkLXByb2ZpbGVzJywgdGhpcy5nZXRTYW5pdGl6ZWRQcm9maWxlc0RhdGEoKSlcblx0XHRcdHJlc29sdmVMb2FkKClcblx0XHR9IGNhdGNoIChlcnIpIHtcblx0XHRcdC8vIENyZWF0ZSB0aGUgcHJvZmlsZXMgZmlsZS5cblx0XHRcdGF3YWl0IHRoaXMudXBkYXRlUHJvZmlsZXMoe30pXG5cdFx0XHR0aGlzLmVtaXR0ZXIuZW1pdCgnZGlkLXJlbG9hZC1wcm9maWxlcycsIHRoaXMuZ2V0U2FuaXRpemVkUHJvZmlsZXNEYXRhKCkpXG5cdFx0XHRyZXNvbHZlTG9hZCgpXG5cdFx0fVxuXHR9XG5cblx0b25EaWRSZWxvYWRQcm9maWxlcyAoY2FsbGJhY2spIHtcblx0XHRyZXR1cm4gdGhpcy5lbWl0dGVyLm9uKCdkaWQtcmVsb2FkLXByb2ZpbGVzJywgY2FsbGJhY2spXG5cdH1cblxuXHRvbkRpZFJlc2V0QmFzZVByb2ZpbGUgKGNhbGxiYWNrKSB7XG5cdFx0cmV0dXJuIHRoaXMuZW1pdHRlci5vbignZGlkLXJlc2V0LWJhc2UtcHJvZmlsZScsIGNhbGxiYWNrKVxuXHR9XG5cblx0YXN5bmMgdXBkYXRlUHJvZmlsZXMgKG5ld1Byb2ZpbGVzQ29uZmlnRGF0YSkge1xuXHRcdGF3YWl0IGZzLmVuc3VyZURpcihwYXRoLmRpcm5hbWUodGhpcy5wcm9maWxlc0NvbmZpZ1BhdGgpKVxuXHRcdG5ld1Byb2ZpbGVzQ29uZmlnRGF0YSA9IHRoaXMuc29ydFByb2ZpbGVzKG5ld1Byb2ZpbGVzQ29uZmlnRGF0YSlcblx0XHRhd2FpdCBmcy53cml0ZUpzb24odGhpcy5wcm9maWxlc0NvbmZpZ1BhdGgsIG5ld1Byb2ZpbGVzQ29uZmlnRGF0YSlcblx0XHR0aGlzLnByb2ZpbGVzID0gbmV3UHJvZmlsZXNDb25maWdEYXRhXG5cdH1cblxuXHRkZWVwQ2xvbmUgKGRhdGEpIHtcblx0XHRyZXR1cm4gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkYXRhKSlcblx0fVxuXG5cdGRpZmZQcm9maWxlcyAob2xkUHJvZmlsZSwgbmV3UHJvZmlsZSkge1xuXHRcdC8vIFRoaXMgbWV0aG9kIHdpbGwgcmV0dXJuIGFkZGVkIG9yIG1vZGlmaWVkIGVudHJpZXMuXG5cdFx0Y29uc3QgZGlmZiA9IGRldGFpbGVkRGlmZihvbGRQcm9maWxlLCBuZXdQcm9maWxlKVxuXHRcdHJldHVybiB7XG5cdFx0XHQuLi5kaWZmLmFkZGVkLFxuXHRcdFx0Li4uZGlmZi51cGRhdGVkLFxuXHRcdH1cblx0fVxuXG5cdGdldERlZmF1bHRQcm9maWxlICgpIHtcblx0XHRjb25zdCBkZWZhdWx0UHJvZmlsZSA9IHt9XG5cdFx0Zm9yIChjb25zdCBkYXRhIG9mIENPTkZJR19EQVRBKSB7XG5cdFx0XHRpZiAoIWRhdGEucHJvZmlsZUtleSkgY29udGludWVcblx0XHRcdGRlZmF1bHRQcm9maWxlW2RhdGEucHJvZmlsZUtleV0gPSBkYXRhLmRlZmF1bHRQcm9maWxlXG5cdFx0fVxuXHRcdHJldHVybiBkZWZhdWx0UHJvZmlsZVxuXHR9XG5cblx0Z2V0QmFzZVByb2ZpbGUgKCkge1xuXHRcdHJldHVybiB0aGlzLmRlZXBDbG9uZSh0aGlzLmJhc2VQcm9maWxlKVxuXHR9XG5cblx0cmVzZXRCYXNlUHJvZmlsZSAoKSB7XG5cdFx0dGhpcy5wcmV2aW91c0Jhc2VQcm9maWxlID0gdGhpcy5kZWVwQ2xvbmUodGhpcy5iYXNlUHJvZmlsZSlcblx0XHR0aGlzLmJhc2VQcm9maWxlID0ge31cblx0XHRmb3IgKGNvbnN0IGRhdGEgb2YgQ09ORklHX0RBVEEpIHtcblx0XHRcdGlmICghZGF0YS5wcm9maWxlS2V5KSBjb250aW51ZVxuXHRcdFx0dGhpcy5iYXNlUHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldID0gZGF0YS50b0Jhc2VQcm9maWxlKHRoaXMucHJldmlvdXNCYXNlUHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldKVxuXHRcdH1cblx0XHR0aGlzLmVtaXR0ZXIuZW1pdCgnZGlkLXJlc2V0LWJhc2UtcHJvZmlsZScsIHRoaXMuZ2V0QmFzZVByb2ZpbGUoKSlcblx0fVxuXG5cdHNhbml0aXplRGF0YSAodW5zYW5pdGl6ZWREYXRhKSB7XG5cdFx0aWYgKCF1bnNhbml0aXplZERhdGEpIHtcblx0XHRcdHJldHVybiB7fVxuXHRcdH1cblx0XHRjb25zdCBzYW5pdGl6ZWREYXRhID0ge31cblx0XHRmb3IgKGNvbnN0IGRhdGEgb2YgQ09ORklHX0RBVEEpIHtcblx0XHRcdGlmICghZGF0YS5wcm9maWxlS2V5KSBjb250aW51ZVxuXHRcdFx0aWYgKGRhdGEucHJvZmlsZUtleSBpbiB1bnNhbml0aXplZERhdGEpIHtcblx0XHRcdFx0c2FuaXRpemVkRGF0YVtkYXRhLnByb2ZpbGVLZXldID0gdW5zYW5pdGl6ZWREYXRhW2RhdGEucHJvZmlsZUtleV1cblx0XHRcdH1cblx0XHR9XG5cblx0XHRyZXR1cm4gdGhpcy5kZWVwQ2xvbmUoc2FuaXRpemVkRGF0YSlcblx0fVxuXG5cdGdldFNhbml0aXplZFByb2ZpbGVzRGF0YSAoKSB7XG5cdFx0Y29uc3QgcmV0dmFsID0ge31cblx0XHRmb3IgKGNvbnN0IGtleSBpbiB0aGlzLnByb2ZpbGVzKSB7XG5cdFx0XHRyZXR2YWxba2V5XSA9IHRoaXMuc2FuaXRpemVEYXRhKHRoaXMucHJvZmlsZXNba2V5XSlcblx0XHR9XG5cdFx0cmV0dXJuIHJldHZhbFxuXHR9XG5cblx0YXN5bmMgZ2V0UHJvZmlsZXMgKCkge1xuXHRcdGF3YWl0IHRoaXMucHJvZmlsZXNMb2FkUHJvbWlzZVxuXHRcdHJldHVybiB0aGlzLmdldFNhbml0aXplZFByb2ZpbGVzRGF0YSgpXG5cdH1cblxuXHRhc3luYyBnZXRQcm9maWxlIChwcm9maWxlTmFtZSkge1xuXHRcdGF3YWl0IHRoaXMucHJvZmlsZXNMb2FkUHJvbWlzZVxuXHRcdHJldHVybiB7XG5cdFx0XHQuLi50aGlzLmRlZXBDbG9uZSh0aGlzLmJhc2VQcm9maWxlKSxcblx0XHRcdC4uLnRoaXMuc2FuaXRpemVEYXRhKHRoaXMucHJvZmlsZXNbcHJvZmlsZU5hbWVdIHx8IHt9KSxcblx0XHR9XG5cdH1cblxuXHRhc3luYyBpc1Byb2ZpbGVFeGlzdHMgKHByb2ZpbGVOYW1lKSB7XG5cdFx0YXdhaXQgdGhpcy5wcm9maWxlc0xvYWRQcm9taXNlXG5cdFx0cmV0dXJuIHByb2ZpbGVOYW1lIGluIHRoaXMucHJvZmlsZXNcblx0fVxuXG5cdGFzeW5jIHNldFByb2ZpbGUgKHByb2ZpbGVOYW1lLCBkYXRhKSB7XG5cdFx0YXdhaXQgdGhpcy5wcm9maWxlc0xvYWRQcm9taXNlXG5cdFx0Y29uc3QgcHJvZmlsZURhdGEgPSB7XG5cdFx0XHQuLi50aGlzLmRlZXBDbG9uZSh0aGlzLmJhc2VQcm9maWxlKSxcblx0XHRcdC4uLnRoaXMuc2FuaXRpemVEYXRhKGRhdGEpLFxuXHRcdH1cblx0XHRjb25zdCBuZXdQcm9maWxlc0NvbmZpZ0RhdGEgPSB7XG5cdFx0XHQuLi50aGlzLmRlZXBDbG9uZSh0aGlzLnByb2ZpbGVzKSxcblx0XHR9XG5cdFx0bmV3UHJvZmlsZXNDb25maWdEYXRhW3Byb2ZpbGVOYW1lXSA9IHByb2ZpbGVEYXRhXG5cdFx0YXdhaXQgdGhpcy51cGRhdGVQcm9maWxlcyhuZXdQcm9maWxlc0NvbmZpZ0RhdGEpXG5cdH1cblxuXHRhc3luYyBkZWxldGVQcm9maWxlIChwcm9maWxlTmFtZSkge1xuXHRcdGF3YWl0IHRoaXMucHJvZmlsZXNMb2FkUHJvbWlzZVxuXHRcdGNvbnN0IG5ld1Byb2ZpbGVzQ29uZmlnRGF0YSA9IHtcblx0XHRcdC4uLnRoaXMuZGVlcENsb25lKHRoaXMucHJvZmlsZXMpLFxuXHRcdH1cblx0XHRkZWxldGUgbmV3UHJvZmlsZXNDb25maWdEYXRhW3Byb2ZpbGVOYW1lXVxuXHRcdGF3YWl0IHRoaXMudXBkYXRlUHJvZmlsZXMobmV3UHJvZmlsZXNDb25maWdEYXRhKVxuXHR9XG5cblx0Z2VuZXJhdGVOZXdVcmkgKCkge1xuXHRcdHJldHVybiBYX1RFUk1JTkFMX0JBU0VfVVJJICsgdXVpZHY0KCkgKyAnLydcblx0fVxuXG5cdGdlbmVyYXRlTmV3VXJsRnJvbVByb2ZpbGVEYXRhIChwcm9maWxlRGF0YSkge1xuXHRcdHByb2ZpbGVEYXRhID0gdGhpcy5zYW5pdGl6ZURhdGEocHJvZmlsZURhdGEpXG5cdFx0Y29uc3QgdXJsID0gbmV3IFVSTCh0aGlzLmdlbmVyYXRlTmV3VXJpKCkpXG5cdFx0Zm9yIChjb25zdCBkYXRhIG9mIENPTkZJR19EQVRBKSB7XG5cdFx0XHRpZiAoIWRhdGEucHJvZmlsZUtleSkgY29udGludWVcblx0XHRcdGlmIChkYXRhLnByb2ZpbGVLZXkgaW4gcHJvZmlsZURhdGEpIHVybC5zZWFyY2hQYXJhbXMuc2V0KGRhdGEucHJvZmlsZUtleSwgZGF0YS50b1VybFBhcmFtKHByb2ZpbGVEYXRhW2RhdGEucHJvZmlsZUtleV0pKVxuXHRcdH1cblx0XHRyZXR1cm4gdXJsXG5cdH1cblxuXHRjcmVhdGVQcm9maWxlRGF0YUZyb21VcmkgKHVyaSkge1xuXHRcdGNvbnN0IHVybCA9IG5ldyBVUkwodXJpKVxuXHRcdGNvbnN0IGJhc2VQcm9maWxlID0gdGhpcy5nZXRCYXNlUHJvZmlsZSgpXG5cdFx0Y29uc3QgcHJvZmlsZURhdGEgPSB7fVxuXHRcdGZvciAoY29uc3QgZGF0YSBvZiBDT05GSUdfREFUQSkge1xuXHRcdFx0aWYgKCFkYXRhLnByb2ZpbGVLZXkpIGNvbnRpbnVlXG5cdFx0XHRjb25zdCBwYXJhbSA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KGRhdGEucHJvZmlsZUtleSlcblx0XHRcdGlmIChwYXJhbSkge1xuXHRcdFx0XHRwcm9maWxlRGF0YVtkYXRhLnByb2ZpbGVLZXldID0gZGF0YS5mcm9tVXJsUGFyYW0ocGFyYW0pXG5cdFx0XHR9XG5cdFx0XHRpZiAoIXBhcmFtIHx8ICFkYXRhLmNoZWNrVXJsUGFyYW0ocHJvZmlsZURhdGFbZGF0YS5wcm9maWxlS2V5XSkpIHtcblx0XHRcdFx0cHJvZmlsZURhdGFbZGF0YS5wcm9maWxlS2V5XSA9IGJhc2VQcm9maWxlW2RhdGEucHJvZmlsZUtleV1cblx0XHRcdH1cblx0XHR9XG5cdFx0cmV0dXJuIHByb2ZpbGVEYXRhXG5cdH1cbn1cblxuZXhwb3J0IHtcblx0WF9URVJNSU5BTF9CQVNFX1VSSSxcblx0WFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24sXG59XG4iXX0=