Object.defineProperty(exports, '__esModule', {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x3, _x4, _x5) { var _again = true; _function: while (_again) { var object = _x3, property = _x4, receiver = _x5; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x3 = parent; _x4 = property; _x5 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _atom = require('atom');

var _nodePtyPrebuiltMultiarch = require('node-pty-prebuilt-multiarch');

var _xterm = require('xterm');

var _xtermAddonFit = require('xterm-addon-fit');

var _xtermAddonWebLinks = require('xterm-addon-web-links');

var _xtermAddonWebgl = require('xterm-addon-webgl');

var _xtermAddonLigatures = require('xterm-addon-ligatures');

var _electron = require('electron');

var _config = require('./config');

var _profileMenuElement = require('./profile-menu-element');

var _profileMenuModel = require('./profile-menu-model');

var _profiles = require('./profiles');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var PTY_PROCESS_OPTIONS = new Set(['command', 'args', 'name', 'cwd', 'env', 'setEnv', 'deleteEnv', 'encoding']);
var X_TERMINAL_OPTIONS = ['leaveOpenAfterExit', 'relaunchTerminalOnStartup', 'title', 'promptToStartup'];

var XTerminalElementImpl = (function (_HTMLElement) {
	_inherits(XTerminalElementImpl, _HTMLElement);

	function XTerminalElementImpl() {
		_classCallCheck(this, XTerminalElementImpl);

		_get(Object.getPrototypeOf(XTerminalElementImpl.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(XTerminalElementImpl, [{
		key: 'initialize',
		value: _asyncToGenerator(function* (model) {
			var _this = this;

			this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;
			this.model = model;
			this.model.element = this;
			this.disposables = new _atom.CompositeDisposable();
			this.topDiv = document.createElement('div');
			this.topDiv.classList.add('x-terminal-top-div');
			this.appendChild(this.topDiv);
			this.mainDiv = document.createElement('div');
			this.mainDiv.classList.add('x-terminal-main-div');
			this.appendChild(this.mainDiv);
			this.menuDiv = document.createElement('div');
			this.menuDiv.classList.add('x-terminal-menu-div');
			this.mainDiv.appendChild(this.menuDiv);
			this.terminalDiv = document.createElement('div');
			this.terminalDiv.classList.add('x-terminal-term-container');
			this.mainDiv.appendChild(this.terminalDiv);
			this.atomXtermProfileMenuElement = new _profileMenuElement.XTerminalProfileMenuElement();
			this.hoveredLink = null;
			this.pendingTerminalProfileOptions = {};
			this.mainDivContentRect = null;
			this.terminalDivInitiallyVisible = false;
			this.isInitialized = false;
			var resolveInit = undefined,
			    rejectInit = undefined;
			this.initializedPromise = new Promise(function (resolve, reject) {
				resolveInit = resolve;
				rejectInit = reject;
			});
			try {
				// Always wait for the model to finish initializing before proceeding.
				yield this.model.initializedPromise;
				this.setAttribute('session-id', this.model.getSessionId());
				yield this.atomXtermProfileMenuElement.initialize(new _profileMenuModel.XTerminalProfileMenuModel(this.model));
				this.menuDiv.append(this.atomXtermProfileMenuElement);
				// An element resize detector is used to check when this element is
				// resized due to the pane resizing or due to the entire window
				// resizing.
				this.mainDivResizeObserver = new ResizeObserver(function (entries) {
					var lastEntry = entries.pop();
					_this.mainDivContentRect = lastEntry.contentRect;
					_this.refitTerminal();
				});
				this.mainDivResizeObserver.observe(this.mainDiv);
				this.disposables.add(new _atom.Disposable(function () {
					_this.mainDivResizeObserver.disconnect();
					_this.mainDivResizeObserver = null;
				}));
				// Add an IntersectionObserver in order to apply new options and
				// refit as soon as the terminal is visible.
				this.terminalDivIntersectionObserver = new IntersectionObserver(_asyncToGenerator(function* (entries) {
					var lastEntry = entries.pop();
					if (lastEntry.intersectionRatio === 1.0) {
						_this.terminalDivInitiallyVisible = true;
						try {
							yield _this.createTerminal();
							_this.applyPendingTerminalProfileOptions();
							resolveInit();
						} catch (ex) {
							rejectInit(ex);
						}
						// Remove observer once visible
						_this.terminalDivIntersectionObserver.disconnect();
						_this.terminalDivIntersectionObserver = null;
					}
				}), {
					root: this,
					threshold: 1.0
				});
				this.terminalDivIntersectionObserver.observe(this.terminalDiv);
				this.disposables.add(new _atom.Disposable(function () {
					if (_this.terminalDivIntersectionObserver) {
						_this.terminalDivIntersectionObserver.disconnect();
					}
				}));
				// Add event handler for increasing/decreasing the font when
				// holding 'ctrl' and moving the mouse wheel up or down.
				this.terminalDiv.addEventListener('wheel', function (wheelEvent) {
					if (!wheelEvent.ctrlKey || !atom.config.get('editor.zoomFontWhenCtrlScrolling')) {
						return;
					}

					var fontSize = _this.model.profile.fontSize + (wheelEvent.deltaY < 0 ? 1 : -1);
					if (fontSize < _config.configDefaults.minimumFontSize) {
						fontSize = _config.configDefaults.minimumFontSize;
					} else if (fontSize > _config.configDefaults.maximumFontSize) {
						fontSize = _config.configDefaults.maximumFontSize;
					}
					_this.model.applyProfileChanges({ fontSize: fontSize });
					wheelEvent.stopPropagation();
				}, { capture: true });
			} catch (ex) {
				rejectInit(ex);
				throw ex;
			}
			this.isInitialized = true;
		})
	}, {
		key: 'destroy',
		value: function destroy() {
			this.atomXtermProfileMenuElement.destroy();
			if (this.ptyProcess) {
				this.ptyProcess.kill();
			}
			if (this.terminal) {
				this.terminal.dispose();
			}
			this.disposables.dispose();
		}
	}, {
		key: 'getShellCommand',
		value: function getShellCommand() {
			return this.model.profile.command;
		}
	}, {
		key: 'getArgs',
		value: function getArgs() {
			var args = this.model.profile.args;
			if (!Array.isArray(args)) {
				throw new Error('Arguments set are not an array.');
			}
			return args;
		}
	}, {
		key: 'getTermType',
		value: function getTermType() {
			return this.model.profile.name;
		}
	}, {
		key: 'checkPathIsDirectory',
		value: _asyncToGenerator(function* (path) {
			if (path) {
				try {
					var stats = yield _fsExtra2['default'].stat(path);
					if (stats && stats.isDirectory()) {
						return true;
					}
				} catch (err) {}
			}

			return false;
		})
	}, {
		key: 'getCwd',
		value: _asyncToGenerator(function* () {
			var cwd = this.model.profile.cwd;
			if (yield this.checkPathIsDirectory(cwd)) {
				return cwd;
			}

			cwd = this.model.getPath();
			if (yield this.checkPathIsDirectory(cwd)) {
				return cwd;
			}

			// If the cwd from the model was invalid, reset it to null.
			this.model.cwd = null;
			cwd = this.profilesSingleton.getBaseProfile.cwd;
			if (yield this.checkPathIsDirectory(cwd)) {
				this.model.cwd = cwd;
				return cwd;
			}

			return null;
		})
	}, {
		key: 'getEnv',
		value: function getEnv() {
			var env = this.model.profile.env;
			if (!env) {
				env = _extends({}, process.env);
			}
			if (typeof env !== 'object' || Array.isArray(env)) {
				throw new Error('Environment set is not an object.');
			}
			var setEnv = this.model.profile.setEnv;
			var deleteEnv = this.model.profile.deleteEnv;
			for (var key in setEnv) {
				env[key] = setEnv[key];
			}
			for (var key of deleteEnv) {
				delete env[key];
			}
			return env;
		}
	}, {
		key: 'getEncoding',
		value: function getEncoding() {
			return this.model.profile.encoding;
		}
	}, {
		key: 'leaveOpenAfterExit',
		value: function leaveOpenAfterExit() {
			return this.model.profile.leaveOpenAfterExit;
		}
	}, {
		key: 'isPromptToStartup',
		value: function isPromptToStartup() {
			return this.model.profile.promptToStartup;
		}
	}, {
		key: 'isPtyProcessRunning',
		value: function isPtyProcessRunning() {
			return this.ptyProcess && this.ptyProcessRunning;
		}
	}, {
		key: 'getTheme',
		value: function getTheme() {
			var profile = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

			var colors = {};
			for (var color in _config.COLORS) {
				var colorItem = _config.COLORS[color];
				colors[color] = profile[colorItem] || this.model.profile[colorItem];
			}
			// themes modified from https://github.com/bus-stop/terminus/tree/master/styles/themes
			switch (profile.theme || this.model.profile.theme) {
				case 'Atom Dark':
					colors.background = '#1d1f21';
					colors.foreground = '#c5c8c6';
					colors.selection = '#999999';
					colors.cursor = '#ffffff';
					break;
				case 'Atom Light':
					colors.background = '#ffffff';
					colors.foreground = '#555555';
					colors.selection = '#afc4da';
					colors.cursor = '#000000';
					break;
				case 'Base16 Tomorrow Dark':
					colors.background = '#1d1f21';
					colors.foreground = '#c5c8c6';
					colors.selection = '#b4b7b4';
					// colors.selectionForeground = '#e0e0e0'
					colors.cursor = '#ffffff';
					break;
				case 'Base16 Tomorrow Light':
					colors.background = '#ffffff';
					colors.foreground = '#1d1f21';
					colors.selection = '#282a2e';
					// colors.selectionForeground = '#e0e0e0'
					colors.cursor = '#1d1f21';
					break;
				case 'Christmas':
					colors.background = '#0c0047';
					colors.foreground = '#f81705';
					colors.selection = '#298f16';
					colors.cursor = '#009f59';
					break;
				case 'City Lights':
					colors.background = '#181d23';
					colors.foreground = '#666d81';
					colors.selection = '#2a2f38';
					// colors.selectionForeground = '#b7c5d3'
					colors.cursor = '#528bff';
					break;
				case 'Dracula':
					colors.background = '#1e1f29';
					colors.foreground = 'white';
					colors.selection = '#44475a';
					colors.cursor = '#999999';
					break;
				case 'Grass':
					colors.background = 'rgb(19, 119, 61)';
					colors.foreground = 'rgb(255, 240, 165)';
					colors.selection = 'rgba(182, 73, 38, .99)';
					colors.cursor = 'rgb(142, 40, 0)';
					break;
				case 'Homebrew':
					colors.background = '#000000';
					colors.foreground = 'rgb(41, 254, 20)';
					colors.selection = 'rgba(7, 30, 155, .99)';
					colors.cursor = 'rgb(55, 254, 38)';
					break;
				case 'Inverse':
					colors.background = '#ffffff';
					colors.foreground = '#000000';
					colors.selection = 'rgba(178, 215, 255, .99)';
					colors.cursor = 'rgb(146, 146, 146)';
					break;
				case 'Linux':
					colors.background = '#000000';
					colors.foreground = 'rgb(230, 230, 230)';
					colors.selection = 'rgba(155, 30, 7, .99)';
					colors.cursor = 'rgb(200, 20, 25)';
					break;
				case 'Man Page':
					colors.background = 'rgb(254, 244, 156)';
					colors.foreground = 'black';
					colors.selection = 'rgba(178, 215, 255, .99)';
					colors.cursor = 'rgb(146, 146, 146)';
					break;
				case 'Novel':
					colors.background = 'rgb(223, 219, 196)';
					colors.foreground = 'rgb(77, 47, 46)';
					colors.selection = 'rgba(155, 153, 122, .99)';
					colors.cursor = 'rgb(115, 99, 89)';
					break;
				case 'Ocean':
					colors.background = 'rgb(44, 102, 201)';
					colors.foreground = 'white';
					colors.selection = 'rgba(41, 134, 255, .99)';
					colors.cursor = 'rgb(146, 146, 146)';
					break;
				case 'One Dark':
					colors.background = '#282c34';
					colors.foreground = '#abb2bf';
					colors.selection = '#9196a1';
					colors.cursor = '#528bff';
					break;
				case 'One Light':
					colors.background = 'hsl(230, 1%, 98%)';
					colors.foreground = 'hsl(230, 8%, 24%)';
					colors.selection = 'hsl(230, 1%, 90%)';
					colors.cursor = 'hsl(230, 100%, 66%)';
					break;
				case 'Predawn':
					colors.background = '#282828';
					colors.foreground = '#f1f1f1';
					colors.selection = 'rgba(255,255,255,0.25)';
					colors.cursor = '#f18260';
					break;
				case 'Pro':
					colors.background = '#000000';
					colors.foreground = 'rgb(244, 244, 244)';
					colors.selection = 'rgba(82, 82, 82, .99)';
					colors.cursor = 'rgb(96, 96, 96)';
					break;
				case 'Red Sands':
					colors.background = 'rgb(143, 53, 39)';
					colors.foreground = 'rgb(215, 201, 167)';
					colors.selection = 'rgba(60, 25, 22, .99)';
					colors.cursor = 'white';
					break;
				case 'Red':
					colors.background = '#000000';
					colors.foreground = 'rgb(255, 38, 14)';
					colors.selection = 'rgba(7, 30, 155, .99)';
					colors.cursor = 'rgb(255, 38, 14)';
					break;
				case 'Silver Aerogel':
					colors.background = 'rgb(146, 146, 146)';
					colors.foreground = '#000000';
					colors.selection = 'rgba(120, 123, 156, .99)';
					colors.cursor = 'rgb(224, 224, 224)';
					break;
				case 'Solarized Dark':
					colors.background = '#042029';
					colors.foreground = '#708284';
					colors.selection = '#839496';
					colors.cursor = '#819090';
					break;
				case 'Solarized Light':
					colors.background = '#fdf6e3';
					colors.foreground = '#657a81';
					colors.selection = '#ece7d5';
					colors.cursor = '#586e75';
					break;
				case 'Solid Colors':
					colors.background = 'rgb(120, 132, 151)';
					colors.foreground = '#000000';
					colors.selection = 'rgba(178, 215, 255, .99)';
					colors.cursor = '#ffffff';
					break;
				case 'Standard':
					{
						var root = getComputedStyle(document.documentElement);
						colors.background = root.getPropertyValue('--standard-app-background-color');
						colors.foreground = root.getPropertyValue('--standard-text-color');
						colors.selection = root.getPropertyValue('--standard-background-color-selected');
						colors.cursor = root.getPropertyValue('--standard-text-color-highlight');
						break;
					}
			}

			return colors;
		}
	}, {
		key: 'getXtermOptions',
		value: function getXtermOptions() {
			var xtermOptions = _extends({
				cursorBlink: true
			}, this.model.profile.xtermOptions);
			xtermOptions.fontSize = this.model.profile.fontSize;
			xtermOptions.fontFamily = this.model.profile.fontFamily;
			xtermOptions.theme = this.getTheme(this.model.profile);
			// NOTE: The cloning is needed because the Terminal class modifies the
			// options passed to it.
			return this.profilesSingleton.deepClone(xtermOptions);
		}
	}, {
		key: 'setMainBackgroundColor',
		value: function setMainBackgroundColor() {
			var xtermOptions = this.getXtermOptions();
			if (xtermOptions.theme && xtermOptions.theme.background) {
				this.style.backgroundColor = xtermOptions.theme.background;
			} else {
				this.style.backgroundColor = '#000000';
			}
		}
	}, {
		key: 'createTerminal',
		value: _asyncToGenerator(function* () {
			var _this2 = this;

			// Attach terminal emulator to this element and refit.
			this.setMainBackgroundColor();
			this.terminal = new _xterm.Terminal(this.getXtermOptions());
			this.fitAddon = new _xtermAddonFit.FitAddon();
			this.terminal.loadAddon(this.fitAddon);
			if (this.model.profile.webLinks) {
				this.terminal.loadAddon(new _xtermAddonWebLinks.WebLinksAddon(function (e, uri) {
					_electron.shell.openExternal(uri);
				}));
			}
			this.terminal.open(this.terminalDiv);
			if (this.model.profile.webgl) {
				this.terminal.loadAddon(new _xtermAddonWebgl.WebglAddon());
			}
			this.terminal.loadAddon(new _xtermAddonLigatures.LigaturesAddon());
			this.ptyProcessCols = 80;
			this.ptyProcessRows = 25;
			this.refitTerminal();
			this.ptyProcess = null;
			this.ptyProcessRunning = false;
			this.disposables.add(this.terminal.onData(function (data) {
				if (_this2.isPtyProcessRunning()) {
					_this2.ptyProcess.write(data);
				}
			}));
			this.disposables.add(this.terminal.onSelectionChange(function () {
				if (_this2.model.profile.copyOnSelect) {
					var text = _this2.terminal.getSelection();
					if (text) {
						var rawLines = text.split(/\r?\n/g);
						var lines = rawLines.map(function (line) {
							return line.replace(/\s/g, ' ').trimRight();
						});
						text = lines.join('\n');
						atom.clipboard.write(text);
					}
				}
			}));
			this.disposables.add(this.profilesSingleton.onDidResetBaseProfile(function (baseProfile) {
				var frontEndSettings = {};
				for (var data of _config.CONFIG_DATA) {
					if (!data.profileKey) continue;
					if (data.terminalFrontEnd) {
						frontEndSettings[data.profileKey] = baseProfile[data.profileKey];
					}
				}
				var profileChanges = _this2.profilesSingleton.diffProfiles(_this2.model.getProfile(),
				// Only allow changes to settings related to the terminal front end
				// to be applied to existing terminals.
				frontEndSettings);
				_this2.model.applyProfileChanges(profileChanges);
			}));
			if (this.isPromptToStartup()) {
				this.promptToStartup();
			} else {
				yield this.restartPtyProcess();
			}
		})
	}, {
		key: 'showNotification',
		value: function showNotification(message, infoType) {
			var _this3 = this;

			var restartButtonText = arguments.length <= 2 || arguments[2] === undefined ? 'Restart' : arguments[2];

			var messageDiv = document.createElement('div');
			var restartButton = document.createElement('button');
			restartButton.classList.add('btn');
			restartButton.appendChild(document.createTextNode(restartButtonText));
			restartButton.addEventListener('click', function (event) {
				_this3.restartPtyProcess();
			}, { passive: true });
			restartButton.classList.add('btn-' + infoType);
			restartButton.classList.add('x-terminal-restart-btn');
			messageDiv.classList.add('x-terminal-notice-' + infoType);
			messageDiv.appendChild(document.createTextNode(message));
			messageDiv.appendChild(restartButton);
			this.topDiv.innerHTML = '';
			this.topDiv.appendChild(messageDiv);
			if (infoType === 'success') {
				atom.notifications.addSuccess(message);
			} else if (infoType === 'error') {
				atom.notifications.addError(message);
			} else if (infoType === 'warning') {
				atom.notifications.addWarning(message);
			} else if (infoType === 'info') {
				atom.notifications.addInfo(message);
			} else {
				throw new Error('Unknown info type: ' + infoType);
			}
		}
	}, {
		key: 'promptToStartup',
		value: _asyncToGenerator(function* () {
			var message = undefined;
			if (this.model.profile.title === null) {
				var command = [this.getShellCommand()];
				command.push.apply(command, _toConsumableArray(this.getArgs()));
				message = 'New command ' + JSON.stringify(command) + ' ready to start.';
			} else {
				message = 'New command for profile ' + this.model.profile.title + ' ready to start.';
			}
			this.showNotification(message, 'info', 'Start');
		})
	}, {
		key: 'restartPtyProcess',
		value: _asyncToGenerator(function* () {
			var _this4 = this;

			var cwd = yield this.getCwd();
			if (this.ptyProcessRunning) {
				this.ptyProcess.removeAllListeners('exit');
				this.ptyProcess.kill();
			}
			// Reset the terminal.
			this.atomXtermProfileMenuElement.hideProfileMenu();
			this.terminal.reset();

			// Setup pty process.
			this.ptyProcessCommand = this.getShellCommand();
			this.ptyProcessArgs = this.getArgs();
			var name = this.getTermType();
			var env = this.getEnv();
			var encoding = this.getEncoding();

			// Attach pty process to terminal.
			// NOTE: This must be done after the terminal is attached to the
			// parent element and refitted.
			this.ptyProcessOptions = {
				name: name,
				cwd: cwd,
				env: env
			};
			if (encoding) {
				// There's some issue if 'encoding=null' is passed in the options,
				// therefore, only set it if there's an actual encoding to set.
				this.ptyProcessOptions.encoding = encoding;
			}

			this.ptyProcessOptions.cols = this.ptyProcessCols;
			this.ptyProcessOptions.rows = this.ptyProcessRows;
			this.ptyProcess = null;
			this.ptyProcessRunning = false;
			try {
				this.ptyProcess = (0, _nodePtyPrebuiltMultiarch.spawn)(this.ptyProcessCommand, this.ptyProcessArgs, this.ptyProcessOptions);

				if (this.ptyProcess) {
					this.ptyProcessRunning = true;
					this.ptyProcess.on('data', function (data) {
						var oldTitle = _this4.model.title;
						if (_this4.model.profile.title !== null) {
							_this4.model.title = _this4.model.profile.title;
						} else if (process.platform !== 'win32') {
							_this4.model.title = _this4.ptyProcess.process;
						}
						if (oldTitle !== _this4.model.title) {
							_this4.model.emitter.emit('did-change-title', _this4.model.title);
						}
						_this4.terminal.write(data);
						_this4.model.handleNewDataArrival();
					});
					this.ptyProcess.on('exit', function (code, signal) {
						_this4.ptyProcessRunning = false;
						if (!_this4.leaveOpenAfterExit()) {
							_this4.model.exit();
						} else {
							if (code === 0) {
								_this4.showNotification('The terminal process has finished successfully.', 'success');
							} else {
								_this4.showNotification('The terminal process has exited with failure code \'' + code + '\'.', 'error');
							}
						}
					});
					this.topDiv.innerHTML = '';
				}
			} catch (err) {
				var message = 'Launching \'' + this.ptyProcessCommand + '\' raised the following error: ' + err.message;
				if (err.message.startsWith('File not found:')) {
					message = 'Could not find command \'' + this.ptyProcessCommand + '\'.';
				}
				this.showNotification(message, 'error');
			}
		})
	}, {
		key: 'clear',
		value: function clear() {
			if (this.terminal) {
				return this.terminal.clear();
			}
		}
	}, {
		key: 'applyPendingTerminalProfileOptions',
		value: function applyPendingTerminalProfileOptions() {
			var _this5 = this;

			// For any changes involving the xterm.js Terminal object, only apply them
			// when the terminal is visible.
			if (this.terminalDivInitiallyVisible) {
				var xtermOptions = this.pendingTerminalProfileOptions.xtermOptions || {};
				// NOTE: For legacy reasons, the font size is defined from the 'fontSize'
				// key outside of any defined xterm.js Terminal options.
				delete xtermOptions.fontSize;
				if ('fontSize' in this.pendingTerminalProfileOptions) {
					xtermOptions.fontSize = this.pendingTerminalProfileOptions.fontSize;
					delete this.pendingTerminalProfileOptions.fontSize;
				}
				delete xtermOptions.fontFamily;
				if ('fontFamily' in this.pendingTerminalProfileOptions) {
					xtermOptions.fontFamily = this.pendingTerminalProfileOptions.fontFamily;
					delete this.pendingTerminalProfileOptions.fontFamily;
				}
				delete xtermOptions.theme;
				if ('theme' in this.pendingTerminalProfileOptions || Object.values(_config.COLORS).some(function (c) {
					return c in _this5.pendingTerminalProfileOptions;
				})) {
					xtermOptions.theme = this.getTheme(this.pendingTerminalProfileOptions);
					delete this.pendingTerminalProfileOptions.theme;
					Object.values(_config.COLORS).forEach(function (c) {
						return delete _this5.pendingTerminalProfileOptions[c];
					});
				}
				this.setMainBackgroundColor();
				for (var key of Object.keys(xtermOptions)) {
					this.terminal.setOption(key, xtermOptions[key]);
				}
				delete this.pendingTerminalProfileOptions.xtermOptions;

				// Restart the pty process if changes to the pty process settings are
				// being made.
				// NOTE: When applying new pty settings, the terminal still needs to be
				// visible.
				var a = new Set(Object.keys(this.pendingTerminalProfileOptions));
				var intersection = new Set([].concat(_toConsumableArray(a)).filter(function (x) {
					return PTY_PROCESS_OPTIONS.has(x);
				}));
				if (intersection.size !== 0) {
					this.restartPtyProcess();
					for (var key of intersection) {
						delete this.pendingTerminalProfileOptions[key];
					}
				}

				this.refitTerminal();
			}

			// x-terminal specific options can be removed since at this point they
			// should already be applied in the terminal's profile.
			for (var key of X_TERMINAL_OPTIONS) {
				delete this.pendingTerminalProfileOptions[key];
			}
		}
	}, {
		key: 'refitTerminal',
		value: function refitTerminal() {
			// Only refit the terminal when it is completely visible.
			if (this.terminalDivInitiallyVisible && this.mainDivContentRect && this.mainDivContentRect.width > 0 && this.mainDivContentRect.height > 0) {
				this.fitAddon.fit();
				var geometry = this.fitAddon.proposeDimensions();
				if (geometry && this.isPtyProcessRunning()) {
					// Resize pty process
					if (this.ptyProcessCols !== geometry.cols || this.ptyProcessRows !== geometry.rows) {
						this.ptyProcess.resize(geometry.cols, geometry.rows);
						this.ptyProcessCols = geometry.cols;
						this.ptyProcessRows = geometry.rows;
					}
				}
			}
		}
	}, {
		key: 'focusOnTerminal',
		value: function focusOnTerminal(double) {
			if (this.terminal) {
				this.model.setActive();
				this.terminal.focus();
				if (double) {
					// second focus will send command to pty
					this.terminal.focus();
				}
			}
		}
	}, {
		key: 'toggleProfileMenu',
		value: _asyncToGenerator(function* () {
			// The profile menu needs to be initialized before it can be toggled.
			yield this.atomXtermProfileMenuElement.initializedPromise;
			this.atomXtermProfileMenuElement.toggleProfileMenu();
		})
	}, {
		key: 'hideTerminal',
		value: function hideTerminal() {
			this.terminalDiv.style.visibility = 'hidden';
		}
	}, {
		key: 'showTerminal',
		value: function showTerminal() {
			this.terminalDiv.style.visibility = 'visible';
		}
	}, {
		key: 'queueNewProfileChanges',
		value: function queueNewProfileChanges(profileChanges) {
			this.pendingTerminalProfileOptions = _extends({}, this.pendingTerminalProfileOptions, profileChanges);
			this.applyPendingTerminalProfileOptions();
		}
	}]);

	return XTerminalElementImpl;
})(HTMLElement);

var XTerminalElement = document.registerElement('x-terminal', {
	prototype: XTerminalElementImpl.prototype
});

exports.XTerminalElement = XTerminalElement;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL2VsZW1lbnQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBcUJnRCxNQUFNOzt3Q0FDcEIsNkJBQTZCOztxQkFDdEMsT0FBTzs7NkJBQ1AsaUJBQWlCOztrQ0FDWix1QkFBdUI7OytCQUMxQixtQkFBbUI7O21DQUNmLHVCQUF1Qjs7d0JBQ2hDLFVBQVU7O3NCQUVvQixVQUFVOztrQ0FDbEIsd0JBQXdCOztnQ0FDMUIsc0JBQXNCOzt3QkFDckIsWUFBWTs7dUJBRXhDLFVBQVU7Ozs7QUFFekIsSUFBTSxtQkFBbUIsR0FBRyxJQUFJLEdBQUcsQ0FBQyxDQUNuQyxTQUFTLEVBQ1QsTUFBTSxFQUNOLE1BQU0sRUFDTixLQUFLLEVBQ0wsS0FBSyxFQUNMLFFBQVEsRUFDUixXQUFXLEVBQ1gsVUFBVSxDQUNWLENBQUMsQ0FBQTtBQUNGLElBQU0sa0JBQWtCLEdBQUcsQ0FDMUIsb0JBQW9CLEVBQ3BCLDJCQUEyQixFQUMzQixPQUFPLEVBQ1AsaUJBQWlCLENBQ2pCLENBQUE7O0lBRUssb0JBQW9CO1dBQXBCLG9CQUFvQjs7VUFBcEIsb0JBQW9CO3dCQUFwQixvQkFBb0I7OzZCQUFwQixvQkFBb0I7OztjQUFwQixvQkFBb0I7OzJCQUNSLFdBQUMsS0FBSyxFQUFFOzs7QUFDeEIsT0FBSSxDQUFDLGlCQUFpQixHQUFHLHFDQUEyQixRQUFRLENBQUE7QUFDNUQsT0FBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUE7QUFDbEIsT0FBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFBO0FBQ3pCLE9BQUksQ0FBQyxXQUFXLEdBQUcsK0JBQXlCLENBQUE7QUFDNUMsT0FBSSxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzNDLE9BQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsQ0FBQyxDQUFBO0FBQy9DLE9BQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQzdCLE9BQUksQ0FBQyxPQUFPLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUM1QyxPQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMscUJBQXFCLENBQUMsQ0FBQTtBQUNqRCxPQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUM5QixPQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDNUMsT0FBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHFCQUFxQixDQUFDLENBQUE7QUFDakQsT0FBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ3RDLE9BQUksQ0FBQyxXQUFXLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUNoRCxPQUFJLENBQUMsV0FBVyxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsMkJBQTJCLENBQUMsQ0FBQTtBQUMzRCxPQUFJLENBQUMsT0FBTyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDMUMsT0FBSSxDQUFDLDJCQUEyQixHQUFHLHFEQUFpQyxDQUFBO0FBQ3BFLE9BQUksQ0FBQyxXQUFXLEdBQUcsSUFBSSxDQUFBO0FBQ3ZCLE9BQUksQ0FBQyw2QkFBNkIsR0FBRyxFQUFFLENBQUE7QUFDdkMsT0FBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQTtBQUM5QixPQUFJLENBQUMsMkJBQTJCLEdBQUcsS0FBSyxDQUFBO0FBQ3hDLE9BQUksQ0FBQyxhQUFhLEdBQUcsS0FBSyxDQUFBO0FBQzFCLE9BQUksV0FBVyxZQUFBO09BQUUsVUFBVSxZQUFBLENBQUE7QUFDM0IsT0FBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSztBQUMxRCxlQUFXLEdBQUcsT0FBTyxDQUFBO0FBQ3JCLGNBQVUsR0FBRyxNQUFNLENBQUE7SUFDbkIsQ0FBQyxDQUFBO0FBQ0YsT0FBSTs7QUFFSCxVQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsa0JBQWtCLENBQUE7QUFDbkMsUUFBSSxDQUFDLFlBQVksQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQyxZQUFZLEVBQUUsQ0FBQyxDQUFBO0FBQzFELFVBQU0sSUFBSSxDQUFDLDJCQUEyQixDQUFDLFVBQVUsQ0FBQyxnREFBOEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLENBQUE7QUFDNUYsUUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLDJCQUEyQixDQUFDLENBQUE7Ozs7QUFJckQsUUFBSSxDQUFDLHFCQUFxQixHQUFHLElBQUksY0FBYyxDQUFDLFVBQUEsT0FBTyxFQUFJO0FBQzFELFNBQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxHQUFHLEVBQUUsQ0FBQTtBQUMvQixXQUFLLGtCQUFrQixHQUFHLFNBQVMsQ0FBQyxXQUFXLENBQUE7QUFDL0MsV0FBSyxhQUFhLEVBQUUsQ0FBQTtLQUNwQixDQUFDLENBQUE7QUFDRixRQUFJLENBQUMscUJBQXFCLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUNoRCxRQUFJLENBQUMsV0FBVyxDQUFDLEdBQUcsQ0FBQyxxQkFBZSxZQUFNO0FBQ3pDLFdBQUsscUJBQXFCLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDdkMsV0FBSyxxQkFBcUIsR0FBRyxJQUFJLENBQUE7S0FDakMsQ0FBQyxDQUFDLENBQUE7OztBQUdILFFBQUksQ0FBQywrQkFBK0IsR0FBRyxJQUFJLG9CQUFvQixtQkFBQyxXQUFNLE9BQU8sRUFBSTtBQUNoRixTQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsR0FBRyxFQUFFLENBQUE7QUFDL0IsU0FBSSxTQUFTLENBQUMsaUJBQWlCLEtBQUssR0FBRyxFQUFFO0FBQ3hDLFlBQUssMkJBQTJCLEdBQUcsSUFBSSxDQUFBO0FBQ3ZDLFVBQUk7QUFDSCxhQUFNLE1BQUssY0FBYyxFQUFFLENBQUE7QUFDM0IsYUFBSyxrQ0FBa0MsRUFBRSxDQUFBO0FBQ3pDLGtCQUFXLEVBQUUsQ0FBQTtPQUNiLENBQUMsT0FBTyxFQUFFLEVBQUU7QUFDWixpQkFBVSxDQUFDLEVBQUUsQ0FBQyxDQUFBO09BQ2Q7O0FBRUQsWUFBSywrQkFBK0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUNqRCxZQUFLLCtCQUErQixHQUFHLElBQUksQ0FBQTtNQUMzQztLQUNELEdBQUU7QUFDRixTQUFJLEVBQUUsSUFBSTtBQUNWLGNBQVMsRUFBRSxHQUFHO0tBQ2QsQ0FBQyxDQUFBO0FBQ0YsUUFBSSxDQUFDLCtCQUErQixDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDOUQsUUFBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMscUJBQWUsWUFBTTtBQUN6QyxTQUFJLE1BQUssK0JBQStCLEVBQUU7QUFDekMsWUFBSywrQkFBK0IsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtNQUNqRDtLQUNELENBQUMsQ0FBQyxDQUFBOzs7QUFHSCxRQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixDQUNoQyxPQUFPLEVBQ1AsVUFBQyxVQUFVLEVBQUs7QUFDZixTQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGtDQUFrQyxDQUFDLEVBQUU7QUFDaEYsYUFBTTtNQUNOOztBQUVELFNBQUksUUFBUSxHQUFHLE1BQUssS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLElBQUksVUFBVSxDQUFDLE1BQU0sR0FBRyxDQUFDLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFBLEFBQUMsQ0FBQTtBQUM3RSxTQUFJLFFBQVEsR0FBRyx1QkFBZSxlQUFlLEVBQUU7QUFDOUMsY0FBUSxHQUFHLHVCQUFlLGVBQWUsQ0FBQTtNQUN6QyxNQUFNLElBQUksUUFBUSxHQUFHLHVCQUFlLGVBQWUsRUFBRTtBQUNyRCxjQUFRLEdBQUcsdUJBQWUsZUFBZSxDQUFBO01BQ3pDO0FBQ0QsV0FBSyxLQUFLLENBQUMsbUJBQW1CLENBQUMsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQTtBQUN0RCxlQUFVLENBQUMsZUFBZSxFQUFFLENBQUE7S0FDNUIsRUFDRCxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FDakIsQ0FBQTtJQUNELENBQUMsT0FBTyxFQUFFLEVBQUU7QUFDWixjQUFVLENBQUMsRUFBRSxDQUFDLENBQUE7QUFDZCxVQUFNLEVBQUUsQ0FBQTtJQUNSO0FBQ0QsT0FBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUE7R0FDekI7OztTQUVPLG1CQUFHO0FBQ1YsT0FBSSxDQUFDLDJCQUEyQixDQUFDLE9BQU8sRUFBRSxDQUFBO0FBQzFDLE9BQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtBQUNwQixRQUFJLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFBO0lBQ3RCO0FBQ0QsT0FBSSxJQUFJLENBQUMsUUFBUSxFQUFFO0FBQ2xCLFFBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxFQUFFLENBQUE7SUFDdkI7QUFDRCxPQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFBO0dBQzFCOzs7U0FFZSwyQkFBRztBQUNsQixVQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQTtHQUNqQzs7O1NBRU8sbUJBQUc7QUFDVixPQUFNLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUE7QUFDcEMsT0FBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDekIsVUFBTSxJQUFJLEtBQUssQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFBO0lBQ2xEO0FBQ0QsVUFBTyxJQUFJLENBQUE7R0FDWDs7O1NBRVcsdUJBQUc7QUFDZCxVQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQTtHQUM5Qjs7OzJCQUUwQixXQUFDLElBQUksRUFBRTtBQUNqQyxPQUFJLElBQUksRUFBRTtBQUNULFFBQUk7QUFDSCxTQUFNLEtBQUssR0FBRyxNQUFNLHFCQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUNqQyxTQUFJLEtBQUssSUFBSSxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUU7QUFDakMsYUFBTyxJQUFJLENBQUE7TUFDWDtLQUNELENBQUMsT0FBTyxHQUFHLEVBQUUsRUFBRTtJQUNoQjs7QUFFRCxVQUFPLEtBQUssQ0FBQTtHQUNaOzs7MkJBRVksYUFBRztBQUNmLE9BQUksR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQTtBQUNoQyxPQUFJLE1BQU0sSUFBSSxDQUFDLG9CQUFvQixDQUFDLEdBQUcsQ0FBQyxFQUFFO0FBQ3pDLFdBQU8sR0FBRyxDQUFBO0lBQ1Y7O0FBRUQsTUFBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxFQUFFLENBQUE7QUFDMUIsT0FBSSxNQUFNLElBQUksQ0FBQyxvQkFBb0IsQ0FBQyxHQUFHLENBQUMsRUFBRTtBQUN6QyxXQUFPLEdBQUcsQ0FBQTtJQUNWOzs7QUFHRCxPQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUE7QUFDckIsTUFBRyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFBO0FBQy9DLE9BQUksTUFBTSxJQUFJLENBQUMsb0JBQW9CLENBQUMsR0FBRyxDQUFDLEVBQUU7QUFDekMsUUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFBO0FBQ3BCLFdBQU8sR0FBRyxDQUFBO0lBQ1Y7O0FBRUQsVUFBTyxJQUFJLENBQUE7R0FDWDs7O1NBRU0sa0JBQUc7QUFDVCxPQUFJLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUE7QUFDaEMsT0FBSSxDQUFDLEdBQUcsRUFBRTtBQUNULE9BQUcsZ0JBQVEsT0FBTyxDQUFDLEdBQUcsQ0FBRSxDQUFBO0lBQ3hCO0FBQ0QsT0FBSSxPQUFPLEdBQUcsS0FBSyxRQUFRLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxHQUFHLENBQUMsRUFBRTtBQUNsRCxVQUFNLElBQUksS0FBSyxDQUFDLG1DQUFtQyxDQUFDLENBQUE7SUFDcEQ7QUFDRCxPQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUE7QUFDeEMsT0FBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFBO0FBQzlDLFFBQUssSUFBTSxHQUFHLElBQUksTUFBTSxFQUFFO0FBQ3pCLE9BQUcsQ0FBQyxHQUFHLENBQUMsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDdEI7QUFDRCxRQUFLLElBQU0sR0FBRyxJQUFJLFNBQVMsRUFBRTtBQUM1QixXQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUNmO0FBQ0QsVUFBTyxHQUFHLENBQUE7R0FDVjs7O1NBRVcsdUJBQUc7QUFDZCxVQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQTtHQUNsQzs7O1NBRWtCLDhCQUFHO0FBQ3JCLFVBQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsa0JBQWtCLENBQUE7R0FDNUM7OztTQUVpQiw2QkFBRztBQUNwQixVQUFPLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLGVBQWUsQ0FBQTtHQUN6Qzs7O1NBRW1CLCtCQUFHO0FBQ3RCLFVBQVEsSUFBSSxDQUFDLFVBQVUsSUFBSSxJQUFJLENBQUMsaUJBQWlCLENBQUM7R0FDbEQ7OztTQUVRLG9CQUFlO09BQWQsT0FBTyx5REFBRyxFQUFFOztBQUNyQixPQUFNLE1BQU0sR0FBRyxFQUFFLENBQUE7QUFDakIsUUFBSyxJQUFNLEtBQUssb0JBQVk7QUFDM0IsUUFBTSxTQUFTLEdBQUcsZUFBTyxLQUFLLENBQUMsQ0FBQTtBQUMvQixVQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsT0FBTyxDQUFDLFNBQVMsQ0FBQyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0lBQ25FOztBQUVELFdBQVEsT0FBTyxDQUFDLEtBQUssSUFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxLQUFLO0FBQ2hELFNBQUssV0FBVztBQUNmLFdBQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO0FBQzdCLFdBQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO0FBQzdCLFdBQU0sQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFBO0FBQzVCLFdBQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFBO0FBQ3pCLFdBQUs7QUFBQSxBQUNOLFNBQUssWUFBWTtBQUNoQixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQTtBQUM1QixXQUFNLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQTtBQUN6QixXQUFLO0FBQUEsQUFDTixTQUFLLHNCQUFzQjtBQUMxQixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQTs7QUFFNUIsV0FBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUE7QUFDekIsV0FBSztBQUFBLEFBQ04sU0FBSyx1QkFBdUI7QUFDM0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUE7O0FBRTVCLFdBQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFBO0FBQ3pCLFdBQUs7QUFBQSxBQUNOLFNBQUssV0FBVztBQUNmLFdBQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO0FBQzdCLFdBQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO0FBQzdCLFdBQU0sQ0FBQyxTQUFTLEdBQUcsU0FBUyxDQUFBO0FBQzVCLFdBQU0sQ0FBQyxNQUFNLEdBQUcsU0FBUyxDQUFBO0FBQ3pCLFdBQUs7QUFBQSxBQUNOLFNBQUssYUFBYTtBQUNqQixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQTs7QUFFNUIsV0FBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUE7QUFDekIsV0FBSztBQUFBLEFBQ04sU0FBSyxTQUFTO0FBQ2IsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxPQUFPLENBQUE7QUFDM0IsV0FBTSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUE7QUFDNUIsV0FBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUE7QUFDekIsV0FBSztBQUFBLEFBQ04sU0FBSyxPQUFPO0FBQ1gsV0FBTSxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQTtBQUN0QyxXQUFNLENBQUMsVUFBVSxHQUFHLG9CQUFvQixDQUFBO0FBQ3hDLFdBQU0sQ0FBQyxTQUFTLEdBQUcsd0JBQXdCLENBQUE7QUFDM0MsV0FBTSxDQUFDLE1BQU0sR0FBRyxpQkFBaUIsQ0FBQTtBQUNqQyxXQUFLO0FBQUEsQUFDTixTQUFLLFVBQVU7QUFDZCxXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsVUFBVSxHQUFHLGtCQUFrQixDQUFBO0FBQ3RDLFdBQU0sQ0FBQyxTQUFTLEdBQUcsdUJBQXVCLENBQUE7QUFDMUMsV0FBTSxDQUFDLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQTtBQUNsQyxXQUFLO0FBQUEsQUFDTixTQUFLLFNBQVM7QUFDYixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsU0FBUyxHQUFHLDBCQUEwQixDQUFBO0FBQzdDLFdBQU0sQ0FBQyxNQUFNLEdBQUcsb0JBQW9CLENBQUE7QUFDcEMsV0FBSztBQUFBLEFBQ04sU0FBSyxPQUFPO0FBQ1gsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQTtBQUN4QyxXQUFNLENBQUMsU0FBUyxHQUFHLHVCQUF1QixDQUFBO0FBQzFDLFdBQU0sQ0FBQyxNQUFNLEdBQUcsa0JBQWtCLENBQUE7QUFDbEMsV0FBSztBQUFBLEFBQ04sU0FBSyxVQUFVO0FBQ2QsV0FBTSxDQUFDLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQTtBQUN4QyxXQUFNLENBQUMsVUFBVSxHQUFHLE9BQU8sQ0FBQTtBQUMzQixXQUFNLENBQUMsU0FBUyxHQUFHLDBCQUEwQixDQUFBO0FBQzdDLFdBQU0sQ0FBQyxNQUFNLEdBQUcsb0JBQW9CLENBQUE7QUFDcEMsV0FBSztBQUFBLEFBQ04sU0FBSyxPQUFPO0FBQ1gsV0FBTSxDQUFDLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQTtBQUN4QyxXQUFNLENBQUMsVUFBVSxHQUFHLGlCQUFpQixDQUFBO0FBQ3JDLFdBQU0sQ0FBQyxTQUFTLEdBQUcsMEJBQTBCLENBQUE7QUFDN0MsV0FBTSxDQUFDLE1BQU0sR0FBRyxrQkFBa0IsQ0FBQTtBQUNsQyxXQUFLO0FBQUEsQUFDTixTQUFLLE9BQU87QUFDWCxXQUFNLENBQUMsVUFBVSxHQUFHLG1CQUFtQixDQUFBO0FBQ3ZDLFdBQU0sQ0FBQyxVQUFVLEdBQUcsT0FBTyxDQUFBO0FBQzNCLFdBQU0sQ0FBQyxTQUFTLEdBQUcseUJBQXlCLENBQUE7QUFDNUMsV0FBTSxDQUFDLE1BQU0sR0FBRyxvQkFBb0IsQ0FBQTtBQUNwQyxXQUFLO0FBQUEsQUFDTixTQUFLLFVBQVU7QUFDZCxXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsU0FBUyxHQUFHLFNBQVMsQ0FBQTtBQUM1QixXQUFNLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQTtBQUN6QixXQUFLO0FBQUEsQUFDTixTQUFLLFdBQVc7QUFDZixXQUFNLENBQUMsVUFBVSxHQUFHLG1CQUFtQixDQUFBO0FBQ3ZDLFdBQU0sQ0FBQyxVQUFVLEdBQUcsbUJBQW1CLENBQUE7QUFDdkMsV0FBTSxDQUFDLFNBQVMsR0FBRyxtQkFBbUIsQ0FBQTtBQUN0QyxXQUFNLENBQUMsTUFBTSxHQUFHLHFCQUFxQixDQUFBO0FBQ3JDLFdBQUs7QUFBQSxBQUNOLFNBQUssU0FBUztBQUNiLFdBQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO0FBQzdCLFdBQU0sQ0FBQyxVQUFVLEdBQUcsU0FBUyxDQUFBO0FBQzdCLFdBQU0sQ0FBQyxTQUFTLEdBQUcsd0JBQXdCLENBQUE7QUFDM0MsV0FBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUE7QUFDekIsV0FBSztBQUFBLEFBQ04sU0FBSyxLQUFLO0FBQ1QsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQTtBQUN4QyxXQUFNLENBQUMsU0FBUyxHQUFHLHVCQUF1QixDQUFBO0FBQzFDLFdBQU0sQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUE7QUFDakMsV0FBSztBQUFBLEFBQ04sU0FBSyxXQUFXO0FBQ2YsV0FBTSxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQTtBQUN0QyxXQUFNLENBQUMsVUFBVSxHQUFHLG9CQUFvQixDQUFBO0FBQ3hDLFdBQU0sQ0FBQyxTQUFTLEdBQUcsdUJBQXVCLENBQUE7QUFDMUMsV0FBTSxDQUFDLE1BQU0sR0FBRyxPQUFPLENBQUE7QUFDdkIsV0FBSztBQUFBLEFBQ04sU0FBSyxLQUFLO0FBQ1QsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxrQkFBa0IsQ0FBQTtBQUN0QyxXQUFNLENBQUMsU0FBUyxHQUFHLHVCQUF1QixDQUFBO0FBQzFDLFdBQU0sQ0FBQyxNQUFNLEdBQUcsa0JBQWtCLENBQUE7QUFDbEMsV0FBSztBQUFBLEFBQ04sU0FBSyxnQkFBZ0I7QUFDcEIsV0FBTSxDQUFDLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQTtBQUN4QyxXQUFNLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtBQUM3QixXQUFNLENBQUMsU0FBUyxHQUFHLDBCQUEwQixDQUFBO0FBQzdDLFdBQU0sQ0FBQyxNQUFNLEdBQUcsb0JBQW9CLENBQUE7QUFDcEMsV0FBSztBQUFBLEFBQ04sU0FBSyxnQkFBZ0I7QUFDcEIsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUE7QUFDNUIsV0FBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUE7QUFDekIsV0FBSztBQUFBLEFBQ04sU0FBSyxpQkFBaUI7QUFDckIsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFNBQVMsR0FBRyxTQUFTLENBQUE7QUFDNUIsV0FBTSxDQUFDLE1BQU0sR0FBRyxTQUFTLENBQUE7QUFDekIsV0FBSztBQUFBLEFBQ04sU0FBSyxjQUFjO0FBQ2xCLFdBQU0sQ0FBQyxVQUFVLEdBQUcsb0JBQW9CLENBQUE7QUFDeEMsV0FBTSxDQUFDLFVBQVUsR0FBRyxTQUFTLENBQUE7QUFDN0IsV0FBTSxDQUFDLFNBQVMsR0FBRywwQkFBMEIsQ0FBQTtBQUM3QyxXQUFNLENBQUMsTUFBTSxHQUFHLFNBQVMsQ0FBQTtBQUN6QixXQUFLO0FBQUEsQUFDTixTQUFLLFVBQVU7QUFBRTtBQUNoQixVQUFNLElBQUksR0FBRyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUMsZUFBZSxDQUFDLENBQUE7QUFDdkQsWUFBTSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUNBQWlDLENBQUMsQ0FBQTtBQUM1RSxZQUFNLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxDQUFBO0FBQ2xFLFlBQU0sQ0FBQyxTQUFTLEdBQUcsSUFBSSxDQUFDLGdCQUFnQixDQUFDLHNDQUFzQyxDQUFDLENBQUE7QUFDaEYsWUFBTSxDQUFDLE1BQU0sR0FBRyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsaUNBQWlDLENBQUMsQ0FBQTtBQUN4RSxZQUFLO01BQ0w7QUFBQSxJQUNEOztBQUVELFVBQU8sTUFBTSxDQUFBO0dBQ2I7OztTQUVlLDJCQUFHO0FBQ2xCLE9BQU0sWUFBWTtBQUNqQixlQUFXLEVBQUUsSUFBSTtNQUNkLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FDbEMsQ0FBQTtBQUNELGVBQVksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFBO0FBQ25ELGVBQVksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFBO0FBQ3ZELGVBQVksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFBOzs7QUFHdEQsVUFBTyxJQUFJLENBQUMsaUJBQWlCLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxDQUFBO0dBQ3JEOzs7U0FFc0Isa0NBQUc7QUFDekIsT0FBTSxZQUFZLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFBO0FBQzNDLE9BQUksWUFBWSxDQUFDLEtBQUssSUFBSSxZQUFZLENBQUMsS0FBSyxDQUFDLFVBQVUsRUFBRTtBQUN4RCxRQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsR0FBRyxZQUFZLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQTtJQUMxRCxNQUFNO0FBQ04sUUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLEdBQUcsU0FBUyxDQUFBO0lBQ3RDO0dBQ0Q7OzsyQkFFb0IsYUFBRzs7OztBQUV2QixPQUFJLENBQUMsc0JBQXNCLEVBQUUsQ0FBQTtBQUM3QixPQUFJLENBQUMsUUFBUSxHQUFHLG9CQUFhLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQyxDQUFBO0FBQ3BELE9BQUksQ0FBQyxRQUFRLEdBQUcsNkJBQWMsQ0FBQTtBQUM5QixPQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDdEMsT0FBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUU7QUFDaEMsUUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFTLENBQUMsc0NBQWtCLFVBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBSztBQUFFLHFCQUFNLFlBQVksQ0FBQyxHQUFHLENBQUMsQ0FBQTtLQUFFLENBQUMsQ0FBQyxDQUFBO0lBQ25GO0FBQ0QsT0FBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQ3BDLE9BQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFO0FBQzdCLFFBQUksQ0FBQyxRQUFRLENBQUMsU0FBUyxDQUFDLGlDQUFnQixDQUFDLENBQUE7SUFDekM7QUFDRCxPQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyx5Q0FBb0IsQ0FBQyxDQUFBO0FBQzdDLE9BQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFBO0FBQ3hCLE9BQUksQ0FBQyxjQUFjLEdBQUcsRUFBRSxDQUFBO0FBQ3hCLE9BQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtBQUNwQixPQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQTtBQUN0QixPQUFJLENBQUMsaUJBQWlCLEdBQUcsS0FBSyxDQUFBO0FBQzlCLE9BQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFVBQUMsSUFBSSxFQUFLO0FBQ25ELFFBQUksT0FBSyxtQkFBbUIsRUFBRSxFQUFFO0FBQy9CLFlBQUssVUFBVSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsQ0FBQTtLQUMzQjtJQUNELENBQUMsQ0FBQyxDQUFBO0FBQ0gsT0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxZQUFNO0FBQzFELFFBQUksT0FBSyxLQUFLLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRTtBQUNwQyxTQUFJLElBQUksR0FBRyxPQUFLLFFBQVEsQ0FBQyxZQUFZLEVBQUUsQ0FBQTtBQUN2QyxTQUFJLElBQUksRUFBRTtBQUNULFVBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDckMsVUFBTSxLQUFLLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxVQUFBLElBQUk7Y0FBSSxJQUFJLENBQUMsT0FBTyxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUMsQ0FBQyxTQUFTLEVBQUU7T0FBQSxDQUFDLENBQUE7QUFDeEUsVUFBSSxHQUFHLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDdkIsVUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUE7TUFDMUI7S0FDRDtJQUNELENBQUMsQ0FBQyxDQUFBO0FBQ0gsT0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLHFCQUFxQixDQUFDLFVBQUMsV0FBVyxFQUFLO0FBQ2xGLFFBQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFBO0FBQzNCLFNBQUssSUFBTSxJQUFJLHlCQUFpQjtBQUMvQixTQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxTQUFRO0FBQzlCLFNBQUksSUFBSSxDQUFDLGdCQUFnQixFQUFFO0FBQzFCLHNCQUFnQixDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO01BQ2hFO0tBQ0Q7QUFDRCxRQUFNLGNBQWMsR0FBRyxPQUFLLGlCQUFpQixDQUFDLFlBQVksQ0FDekQsT0FBSyxLQUFLLENBQUMsVUFBVSxFQUFFOzs7QUFHdkIsb0JBQWdCLENBQ2hCLENBQUE7QUFDRCxXQUFLLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQTtJQUM5QyxDQUFDLENBQUMsQ0FBQTtBQUNILE9BQUksSUFBSSxDQUFDLGlCQUFpQixFQUFFLEVBQUU7QUFDN0IsUUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFBO0lBQ3RCLE1BQU07QUFDTixVQUFNLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0lBQzlCO0dBQ0Q7OztTQUVnQiwwQkFBQyxPQUFPLEVBQUUsUUFBUSxFQUFpQzs7O09BQS9CLGlCQUFpQix5REFBRyxTQUFTOztBQUNqRSxPQUFNLFVBQVUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ2hELE9BQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDdEQsZ0JBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ2xDLGdCQUFhLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsaUJBQWlCLENBQUMsQ0FBQyxDQUFBO0FBQ3JFLGdCQUFhLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFVBQUMsS0FBSyxFQUFLO0FBQ2xELFdBQUssaUJBQWlCLEVBQUUsQ0FBQTtJQUN4QixFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7QUFDckIsZ0JBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLE1BQU0sR0FBRyxRQUFRLENBQUMsQ0FBQTtBQUM5QyxnQkFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtBQUNyRCxhQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxvQkFBb0IsR0FBRyxRQUFRLENBQUMsQ0FBQTtBQUN6RCxhQUFVLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQTtBQUN4RCxhQUFVLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0FBQ3JDLE9BQUksQ0FBQyxNQUFNLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQTtBQUMxQixPQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUNuQyxPQUFJLFFBQVEsS0FBSyxTQUFTLEVBQUU7QUFDM0IsUUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDdEMsTUFBTSxJQUFJLFFBQVEsS0FBSyxPQUFPLEVBQUU7QUFDaEMsUUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDcEMsTUFBTSxJQUFJLFFBQVEsS0FBSyxTQUFTLEVBQUU7QUFDbEMsUUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDdEMsTUFBTSxJQUFJLFFBQVEsS0FBSyxNQUFNLEVBQUU7QUFDL0IsUUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLENBQUE7SUFDbkMsTUFBTTtBQUNOLFVBQU0sSUFBSSxLQUFLLENBQUMscUJBQXFCLEdBQUcsUUFBUSxDQUFDLENBQUE7SUFDakQ7R0FDRDs7OzJCQUVxQixhQUFHO0FBQ3hCLE9BQUksT0FBTyxZQUFBLENBQUE7QUFDWCxPQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssS0FBSyxJQUFJLEVBQUU7QUFDdEMsUUFBTSxPQUFPLEdBQUcsQ0FBQyxJQUFJLENBQUMsZUFBZSxFQUFFLENBQUMsQ0FBQTtBQUN4QyxXQUFPLENBQUMsSUFBSSxNQUFBLENBQVosT0FBTyxxQkFBUyxJQUFJLENBQUMsT0FBTyxFQUFFLEVBQUMsQ0FBQTtBQUMvQixXQUFPLG9CQUFrQixJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxxQkFBa0IsQ0FBQTtJQUNsRSxNQUFNO0FBQ04sV0FBTyxnQ0FBOEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxxQkFBa0IsQ0FBQTtJQUMvRTtBQUNELE9BQUksQ0FBQyxnQkFBZ0IsQ0FDcEIsT0FBTyxFQUNQLE1BQU0sRUFDTixPQUFPLENBQ1AsQ0FBQTtHQUNEOzs7MkJBRXVCLGFBQUc7OztBQUMxQixPQUFNLEdBQUcsR0FBRyxNQUFNLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQTtBQUMvQixPQUFJLElBQUksQ0FBQyxpQkFBaUIsRUFBRTtBQUMzQixRQUFJLENBQUMsVUFBVSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQzFDLFFBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxFQUFFLENBQUE7SUFDdEI7O0FBRUQsT0FBSSxDQUFDLDJCQUEyQixDQUFDLGVBQWUsRUFBRSxDQUFBO0FBQ2xELE9BQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUE7OztBQUdyQixPQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFBO0FBQy9DLE9BQUksQ0FBQyxjQUFjLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFBO0FBQ3BDLE9BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUMvQixPQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUE7QUFDekIsT0FBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFBOzs7OztBQUtuQyxPQUFJLENBQUMsaUJBQWlCLEdBQUc7QUFDeEIsUUFBSSxFQUFFLElBQUk7QUFDVixPQUFHLEVBQUUsR0FBRztBQUNSLE9BQUcsRUFBRSxHQUFHO0lBQ1IsQ0FBQTtBQUNELE9BQUksUUFBUSxFQUFFOzs7QUFHYixRQUFJLENBQUMsaUJBQWlCLENBQUMsUUFBUSxHQUFHLFFBQVEsQ0FBQTtJQUMxQzs7QUFFRCxPQUFJLENBQUMsaUJBQWlCLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxjQUFjLENBQUE7QUFDakQsT0FBSSxDQUFDLGlCQUFpQixDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsY0FBYyxDQUFBO0FBQ2pELE9BQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFBO0FBQ3RCLE9BQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUE7QUFDOUIsT0FBSTtBQUNILFFBQUksQ0FBQyxVQUFVLEdBQUcscUNBQVMsSUFBSSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQyxjQUFjLEVBQUUsSUFBSSxDQUFDLGlCQUFpQixDQUFDLENBQUE7O0FBRS9GLFFBQUksSUFBSSxDQUFDLFVBQVUsRUFBRTtBQUNwQixTQUFJLENBQUMsaUJBQWlCLEdBQUcsSUFBSSxDQUFBO0FBQzdCLFNBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxDQUFDLE1BQU0sRUFBRSxVQUFDLElBQUksRUFBSztBQUNwQyxVQUFNLFFBQVEsR0FBRyxPQUFLLEtBQUssQ0FBQyxLQUFLLENBQUE7QUFDakMsVUFBSSxPQUFLLEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksRUFBRTtBQUN0QyxjQUFLLEtBQUssQ0FBQyxLQUFLLEdBQUcsT0FBSyxLQUFLLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQTtPQUMzQyxNQUFNLElBQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7QUFDeEMsY0FBSyxLQUFLLENBQUMsS0FBSyxHQUFHLE9BQUssVUFBVSxDQUFDLE9BQU8sQ0FBQTtPQUMxQztBQUNELFVBQUksUUFBUSxLQUFLLE9BQUssS0FBSyxDQUFDLEtBQUssRUFBRTtBQUNsQyxjQUFLLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLGtCQUFrQixFQUFFLE9BQUssS0FBSyxDQUFDLEtBQUssQ0FBQyxDQUFBO09BQzdEO0FBQ0QsYUFBSyxRQUFRLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3pCLGFBQUssS0FBSyxDQUFDLG9CQUFvQixFQUFFLENBQUE7TUFDakMsQ0FBQyxDQUFBO0FBQ0YsU0FBSSxDQUFDLFVBQVUsQ0FBQyxFQUFFLENBQUMsTUFBTSxFQUFFLFVBQUMsSUFBSSxFQUFFLE1BQU0sRUFBSztBQUM1QyxhQUFLLGlCQUFpQixHQUFHLEtBQUssQ0FBQTtBQUM5QixVQUFJLENBQUMsT0FBSyxrQkFBa0IsRUFBRSxFQUFFO0FBQy9CLGNBQUssS0FBSyxDQUFDLElBQUksRUFBRSxDQUFBO09BQ2pCLE1BQU07QUFDTixXQUFJLElBQUksS0FBSyxDQUFDLEVBQUU7QUFDZixlQUFLLGdCQUFnQixDQUNwQixpREFBaUQsRUFDakQsU0FBUyxDQUNULENBQUE7UUFDRCxNQUFNO0FBQ04sZUFBSyxnQkFBZ0IsQ0FDcEIsc0RBQXNELEdBQUcsSUFBSSxHQUFHLEtBQUssRUFDckUsT0FBTyxDQUNQLENBQUE7UUFDRDtPQUNEO01BQ0QsQ0FBQyxDQUFBO0FBQ0YsU0FBSSxDQUFDLE1BQU0sQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFBO0tBQzFCO0lBQ0QsQ0FBQyxPQUFPLEdBQUcsRUFBRTtBQUNiLFFBQUksT0FBTyxHQUFHLGNBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLEdBQUcsaUNBQWlDLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQTtBQUN2RyxRQUFJLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLGlCQUFpQixDQUFDLEVBQUU7QUFDOUMsWUFBTyxHQUFHLDJCQUEyQixHQUFHLElBQUksQ0FBQyxpQkFBaUIsR0FBRyxLQUFLLENBQUE7S0FDdEU7QUFDRCxRQUFJLENBQUMsZ0JBQWdCLENBQ3BCLE9BQU8sRUFDUCxPQUFPLENBQ1AsQ0FBQTtJQUNEO0dBQ0Q7OztTQUVLLGlCQUFHO0FBQ1IsT0FBSSxJQUFJLENBQUMsUUFBUSxFQUFFO0FBQ2xCLFdBQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUM1QjtHQUNEOzs7U0FFa0MsOENBQUc7Ozs7O0FBR3JDLE9BQUksSUFBSSxDQUFDLDJCQUEyQixFQUFFO0FBQ3JDLFFBQU0sWUFBWSxHQUFHLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxZQUFZLElBQUksRUFBRSxDQUFBOzs7QUFHMUUsV0FBTyxZQUFZLENBQUMsUUFBUSxDQUFBO0FBQzVCLFFBQUksVUFBVSxJQUFJLElBQUksQ0FBQyw2QkFBNkIsRUFBRTtBQUNyRCxpQkFBWSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsNkJBQTZCLENBQUMsUUFBUSxDQUFBO0FBQ25FLFlBQU8sSUFBSSxDQUFDLDZCQUE2QixDQUFDLFFBQVEsQ0FBQTtLQUNsRDtBQUNELFdBQU8sWUFBWSxDQUFDLFVBQVUsQ0FBQTtBQUM5QixRQUFJLFlBQVksSUFBSSxJQUFJLENBQUMsNkJBQTZCLEVBQUU7QUFDdkQsaUJBQVksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLDZCQUE2QixDQUFDLFVBQVUsQ0FBQTtBQUN2RSxZQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxVQUFVLENBQUE7S0FDcEQ7QUFDRCxXQUFPLFlBQVksQ0FBQyxLQUFLLENBQUE7QUFDekIsUUFDQyxPQUFPLElBQUksSUFBSSxDQUFDLDZCQUE2QixJQUM3QyxNQUFNLENBQUMsTUFBTSxnQkFBUSxDQUFDLElBQUksQ0FBQyxVQUFBLENBQUM7WUFBSSxDQUFDLElBQUksT0FBSyw2QkFBNkI7S0FBQSxDQUFDLEVBQ3ZFO0FBQ0QsaUJBQVksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsNkJBQTZCLENBQUMsQ0FBQTtBQUN0RSxZQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxLQUFLLENBQUE7QUFDL0MsV0FBTSxDQUFDLE1BQU0sZ0JBQVEsQ0FBQyxPQUFPLENBQUMsVUFBQSxDQUFDO2FBQUksT0FBTyxPQUFLLDZCQUE2QixDQUFDLENBQUMsQ0FBQztNQUFBLENBQUMsQ0FBQTtLQUNoRjtBQUNELFFBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFBO0FBQzdCLFNBQUssSUFBTSxHQUFHLElBQUksTUFBTSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBRTtBQUM1QyxTQUFJLENBQUMsUUFBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEVBQUUsWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUE7S0FDL0M7QUFDRCxXQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxZQUFZLENBQUE7Ozs7OztBQU10RCxRQUFNLENBQUMsR0FBRyxJQUFJLEdBQUcsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxDQUFDLENBQUE7QUFDbEUsUUFBTSxZQUFZLEdBQUcsSUFBSSxHQUFHLENBQUMsNkJBQUksQ0FBQyxHQUFFLE1BQU0sQ0FBQyxVQUFBLENBQUM7WUFBSSxtQkFBbUIsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0tBQUEsQ0FBQyxDQUFDLENBQUE7QUFDNUUsUUFBSSxZQUFZLENBQUMsSUFBSSxLQUFLLENBQUMsRUFBRTtBQUM1QixTQUFJLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUN4QixVQUFLLElBQU0sR0FBRyxJQUFJLFlBQVksRUFBRTtBQUMvQixhQUFPLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxHQUFHLENBQUMsQ0FBQTtNQUM5QztLQUNEOztBQUVELFFBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtJQUNwQjs7OztBQUlELFFBQUssSUFBTSxHQUFHLElBQUksa0JBQWtCLEVBQUU7QUFDckMsV0FBTyxJQUFJLENBQUMsNkJBQTZCLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDOUM7R0FDRDs7O1NBRWEseUJBQUc7O0FBRWhCLE9BQ0MsSUFBSSxDQUFDLDJCQUEyQixJQUNoQyxJQUFJLENBQUMsa0JBQWtCLElBQ3ZCLElBQUksQ0FBQyxrQkFBa0IsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxJQUNqQyxJQUFJLENBQUMsa0JBQWtCLENBQUMsTUFBTSxHQUFHLENBQUMsRUFDakM7QUFDRCxRQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsRUFBRSxDQUFBO0FBQ25CLFFBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUNsRCxRQUFJLFFBQVEsSUFBSSxJQUFJLENBQUMsbUJBQW1CLEVBQUUsRUFBRTs7QUFFM0MsU0FBSSxJQUFJLENBQUMsY0FBYyxLQUFLLFFBQVEsQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLGNBQWMsS0FBSyxRQUFRLENBQUMsSUFBSSxFQUFFO0FBQ25GLFVBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3BELFVBQUksQ0FBQyxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQTtBQUNuQyxVQUFJLENBQUMsY0FBYyxHQUFHLFFBQVEsQ0FBQyxJQUFJLENBQUE7TUFDbkM7S0FDRDtJQUNEO0dBQ0Q7OztTQUVlLHlCQUFDLE1BQU0sRUFBRTtBQUN4QixPQUFJLElBQUksQ0FBQyxRQUFRLEVBQUU7QUFDbEIsUUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsQ0FBQTtBQUN0QixRQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRSxDQUFBO0FBQ3JCLFFBQUksTUFBTSxFQUFFOztBQUVYLFNBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFLENBQUE7S0FDckI7SUFDRDtHQUNEOzs7MkJBRXVCLGFBQUc7O0FBRTFCLFNBQU0sSUFBSSxDQUFDLDJCQUEyQixDQUFDLGtCQUFrQixDQUFBO0FBQ3pELE9BQUksQ0FBQywyQkFBMkIsQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0dBQ3BEOzs7U0FFWSx3QkFBRztBQUNmLE9BQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUE7R0FDNUM7OztTQUVZLHdCQUFHO0FBQ2YsT0FBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtHQUM3Qzs7O1NBRXNCLGdDQUFDLGNBQWMsRUFBRTtBQUN2QyxPQUFJLENBQUMsNkJBQTZCLGdCQUM5QixJQUFJLENBQUMsNkJBQTZCLEVBQ2xDLGNBQWMsQ0FDakIsQ0FBQTtBQUNELE9BQUksQ0FBQyxrQ0FBa0MsRUFBRSxDQUFBO0dBQ3pDOzs7UUFqckJJLG9CQUFvQjtHQUFTLFdBQVc7O0FBb3JCOUMsSUFBTSxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsZUFBZSxDQUFDLFlBQVksRUFBRTtBQUMvRCxVQUFTLEVBQUUsb0JBQW9CLENBQUMsU0FBUztDQUN6QyxDQUFDLENBQUE7O1FBR0QsZ0JBQWdCLEdBQWhCLGdCQUFnQiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy94LXRlcm1pbmFsL3NyYy9lbGVtZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqIEBiYWJlbCAqL1xuLypcbiAqIENvcHlyaWdodCAyMDE3IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgMjAxNy0yMDE4IEFuZHJlcyBNZWppYSA8YW1lamlhMDA0QGdtYWlsLmNvbT4uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgVXppVGVjaCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIGJ1cy1zdG9wIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzXG4gKiBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGUgXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmVcbiAqIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSxcbiAqIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG9cbiAqIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzby5cbiAqXG4gKiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SIElNUExJRUQsXG4gKiBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQVxuICogUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVFxuICogSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OXG4gKiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEVcbiAqIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuICovXG5cbmltcG9ydCB7IENvbXBvc2l0ZURpc3Bvc2FibGUsIERpc3Bvc2FibGUgfSBmcm9tICdhdG9tJ1xuaW1wb3J0IHsgc3Bhd24gYXMgc3Bhd25QdHkgfSBmcm9tICdub2RlLXB0eS1wcmVidWlsdC1tdWx0aWFyY2gnXG5pbXBvcnQgeyBUZXJtaW5hbCB9IGZyb20gJ3h0ZXJtJ1xuaW1wb3J0IHsgRml0QWRkb24gfSBmcm9tICd4dGVybS1hZGRvbi1maXQnXG5pbXBvcnQgeyBXZWJMaW5rc0FkZG9uIH0gZnJvbSAneHRlcm0tYWRkb24td2ViLWxpbmtzJ1xuaW1wb3J0IHsgV2ViZ2xBZGRvbiB9IGZyb20gJ3h0ZXJtLWFkZG9uLXdlYmdsJ1xuaW1wb3J0IHsgTGlnYXR1cmVzQWRkb24gfSBmcm9tICd4dGVybS1hZGRvbi1saWdhdHVyZXMnXG5pbXBvcnQgeyBzaGVsbCB9IGZyb20gJ2VsZWN0cm9uJ1xuXG5pbXBvcnQgeyBjb25maWdEZWZhdWx0cywgQ09MT1JTLCBDT05GSUdfREFUQSB9IGZyb20gJy4vY29uZmlnJ1xuaW1wb3J0IHsgWFRlcm1pbmFsUHJvZmlsZU1lbnVFbGVtZW50IH0gZnJvbSAnLi9wcm9maWxlLW1lbnUtZWxlbWVudCdcbmltcG9ydCB7IFhUZXJtaW5hbFByb2ZpbGVNZW51TW9kZWwgfSBmcm9tICcuL3Byb2ZpbGUtbWVudS1tb2RlbCdcbmltcG9ydCB7IFhUZXJtaW5hbFByb2ZpbGVzU2luZ2xldG9uIH0gZnJvbSAnLi9wcm9maWxlcydcblxuaW1wb3J0IGZzIGZyb20gJ2ZzLWV4dHJhJ1xuXG5jb25zdCBQVFlfUFJPQ0VTU19PUFRJT05TID0gbmV3IFNldChbXG5cdCdjb21tYW5kJyxcblx0J2FyZ3MnLFxuXHQnbmFtZScsXG5cdCdjd2QnLFxuXHQnZW52Jyxcblx0J3NldEVudicsXG5cdCdkZWxldGVFbnYnLFxuXHQnZW5jb2RpbmcnLFxuXSlcbmNvbnN0IFhfVEVSTUlOQUxfT1BUSU9OUyA9IFtcblx0J2xlYXZlT3BlbkFmdGVyRXhpdCcsXG5cdCdyZWxhdW5jaFRlcm1pbmFsT25TdGFydHVwJyxcblx0J3RpdGxlJyxcblx0J3Byb21wdFRvU3RhcnR1cCcsXG5dXG5cbmNsYXNzIFhUZXJtaW5hbEVsZW1lbnRJbXBsIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuXHRhc3luYyBpbml0aWFsaXplIChtb2RlbCkge1xuXHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24gPSBYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbi5pbnN0YW5jZVxuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMubW9kZWwuZWxlbWVudCA9IHRoaXNcblx0XHR0aGlzLmRpc3Bvc2FibGVzID0gbmV3IENvbXBvc2l0ZURpc3Bvc2FibGUoKVxuXHRcdHRoaXMudG9wRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHR0aGlzLnRvcERpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXRvcC1kaXYnKVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQodGhpcy50b3BEaXYpXG5cdFx0dGhpcy5tYWluRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHR0aGlzLm1haW5EaXYuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1tYWluLWRpdicpXG5cdFx0dGhpcy5hcHBlbmRDaGlsZCh0aGlzLm1haW5EaXYpXG5cdFx0dGhpcy5tZW51RGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHR0aGlzLm1lbnVEaXYuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1tZW51LWRpdicpXG5cdFx0dGhpcy5tYWluRGl2LmFwcGVuZENoaWxkKHRoaXMubWVudURpdilcblx0XHR0aGlzLnRlcm1pbmFsRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHR0aGlzLnRlcm1pbmFsRGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtdGVybS1jb250YWluZXInKVxuXHRcdHRoaXMubWFpbkRpdi5hcHBlbmRDaGlsZCh0aGlzLnRlcm1pbmFsRGl2KVxuXHRcdHRoaXMuYXRvbVh0ZXJtUHJvZmlsZU1lbnVFbGVtZW50ID0gbmV3IFhUZXJtaW5hbFByb2ZpbGVNZW51RWxlbWVudCgpXG5cdFx0dGhpcy5ob3ZlcmVkTGluayA9IG51bGxcblx0XHR0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zID0ge31cblx0XHR0aGlzLm1haW5EaXZDb250ZW50UmVjdCA9IG51bGxcblx0XHR0aGlzLnRlcm1pbmFsRGl2SW5pdGlhbGx5VmlzaWJsZSA9IGZhbHNlXG5cdFx0dGhpcy5pc0luaXRpYWxpemVkID0gZmFsc2Vcblx0XHRsZXQgcmVzb2x2ZUluaXQsIHJlamVjdEluaXRcblx0XHR0aGlzLmluaXRpYWxpemVkUHJvbWlzZSA9IG5ldyBQcm9taXNlKChyZXNvbHZlLCByZWplY3QpID0+IHtcblx0XHRcdHJlc29sdmVJbml0ID0gcmVzb2x2ZVxuXHRcdFx0cmVqZWN0SW5pdCA9IHJlamVjdFxuXHRcdH0pXG5cdFx0dHJ5IHtcblx0XHRcdC8vIEFsd2F5cyB3YWl0IGZvciB0aGUgbW9kZWwgdG8gZmluaXNoIGluaXRpYWxpemluZyBiZWZvcmUgcHJvY2VlZGluZy5cblx0XHRcdGF3YWl0IHRoaXMubW9kZWwuaW5pdGlhbGl6ZWRQcm9taXNlXG5cdFx0XHR0aGlzLnNldEF0dHJpYnV0ZSgnc2Vzc2lvbi1pZCcsIHRoaXMubW9kZWwuZ2V0U2Vzc2lvbklkKCkpXG5cdFx0XHRhd2FpdCB0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudC5pbml0aWFsaXplKG5ldyBYVGVybWluYWxQcm9maWxlTWVudU1vZGVsKHRoaXMubW9kZWwpKVxuXHRcdFx0dGhpcy5tZW51RGl2LmFwcGVuZCh0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudClcblx0XHRcdC8vIEFuIGVsZW1lbnQgcmVzaXplIGRldGVjdG9yIGlzIHVzZWQgdG8gY2hlY2sgd2hlbiB0aGlzIGVsZW1lbnQgaXNcblx0XHRcdC8vIHJlc2l6ZWQgZHVlIHRvIHRoZSBwYW5lIHJlc2l6aW5nIG9yIGR1ZSB0byB0aGUgZW50aXJlIHdpbmRvd1xuXHRcdFx0Ly8gcmVzaXppbmcuXG5cdFx0XHR0aGlzLm1haW5EaXZSZXNpemVPYnNlcnZlciA9IG5ldyBSZXNpemVPYnNlcnZlcihlbnRyaWVzID0+IHtcblx0XHRcdFx0Y29uc3QgbGFzdEVudHJ5ID0gZW50cmllcy5wb3AoKVxuXHRcdFx0XHR0aGlzLm1haW5EaXZDb250ZW50UmVjdCA9IGxhc3RFbnRyeS5jb250ZW50UmVjdFxuXHRcdFx0XHR0aGlzLnJlZml0VGVybWluYWwoKVxuXHRcdFx0fSlcblx0XHRcdHRoaXMubWFpbkRpdlJlc2l6ZU9ic2VydmVyLm9ic2VydmUodGhpcy5tYWluRGl2KVxuXHRcdFx0dGhpcy5kaXNwb3NhYmxlcy5hZGQobmV3IERpc3Bvc2FibGUoKCkgPT4ge1xuXHRcdFx0XHR0aGlzLm1haW5EaXZSZXNpemVPYnNlcnZlci5kaXNjb25uZWN0KClcblx0XHRcdFx0dGhpcy5tYWluRGl2UmVzaXplT2JzZXJ2ZXIgPSBudWxsXG5cdFx0XHR9KSlcblx0XHRcdC8vIEFkZCBhbiBJbnRlcnNlY3Rpb25PYnNlcnZlciBpbiBvcmRlciB0byBhcHBseSBuZXcgb3B0aW9ucyBhbmRcblx0XHRcdC8vIHJlZml0IGFzIHNvb24gYXMgdGhlIHRlcm1pbmFsIGlzIHZpc2libGUuXG5cdFx0XHR0aGlzLnRlcm1pbmFsRGl2SW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSBuZXcgSW50ZXJzZWN0aW9uT2JzZXJ2ZXIoYXN5bmMgZW50cmllcyA9PiB7XG5cdFx0XHRcdGNvbnN0IGxhc3RFbnRyeSA9IGVudHJpZXMucG9wKClcblx0XHRcdFx0aWYgKGxhc3RFbnRyeS5pbnRlcnNlY3Rpb25SYXRpbyA9PT0gMS4wKSB7XG5cdFx0XHRcdFx0dGhpcy50ZXJtaW5hbERpdkluaXRpYWxseVZpc2libGUgPSB0cnVlXG5cdFx0XHRcdFx0dHJ5IHtcblx0XHRcdFx0XHRcdGF3YWl0IHRoaXMuY3JlYXRlVGVybWluYWwoKVxuXHRcdFx0XHRcdFx0dGhpcy5hcHBseVBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zKClcblx0XHRcdFx0XHRcdHJlc29sdmVJbml0KClcblx0XHRcdFx0XHR9IGNhdGNoIChleCkge1xuXHRcdFx0XHRcdFx0cmVqZWN0SW5pdChleClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0Ly8gUmVtb3ZlIG9ic2VydmVyIG9uY2UgdmlzaWJsZVxuXHRcdFx0XHRcdHRoaXMudGVybWluYWxEaXZJbnRlcnNlY3Rpb25PYnNlcnZlci5kaXNjb25uZWN0KClcblx0XHRcdFx0XHR0aGlzLnRlcm1pbmFsRGl2SW50ZXJzZWN0aW9uT2JzZXJ2ZXIgPSBudWxsXG5cdFx0XHRcdH1cblx0XHRcdH0sIHtcblx0XHRcdFx0cm9vdDogdGhpcyxcblx0XHRcdFx0dGhyZXNob2xkOiAxLjAsXG5cdFx0XHR9KVxuXHRcdFx0dGhpcy50ZXJtaW5hbERpdkludGVyc2VjdGlvbk9ic2VydmVyLm9ic2VydmUodGhpcy50ZXJtaW5hbERpdilcblx0XHRcdHRoaXMuZGlzcG9zYWJsZXMuYWRkKG5ldyBEaXNwb3NhYmxlKCgpID0+IHtcblx0XHRcdFx0aWYgKHRoaXMudGVybWluYWxEaXZJbnRlcnNlY3Rpb25PYnNlcnZlcikge1xuXHRcdFx0XHRcdHRoaXMudGVybWluYWxEaXZJbnRlcnNlY3Rpb25PYnNlcnZlci5kaXNjb25uZWN0KClcblx0XHRcdFx0fVxuXHRcdFx0fSkpXG5cdFx0XHQvLyBBZGQgZXZlbnQgaGFuZGxlciBmb3IgaW5jcmVhc2luZy9kZWNyZWFzaW5nIHRoZSBmb250IHdoZW5cblx0XHRcdC8vIGhvbGRpbmcgJ2N0cmwnIGFuZCBtb3ZpbmcgdGhlIG1vdXNlIHdoZWVsIHVwIG9yIGRvd24uXG5cdFx0XHR0aGlzLnRlcm1pbmFsRGl2LmFkZEV2ZW50TGlzdGVuZXIoXG5cdFx0XHRcdCd3aGVlbCcsXG5cdFx0XHRcdCh3aGVlbEV2ZW50KSA9PiB7XG5cdFx0XHRcdFx0aWYgKCF3aGVlbEV2ZW50LmN0cmxLZXkgfHwgIWF0b20uY29uZmlnLmdldCgnZWRpdG9yLnpvb21Gb250V2hlbkN0cmxTY3JvbGxpbmcnKSkge1xuXHRcdFx0XHRcdFx0cmV0dXJuXG5cdFx0XHRcdFx0fVxuXG5cdFx0XHRcdFx0bGV0IGZvbnRTaXplID0gdGhpcy5tb2RlbC5wcm9maWxlLmZvbnRTaXplICsgKHdoZWVsRXZlbnQuZGVsdGFZIDwgMCA/IDEgOiAtMSlcblx0XHRcdFx0XHRpZiAoZm9udFNpemUgPCBjb25maWdEZWZhdWx0cy5taW5pbXVtRm9udFNpemUpIHtcblx0XHRcdFx0XHRcdGZvbnRTaXplID0gY29uZmlnRGVmYXVsdHMubWluaW11bUZvbnRTaXplXG5cdFx0XHRcdFx0fSBlbHNlIGlmIChmb250U2l6ZSA+IGNvbmZpZ0RlZmF1bHRzLm1heGltdW1Gb250U2l6ZSkge1xuXHRcdFx0XHRcdFx0Zm9udFNpemUgPSBjb25maWdEZWZhdWx0cy5tYXhpbXVtRm9udFNpemVcblx0XHRcdFx0XHR9XG5cdFx0XHRcdFx0dGhpcy5tb2RlbC5hcHBseVByb2ZpbGVDaGFuZ2VzKHsgZm9udFNpemU6IGZvbnRTaXplIH0pXG5cdFx0XHRcdFx0d2hlZWxFdmVudC5zdG9wUHJvcGFnYXRpb24oKVxuXHRcdFx0XHR9LFxuXHRcdFx0XHR7IGNhcHR1cmU6IHRydWUgfSxcblx0XHRcdClcblx0XHR9IGNhdGNoIChleCkge1xuXHRcdFx0cmVqZWN0SW5pdChleClcblx0XHRcdHRocm93IGV4XG5cdFx0fVxuXHRcdHRoaXMuaXNJbml0aWFsaXplZCA9IHRydWVcblx0fVxuXG5cdGRlc3Ryb3kgKCkge1xuXHRcdHRoaXMuYXRvbVh0ZXJtUHJvZmlsZU1lbnVFbGVtZW50LmRlc3Ryb3koKVxuXHRcdGlmICh0aGlzLnB0eVByb2Nlc3MpIHtcblx0XHRcdHRoaXMucHR5UHJvY2Vzcy5raWxsKClcblx0XHR9XG5cdFx0aWYgKHRoaXMudGVybWluYWwpIHtcblx0XHRcdHRoaXMudGVybWluYWwuZGlzcG9zZSgpXG5cdFx0fVxuXHRcdHRoaXMuZGlzcG9zYWJsZXMuZGlzcG9zZSgpXG5cdH1cblxuXHRnZXRTaGVsbENvbW1hbmQgKCkge1xuXHRcdHJldHVybiB0aGlzLm1vZGVsLnByb2ZpbGUuY29tbWFuZFxuXHR9XG5cblx0Z2V0QXJncyAoKSB7XG5cdFx0Y29uc3QgYXJncyA9IHRoaXMubW9kZWwucHJvZmlsZS5hcmdzXG5cdFx0aWYgKCFBcnJheS5pc0FycmF5KGFyZ3MpKSB7XG5cdFx0XHR0aHJvdyBuZXcgRXJyb3IoJ0FyZ3VtZW50cyBzZXQgYXJlIG5vdCBhbiBhcnJheS4nKVxuXHRcdH1cblx0XHRyZXR1cm4gYXJnc1xuXHR9XG5cblx0Z2V0VGVybVR5cGUgKCkge1xuXHRcdHJldHVybiB0aGlzLm1vZGVsLnByb2ZpbGUubmFtZVxuXHR9XG5cblx0YXN5bmMgY2hlY2tQYXRoSXNEaXJlY3RvcnkgKHBhdGgpIHtcblx0XHRpZiAocGF0aCkge1xuXHRcdFx0dHJ5IHtcblx0XHRcdFx0Y29uc3Qgc3RhdHMgPSBhd2FpdCBmcy5zdGF0KHBhdGgpXG5cdFx0XHRcdGlmIChzdGF0cyAmJiBzdGF0cy5pc0RpcmVjdG9yeSgpKSB7XG5cdFx0XHRcdFx0cmV0dXJuIHRydWVcblx0XHRcdFx0fVxuXHRcdFx0fSBjYXRjaCAoZXJyKSB7fVxuXHRcdH1cblxuXHRcdHJldHVybiBmYWxzZVxuXHR9XG5cblx0YXN5bmMgZ2V0Q3dkICgpIHtcblx0XHRsZXQgY3dkID0gdGhpcy5tb2RlbC5wcm9maWxlLmN3ZFxuXHRcdGlmIChhd2FpdCB0aGlzLmNoZWNrUGF0aElzRGlyZWN0b3J5KGN3ZCkpIHtcblx0XHRcdHJldHVybiBjd2Rcblx0XHR9XG5cblx0XHRjd2QgPSB0aGlzLm1vZGVsLmdldFBhdGgoKVxuXHRcdGlmIChhd2FpdCB0aGlzLmNoZWNrUGF0aElzRGlyZWN0b3J5KGN3ZCkpIHtcblx0XHRcdHJldHVybiBjd2Rcblx0XHR9XG5cblx0XHQvLyBJZiB0aGUgY3dkIGZyb20gdGhlIG1vZGVsIHdhcyBpbnZhbGlkLCByZXNldCBpdCB0byBudWxsLlxuXHRcdHRoaXMubW9kZWwuY3dkID0gbnVsbFxuXHRcdGN3ZCA9IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2V0QmFzZVByb2ZpbGUuY3dkXG5cdFx0aWYgKGF3YWl0IHRoaXMuY2hlY2tQYXRoSXNEaXJlY3RvcnkoY3dkKSkge1xuXHRcdFx0dGhpcy5tb2RlbC5jd2QgPSBjd2Rcblx0XHRcdHJldHVybiBjd2Rcblx0XHR9XG5cblx0XHRyZXR1cm4gbnVsbFxuXHR9XG5cblx0Z2V0RW52ICgpIHtcblx0XHRsZXQgZW52ID0gdGhpcy5tb2RlbC5wcm9maWxlLmVudlxuXHRcdGlmICghZW52KSB7XG5cdFx0XHRlbnYgPSB7IC4uLnByb2Nlc3MuZW52IH1cblx0XHR9XG5cdFx0aWYgKHR5cGVvZiBlbnYgIT09ICdvYmplY3QnIHx8IEFycmF5LmlzQXJyYXkoZW52KSkge1xuXHRcdFx0dGhyb3cgbmV3IEVycm9yKCdFbnZpcm9ubWVudCBzZXQgaXMgbm90IGFuIG9iamVjdC4nKVxuXHRcdH1cblx0XHRjb25zdCBzZXRFbnYgPSB0aGlzLm1vZGVsLnByb2ZpbGUuc2V0RW52XG5cdFx0Y29uc3QgZGVsZXRlRW52ID0gdGhpcy5tb2RlbC5wcm9maWxlLmRlbGV0ZUVudlxuXHRcdGZvciAoY29uc3Qga2V5IGluIHNldEVudikge1xuXHRcdFx0ZW52W2tleV0gPSBzZXRFbnZba2V5XVxuXHRcdH1cblx0XHRmb3IgKGNvbnN0IGtleSBvZiBkZWxldGVFbnYpIHtcblx0XHRcdGRlbGV0ZSBlbnZba2V5XVxuXHRcdH1cblx0XHRyZXR1cm4gZW52XG5cdH1cblxuXHRnZXRFbmNvZGluZyAoKSB7XG5cdFx0cmV0dXJuIHRoaXMubW9kZWwucHJvZmlsZS5lbmNvZGluZ1xuXHR9XG5cblx0bGVhdmVPcGVuQWZ0ZXJFeGl0ICgpIHtcblx0XHRyZXR1cm4gdGhpcy5tb2RlbC5wcm9maWxlLmxlYXZlT3BlbkFmdGVyRXhpdFxuXHR9XG5cblx0aXNQcm9tcHRUb1N0YXJ0dXAgKCkge1xuXHRcdHJldHVybiB0aGlzLm1vZGVsLnByb2ZpbGUucHJvbXB0VG9TdGFydHVwXG5cdH1cblxuXHRpc1B0eVByb2Nlc3NSdW5uaW5nICgpIHtcblx0XHRyZXR1cm4gKHRoaXMucHR5UHJvY2VzcyAmJiB0aGlzLnB0eVByb2Nlc3NSdW5uaW5nKVxuXHR9XG5cblx0Z2V0VGhlbWUgKHByb2ZpbGUgPSB7fSkge1xuXHRcdGNvbnN0IGNvbG9ycyA9IHt9XG5cdFx0Zm9yIChjb25zdCBjb2xvciBpbiBDT0xPUlMpIHtcblx0XHRcdGNvbnN0IGNvbG9ySXRlbSA9IENPTE9SU1tjb2xvcl1cblx0XHRcdGNvbG9yc1tjb2xvcl0gPSBwcm9maWxlW2NvbG9ySXRlbV0gfHwgdGhpcy5tb2RlbC5wcm9maWxlW2NvbG9ySXRlbV1cblx0XHR9XG5cdFx0Ly8gdGhlbWVzIG1vZGlmaWVkIGZyb20gaHR0cHM6Ly9naXRodWIuY29tL2J1cy1zdG9wL3Rlcm1pbnVzL3RyZWUvbWFzdGVyL3N0eWxlcy90aGVtZXNcblx0XHRzd2l0Y2ggKHByb2ZpbGUudGhlbWUgfHwgdGhpcy5tb2RlbC5wcm9maWxlLnRoZW1lKSB7XG5cdFx0XHRjYXNlICdBdG9tIERhcmsnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjMWQxZjIxJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjYzVjOGM2J1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJyM5OTk5OTknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnI2ZmZmZmZidcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ0F0b20gTGlnaHQnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjZmZmZmZmJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjNTU1NTU1J1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJyNhZmM0ZGEnXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnIzAwMDAwMCdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ0Jhc2UxNiBUb21vcnJvdyBEYXJrJzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAnIzFkMWYyMSdcblx0XHRcdFx0Y29sb3JzLmZvcmVncm91bmQgPSAnI2M1YzhjNidcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICcjYjRiN2I0J1xuXHRcdFx0XHQvLyBjb2xvcnMuc2VsZWN0aW9uRm9yZWdyb3VuZCA9ICcjZTBlMGUwJ1xuXHRcdFx0XHRjb2xvcnMuY3Vyc29yID0gJyNmZmZmZmYnXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdCYXNlMTYgVG9tb3Jyb3cgTGlnaHQnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjZmZmZmZmJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjMWQxZjIxJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJyMyODJhMmUnXG5cdFx0XHRcdC8vIGNvbG9ycy5zZWxlY3Rpb25Gb3JlZ3JvdW5kID0gJyNlMGUwZTAnXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnIzFkMWYyMSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ0NocmlzdG1hcyc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJyMwYzAwNDcnXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJyNmODE3MDUnXG5cdFx0XHRcdGNvbG9ycy5zZWxlY3Rpb24gPSAnIzI5OGYxNidcblx0XHRcdFx0Y29sb3JzLmN1cnNvciA9ICcjMDA5ZjU5J1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnQ2l0eSBMaWdodHMnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjMTgxZDIzJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjNjY2ZDgxJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJyMyYTJmMzgnXG5cdFx0XHRcdC8vIGNvbG9ycy5zZWxlY3Rpb25Gb3JlZ3JvdW5kID0gJyNiN2M1ZDMnXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnIzUyOGJmZidcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ0RyYWN1bGEnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjMWUxZjI5J1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICd3aGl0ZSdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICcjNDQ0NzVhJ1xuXHRcdFx0XHRjb2xvcnMuY3Vyc29yID0gJyM5OTk5OTknXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdHcmFzcyc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJ3JnYigxOSwgMTE5LCA2MSknXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJ3JnYigyNTUsIDI0MCwgMTY1KSdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDE4MiwgNzMsIDM4LCAuOTkpJ1xuXHRcdFx0XHRjb2xvcnMuY3Vyc29yID0gJ3JnYigxNDIsIDQwLCAwKSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ0hvbWVicmV3Jzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAnIzAwMDAwMCdcblx0XHRcdFx0Y29sb3JzLmZvcmVncm91bmQgPSAncmdiKDQxLCAyNTQsIDIwKSdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDcsIDMwLCAxNTUsIC45OSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAncmdiKDU1LCAyNTQsIDM4KSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ0ludmVyc2UnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjZmZmZmZmJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjMDAwMDAwJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJ3JnYmEoMTc4LCAyMTUsIDI1NSwgLjk5KSdcblx0XHRcdFx0Y29sb3JzLmN1cnNvciA9ICdyZ2IoMTQ2LCAxNDYsIDE0NiknXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdMaW51eCc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJyMwMDAwMDAnXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJ3JnYigyMzAsIDIzMCwgMjMwKSdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDE1NSwgMzAsIDcsIC45OSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAncmdiKDIwMCwgMjAsIDI1KSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ01hbiBQYWdlJzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAncmdiKDI1NCwgMjQ0LCAxNTYpJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICdibGFjaydcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDE3OCwgMjE1LCAyNTUsIC45OSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAncmdiKDE0NiwgMTQ2LCAxNDYpJ1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnTm92ZWwnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICdyZ2IoMjIzLCAyMTksIDE5NiknXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJ3JnYig3NywgNDcsIDQ2KSdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDE1NSwgMTUzLCAxMjIsIC45OSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAncmdiKDExNSwgOTksIDg5KSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ09jZWFuJzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAncmdiKDQ0LCAxMDIsIDIwMSknXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJ3doaXRlJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJ3JnYmEoNDEsIDEzNCwgMjU1LCAuOTkpJ1xuXHRcdFx0XHRjb2xvcnMuY3Vyc29yID0gJ3JnYigxNDYsIDE0NiwgMTQ2KSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ09uZSBEYXJrJzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAnIzI4MmMzNCdcblx0XHRcdFx0Y29sb3JzLmZvcmVncm91bmQgPSAnI2FiYjJiZidcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICcjOTE5NmExJ1xuXHRcdFx0XHRjb2xvcnMuY3Vyc29yID0gJyM1MjhiZmYnXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdPbmUgTGlnaHQnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICdoc2woMjMwLCAxJSwgOTglKSdcblx0XHRcdFx0Y29sb3JzLmZvcmVncm91bmQgPSAnaHNsKDIzMCwgOCUsIDI0JSknXG5cdFx0XHRcdGNvbG9ycy5zZWxlY3Rpb24gPSAnaHNsKDIzMCwgMSUsIDkwJSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnaHNsKDIzMCwgMTAwJSwgNjYlKSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ1ByZWRhd24nOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjMjgyODI4J1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjZjFmMWYxJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJ3JnYmEoMjU1LDI1NSwyNTUsMC4yNSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnI2YxODI2MCdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ1Bybyc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJyMwMDAwMDAnXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJ3JnYigyNDQsIDI0NCwgMjQ0KSdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDgyLCA4MiwgODIsIC45OSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAncmdiKDk2LCA5NiwgOTYpJ1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnUmVkIFNhbmRzJzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAncmdiKDE0MywgNTMsIDM5KSdcblx0XHRcdFx0Y29sb3JzLmZvcmVncm91bmQgPSAncmdiKDIxNSwgMjAxLCAxNjcpJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJ3JnYmEoNjAsIDI1LCAyMiwgLjk5KSdcblx0XHRcdFx0Y29sb3JzLmN1cnNvciA9ICd3aGl0ZSdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ1JlZCc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJyMwMDAwMDAnXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJ3JnYigyNTUsIDM4LCAxNCknXG5cdFx0XHRcdGNvbG9ycy5zZWxlY3Rpb24gPSAncmdiYSg3LCAzMCwgMTU1LCAuOTkpJ1xuXHRcdFx0XHRjb2xvcnMuY3Vyc29yID0gJ3JnYigyNTUsIDM4LCAxNCknXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdTaWx2ZXIgQWVyb2dlbCc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJ3JnYigxNDYsIDE0NiwgMTQ2KSdcblx0XHRcdFx0Y29sb3JzLmZvcmVncm91bmQgPSAnIzAwMDAwMCdcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9ICdyZ2JhKDEyMCwgMTIzLCAxNTYsIC45OSknXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAncmdiKDIyNCwgMjI0LCAyMjQpJ1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnU29sYXJpemVkIERhcmsnOlxuXHRcdFx0XHRjb2xvcnMuYmFja2dyb3VuZCA9ICcjMDQyMDI5J1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjNzA4Mjg0J1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJyM4Mzk0OTYnXG5cdFx0XHRcdGNvbG9ycy5jdXJzb3IgPSAnIzgxOTA5MCdcblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ1NvbGFyaXplZCBMaWdodCc6XG5cdFx0XHRcdGNvbG9ycy5iYWNrZ3JvdW5kID0gJyNmZGY2ZTMnXG5cdFx0XHRcdGNvbG9ycy5mb3JlZ3JvdW5kID0gJyM2NTdhODEnXG5cdFx0XHRcdGNvbG9ycy5zZWxlY3Rpb24gPSAnI2VjZTdkNSdcblx0XHRcdFx0Y29sb3JzLmN1cnNvciA9ICcjNTg2ZTc1J1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnU29saWQgQ29sb3JzJzpcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSAncmdiKDEyMCwgMTMyLCAxNTEpJ1xuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9ICcjMDAwMDAwJ1xuXHRcdFx0XHRjb2xvcnMuc2VsZWN0aW9uID0gJ3JnYmEoMTc4LCAyMTUsIDI1NSwgLjk5KSdcblx0XHRcdFx0Y29sb3JzLmN1cnNvciA9ICcjZmZmZmZmJ1xuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnU3RhbmRhcmQnOiB7XG5cdFx0XHRcdGNvbnN0IHJvb3QgPSBnZXRDb21wdXRlZFN0eWxlKGRvY3VtZW50LmRvY3VtZW50RWxlbWVudClcblx0XHRcdFx0Y29sb3JzLmJhY2tncm91bmQgPSByb290LmdldFByb3BlcnR5VmFsdWUoJy0tc3RhbmRhcmQtYXBwLWJhY2tncm91bmQtY29sb3InKVxuXHRcdFx0XHRjb2xvcnMuZm9yZWdyb3VuZCA9IHJvb3QuZ2V0UHJvcGVydHlWYWx1ZSgnLS1zdGFuZGFyZC10ZXh0LWNvbG9yJylcblx0XHRcdFx0Y29sb3JzLnNlbGVjdGlvbiA9IHJvb3QuZ2V0UHJvcGVydHlWYWx1ZSgnLS1zdGFuZGFyZC1iYWNrZ3JvdW5kLWNvbG9yLXNlbGVjdGVkJylcblx0XHRcdFx0Y29sb3JzLmN1cnNvciA9IHJvb3QuZ2V0UHJvcGVydHlWYWx1ZSgnLS1zdGFuZGFyZC10ZXh0LWNvbG9yLWhpZ2hsaWdodCcpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIGNvbG9yc1xuXHR9XG5cblx0Z2V0WHRlcm1PcHRpb25zICgpIHtcblx0XHRjb25zdCB4dGVybU9wdGlvbnMgPSB7XG5cdFx0XHRjdXJzb3JCbGluazogdHJ1ZSxcblx0XHRcdC4uLnRoaXMubW9kZWwucHJvZmlsZS54dGVybU9wdGlvbnMsXG5cdFx0fVxuXHRcdHh0ZXJtT3B0aW9ucy5mb250U2l6ZSA9IHRoaXMubW9kZWwucHJvZmlsZS5mb250U2l6ZVxuXHRcdHh0ZXJtT3B0aW9ucy5mb250RmFtaWx5ID0gdGhpcy5tb2RlbC5wcm9maWxlLmZvbnRGYW1pbHlcblx0XHR4dGVybU9wdGlvbnMudGhlbWUgPSB0aGlzLmdldFRoZW1lKHRoaXMubW9kZWwucHJvZmlsZSlcblx0XHQvLyBOT1RFOiBUaGUgY2xvbmluZyBpcyBuZWVkZWQgYmVjYXVzZSB0aGUgVGVybWluYWwgY2xhc3MgbW9kaWZpZXMgdGhlXG5cdFx0Ly8gb3B0aW9ucyBwYXNzZWQgdG8gaXQuXG5cdFx0cmV0dXJuIHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZGVlcENsb25lKHh0ZXJtT3B0aW9ucylcblx0fVxuXG5cdHNldE1haW5CYWNrZ3JvdW5kQ29sb3IgKCkge1xuXHRcdGNvbnN0IHh0ZXJtT3B0aW9ucyA9IHRoaXMuZ2V0WHRlcm1PcHRpb25zKClcblx0XHRpZiAoeHRlcm1PcHRpb25zLnRoZW1lICYmIHh0ZXJtT3B0aW9ucy50aGVtZS5iYWNrZ3JvdW5kKSB7XG5cdFx0XHR0aGlzLnN0eWxlLmJhY2tncm91bmRDb2xvciA9IHh0ZXJtT3B0aW9ucy50aGVtZS5iYWNrZ3JvdW5kXG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMuc3R5bGUuYmFja2dyb3VuZENvbG9yID0gJyMwMDAwMDAnXG5cdFx0fVxuXHR9XG5cblx0YXN5bmMgY3JlYXRlVGVybWluYWwgKCkge1xuXHRcdC8vIEF0dGFjaCB0ZXJtaW5hbCBlbXVsYXRvciB0byB0aGlzIGVsZW1lbnQgYW5kIHJlZml0LlxuXHRcdHRoaXMuc2V0TWFpbkJhY2tncm91bmRDb2xvcigpXG5cdFx0dGhpcy50ZXJtaW5hbCA9IG5ldyBUZXJtaW5hbCh0aGlzLmdldFh0ZXJtT3B0aW9ucygpKVxuXHRcdHRoaXMuZml0QWRkb24gPSBuZXcgRml0QWRkb24oKVxuXHRcdHRoaXMudGVybWluYWwubG9hZEFkZG9uKHRoaXMuZml0QWRkb24pXG5cdFx0aWYgKHRoaXMubW9kZWwucHJvZmlsZS53ZWJMaW5rcykge1xuXHRcdFx0dGhpcy50ZXJtaW5hbC5sb2FkQWRkb24obmV3IFdlYkxpbmtzQWRkb24oKGUsIHVyaSkgPT4geyBzaGVsbC5vcGVuRXh0ZXJuYWwodXJpKSB9KSlcblx0XHR9XG5cdFx0dGhpcy50ZXJtaW5hbC5vcGVuKHRoaXMudGVybWluYWxEaXYpXG5cdFx0aWYgKHRoaXMubW9kZWwucHJvZmlsZS53ZWJnbCkge1xuXHRcdFx0dGhpcy50ZXJtaW5hbC5sb2FkQWRkb24obmV3IFdlYmdsQWRkb24oKSlcblx0XHR9XG5cdFx0dGhpcy50ZXJtaW5hbC5sb2FkQWRkb24obmV3IExpZ2F0dXJlc0FkZG9uKCkpXG5cdFx0dGhpcy5wdHlQcm9jZXNzQ29scyA9IDgwXG5cdFx0dGhpcy5wdHlQcm9jZXNzUm93cyA9IDI1XG5cdFx0dGhpcy5yZWZpdFRlcm1pbmFsKClcblx0XHR0aGlzLnB0eVByb2Nlc3MgPSBudWxsXG5cdFx0dGhpcy5wdHlQcm9jZXNzUnVubmluZyA9IGZhbHNlXG5cdFx0dGhpcy5kaXNwb3NhYmxlcy5hZGQodGhpcy50ZXJtaW5hbC5vbkRhdGEoKGRhdGEpID0+IHtcblx0XHRcdGlmICh0aGlzLmlzUHR5UHJvY2Vzc1J1bm5pbmcoKSkge1xuXHRcdFx0XHR0aGlzLnB0eVByb2Nlc3Mud3JpdGUoZGF0YSlcblx0XHRcdH1cblx0XHR9KSlcblx0XHR0aGlzLmRpc3Bvc2FibGVzLmFkZCh0aGlzLnRlcm1pbmFsLm9uU2VsZWN0aW9uQ2hhbmdlKCgpID0+IHtcblx0XHRcdGlmICh0aGlzLm1vZGVsLnByb2ZpbGUuY29weU9uU2VsZWN0KSB7XG5cdFx0XHRcdGxldCB0ZXh0ID0gdGhpcy50ZXJtaW5hbC5nZXRTZWxlY3Rpb24oKVxuXHRcdFx0XHRpZiAodGV4dCkge1xuXHRcdFx0XHRcdGNvbnN0IHJhd0xpbmVzID0gdGV4dC5zcGxpdCgvXFxyP1xcbi9nKVxuXHRcdFx0XHRcdGNvbnN0IGxpbmVzID0gcmF3TGluZXMubWFwKGxpbmUgPT4gbGluZS5yZXBsYWNlKC9cXHMvZywgJyAnKS50cmltUmlnaHQoKSlcblx0XHRcdFx0XHR0ZXh0ID0gbGluZXMuam9pbignXFxuJylcblx0XHRcdFx0XHRhdG9tLmNsaXBib2FyZC53cml0ZSh0ZXh0KVxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0fSkpXG5cdFx0dGhpcy5kaXNwb3NhYmxlcy5hZGQodGhpcy5wcm9maWxlc1NpbmdsZXRvbi5vbkRpZFJlc2V0QmFzZVByb2ZpbGUoKGJhc2VQcm9maWxlKSA9PiB7XG5cdFx0XHRjb25zdCBmcm9udEVuZFNldHRpbmdzID0ge31cblx0XHRcdGZvciAoY29uc3QgZGF0YSBvZiBDT05GSUdfREFUQSkge1xuXHRcdFx0XHRpZiAoIWRhdGEucHJvZmlsZUtleSkgY29udGludWVcblx0XHRcdFx0aWYgKGRhdGEudGVybWluYWxGcm9udEVuZCkge1xuXHRcdFx0XHRcdGZyb250RW5kU2V0dGluZ3NbZGF0YS5wcm9maWxlS2V5XSA9IGJhc2VQcm9maWxlW2RhdGEucHJvZmlsZUtleV1cblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdFx0Y29uc3QgcHJvZmlsZUNoYW5nZXMgPSB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmRpZmZQcm9maWxlcyhcblx0XHRcdFx0dGhpcy5tb2RlbC5nZXRQcm9maWxlKCksXG5cdFx0XHRcdC8vIE9ubHkgYWxsb3cgY2hhbmdlcyB0byBzZXR0aW5ncyByZWxhdGVkIHRvIHRoZSB0ZXJtaW5hbCBmcm9udCBlbmRcblx0XHRcdFx0Ly8gdG8gYmUgYXBwbGllZCB0byBleGlzdGluZyB0ZXJtaW5hbHMuXG5cdFx0XHRcdGZyb250RW5kU2V0dGluZ3MsXG5cdFx0XHQpXG5cdFx0XHR0aGlzLm1vZGVsLmFwcGx5UHJvZmlsZUNoYW5nZXMocHJvZmlsZUNoYW5nZXMpXG5cdFx0fSkpXG5cdFx0aWYgKHRoaXMuaXNQcm9tcHRUb1N0YXJ0dXAoKSkge1xuXHRcdFx0dGhpcy5wcm9tcHRUb1N0YXJ0dXAoKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRhd2FpdCB0aGlzLnJlc3RhcnRQdHlQcm9jZXNzKClcblx0XHR9XG5cdH1cblxuXHRzaG93Tm90aWZpY2F0aW9uIChtZXNzYWdlLCBpbmZvVHlwZSwgcmVzdGFydEJ1dHRvblRleHQgPSAnUmVzdGFydCcpIHtcblx0XHRjb25zdCBtZXNzYWdlRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHRjb25zdCByZXN0YXJ0QnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJylcblx0XHRyZXN0YXJ0QnV0dG9uLmNsYXNzTGlzdC5hZGQoJ2J0bicpXG5cdFx0cmVzdGFydEJ1dHRvbi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShyZXN0YXJ0QnV0dG9uVGV4dCkpXG5cdFx0cmVzdGFydEJ1dHRvbi5hZGRFdmVudExpc3RlbmVyKCdjbGljaycsIChldmVudCkgPT4ge1xuXHRcdFx0dGhpcy5yZXN0YXJ0UHR5UHJvY2VzcygpXG5cdFx0fSwgeyBwYXNzaXZlOiB0cnVlIH0pXG5cdFx0cmVzdGFydEJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdidG4tJyArIGluZm9UeXBlKVxuXHRcdHJlc3RhcnRCdXR0b24uY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1yZXN0YXJ0LWJ0bicpXG5cdFx0bWVzc2FnZURpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLW5vdGljZS0nICsgaW5mb1R5cGUpXG5cdFx0bWVzc2FnZURpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZShtZXNzYWdlKSlcblx0XHRtZXNzYWdlRGl2LmFwcGVuZENoaWxkKHJlc3RhcnRCdXR0b24pXG5cdFx0dGhpcy50b3BEaXYuaW5uZXJIVE1MID0gJydcblx0XHR0aGlzLnRvcERpdi5hcHBlbmRDaGlsZChtZXNzYWdlRGl2KVxuXHRcdGlmIChpbmZvVHlwZSA9PT0gJ3N1Y2Nlc3MnKSB7XG5cdFx0XHRhdG9tLm5vdGlmaWNhdGlvbnMuYWRkU3VjY2VzcyhtZXNzYWdlKVxuXHRcdH0gZWxzZSBpZiAoaW5mb1R5cGUgPT09ICdlcnJvcicpIHtcblx0XHRcdGF0b20ubm90aWZpY2F0aW9ucy5hZGRFcnJvcihtZXNzYWdlKVxuXHRcdH0gZWxzZSBpZiAoaW5mb1R5cGUgPT09ICd3YXJuaW5nJykge1xuXHRcdFx0YXRvbS5ub3RpZmljYXRpb25zLmFkZFdhcm5pbmcobWVzc2FnZSlcblx0XHR9IGVsc2UgaWYgKGluZm9UeXBlID09PSAnaW5mbycpIHtcblx0XHRcdGF0b20ubm90aWZpY2F0aW9ucy5hZGRJbmZvKG1lc3NhZ2UpXG5cdFx0fSBlbHNlIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcignVW5rbm93biBpbmZvIHR5cGU6ICcgKyBpbmZvVHlwZSlcblx0XHR9XG5cdH1cblxuXHRhc3luYyBwcm9tcHRUb1N0YXJ0dXAgKCkge1xuXHRcdGxldCBtZXNzYWdlXG5cdFx0aWYgKHRoaXMubW9kZWwucHJvZmlsZS50aXRsZSA9PT0gbnVsbCkge1xuXHRcdFx0Y29uc3QgY29tbWFuZCA9IFt0aGlzLmdldFNoZWxsQ29tbWFuZCgpXVxuXHRcdFx0Y29tbWFuZC5wdXNoKC4uLnRoaXMuZ2V0QXJncygpKVxuXHRcdFx0bWVzc2FnZSA9IGBOZXcgY29tbWFuZCAke0pTT04uc3RyaW5naWZ5KGNvbW1hbmQpfSByZWFkeSB0byBzdGFydC5gXG5cdFx0fSBlbHNlIHtcblx0XHRcdG1lc3NhZ2UgPSBgTmV3IGNvbW1hbmQgZm9yIHByb2ZpbGUgJHt0aGlzLm1vZGVsLnByb2ZpbGUudGl0bGV9IHJlYWR5IHRvIHN0YXJ0LmBcblx0XHR9XG5cdFx0dGhpcy5zaG93Tm90aWZpY2F0aW9uKFxuXHRcdFx0bWVzc2FnZSxcblx0XHRcdCdpbmZvJyxcblx0XHRcdCdTdGFydCcsXG5cdFx0KVxuXHR9XG5cblx0YXN5bmMgcmVzdGFydFB0eVByb2Nlc3MgKCkge1xuXHRcdGNvbnN0IGN3ZCA9IGF3YWl0IHRoaXMuZ2V0Q3dkKClcblx0XHRpZiAodGhpcy5wdHlQcm9jZXNzUnVubmluZykge1xuXHRcdFx0dGhpcy5wdHlQcm9jZXNzLnJlbW92ZUFsbExpc3RlbmVycygnZXhpdCcpXG5cdFx0XHR0aGlzLnB0eVByb2Nlc3Mua2lsbCgpXG5cdFx0fVxuXHRcdC8vIFJlc2V0IHRoZSB0ZXJtaW5hbC5cblx0XHR0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudC5oaWRlUHJvZmlsZU1lbnUoKVxuXHRcdHRoaXMudGVybWluYWwucmVzZXQoKVxuXG5cdFx0Ly8gU2V0dXAgcHR5IHByb2Nlc3MuXG5cdFx0dGhpcy5wdHlQcm9jZXNzQ29tbWFuZCA9IHRoaXMuZ2V0U2hlbGxDb21tYW5kKClcblx0XHR0aGlzLnB0eVByb2Nlc3NBcmdzID0gdGhpcy5nZXRBcmdzKClcblx0XHRjb25zdCBuYW1lID0gdGhpcy5nZXRUZXJtVHlwZSgpXG5cdFx0Y29uc3QgZW52ID0gdGhpcy5nZXRFbnYoKVxuXHRcdGNvbnN0IGVuY29kaW5nID0gdGhpcy5nZXRFbmNvZGluZygpXG5cblx0XHQvLyBBdHRhY2ggcHR5IHByb2Nlc3MgdG8gdGVybWluYWwuXG5cdFx0Ly8gTk9URTogVGhpcyBtdXN0IGJlIGRvbmUgYWZ0ZXIgdGhlIHRlcm1pbmFsIGlzIGF0dGFjaGVkIHRvIHRoZVxuXHRcdC8vIHBhcmVudCBlbGVtZW50IGFuZCByZWZpdHRlZC5cblx0XHR0aGlzLnB0eVByb2Nlc3NPcHRpb25zID0ge1xuXHRcdFx0bmFtZTogbmFtZSxcblx0XHRcdGN3ZDogY3dkLFxuXHRcdFx0ZW52OiBlbnYsXG5cdFx0fVxuXHRcdGlmIChlbmNvZGluZykge1xuXHRcdFx0Ly8gVGhlcmUncyBzb21lIGlzc3VlIGlmICdlbmNvZGluZz1udWxsJyBpcyBwYXNzZWQgaW4gdGhlIG9wdGlvbnMsXG5cdFx0XHQvLyB0aGVyZWZvcmUsIG9ubHkgc2V0IGl0IGlmIHRoZXJlJ3MgYW4gYWN0dWFsIGVuY29kaW5nIHRvIHNldC5cblx0XHRcdHRoaXMucHR5UHJvY2Vzc09wdGlvbnMuZW5jb2RpbmcgPSBlbmNvZGluZ1xuXHRcdH1cblxuXHRcdHRoaXMucHR5UHJvY2Vzc09wdGlvbnMuY29scyA9IHRoaXMucHR5UHJvY2Vzc0NvbHNcblx0XHR0aGlzLnB0eVByb2Nlc3NPcHRpb25zLnJvd3MgPSB0aGlzLnB0eVByb2Nlc3NSb3dzXG5cdFx0dGhpcy5wdHlQcm9jZXNzID0gbnVsbFxuXHRcdHRoaXMucHR5UHJvY2Vzc1J1bm5pbmcgPSBmYWxzZVxuXHRcdHRyeSB7XG5cdFx0XHR0aGlzLnB0eVByb2Nlc3MgPSBzcGF3blB0eSh0aGlzLnB0eVByb2Nlc3NDb21tYW5kLCB0aGlzLnB0eVByb2Nlc3NBcmdzLCB0aGlzLnB0eVByb2Nlc3NPcHRpb25zKVxuXG5cdFx0XHRpZiAodGhpcy5wdHlQcm9jZXNzKSB7XG5cdFx0XHRcdHRoaXMucHR5UHJvY2Vzc1J1bm5pbmcgPSB0cnVlXG5cdFx0XHRcdHRoaXMucHR5UHJvY2Vzcy5vbignZGF0YScsIChkYXRhKSA9PiB7XG5cdFx0XHRcdFx0Y29uc3Qgb2xkVGl0bGUgPSB0aGlzLm1vZGVsLnRpdGxlXG5cdFx0XHRcdFx0aWYgKHRoaXMubW9kZWwucHJvZmlsZS50aXRsZSAhPT0gbnVsbCkge1xuXHRcdFx0XHRcdFx0dGhpcy5tb2RlbC50aXRsZSA9IHRoaXMubW9kZWwucHJvZmlsZS50aXRsZVxuXHRcdFx0XHRcdH0gZWxzZSBpZiAocHJvY2Vzcy5wbGF0Zm9ybSAhPT0gJ3dpbjMyJykge1xuXHRcdFx0XHRcdFx0dGhpcy5tb2RlbC50aXRsZSA9IHRoaXMucHR5UHJvY2Vzcy5wcm9jZXNzXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdGlmIChvbGRUaXRsZSAhPT0gdGhpcy5tb2RlbC50aXRsZSkge1xuXHRcdFx0XHRcdFx0dGhpcy5tb2RlbC5lbWl0dGVyLmVtaXQoJ2RpZC1jaGFuZ2UtdGl0bGUnLCB0aGlzLm1vZGVsLnRpdGxlKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0XHR0aGlzLnRlcm1pbmFsLndyaXRlKGRhdGEpXG5cdFx0XHRcdFx0dGhpcy5tb2RlbC5oYW5kbGVOZXdEYXRhQXJyaXZhbCgpXG5cdFx0XHRcdH0pXG5cdFx0XHRcdHRoaXMucHR5UHJvY2Vzcy5vbignZXhpdCcsIChjb2RlLCBzaWduYWwpID0+IHtcblx0XHRcdFx0XHR0aGlzLnB0eVByb2Nlc3NSdW5uaW5nID0gZmFsc2Vcblx0XHRcdFx0XHRpZiAoIXRoaXMubGVhdmVPcGVuQWZ0ZXJFeGl0KCkpIHtcblx0XHRcdFx0XHRcdHRoaXMubW9kZWwuZXhpdCgpXG5cdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdGlmIChjb2RlID09PSAwKSB7XG5cdFx0XHRcdFx0XHRcdHRoaXMuc2hvd05vdGlmaWNhdGlvbihcblx0XHRcdFx0XHRcdFx0XHQnVGhlIHRlcm1pbmFsIHByb2Nlc3MgaGFzIGZpbmlzaGVkIHN1Y2Nlc3NmdWxseS4nLFxuXHRcdFx0XHRcdFx0XHRcdCdzdWNjZXNzJyxcblx0XHRcdFx0XHRcdFx0KVxuXHRcdFx0XHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0XHRcdFx0dGhpcy5zaG93Tm90aWZpY2F0aW9uKFxuXHRcdFx0XHRcdFx0XHRcdCdUaGUgdGVybWluYWwgcHJvY2VzcyBoYXMgZXhpdGVkIHdpdGggZmFpbHVyZSBjb2RlIFxcJycgKyBjb2RlICsgJ1xcJy4nLFxuXHRcdFx0XHRcdFx0XHRcdCdlcnJvcicsXG5cdFx0XHRcdFx0XHRcdClcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHR9XG5cdFx0XHRcdH0pXG5cdFx0XHRcdHRoaXMudG9wRGl2LmlubmVySFRNTCA9ICcnXG5cdFx0XHR9XG5cdFx0fSBjYXRjaCAoZXJyKSB7XG5cdFx0XHRsZXQgbWVzc2FnZSA9ICdMYXVuY2hpbmcgXFwnJyArIHRoaXMucHR5UHJvY2Vzc0NvbW1hbmQgKyAnXFwnIHJhaXNlZCB0aGUgZm9sbG93aW5nIGVycm9yOiAnICsgZXJyLm1lc3NhZ2Vcblx0XHRcdGlmIChlcnIubWVzc2FnZS5zdGFydHNXaXRoKCdGaWxlIG5vdCBmb3VuZDonKSkge1xuXHRcdFx0XHRtZXNzYWdlID0gJ0NvdWxkIG5vdCBmaW5kIGNvbW1hbmQgXFwnJyArIHRoaXMucHR5UHJvY2Vzc0NvbW1hbmQgKyAnXFwnLidcblx0XHRcdH1cblx0XHRcdHRoaXMuc2hvd05vdGlmaWNhdGlvbihcblx0XHRcdFx0bWVzc2FnZSxcblx0XHRcdFx0J2Vycm9yJyxcblx0XHRcdClcblx0XHR9XG5cdH1cblxuXHRjbGVhciAoKSB7XG5cdFx0aWYgKHRoaXMudGVybWluYWwpIHtcblx0XHRcdHJldHVybiB0aGlzLnRlcm1pbmFsLmNsZWFyKClcblx0XHR9XG5cdH1cblxuXHRhcHBseVBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zICgpIHtcblx0XHQvLyBGb3IgYW55IGNoYW5nZXMgaW52b2x2aW5nIHRoZSB4dGVybS5qcyBUZXJtaW5hbCBvYmplY3QsIG9ubHkgYXBwbHkgdGhlbVxuXHRcdC8vIHdoZW4gdGhlIHRlcm1pbmFsIGlzIHZpc2libGUuXG5cdFx0aWYgKHRoaXMudGVybWluYWxEaXZJbml0aWFsbHlWaXNpYmxlKSB7XG5cdFx0XHRjb25zdCB4dGVybU9wdGlvbnMgPSB0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zLnh0ZXJtT3B0aW9ucyB8fCB7fVxuXHRcdFx0Ly8gTk9URTogRm9yIGxlZ2FjeSByZWFzb25zLCB0aGUgZm9udCBzaXplIGlzIGRlZmluZWQgZnJvbSB0aGUgJ2ZvbnRTaXplJ1xuXHRcdFx0Ly8ga2V5IG91dHNpZGUgb2YgYW55IGRlZmluZWQgeHRlcm0uanMgVGVybWluYWwgb3B0aW9ucy5cblx0XHRcdGRlbGV0ZSB4dGVybU9wdGlvbnMuZm9udFNpemVcblx0XHRcdGlmICgnZm9udFNpemUnIGluIHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMpIHtcblx0XHRcdFx0eHRlcm1PcHRpb25zLmZvbnRTaXplID0gdGhpcy5wZW5kaW5nVGVybWluYWxQcm9maWxlT3B0aW9ucy5mb250U2l6ZVxuXHRcdFx0XHRkZWxldGUgdGhpcy5wZW5kaW5nVGVybWluYWxQcm9maWxlT3B0aW9ucy5mb250U2l6ZVxuXHRcdFx0fVxuXHRcdFx0ZGVsZXRlIHh0ZXJtT3B0aW9ucy5mb250RmFtaWx5XG5cdFx0XHRpZiAoJ2ZvbnRGYW1pbHknIGluIHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMpIHtcblx0XHRcdFx0eHRlcm1PcHRpb25zLmZvbnRGYW1pbHkgPSB0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zLmZvbnRGYW1pbHlcblx0XHRcdFx0ZGVsZXRlIHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMuZm9udEZhbWlseVxuXHRcdFx0fVxuXHRcdFx0ZGVsZXRlIHh0ZXJtT3B0aW9ucy50aGVtZVxuXHRcdFx0aWYgKFxuXHRcdFx0XHQndGhlbWUnIGluIHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMgfHxcblx0XHRcdFx0T2JqZWN0LnZhbHVlcyhDT0xPUlMpLnNvbWUoYyA9PiBjIGluIHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMpXG5cdFx0XHQpIHtcblx0XHRcdFx0eHRlcm1PcHRpb25zLnRoZW1lID0gdGhpcy5nZXRUaGVtZSh0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zKVxuXHRcdFx0XHRkZWxldGUgdGhpcy5wZW5kaW5nVGVybWluYWxQcm9maWxlT3B0aW9ucy50aGVtZVxuXHRcdFx0XHRPYmplY3QudmFsdWVzKENPTE9SUykuZm9yRWFjaChjID0+IGRlbGV0ZSB0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zW2NdKVxuXHRcdFx0fVxuXHRcdFx0dGhpcy5zZXRNYWluQmFja2dyb3VuZENvbG9yKClcblx0XHRcdGZvciAoY29uc3Qga2V5IG9mIE9iamVjdC5rZXlzKHh0ZXJtT3B0aW9ucykpIHtcblx0XHRcdFx0dGhpcy50ZXJtaW5hbC5zZXRPcHRpb24oa2V5LCB4dGVybU9wdGlvbnNba2V5XSlcblx0XHRcdH1cblx0XHRcdGRlbGV0ZSB0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zLnh0ZXJtT3B0aW9uc1xuXG5cdFx0XHQvLyBSZXN0YXJ0IHRoZSBwdHkgcHJvY2VzcyBpZiBjaGFuZ2VzIHRvIHRoZSBwdHkgcHJvY2VzcyBzZXR0aW5ncyBhcmVcblx0XHRcdC8vIGJlaW5nIG1hZGUuXG5cdFx0XHQvLyBOT1RFOiBXaGVuIGFwcGx5aW5nIG5ldyBwdHkgc2V0dGluZ3MsIHRoZSB0ZXJtaW5hbCBzdGlsbCBuZWVkcyB0byBiZVxuXHRcdFx0Ly8gdmlzaWJsZS5cblx0XHRcdGNvbnN0IGEgPSBuZXcgU2V0KE9iamVjdC5rZXlzKHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMpKVxuXHRcdFx0Y29uc3QgaW50ZXJzZWN0aW9uID0gbmV3IFNldChbLi4uYV0uZmlsdGVyKHggPT4gUFRZX1BST0NFU1NfT1BUSU9OUy5oYXMoeCkpKVxuXHRcdFx0aWYgKGludGVyc2VjdGlvbi5zaXplICE9PSAwKSB7XG5cdFx0XHRcdHRoaXMucmVzdGFydFB0eVByb2Nlc3MoKVxuXHRcdFx0XHRmb3IgKGNvbnN0IGtleSBvZiBpbnRlcnNlY3Rpb24pIHtcblx0XHRcdFx0XHRkZWxldGUgdGhpcy5wZW5kaW5nVGVybWluYWxQcm9maWxlT3B0aW9uc1trZXldXG5cdFx0XHRcdH1cblx0XHRcdH1cblxuXHRcdFx0dGhpcy5yZWZpdFRlcm1pbmFsKClcblx0XHR9XG5cblx0XHQvLyB4LXRlcm1pbmFsIHNwZWNpZmljIG9wdGlvbnMgY2FuIGJlIHJlbW92ZWQgc2luY2UgYXQgdGhpcyBwb2ludCB0aGV5XG5cdFx0Ly8gc2hvdWxkIGFscmVhZHkgYmUgYXBwbGllZCBpbiB0aGUgdGVybWluYWwncyBwcm9maWxlLlxuXHRcdGZvciAoY29uc3Qga2V5IG9mIFhfVEVSTUlOQUxfT1BUSU9OUykge1xuXHRcdFx0ZGVsZXRlIHRoaXMucGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnNba2V5XVxuXHRcdH1cblx0fVxuXG5cdHJlZml0VGVybWluYWwgKCkge1xuXHRcdC8vIE9ubHkgcmVmaXQgdGhlIHRlcm1pbmFsIHdoZW4gaXQgaXMgY29tcGxldGVseSB2aXNpYmxlLlxuXHRcdGlmIChcblx0XHRcdHRoaXMudGVybWluYWxEaXZJbml0aWFsbHlWaXNpYmxlICYmXG5cdFx0XHR0aGlzLm1haW5EaXZDb250ZW50UmVjdCAmJlxuXHRcdFx0dGhpcy5tYWluRGl2Q29udGVudFJlY3Qud2lkdGggPiAwICYmXG5cdFx0XHR0aGlzLm1haW5EaXZDb250ZW50UmVjdC5oZWlnaHQgPiAwXG5cdFx0KSB7XG5cdFx0XHR0aGlzLmZpdEFkZG9uLmZpdCgpXG5cdFx0XHRjb25zdCBnZW9tZXRyeSA9IHRoaXMuZml0QWRkb24ucHJvcG9zZURpbWVuc2lvbnMoKVxuXHRcdFx0aWYgKGdlb21ldHJ5ICYmIHRoaXMuaXNQdHlQcm9jZXNzUnVubmluZygpKSB7XG5cdFx0XHRcdC8vIFJlc2l6ZSBwdHkgcHJvY2Vzc1xuXHRcdFx0XHRpZiAodGhpcy5wdHlQcm9jZXNzQ29scyAhPT0gZ2VvbWV0cnkuY29scyB8fCB0aGlzLnB0eVByb2Nlc3NSb3dzICE9PSBnZW9tZXRyeS5yb3dzKSB7XG5cdFx0XHRcdFx0dGhpcy5wdHlQcm9jZXNzLnJlc2l6ZShnZW9tZXRyeS5jb2xzLCBnZW9tZXRyeS5yb3dzKVxuXHRcdFx0XHRcdHRoaXMucHR5UHJvY2Vzc0NvbHMgPSBnZW9tZXRyeS5jb2xzXG5cdFx0XHRcdFx0dGhpcy5wdHlQcm9jZXNzUm93cyA9IGdlb21ldHJ5LnJvd3Ncblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGZvY3VzT25UZXJtaW5hbCAoZG91YmxlKSB7XG5cdFx0aWYgKHRoaXMudGVybWluYWwpIHtcblx0XHRcdHRoaXMubW9kZWwuc2V0QWN0aXZlKClcblx0XHRcdHRoaXMudGVybWluYWwuZm9jdXMoKVxuXHRcdFx0aWYgKGRvdWJsZSkge1xuXHRcdFx0XHQvLyBzZWNvbmQgZm9jdXMgd2lsbCBzZW5kIGNvbW1hbmQgdG8gcHR5XG5cdFx0XHRcdHRoaXMudGVybWluYWwuZm9jdXMoKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGFzeW5jIHRvZ2dsZVByb2ZpbGVNZW51ICgpIHtcblx0XHQvLyBUaGUgcHJvZmlsZSBtZW51IG5lZWRzIHRvIGJlIGluaXRpYWxpemVkIGJlZm9yZSBpdCBjYW4gYmUgdG9nZ2xlZC5cblx0XHRhd2FpdCB0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudC5pbml0aWFsaXplZFByb21pc2Vcblx0XHR0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudC50b2dnbGVQcm9maWxlTWVudSgpXG5cdH1cblxuXHRoaWRlVGVybWluYWwgKCkge1xuXHRcdHRoaXMudGVybWluYWxEaXYuc3R5bGUudmlzaWJpbGl0eSA9ICdoaWRkZW4nXG5cdH1cblxuXHRzaG93VGVybWluYWwgKCkge1xuXHRcdHRoaXMudGVybWluYWxEaXYuc3R5bGUudmlzaWJpbGl0eSA9ICd2aXNpYmxlJ1xuXHR9XG5cblx0cXVldWVOZXdQcm9maWxlQ2hhbmdlcyAocHJvZmlsZUNoYW5nZXMpIHtcblx0XHR0aGlzLnBlbmRpbmdUZXJtaW5hbFByb2ZpbGVPcHRpb25zID0ge1xuXHRcdFx0Li4udGhpcy5wZW5kaW5nVGVybWluYWxQcm9maWxlT3B0aW9ucyxcblx0XHRcdC4uLnByb2ZpbGVDaGFuZ2VzLFxuXHRcdH1cblx0XHR0aGlzLmFwcGx5UGVuZGluZ1Rlcm1pbmFsUHJvZmlsZU9wdGlvbnMoKVxuXHR9XG59XG5cbmNvbnN0IFhUZXJtaW5hbEVsZW1lbnQgPSBkb2N1bWVudC5yZWdpc3RlckVsZW1lbnQoJ3gtdGVybWluYWwnLCB7XG5cdHByb3RvdHlwZTogWFRlcm1pbmFsRWxlbWVudEltcGwucHJvdG90eXBlLFxufSlcblxuZXhwb3J0IHtcblx0WFRlcm1pbmFsRWxlbWVudCxcbn1cbiJdfQ==