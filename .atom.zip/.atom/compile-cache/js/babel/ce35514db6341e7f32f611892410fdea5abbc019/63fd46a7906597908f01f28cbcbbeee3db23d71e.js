Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

'use babel';
exports['default'] = {
  splitCells: function splitCells(line) {
    return line.trim().replace(/[ ]{2,}/g, '\t').split(/\t+/);
  },
  getCurrentResource: function getCurrentResource(path, autocompleteRobotProvider) {
    path = _path2['default'].normalize(path);
    for (var resourceKey of autocompleteRobotProvider.getResourceKeys()) {
      var resource = autocompleteRobotProvider.getResourceByKey(resourceKey);
      if (resource && path === resource.path) {
        return resource;
      }
    }
    return undefined;
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2h5cGVyY2xpY2stcm9ib3QtZnJhbWV3b3JrL2xpYi9jb21tb24uanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O29CQUNzQixNQUFNOzs7O0FBRDVCLFdBQVcsQ0FBQTtxQkFHSTtBQUNiLFlBQVUsRUFBQSxvQkFBQyxJQUFJLEVBQUM7QUFDZCxXQUFPLElBQUksQ0FBQyxJQUFJLEVBQUUsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsQ0FBQztHQUMzRDtBQUNELG9CQUFrQixFQUFBLDRCQUFDLElBQUksRUFBRSx5QkFBeUIsRUFBQztBQUNqRCxRQUFJLEdBQUcsa0JBQVUsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ2hDLFNBQUksSUFBTSxXQUFXLElBQUkseUJBQXlCLENBQUMsZUFBZSxFQUFFLEVBQUM7QUFDbkUsVUFBTSxRQUFRLEdBQUcseUJBQXlCLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDeEUsVUFBRyxRQUFRLElBQUksSUFBSSxLQUFHLFFBQVEsQ0FBQyxJQUFJLEVBQUM7QUFDbEMsZUFBTyxRQUFRLENBQUE7T0FDaEI7S0FDRjtBQUNELFdBQU8sU0FBUyxDQUFBO0dBQ2pCO0NBQ0YiLCJmaWxlIjoiZmlsZTovLy9DOi9Vc2Vycy9GcmFuY2lzY28vLmF0b20vcGFja2FnZXMvaHlwZXJjbGljay1yb2JvdC1mcmFtZXdvcmsvbGliL2NvbW1vbi5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnXG5pbXBvcnQgcGF0aFV0aWxzIGZyb20gJ3BhdGgnXG5cbmV4cG9ydCBkZWZhdWx0IHtcbiAgc3BsaXRDZWxscyhsaW5lKXtcbiAgICByZXR1cm4gbGluZS50cmltKCkucmVwbGFjZSgvWyBdezIsfS9nLCAnXFx0Jykuc3BsaXQoL1xcdCsvKTtcbiAgfSxcbiAgZ2V0Q3VycmVudFJlc291cmNlKHBhdGgsIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIpe1xuICAgIHBhdGggPSBwYXRoVXRpbHMubm9ybWFsaXplKHBhdGgpXG4gICAgZm9yKGNvbnN0IHJlc291cmNlS2V5IG9mIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VLZXlzKCkpe1xuICAgICAgY29uc3QgcmVzb3VyY2UgPSBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyLmdldFJlc291cmNlQnlLZXkocmVzb3VyY2VLZXkpXG4gICAgICBpZihyZXNvdXJjZSAmJiBwYXRoPT09cmVzb3VyY2UucGF0aCl7XG4gICAgICAgIHJldHVybiByZXNvdXJjZVxuICAgICAgfVxuICAgIH1cbiAgICByZXR1cm4gdW5kZWZpbmVkXG4gIH1cbn1cbiJdfQ==