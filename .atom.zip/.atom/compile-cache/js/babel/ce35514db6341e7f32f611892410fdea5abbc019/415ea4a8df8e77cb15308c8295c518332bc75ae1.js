Object.defineProperty(exports, '__esModule', {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

exports.resetConfigDefaults = resetConfigDefaults;

var setInitialCommand = _asyncToGenerator(function* (which) {
	var command = undefined;
	if (process.platform === 'win32') {
		try {
			command = yield which('pwsh.exe');
		} catch (e1) {
			try {
				command = yield which('powershell.exe');
			} catch (e2) {
				// powershell not found
			}
		}
	}

	if (command && atom.config.get('x-terminal.spawnPtySettings.command') === configDefaults.command) {
		atom.config.set('x-terminal.spawnPtySettings.command', command);
	}
}

// set shell command automatically on first install
);

exports.setInitialCommand = setInitialCommand;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _which = require('which');

var _which2 = _interopRequireDefault(_which);

function resetConfigDefaults() {
	return {
		command: process.platform === 'win32' ? process.env.COMSPEC || 'cmd.exe' : process.env.SHELL || '/bin/sh',
		args: '[]',
		termType: process.env.TERM || 'xterm-256color',
		cwd: process.platform === 'win32' ? process.env.USERPROFILE : process.env.HOME,
		projectCwd: false,
		webgl: false,
		webLinks: true,
		env: '',
		setEnv: '{}',
		deleteEnv: '["NODE_ENV"]',
		encoding: '',
		fontSize: 14,
		// NOTE: Atom will crash if the font is set below 8.
		minimumFontSize: 8,
		maximumFontSize: 100,
		useEditorFont: true,
		fontFamily: atom.config.get('editor.fontFamily') || 'monospace',
		theme: 'Custom',
		colorForeground: '#ffffff',
		colorBackground: '#000000',
		colorCursor: '#ffffff',
		colorCursorAccent: '#000000',
		colorSelection: '#4d4d4d',
		colorBlack: '#2e3436',
		colorRed: '#cc0000',
		colorGreen: '#4e9a06',
		colorYellow: '#c4a000',
		colorBlue: '#3465a4',
		colorMagenta: '#75507b',
		colorCyan: '#06989a',
		colorWhite: '#d3d7cf',
		colorBrightBlack: '#555753',
		colorBrightRed: '#ef2929',
		colorBrightGreen: '#8ae234',
		colorBrightYellow: '#fce94f',
		colorBrightBlue: '#729fcf',
		colorBrightMagenta: '#ad7fa8',
		colorBrightCyan: '#34e2e2',
		colorBrightWhite: '#eeeeec',
		allowHiddenToStayActive: false,
		runInActive: false,
		leaveOpenAfterExit: true,
		allowRelaunchingTerminalsOnStartup: true,
		relaunchTerminalOnStartup: true,
		userDataPath: (function () {
			var appDataPath = undefined;
			if (process.platform === 'win32') {
				appDataPath = process.env.APPDATA || _path2['default'].join(_os2['default'].homedir(), 'AppData', 'Roaming');
			} else if (process.platform === 'darwin') {
				appDataPath = _path2['default'].join(_os2['default'].homedir(), 'Library', 'Application Support');
			} else {
				appDataPath = process.env.XDG_CONFIG_HOME || _path2['default'].join(_os2['default'].homedir(), '.config');
			}
			return _path2['default'].join(appDataPath, 'x-terminal');
		})(),
		title: '',
		xtermOptions: '{}',
		promptToStartup: false,
		copyOnSelect: false,
		apiOpenPosition: 'Center'
	};
}

var configDefaults = resetConfigDefaults();

exports.configDefaults = configDefaults;
function configOrder(obj) {
	var order = 1;
	for (var _name in obj) {
		obj[_name].order = order++;
		if (obj[_name].type === 'object' && 'properties' in obj[_name]) {
			configOrder(obj[_name].properties);
		}
	}
	return obj;
}

var config = configOrder({
	spawnPtySettings: {
		title: 'Shell Process Settings',
		description: 'Settings related to the process running the shell.',
		type: 'object',
		properties: {
			command: {
				title: 'Command',
				description: 'Command to run',
				type: 'string',
				'default': configDefaults.command,
				profileData: {
					defaultProfile: configDefaults.command,
					toUrlParam: function toUrlParam(val) {
						return val;
					},
					fromUrlParam: function fromUrlParam(val) {
						return val;
					},
					checkUrlParam: function checkUrlParam(val) {
						return true;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return atom.config.get('x-terminal.spawnPtySettings.command') || configDefaults.command;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.getModel().getText() || baseValue;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			args: {
				title: 'Arguments',
				description: 'Arguments to pass to command, must be in a [JSON array](https://www.w3schools.com/JS/js_json_arrays.asp).',
				type: 'string',
				'default': configDefaults.args,
				profileData: {
					defaultProfile: JSON.parse(configDefaults.args),
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return !!val;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateJsonConfigSetting('x-terminal.spawnPtySettings.args', configDefaults.args, previousValue);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return parseJson(element.getModel().getText(), baseValue, Array);
					},
					toMenuSetting: function toMenuSetting(val) {
						return JSON.stringify(val);
					}
				}
			},
			name: {
				title: 'Terminal Type',
				description: 'The terminal type to use.',
				type: 'string',
				'default': configDefaults.termType,
				profileData: {
					defaultProfile: configDefaults.termType,
					toUrlParam: function toUrlParam(val) {
						return val;
					},
					fromUrlParam: function fromUrlParam(val) {
						return val;
					},
					checkUrlParam: function checkUrlParam(val) {
						return true;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return atom.config.get('x-terminal.spawnPtySettings.name') || configDefaults.termType;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.getModel().getText() || baseValue;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			cwd: {
				title: 'Working Directory',
				description: 'The working directory to use when launching command.',
				type: 'string',
				'default': configDefaults.cwd,
				profileData: {
					defaultProfile: configDefaults.cwd,
					toUrlParam: function toUrlParam(val) {
						return val;
					},
					fromUrlParam: function fromUrlParam(val) {
						return val;
					},
					checkUrlParam: function checkUrlParam(val) {
						return true;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return atom.config.get('x-terminal.spawnPtySettings.cwd') || configDefaults.cwd;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.getModel().getText() || baseValue;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			projectCwd: {
				title: 'Use Project Directory',
				description: 'Use project directory if cwd is in a project when launching command.',
				type: 'boolean',
				'default': configDefaults.projectCwd,
				profileData: {
					defaultProfile: configDefaults.projectCwd,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.spawnPtySettings.projectCwd', configDefaults.projectCwd);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			env: {
				title: 'Environment',
				description: 'The environment to use when launching command, must be in a [JSON object](https://www.w3schools.com/JS/js_json_objects.asp). If not set, defaults to the current environment.',
				type: 'string',
				'default': configDefaults.env,
				profileData: {
					defaultProfile: null,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return !!val;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						var env = validateJsonConfigSetting('x-terminal.spawnPtySettings.env', 'null');
						if (!env || env.constructor !== Object) {
							env = null;
						}
						return env;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return parseJson(element.getModel().getText(), baseValue, Object);
					},
					toMenuSetting: function toMenuSetting(val) {
						return convertNullToEmptyString(val);
					}
				}
			},
			setEnv: {
				title: 'Environment Overrides',
				description: 'Environment variables to use in place of the Atom process environment, must be in a [JSON object](https://www.w3schools.com/JS/js_json_objects.asp).',
				type: 'string',
				'default': configDefaults.setEnv,
				profileData: {
					defaultProfile: JSON.parse(configDefaults.setEnv),
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return !!val;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateJsonConfigSetting('x-terminal.spawnPtySettings.setEnv', configDefaults.setEnv);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return parseJson(element.getModel().getText(), baseValue, Object);
					},
					toMenuSetting: function toMenuSetting(val) {
						return JSON.stringify(val);
					}
				}
			},
			deleteEnv: {
				title: 'Environment Deletions',
				description: 'Environment variables to delete from original environment, must be in a [JSON array](https://www.w3schools.com/JS/js_json_arrays.asp).',
				type: 'string',
				'default': configDefaults.deleteEnv,
				profileData: {
					defaultProfile: JSON.parse(configDefaults.deleteEnv),
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return !!val;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateJsonConfigSetting('x-terminal.spawnPtySettings.deleteEnv', configDefaults.deleteEnv);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return parseJson(element.getModel().getText(), baseValue, Array);
					},
					toMenuSetting: function toMenuSetting(val) {
						return JSON.stringify(val);
					}
				}
			},
			encoding: {
				title: 'Character Encoding',
				description: 'Character encoding to use in spawned terminal.',
				type: 'string',
				'default': configDefaults.encoding,
				profileData: {
					defaultProfile: null,
					toUrlParam: function toUrlParam(val) {
						return val;
					},
					fromUrlParam: function fromUrlParam(val) {
						return val === 'null' ? null : val;
					},
					checkUrlParam: function checkUrlParam(val) {
						return true;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return atom.config.get('x-terminal.spawnPtySettings.encoding') || null;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.getModel().getText() || baseValue;
					},
					toMenuSetting: function toMenuSetting(val) {
						return convertNullToEmptyString(val);
					}
				}
			}
		}
	},
	xtermAddons: {
		title: 'xterm.js Addons',
		description: 'Select the xterm.js addons to enable',
		type: 'object',
		properties: {
			webgl: {
				title: 'WebGL Renderer',
				description: 'Enable the WebGL-based renderer using the **experimental** xterm.js [WebGL addon](https://github.com/xtermjs/xterm.js/tree/master/addons/xterm-addon-webgl)',
				type: 'boolean',
				'default': configDefaults.webgl,
				profileData: {
					defaultProfile: configDefaults.webgl,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.xtermAddons.webgl', configDefaults.webgl);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			webLinks: {
				title: 'Web Links',
				description: 'Enable clickable web links using the xterm.js [Web links addon](https://github.com/xtermjs/xterm.js/tree/master/addons/xterm-addon-web-links)',
				type: 'boolean',
				'default': configDefaults.webLinks,
				profileData: {
					defaultProfile: configDefaults.webLinks,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.xtermAddons.webLinks', configDefaults.webLinks);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			}
		}
	},
	terminalSettings: {
		title: 'Terminal Emulator Settings',
		description: 'Settings for the terminal emulator.',
		type: 'object',
		properties: {
			title: {
				title: 'Terminal tab title',
				description: 'Title to use for terminal tabs.',
				type: 'string',
				'default': configDefaults.title,
				profileData: {
					defaultProfile: null,
					toUrlParam: function toUrlParam(val) {
						return val;
					},
					fromUrlParam: function fromUrlParam(val) {
						return val === 'null' ? null : val;
					},
					checkUrlParam: function checkUrlParam(val) {
						return true;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return atom.config.get('x-terminal.terminalSettings.title') || configDefaults.title || null;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.getModel().getText() || baseValue;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val || '';
					}
				}
			},
			xtermOptions: {
				title: 'xterm.js Terminal Options',
				description: 'Options to apply to xterm.js terminal objects, must be in a [JSON object](https://www.w3schools.com/JS/js_json_objects.asp). Read more on the supported [xterm.js API properties](https://xtermjs.org/docs/api/terminal/interfaces/iterminaloptions/#properties).',
				type: 'string',
				'default': configDefaults.xtermOptions,
				profileData: {
					terminalFrontEnd: true,
					defaultProfile: JSON.parse(configDefaults.xtermOptions),
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return !!val;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateJsonConfigSetting('x-terminal.terminalSettings.xtermOptions', configDefaults.xtermOptions, previousValue);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return parseJson(element.getModel().getText(), baseValue, Object);
					},
					toMenuSetting: function toMenuSetting(val) {
						return JSON.stringify(val);
					}
				}
			},
			useEditorFont: {
				title: 'Use editor\'s Font Family',
				description: 'Use editor\'s Font Family setting in the terminal. (Overrides Font Family below)',
				type: 'boolean',
				'default': configDefaults.useEditorFont,
				profileData: {
					defaultProfile: configDefaults.useEditorFont,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.terminalSettings.useEditorFont', configDefaults.useEditorFont);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			fontFamily: {
				title: 'Font Family',
				description: 'Font family used in terminal emulator.',
				type: 'string',
				'default': configDefaults.fontFamily,
				profileData: {
					terminalFrontEnd: true,
					defaultProfile: configDefaults.fontFamily,
					toUrlParam: function toUrlParam(val) {
						return val;
					},
					fromUrlParam: function fromUrlParam(val) {
						return val;
					},
					checkUrlParam: function checkUrlParam(val) {
						return true;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return getFontFamilyBaseProfile();
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.getModel().getText() || baseValue;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			fontSize: {
				title: 'Font Size',
				description: 'Font size used in terminal emulator.',
				type: 'integer',
				'default': configDefaults.fontSize,
				minimum: configDefaults.minimumFontSize,
				maximum: configDefaults.maximumFontSize,
				profileData: {
					terminalFrontEnd: true,
					defaultProfile: configDefaults.fontSize,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return !!val;
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return atom.config.get('x-terminal.terminalSettings.fontSize') || configDefaults.fontSize;
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return parseJson(element.getModel().getText(), baseValue, Number);
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			defaultOpenPosition: {
				title: 'Default Open Position',
				description: 'Position to open terminal through service API or x-terminal:open.',
				type: 'string',
				'enum': ['Center', 'Split Up', 'Split Down', 'Split Left', 'Split Right', 'Bottom Dock', 'Left Dock', 'Right Dock'],
				'default': configDefaults.apiOpenPosition
			},
			promptToStartup: {
				title: 'Prompt to start command',
				description: 'Whether to prompt to start command in terminal on startup.',
				type: 'boolean',
				'default': configDefaults.promptToStartup,
				profileData: {
					defaultProfile: configDefaults.promptToStartup,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.terminalSettings.promptToStartup', configDefaults.promptToStartup);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			allowHiddenToStayActive: {
				title: 'Allow Hidden Terminal To Stay Active',
				description: 'When an active terminal is hidden keep it active until another terminal is focused.',
				type: 'boolean',
				'default': configDefaults.allowHiddenToStayActive
			},
			runInActive: {
				title: 'Run in Active Terminal',
				description: 'Whether to run commands from the service API in the active terminal or in a new terminal.',
				type: 'boolean',
				'default': configDefaults.runInActive
			},
			leaveOpenAfterExit: {
				title: 'Leave Open After Exit',
				description: 'Whether to leave terminal emulators open after their shell processes have exited.',
				type: 'boolean',
				'default': configDefaults.leaveOpenAfterExit,
				profileData: {
					defaultProfile: configDefaults.leaveOpenAfterExit,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.terminalSettings.leaveOpenAfterExit', configDefaults.leaveOpenAfterExit);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			allowRelaunchingTerminalsOnStartup: {
				title: 'Allow relaunching terminals on startup',
				description: 'Whether to allow relaunching terminals on startup.',
				type: 'boolean',
				'default': configDefaults.allowRelaunchingTerminalsOnStartup
			},
			relaunchTerminalOnStartup: {
				title: 'Relaunch terminal on startup',
				description: 'Whether to relaunch terminal on startup.',
				type: 'boolean',
				'default': configDefaults.relaunchTerminalOnStartup,
				profileData: {
					defaultProfile: configDefaults.relaunchTerminalOnStartup,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.terminalSettings.relaunchTerminalOnStartup', configDefaults.relaunchTerminalOnStartup);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			copyOnSelect: {
				title: 'Copy On Select',
				description: 'Copy text to clipboard on selection.',
				type: 'boolean',
				'default': configDefaults.copyOnSelect,
				profileData: {
					defaultProfile: configDefaults.copyOnSelect,
					toUrlParam: function toUrlParam(val) {
						return JSON.stringify(val);
					},
					fromUrlParam: function fromUrlParam(val) {
						return JSON.parse(val);
					},
					checkUrlParam: function checkUrlParam(val) {
						return val !== null && val !== '';
					},
					toBaseProfile: function toBaseProfile(previousValue) {
						return validateBooleanConfigSetting('x-terminal.terminalSettings.copyOnSelect', configDefaults.copyOnSelect);
					},
					fromMenuSetting: function fromMenuSetting(element, baseValue) {
						return element.checked;
					},
					toMenuSetting: function toMenuSetting(val) {
						return val;
					}
				}
			},
			colors: {
				title: 'Colors',
				description: 'Settings for the terminal colors.',
				type: 'object',
				properties: {
					theme: {
						title: 'Theme',
						description: 'Theme used in terminal emulator.',
						type: 'string',
						'enum': ['Custom', 'Atom Dark', 'Atom Light', 'Base16 Tomorrow Dark', 'Base16 Tomorrow Light', 'Christmas', 'City Lights', 'Dracula', 'Grass', 'Homebrew', 'Inverse', 'Linux', 'Man Page', 'Novel', 'Ocean', 'One Dark', 'One Light', 'Predawn', 'Pro', 'Red Sands', 'Red', 'Silver Aerogel', 'Solarized Dark', 'Solarized Light', 'Solid Colors', 'Standard'],
						'default': configDefaults.theme,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.theme,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.theme') || configDefaults.theme;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					foreground: {
						title: 'Text Color',
						description: 'This will be overridden if the theme is not \'Custom\'.',
						type: 'color',
						'default': configDefaults.colorForeground,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorForeground,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.foreground') || configDefaults.colorForeground;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					background: {
						title: 'Background Color',
						description: 'This will be overridden if the theme is not \'Custom\'.',
						type: 'color',
						'default': configDefaults.colorBackground,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBackground,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.background') || configDefaults.colorBackground;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					cursor: {
						title: 'Cursor Color',
						description: 'Can be transparent. This will be overridden if the theme is not \'Custom\'.',
						type: 'color',
						'default': configDefaults.colorCursor,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorCursor,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.cursor') || configDefaults.colorCursor;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					cursorAccent: {
						title: 'Cursor Text Color',
						description: 'Can be transparent. This will be overridden if the theme is not \'Custom\'.',
						type: 'color',
						'default': configDefaults.colorCursorAccent,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorCursorAccent,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.cursorAccent') || configDefaults.colorCursorAccent;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					selection: {
						title: 'Selection Background Color',
						description: 'Can be transparent. This will be overridden if the theme is not \'Custom\'.',
						type: 'color',
						'default': configDefaults.colorSelection,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorSelection,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.selection') || configDefaults.colorSelection;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					black: {
						title: 'ANSI Black',
						description: '`\\x1b[30m`',
						type: 'color',
						'default': configDefaults.colorBlack,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBlack,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.black') || configDefaults.colorBlack;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					red: {
						title: 'ANSI Red',
						description: '`\\x1b[31m`',
						type: 'color',
						'default': configDefaults.colorRed,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorRed,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.red') || configDefaults.colorRed;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					green: {
						title: 'ANSI Green',
						description: '`\\x1b[32m`',
						type: 'color',
						'default': configDefaults.colorGreen,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorGreen,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.green') || configDefaults.colorGreen;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					yellow: {
						title: 'ANSI Yellow',
						description: '`\\x1b[33m`',
						type: 'color',
						'default': configDefaults.colorYellow,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorYellow,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.yellow') || configDefaults.colorYellow;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					blue: {
						title: 'ANSI Blue',
						description: '`\\x1b[34m`',
						type: 'color',
						'default': configDefaults.colorBlue,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBlue,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.blue') || configDefaults.colorBlue;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					magenta: {
						title: 'ANSI Magenta',
						description: '`\\x1b[35m`',
						type: 'color',
						'default': configDefaults.colorMagenta,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorMagenta,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.magenta') || configDefaults.colorMagenta;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					cyan: {
						title: 'ANSI Cyan',
						description: '`\\x1b[36m`',
						type: 'color',
						'default': configDefaults.colorCyan,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorCyan,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.cyan') || configDefaults.colorCyan;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					white: {
						title: 'ANSI White',
						description: '`\\x1b[37m`',
						type: 'color',
						'default': configDefaults.colorWhite,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorWhite,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.white') || configDefaults.colorWhite;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightBlack: {
						title: 'ANSI Bright Black',
						description: '`\\x1b[1;30m`',
						type: 'color',
						'default': configDefaults.colorBrightBlack,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightBlack,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightBlack') || configDefaults.colorBrightBlack;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightRed: {
						title: 'ANSI Bright Red',
						description: '`\\x1b[1;31m`',
						type: 'color',
						'default': configDefaults.colorBrightRed,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightRed,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightRed') || configDefaults.colorBrightRed;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightGreen: {
						title: 'ANSI Bright Green',
						description: '`\\x1b[1;32m`',
						type: 'color',
						'default': configDefaults.colorBrightGreen,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightGreen,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightGreen') || configDefaults.colorBrightGreen;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightYellow: {
						title: 'ANSI Bright Yellow',
						description: '`\\x1b[1;33m`',
						type: 'color',
						'default': configDefaults.colorBrightYellow,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightYellow,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightYellow') || configDefaults.colorBrightYellow;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightBlue: {
						title: 'ANSI Bright Blue',
						description: '`\\x1b[1;34m`',
						type: 'color',
						'default': configDefaults.colorBrightBlue,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightBlue,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightBlue') || configDefaults.colorBrightBlue;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightMagenta: {
						title: 'ANSI Bright Magenta',
						description: '`\\x1b[1;35m`',
						type: 'color',
						'default': configDefaults.colorBrightMagenta,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightMagenta,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightMagenta') || configDefaults.colorBrightMagenta;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightCyan: {
						title: 'ANSI Bright Cyan',
						description: '`\\x1b[1;36m`',
						type: 'color',
						'default': configDefaults.colorBrightCyan,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightCyan,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightCyan') || configDefaults.colorBrightCyan;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					},
					brightWhite: {
						title: 'ANSI Bright White',
						description: '`\\x1b[1;37m`',
						type: 'color',
						'default': configDefaults.colorBrightWhite,
						profileData: {
							terminalFrontEnd: true,
							defaultProfile: configDefaults.colorBrightWhite,
							toUrlParam: function toUrlParam(val) {
								return val;
							},
							fromUrlParam: function fromUrlParam(val) {
								return val;
							},
							checkUrlParam: function checkUrlParam(val) {
								return true;
							},
							toBaseProfile: function toBaseProfile(previousValue) {
								return atom.config.get('x-terminal.terminalSettings.colors.brightWhite') || configDefaults.colorBrightWhite;
							},
							fromMenuSetting: function fromMenuSetting(element, baseValue) {
								return element.value || baseValue;
							},
							toMenuSetting: function toMenuSetting(val) {
								return val;
							}
						}
					}
				}
			}
		}
	}
});

exports.config = config;
function getFontFamilyBaseProfile() {
	if (atom.config.get('x-terminal.terminalSettings.useEditorFont') && atom.config.get('editor.fontFamily')) {
		return atom.config.get('editor.fontFamily');
	}
	return atom.config.get('x-terminal.terminalSettings.fontFamily') || configDefaults.fontFamily;
}

function validateBooleanConfigSetting(name, defaultValue) {
	var value = atom.config.get(name);
	return typeof value === 'boolean' ? value : defaultValue;
}

function validateJsonConfigSetting(name, defaultJsonValue, previousValue) {
	var value = atom.config.get(name);
	try {
		value = JSON.parse(value || defaultJsonValue) || previousValue;
	} catch (e) {
		// This normally happens when the user is in the middle of updating some
		// setting that is a JSON string. Ignore syntax errors and use the last
		// known good config setting.
		if (!(e instanceof SyntaxError)) {
			throw e;
		}
		value = previousValue;
	}
	return value;
}

function parseJson(value, defaultValue, type) {
	var retval = value;
	try {
		retval = JSON.parse(retval);
	} catch (e) {
		if (!(e instanceof SyntaxError)) {
			throw e;
		}
		retval = null;
	}
	if (!retval || retval.constructor !== type) {
		retval = defaultValue;
	}
	return retval;
}

function convertNullToEmptyString(value) {
	if (value === null) {
		return '';
	}
	return JSON.stringify(value);
}

var COLORS = {
	foreground: 'colorForeground',
	background: 'colorBackground',
	cursor: 'colorCursor',
	cursorAccent: 'colorCursorAccent',
	selection: 'colorSelection',
	black: 'colorBlack',
	red: 'colorRed',
	green: 'colorGreen',
	yellow: 'colorYellow',
	blue: 'colorBlue',
	magenta: 'colorMagenta',
	cyan: 'colorCyan',
	white: 'colorWhite',
	brightBlack: 'colorBrightBlack',
	brightRed: 'colorBrightRed',
	brightGreen: 'colorBrightGreen',
	brightYellow: 'colorBrightYellow',
	brightBlue: 'colorBrightBlue',
	brightMagenta: 'colorBrightMagenta',
	brightCyan: 'colorBrightCyan',
	brightWhite: 'colorBrightWhite'
};

exports.COLORS = COLORS;
function configToData(obj, prefix) {
	var data = [];
	for (var key in obj) {
		if (obj[key].type === 'object') {
			data.push.apply(data, _toConsumableArray(configToData(obj[key].properties, prefix + '.' + key)));
		} else {
			var profileData = obj[key].profileData;
			if (profileData) {
				profileData.profileKey = key in COLORS ? COLORS[key] : key;
				delete obj[key].profileData;
			}
			var keyPath = prefix + '.' + key;
			data.push(_extends({}, obj[key], profileData, { keyPath: keyPath }));
		}
	}
	return data;
}

var CONFIG_DATA = configToData(config, 'x-terminal');

exports.CONFIG_DATA = CONFIG_DATA;
if (localStorage.getItem('x-terminal.initialCommandSet') === null) {
	localStorage.setItem('x-terminal.initialCommandSet', 'true');
	setInitialCommand(_which2['default']);
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL2NvbmZpZy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7OztJQTA3QnNCLGlCQUFpQixxQkFBaEMsV0FBa0MsS0FBSyxFQUFFO0FBQy9DLEtBQUksT0FBTyxZQUFBLENBQUE7QUFDWCxLQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssT0FBTyxFQUFFO0FBQ2pDLE1BQUk7QUFDSCxVQUFPLEdBQUcsTUFBTSxLQUFLLENBQUMsVUFBVSxDQUFDLENBQUE7R0FDakMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtBQUNaLE9BQUk7QUFDSCxXQUFPLEdBQUcsTUFBTSxLQUFLLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtJQUN2QyxDQUFDLE9BQU8sRUFBRSxFQUFFOztJQUVaO0dBQ0Q7RUFDRDs7QUFFRCxLQUFJLE9BQU8sSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxLQUFLLGNBQWMsQ0FBQyxPQUFPLEVBQUU7QUFDakcsTUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMscUNBQXFDLEVBQUUsT0FBTyxDQUFDLENBQUE7RUFDL0Q7Q0FDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztrQkF0N0JjLElBQUk7Ozs7b0JBQ0YsTUFBTTs7OztxQkFDTCxPQUFPOzs7O0FBRWxCLFNBQVMsbUJBQW1CLEdBQUk7QUFDdEMsUUFBTztBQUNOLFNBQU8sRUFBRSxPQUFPLENBQUMsUUFBUSxLQUFLLE9BQU8sR0FBSSxPQUFPLENBQUMsR0FBRyxDQUFDLE9BQU8sSUFBSSxTQUFTLEdBQUssT0FBTyxDQUFDLEdBQUcsQ0FBQyxLQUFLLElBQUksU0FBUyxBQUFDO0FBQzdHLE1BQUksRUFBRSxJQUFJO0FBQ1YsVUFBUSxFQUFFLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxJQUFJLGdCQUFnQjtBQUM5QyxLQUFHLEVBQUUsT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFPLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxXQUFXLEdBQUcsT0FBTyxDQUFDLEdBQUcsQ0FBQyxJQUFJO0FBQzlFLFlBQVUsRUFBRSxLQUFLO0FBQ2pCLE9BQUssRUFBRSxLQUFLO0FBQ1osVUFBUSxFQUFFLElBQUk7QUFDZCxLQUFHLEVBQUUsRUFBRTtBQUNQLFFBQU0sRUFBRSxJQUFJO0FBQ1osV0FBUyxFQUFFLGNBQWM7QUFDekIsVUFBUSxFQUFFLEVBQUU7QUFDWixVQUFRLEVBQUUsRUFBRTs7QUFFWixpQkFBZSxFQUFFLENBQUM7QUFDbEIsaUJBQWUsRUFBRSxHQUFHO0FBQ3BCLGVBQWEsRUFBRSxJQUFJO0FBQ25CLFlBQVUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxJQUFJLFdBQVc7QUFDL0QsT0FBSyxFQUFFLFFBQVE7QUFDZixpQkFBZSxFQUFFLFNBQVM7QUFDMUIsaUJBQWUsRUFBRSxTQUFTO0FBQzFCLGFBQVcsRUFBRSxTQUFTO0FBQ3RCLG1CQUFpQixFQUFFLFNBQVM7QUFDNUIsZ0JBQWMsRUFBRSxTQUFTO0FBQ3pCLFlBQVUsRUFBRSxTQUFTO0FBQ3JCLFVBQVEsRUFBRSxTQUFTO0FBQ25CLFlBQVUsRUFBRSxTQUFTO0FBQ3JCLGFBQVcsRUFBRSxTQUFTO0FBQ3RCLFdBQVMsRUFBRSxTQUFTO0FBQ3BCLGNBQVksRUFBRSxTQUFTO0FBQ3ZCLFdBQVMsRUFBRSxTQUFTO0FBQ3BCLFlBQVUsRUFBRSxTQUFTO0FBQ3JCLGtCQUFnQixFQUFFLFNBQVM7QUFDM0IsZ0JBQWMsRUFBRSxTQUFTO0FBQ3pCLGtCQUFnQixFQUFFLFNBQVM7QUFDM0IsbUJBQWlCLEVBQUUsU0FBUztBQUM1QixpQkFBZSxFQUFFLFNBQVM7QUFDMUIsb0JBQWtCLEVBQUUsU0FBUztBQUM3QixpQkFBZSxFQUFFLFNBQVM7QUFDMUIsa0JBQWdCLEVBQUUsU0FBUztBQUMzQix5QkFBdUIsRUFBRSxLQUFLO0FBQzlCLGFBQVcsRUFBRSxLQUFLO0FBQ2xCLG9CQUFrQixFQUFFLElBQUk7QUFDeEIsb0NBQWtDLEVBQUUsSUFBSTtBQUN4QywyQkFBeUIsRUFBRSxJQUFJO0FBQy9CLGNBQVksRUFBRSxDQUFDLFlBQU07QUFDcEIsT0FBSSxXQUFXLFlBQUEsQ0FBQTtBQUNmLE9BQUksT0FBTyxDQUFDLFFBQVEsS0FBSyxPQUFPLEVBQUU7QUFDakMsZUFBVyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsT0FBTyxJQUFJLGtCQUFLLElBQUksQ0FBQyxnQkFBRyxPQUFPLEVBQUUsRUFBRSxTQUFTLEVBQUUsU0FBUyxDQUFDLENBQUE7SUFDbEYsTUFBTSxJQUFJLE9BQU8sQ0FBQyxRQUFRLEtBQUssUUFBUSxFQUFFO0FBQ3pDLGVBQVcsR0FBRyxrQkFBSyxJQUFJLENBQUMsZ0JBQUcsT0FBTyxFQUFFLEVBQUUsU0FBUyxFQUFFLHFCQUFxQixDQUFDLENBQUE7SUFDdkUsTUFBTTtBQUNOLGVBQVcsR0FBRyxPQUFPLENBQUMsR0FBRyxDQUFDLGVBQWUsSUFBSSxrQkFBSyxJQUFJLENBQUMsZ0JBQUcsT0FBTyxFQUFFLEVBQUUsU0FBUyxDQUFDLENBQUE7SUFDL0U7QUFDRCxVQUFPLGtCQUFLLElBQUksQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUE7R0FDM0MsQ0FBQSxFQUFHO0FBQ0osT0FBSyxFQUFFLEVBQUU7QUFDVCxjQUFZLEVBQUUsSUFBSTtBQUNsQixpQkFBZSxFQUFFLEtBQUs7QUFDdEIsY0FBWSxFQUFFLEtBQUs7QUFDbkIsaUJBQWUsRUFBRSxRQUFRO0VBQ3pCLENBQUE7Q0FDRDs7QUFFTSxJQUFNLGNBQWMsR0FBRyxtQkFBbUIsRUFBRSxDQUFBOzs7QUFFbkQsU0FBUyxXQUFXLENBQUUsR0FBRyxFQUFFO0FBQzFCLEtBQUksS0FBSyxHQUFHLENBQUMsQ0FBQTtBQUNiLE1BQUssSUFBTSxLQUFJLElBQUksR0FBRyxFQUFFO0FBQ3ZCLEtBQUcsQ0FBQyxLQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsS0FBSyxFQUFFLENBQUE7QUFDekIsTUFBSSxHQUFHLENBQUMsS0FBSSxDQUFDLENBQUMsSUFBSSxLQUFLLFFBQVEsSUFBSSxZQUFZLElBQUksR0FBRyxDQUFDLEtBQUksQ0FBQyxFQUFFO0FBQzdELGNBQVcsQ0FBQyxHQUFHLENBQUMsS0FBSSxDQUFDLENBQUMsVUFBVSxDQUFDLENBQUE7R0FDakM7RUFDRDtBQUNELFFBQU8sR0FBRyxDQUFBO0NBQ1Y7O0FBRU0sSUFBTSxNQUFNLEdBQUcsV0FBVyxDQUFDO0FBQ2pDLGlCQUFnQixFQUFFO0FBQ2pCLE9BQUssRUFBRSx3QkFBd0I7QUFDL0IsYUFBVyxFQUFFLG9EQUFvRDtBQUNqRSxNQUFJLEVBQUUsUUFBUTtBQUNkLFlBQVUsRUFBRTtBQUNYLFVBQU8sRUFBRTtBQUNSLFNBQUssRUFBRSxTQUFTO0FBQ2hCLGVBQVcsRUFBRSxnQkFBZ0I7QUFDN0IsUUFBSSxFQUFFLFFBQVE7QUFDZCxlQUFTLGNBQWMsQ0FBQyxPQUFPO0FBQy9CLGVBQVcsRUFBRTtBQUNaLG1CQUFjLEVBQUUsY0FBYyxDQUFDLE9BQU87QUFDdEMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7QUFDeEIsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0FBQzFCLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLElBQUk7TUFBQTtBQUM1QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxPQUFPO01BQUM7QUFDcEgsb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFNLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxTQUFTO01BQUM7QUFDcEYsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0tBQzNCO0lBQ0Q7QUFDRCxPQUFJLEVBQUU7QUFDTCxTQUFLLEVBQUUsV0FBVztBQUNsQixlQUFXLEVBQUUsMkdBQTJHO0FBQ3hILFFBQUksRUFBRSxRQUFRO0FBQ2QsZUFBUyxjQUFjLENBQUMsSUFBSTtBQUM1QixlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLElBQUksQ0FBQztBQUMvQyxlQUFVLEVBQUUsb0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDeEMsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN0QyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxDQUFDLENBQUMsR0FBRztNQUFBO0FBQzdCLGtCQUFhLEVBQUUsdUJBQUMsYUFBYTthQUFLLHlCQUF5QixDQUFDLGtDQUFrQyxFQUFFLGNBQWMsQ0FBQyxJQUFJLEVBQUUsYUFBYSxDQUFDO01BQUE7QUFDbkksb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFLLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUUsU0FBUyxFQUFFLEtBQUssQ0FBQztNQUFBO0FBQ2xHLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7S0FDM0M7SUFDRDtBQUNELE9BQUksRUFBRTtBQUNMLFNBQUssRUFBRSxlQUFlO0FBQ3RCLGVBQVcsRUFBRSwyQkFBMkI7QUFDeEMsUUFBSSxFQUFFLFFBQVE7QUFDZCxlQUFTLGNBQWMsQ0FBQyxRQUFRO0FBQ2hDLGVBQVcsRUFBRTtBQUNaLG1CQUFjLEVBQUUsY0FBYyxDQUFDLFFBQVE7QUFDdkMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7QUFDeEIsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0FBQzFCLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLElBQUk7TUFBQTtBQUM1QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxrQ0FBa0MsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxRQUFRO01BQUM7QUFDbEgsb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFNLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxTQUFTO01BQUM7QUFDcEYsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0tBQzNCO0lBQ0Q7QUFDRCxNQUFHLEVBQUU7QUFDSixTQUFLLEVBQUUsbUJBQW1CO0FBQzFCLGVBQVcsRUFBRSxzREFBc0Q7QUFDbkUsUUFBSSxFQUFFLFFBQVE7QUFDZCxlQUFTLGNBQWMsQ0FBQyxHQUFHO0FBQzNCLGVBQVcsRUFBRTtBQUNaLG1CQUFjLEVBQUUsY0FBYyxDQUFDLEdBQUc7QUFDbEMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7QUFDeEIsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0FBQzFCLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLElBQUk7TUFBQTtBQUM1QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxHQUFHO01BQUM7QUFDNUcsb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFNLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsSUFBSSxTQUFTO01BQUM7QUFDcEYsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0tBQzNCO0lBQ0Q7QUFDRCxhQUFVLEVBQUU7QUFDWCxTQUFLLEVBQUUsdUJBQXVCO0FBQzlCLGVBQVcsRUFBRSxzRUFBc0U7QUFDbkYsUUFBSSxFQUFFLFNBQVM7QUFDZixlQUFTLGNBQWMsQ0FBQyxVQUFVO0FBQ2xDLGVBQVcsRUFBRTtBQUNaLG1CQUFjLEVBQUUsY0FBYyxDQUFDLFVBQVU7QUFDekMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3hDLGlCQUFZLEVBQUUsc0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDdEMsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQU0sR0FBRyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssRUFBRTtNQUFDO0FBQ3BELGtCQUFhLEVBQUUsdUJBQUMsYUFBYTthQUFLLDRCQUE0QixDQUFDLHdDQUF3QyxFQUFFLGNBQWMsQ0FBQyxVQUFVLENBQUM7TUFBQTtBQUNuSSxvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQUssT0FBTyxDQUFDLE9BQU87TUFBQTtBQUN4RCxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7S0FDM0I7SUFDRDtBQUNELE1BQUcsRUFBRTtBQUNKLFNBQUssRUFBRSxhQUFhO0FBQ3BCLGVBQVcsRUFBRSwrS0FBK0s7QUFDNUwsUUFBSSxFQUFFLFFBQVE7QUFDZCxlQUFTLGNBQWMsQ0FBQyxHQUFHO0FBQzNCLGVBQVcsRUFBRTtBQUNaLG1CQUFjLEVBQUUsSUFBSTtBQUNwQixlQUFVLEVBQUUsb0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDeEMsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN0QyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxDQUFDLENBQUMsR0FBRztNQUFBO0FBQzdCLGtCQUFhLEVBQUUsdUJBQUMsYUFBYSxFQUFLO0FBQ2pDLFVBQUksR0FBRyxHQUFHLHlCQUF5QixDQUFDLGlDQUFpQyxFQUFFLE1BQU0sQ0FBQyxDQUFBO0FBQzlFLFVBQUksQ0FBQyxHQUFHLElBQUksR0FBRyxDQUFDLFdBQVcsS0FBSyxNQUFNLEVBQUU7QUFDdkMsVUFBRyxHQUFHLElBQUksQ0FBQTtPQUNWO0FBQ0QsYUFBTyxHQUFHLENBQUE7TUFDVjtBQUNELG9CQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7YUFBSyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUM7TUFBQTtBQUNuRyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyx3QkFBd0IsQ0FBQyxHQUFHLENBQUM7TUFBQTtLQUNyRDtJQUNEO0FBQ0QsU0FBTSxFQUFFO0FBQ1AsU0FBSyxFQUFFLHVCQUF1QjtBQUM5QixlQUFXLEVBQUUsc0pBQXNKO0FBQ25LLFFBQUksRUFBRSxRQUFRO0FBQ2QsZUFBUyxjQUFjLENBQUMsTUFBTTtBQUM5QixlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQztBQUNqRCxlQUFVLEVBQUUsb0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDeEMsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN0QyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxDQUFDLENBQUMsR0FBRztNQUFBO0FBQzdCLGtCQUFhLEVBQUUsdUJBQUMsYUFBYTthQUFLLHlCQUF5QixDQUFDLG9DQUFvQyxFQUFFLGNBQWMsQ0FBQyxNQUFNLENBQUM7TUFBQTtBQUN4SCxvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQUssU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxTQUFTLEVBQUUsTUFBTSxDQUFDO01BQUE7QUFDbkcsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7TUFBQTtLQUMzQztJQUNEO0FBQ0QsWUFBUyxFQUFFO0FBQ1YsU0FBSyxFQUFFLHVCQUF1QjtBQUM5QixlQUFXLEVBQUUsd0lBQXdJO0FBQ3JKLFFBQUksRUFBRSxRQUFRO0FBQ2QsZUFBUyxjQUFjLENBQUMsU0FBUztBQUNqQyxlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQztBQUNwRCxlQUFVLEVBQUUsb0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDeEMsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN0QyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxDQUFDLENBQUMsR0FBRztNQUFBO0FBQzdCLGtCQUFhLEVBQUUsdUJBQUMsYUFBYTthQUFLLHlCQUF5QixDQUFDLHVDQUF1QyxFQUFFLGNBQWMsQ0FBQyxTQUFTLENBQUM7TUFBQTtBQUM5SCxvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQUssU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxPQUFPLEVBQUUsRUFBRSxTQUFTLEVBQUUsS0FBSyxDQUFDO01BQUE7QUFDbEcsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7TUFBQTtLQUMzQztJQUNEO0FBQ0QsV0FBUSxFQUFFO0FBQ1QsU0FBSyxFQUFFLG9CQUFvQjtBQUMzQixlQUFXLEVBQUUsZ0RBQWdEO0FBQzdELFFBQUksRUFBRSxRQUFRO0FBQ2QsZUFBUyxjQUFjLENBQUMsUUFBUTtBQUNoQyxlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLElBQUk7QUFDcEIsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7QUFDeEIsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQU0sR0FBRyxLQUFLLE1BQU0sR0FBRyxJQUFJLEdBQUcsR0FBRztNQUFDO0FBQ3BELGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLElBQUk7TUFBQTtBQUM1QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxJQUFJLElBQUk7TUFBQztBQUNuRyxvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQU0sT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLFNBQVM7TUFBQztBQUNwRixrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyx3QkFBd0IsQ0FBQyxHQUFHLENBQUM7TUFBQTtLQUNyRDtJQUNEO0dBQ0Q7RUFDRDtBQUNELFlBQVcsRUFBRTtBQUNaLE9BQUssRUFBRSxpQkFBaUI7QUFDeEIsYUFBVyxFQUFFLHNDQUFzQztBQUNuRCxNQUFJLEVBQUUsUUFBUTtBQUNkLFlBQVUsRUFBRTtBQUNYLFFBQUssRUFBRTtBQUNOLFNBQUssRUFBRSxnQkFBZ0I7QUFDdkIsZUFBVyxFQUFFLDZKQUE2SjtBQUMxSyxRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLEtBQUs7QUFDN0IsZUFBVyxFQUFFO0FBQ1osbUJBQWMsRUFBRSxjQUFjLENBQUMsS0FBSztBQUNwQyxlQUFVLEVBQUUsb0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDeEMsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN0QyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBTSxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxFQUFFO01BQUM7QUFDcEQsa0JBQWEsRUFBRSx1QkFBQyxhQUFhO2FBQUssNEJBQTRCLENBQUMsOEJBQThCLEVBQUUsY0FBYyxDQUFDLEtBQUssQ0FBQztNQUFBO0FBQ3BILG9CQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7YUFBSyxPQUFPLENBQUMsT0FBTztNQUFBO0FBQ3hELGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLEdBQUc7TUFBQTtLQUMzQjtJQUNEO0FBQ0QsV0FBUSxFQUFFO0FBQ1QsU0FBSyxFQUFFLFdBQVc7QUFDbEIsZUFBVyxFQUFFLCtJQUErSTtBQUM1SixRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLFFBQVE7QUFDaEMsZUFBVyxFQUFFO0FBQ1osbUJBQWMsRUFBRSxjQUFjLENBQUMsUUFBUTtBQUN2QyxlQUFVLEVBQUUsb0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDeEMsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN0QyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBTSxHQUFHLEtBQUssSUFBSSxJQUFJLEdBQUcsS0FBSyxFQUFFO01BQUM7QUFDcEQsa0JBQWEsRUFBRSx1QkFBQyxhQUFhO2FBQUssNEJBQTRCLENBQUMsaUNBQWlDLEVBQUUsY0FBYyxDQUFDLFFBQVEsQ0FBQztNQUFBO0FBQzFILG9CQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7YUFBSyxPQUFPLENBQUMsT0FBTztNQUFBO0FBQ3hELGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLEdBQUc7TUFBQTtLQUMzQjtJQUNEO0dBQ0Q7RUFDRDtBQUNELGlCQUFnQixFQUFFO0FBQ2pCLE9BQUssRUFBRSw0QkFBNEI7QUFDbkMsYUFBVyxFQUFFLHFDQUFxQztBQUNsRCxNQUFJLEVBQUUsUUFBUTtBQUNkLFlBQVUsRUFBRTtBQUNYLFFBQUssRUFBRTtBQUNOLFNBQUssRUFBRSxvQkFBb0I7QUFDM0IsZUFBVyxFQUFFLGlDQUFpQztBQUM5QyxRQUFJLEVBQUUsUUFBUTtBQUNkLGVBQVMsY0FBYyxDQUFDLEtBQUs7QUFDN0IsZUFBVyxFQUFFO0FBQ1osbUJBQWMsRUFBRSxJQUFJO0FBQ3BCLGVBQVUsRUFBRSxvQkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0FBQ3hCLGlCQUFZLEVBQUUsc0JBQUMsR0FBRzthQUFNLEdBQUcsS0FBSyxNQUFNLEdBQUcsSUFBSSxHQUFHLEdBQUc7TUFBQztBQUNwRCxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxJQUFJO01BQUE7QUFDNUIsa0JBQWEsRUFBRSx1QkFBQyxhQUFhO2FBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUNBQW1DLENBQUMsSUFBSSxjQUFjLENBQUMsS0FBSyxJQUFJLElBQUk7TUFBQztBQUN4SCxvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQU0sT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sRUFBRSxJQUFJLFNBQVM7TUFBQztBQUNwRixrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBTSxHQUFHLElBQUksRUFBRTtNQUFDO0tBQ25DO0lBQ0Q7QUFDRCxlQUFZLEVBQUU7QUFDYixTQUFLLEVBQUUsMkJBQTJCO0FBQ2xDLGVBQVcsRUFBRSxtUUFBbVE7QUFDaFIsUUFBSSxFQUFFLFFBQVE7QUFDZCxlQUFTLGNBQWMsQ0FBQyxZQUFZO0FBQ3BDLGVBQVcsRUFBRTtBQUNaLHFCQUFnQixFQUFFLElBQUk7QUFDdEIsbUJBQWMsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQUM7QUFDdkQsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3hDLGlCQUFZLEVBQUUsc0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDdEMsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssQ0FBQyxDQUFDLEdBQUc7TUFBQTtBQUM3QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBSyx5QkFBeUIsQ0FBQywwQ0FBMEMsRUFBRSxjQUFjLENBQUMsWUFBWSxFQUFFLGFBQWEsQ0FBQztNQUFBO0FBQ25KLG9CQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7YUFBSyxTQUFTLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLE9BQU8sRUFBRSxFQUFFLFNBQVMsRUFBRSxNQUFNLENBQUM7TUFBQTtBQUNuRyxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUFBO0tBQzNDO0lBQ0Q7QUFDRCxnQkFBYSxFQUFFO0FBQ2QsU0FBSyxFQUFFLDJCQUEyQjtBQUNsQyxlQUFXLEVBQUUsa0ZBQWtGO0FBQy9GLFFBQUksRUFBRSxTQUFTO0FBQ2YsZUFBUyxjQUFjLENBQUMsYUFBYTtBQUNyQyxlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLGNBQWMsQ0FBQyxhQUFhO0FBQzVDLGVBQVUsRUFBRSxvQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN4QyxpQkFBWSxFQUFFLHNCQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3RDLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFNLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEVBQUU7TUFBQztBQUNwRCxrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBSyw0QkFBNEIsQ0FBQywyQ0FBMkMsRUFBRSxjQUFjLENBQUMsYUFBYSxDQUFDO01BQUE7QUFDekksb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFLLE9BQU8sQ0FBQyxPQUFPO01BQUE7QUFDeEQsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0tBQzNCO0lBQ0Q7QUFDRCxhQUFVLEVBQUU7QUFDWCxTQUFLLEVBQUUsYUFBYTtBQUNwQixlQUFXLEVBQUUsd0NBQXdDO0FBQ3JELFFBQUksRUFBRSxRQUFRO0FBQ2QsZUFBUyxjQUFjLENBQUMsVUFBVTtBQUNsQyxlQUFXLEVBQUU7QUFDWixxQkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLG1CQUFjLEVBQUUsY0FBYyxDQUFDLFVBQVU7QUFDekMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7QUFDeEIsaUJBQVksRUFBRSxzQkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0FBQzFCLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLElBQUk7TUFBQTtBQUM1QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBSyx3QkFBd0IsRUFBRTtNQUFBO0FBQzVELG9CQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7YUFBTSxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxFQUFFLElBQUksU0FBUztNQUFDO0FBQ3BGLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLEdBQUc7TUFBQTtLQUMzQjtJQUNEO0FBQ0QsV0FBUSxFQUFFO0FBQ1QsU0FBSyxFQUFFLFdBQVc7QUFDbEIsZUFBVyxFQUFFLHNDQUFzQztBQUNuRCxRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLFFBQVE7QUFDaEMsV0FBTyxFQUFFLGNBQWMsQ0FBQyxlQUFlO0FBQ3ZDLFdBQU8sRUFBRSxjQUFjLENBQUMsZUFBZTtBQUN2QyxlQUFXLEVBQUU7QUFDWixxQkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLG1CQUFjLEVBQUUsY0FBYyxDQUFDLFFBQVE7QUFDdkMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3hDLGlCQUFZLEVBQUUsc0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDdEMsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssQ0FBQyxDQUFDLEdBQUc7TUFBQTtBQUM3QixrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxzQ0FBc0MsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxRQUFRO01BQUM7QUFDdEgsb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFLLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxFQUFFLENBQUMsT0FBTyxFQUFFLEVBQUUsU0FBUyxFQUFFLE1BQU0sQ0FBQztNQUFBO0FBQ25HLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLEdBQUc7TUFBQTtLQUMzQjtJQUNEO0FBQ0Qsc0JBQW1CLEVBQUU7QUFDcEIsU0FBSyxFQUFFLHVCQUF1QjtBQUM5QixlQUFXLEVBQUUsbUVBQW1FO0FBQ2hGLFFBQUksRUFBRSxRQUFRO0FBQ2QsWUFBTSxDQUNMLFFBQVEsRUFDUixVQUFVLEVBQ1YsWUFBWSxFQUNaLFlBQVksRUFDWixhQUFhLEVBQ2IsYUFBYSxFQUNiLFdBQVcsRUFDWCxZQUFZLENBQ1o7QUFDRCxlQUFTLGNBQWMsQ0FBQyxlQUFlO0lBQ3ZDO0FBQ0Qsa0JBQWUsRUFBRTtBQUNoQixTQUFLLEVBQUUseUJBQXlCO0FBQ2hDLGVBQVcsRUFBRSw0REFBNEQ7QUFDekUsUUFBSSxFQUFFLFNBQVM7QUFDZixlQUFTLGNBQWMsQ0FBQyxlQUFlO0FBQ3ZDLGVBQVcsRUFBRTtBQUNaLG1CQUFjLEVBQUUsY0FBYyxDQUFDLGVBQWU7QUFDOUMsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3hDLGlCQUFZLEVBQUUsc0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDdEMsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQU0sR0FBRyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssRUFBRTtNQUFDO0FBQ3BELGtCQUFhLEVBQUUsdUJBQUMsYUFBYTthQUFLLDRCQUE0QixDQUFDLDZDQUE2QyxFQUFFLGNBQWMsQ0FBQyxlQUFlLENBQUM7TUFBQTtBQUM3SSxvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQUssT0FBTyxDQUFDLE9BQU87TUFBQTtBQUN4RCxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7S0FDM0I7SUFDRDtBQUNELDBCQUF1QixFQUFFO0FBQ3hCLFNBQUssRUFBRSxzQ0FBc0M7QUFDN0MsZUFBVyxFQUFFLHFGQUFxRjtBQUNsRyxRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLHVCQUF1QjtJQUMvQztBQUNELGNBQVcsRUFBRTtBQUNaLFNBQUssRUFBRSx3QkFBd0I7QUFDL0IsZUFBVyxFQUFFLDJGQUEyRjtBQUN4RyxRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLFdBQVc7SUFDbkM7QUFDRCxxQkFBa0IsRUFBRTtBQUNuQixTQUFLLEVBQUUsdUJBQXVCO0FBQzlCLGVBQVcsRUFBRSxtRkFBbUY7QUFDaEcsUUFBSSxFQUFFLFNBQVM7QUFDZixlQUFTLGNBQWMsQ0FBQyxrQkFBa0I7QUFDMUMsZUFBVyxFQUFFO0FBQ1osbUJBQWMsRUFBRSxjQUFjLENBQUMsa0JBQWtCO0FBQ2pELGVBQVUsRUFBRSxvQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN4QyxpQkFBWSxFQUFFLHNCQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3RDLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFNLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEVBQUU7TUFBQztBQUNwRCxrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBSyw0QkFBNEIsQ0FBQyxnREFBZ0QsRUFBRSxjQUFjLENBQUMsa0JBQWtCLENBQUM7TUFBQTtBQUNuSixvQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2FBQUssT0FBTyxDQUFDLE9BQU87TUFBQTtBQUN4RCxrQkFBYSxFQUFFLHVCQUFDLEdBQUc7YUFBSyxHQUFHO01BQUE7S0FDM0I7SUFDRDtBQUNELHFDQUFrQyxFQUFFO0FBQ25DLFNBQUssRUFBRSx3Q0FBd0M7QUFDL0MsZUFBVyxFQUFFLG9EQUFvRDtBQUNqRSxRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLGtDQUFrQztJQUMxRDtBQUNELDRCQUF5QixFQUFFO0FBQzFCLFNBQUssRUFBRSw4QkFBOEI7QUFDckMsZUFBVyxFQUFFLDBDQUEwQztBQUN2RCxRQUFJLEVBQUUsU0FBUztBQUNmLGVBQVMsY0FBYyxDQUFDLHlCQUF5QjtBQUNqRCxlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLGNBQWMsQ0FBQyx5QkFBeUI7QUFDeEQsZUFBVSxFQUFFLG9CQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3hDLGlCQUFZLEVBQUUsc0JBQUMsR0FBRzthQUFLLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO01BQUE7QUFDdEMsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQU0sR0FBRyxLQUFLLElBQUksSUFBSSxHQUFHLEtBQUssRUFBRTtNQUFDO0FBQ3BELGtCQUFhLEVBQUUsdUJBQUMsYUFBYTthQUFLLDRCQUE0QixDQUFDLHVEQUF1RCxFQUFFLGNBQWMsQ0FBQyx5QkFBeUIsQ0FBQztNQUFBO0FBQ2pLLG9CQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7YUFBSyxPQUFPLENBQUMsT0FBTztNQUFBO0FBQ3hELGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFLLEdBQUc7TUFBQTtLQUMzQjtJQUNEO0FBQ0QsZUFBWSxFQUFFO0FBQ2IsU0FBSyxFQUFFLGdCQUFnQjtBQUN2QixlQUFXLEVBQUUsc0NBQXNDO0FBQ25ELFFBQUksRUFBRSxTQUFTO0FBQ2YsZUFBUyxjQUFjLENBQUMsWUFBWTtBQUNwQyxlQUFXLEVBQUU7QUFDWixtQkFBYyxFQUFFLGNBQWMsQ0FBQyxZQUFZO0FBQzNDLGVBQVUsRUFBRSxvQkFBQyxHQUFHO2FBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUM7TUFBQTtBQUN4QyxpQkFBWSxFQUFFLHNCQUFDLEdBQUc7YUFBSyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztNQUFBO0FBQ3RDLGtCQUFhLEVBQUUsdUJBQUMsR0FBRzthQUFNLEdBQUcsS0FBSyxJQUFJLElBQUksR0FBRyxLQUFLLEVBQUU7TUFBQztBQUNwRCxrQkFBYSxFQUFFLHVCQUFDLGFBQWE7YUFBSyw0QkFBNEIsQ0FBQywwQ0FBMEMsRUFBRSxjQUFjLENBQUMsWUFBWSxDQUFDO01BQUE7QUFDdkksb0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUzthQUFLLE9BQU8sQ0FBQyxPQUFPO01BQUE7QUFDeEQsa0JBQWEsRUFBRSx1QkFBQyxHQUFHO2FBQUssR0FBRztNQUFBO0tBQzNCO0lBQ0Q7QUFDRCxTQUFNLEVBQUU7QUFDUCxTQUFLLEVBQUUsUUFBUTtBQUNmLGVBQVcsRUFBRSxtQ0FBbUM7QUFDaEQsUUFBSSxFQUFFLFFBQVE7QUFDZCxjQUFVLEVBQUU7QUFDWCxVQUFLLEVBQUU7QUFDTixXQUFLLEVBQUUsT0FBTztBQUNkLGlCQUFXLEVBQUUsa0NBQWtDO0FBQy9DLFVBQUksRUFBRSxRQUFRO0FBQ2QsY0FBTSxDQUNMLFFBQVEsRUFDUixXQUFXLEVBQ1gsWUFBWSxFQUNaLHNCQUFzQixFQUN0Qix1QkFBdUIsRUFDdkIsV0FBVyxFQUNYLGFBQWEsRUFDYixTQUFTLEVBQ1QsT0FBTyxFQUNQLFVBQVUsRUFDVixTQUFTLEVBQ1QsT0FBTyxFQUNQLFVBQVUsRUFDVixPQUFPLEVBQ1AsT0FBTyxFQUNQLFVBQVUsRUFDVixXQUFXLEVBQ1gsU0FBUyxFQUNULEtBQUssRUFDTCxXQUFXLEVBQ1gsS0FBSyxFQUNMLGdCQUFnQixFQUNoQixnQkFBZ0IsRUFDaEIsaUJBQWlCLEVBQ2pCLGNBQWMsRUFDZCxVQUFVLENBQ1Y7QUFDRCxpQkFBUyxjQUFjLENBQUMsS0FBSztBQUM3QixpQkFBVyxFQUFFO0FBQ1osdUJBQWdCLEVBQUUsSUFBSTtBQUN0QixxQkFBYyxFQUFFLGNBQWMsQ0FBQyxLQUFLO0FBQ3BDLGlCQUFVLEVBQUUsb0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUN4QixtQkFBWSxFQUFFLHNCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDMUIsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssSUFBSTtRQUFBO0FBQzVCLG9CQUFhLEVBQUUsdUJBQUMsYUFBYTtlQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLElBQUksY0FBYyxDQUFDLEtBQUs7UUFBQztBQUN2SCxzQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2VBQU0sT0FBTyxDQUFDLEtBQUssSUFBSSxTQUFTO1FBQUM7QUFDckUsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO09BQzNCO01BQ0Q7QUFDRCxlQUFVLEVBQUU7QUFDWCxXQUFLLEVBQUUsWUFBWTtBQUNuQixpQkFBVyxFQUFFLHlEQUF5RDtBQUN0RSxVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxlQUFlO0FBQ3ZDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLGVBQWU7QUFDOUMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsK0NBQStDLENBQUMsSUFBSSxjQUFjLENBQUMsZUFBZTtRQUFDO0FBQ3RJLHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELGVBQVUsRUFBRTtBQUNYLFdBQUssRUFBRSxrQkFBa0I7QUFDekIsaUJBQVcsRUFBRSx5REFBeUQ7QUFDdEUsVUFBSSxFQUFFLE9BQU87QUFDYixpQkFBUyxjQUFjLENBQUMsZUFBZTtBQUN2QyxpQkFBVyxFQUFFO0FBQ1osdUJBQWdCLEVBQUUsSUFBSTtBQUN0QixxQkFBYyxFQUFFLGNBQWMsQ0FBQyxlQUFlO0FBQzlDLGlCQUFVLEVBQUUsb0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUN4QixtQkFBWSxFQUFFLHNCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDMUIsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssSUFBSTtRQUFBO0FBQzVCLG9CQUFhLEVBQUUsdUJBQUMsYUFBYTtlQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLCtDQUErQyxDQUFDLElBQUksY0FBYyxDQUFDLGVBQWU7UUFBQztBQUN0SSxzQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2VBQU0sT0FBTyxDQUFDLEtBQUssSUFBSSxTQUFTO1FBQUM7QUFDckUsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO09BQzNCO01BQ0Q7QUFDRCxXQUFNLEVBQUU7QUFDUCxXQUFLLEVBQUUsY0FBYztBQUNyQixpQkFBVyxFQUFFLDZFQUE2RTtBQUMxRixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxXQUFXO0FBQ25DLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFdBQVc7QUFDMUMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMkNBQTJDLENBQUMsSUFBSSxjQUFjLENBQUMsV0FBVztRQUFDO0FBQzlILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELGlCQUFZLEVBQUU7QUFDYixXQUFLLEVBQUUsbUJBQW1CO0FBQzFCLGlCQUFXLEVBQUUsNkVBQTZFO0FBQzFGLFVBQUksRUFBRSxPQUFPO0FBQ2IsaUJBQVMsY0FBYyxDQUFDLGlCQUFpQjtBQUN6QyxpQkFBVyxFQUFFO0FBQ1osdUJBQWdCLEVBQUUsSUFBSTtBQUN0QixxQkFBYyxFQUFFLGNBQWMsQ0FBQyxpQkFBaUI7QUFDaEQsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsaURBQWlELENBQUMsSUFBSSxjQUFjLENBQUMsaUJBQWlCO1FBQUM7QUFDMUksc0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUztlQUFNLE9BQU8sQ0FBQyxLQUFLLElBQUksU0FBUztRQUFDO0FBQ3JFLG9CQUFhLEVBQUUsdUJBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtPQUMzQjtNQUNEO0FBQ0QsY0FBUyxFQUFFO0FBQ1YsV0FBSyxFQUFFLDRCQUE0QjtBQUNuQyxpQkFBVyxFQUFFLDZFQUE2RTtBQUMxRixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxjQUFjO0FBQ3RDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLGNBQWM7QUFDN0MsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsOENBQThDLENBQUMsSUFBSSxjQUFjLENBQUMsY0FBYztRQUFDO0FBQ3BJLHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFVBQUssRUFBRTtBQUNOLFdBQUssRUFBRSxZQUFZO0FBQ25CLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxVQUFVO0FBQ2xDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFVBQVU7QUFDekMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMENBQTBDLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVTtRQUFDO0FBQzVILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFFBQUcsRUFBRTtBQUNKLFdBQUssRUFBRSxVQUFVO0FBQ2pCLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxRQUFRO0FBQ2hDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFFBQVE7QUFDdkMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLENBQUMsSUFBSSxjQUFjLENBQUMsUUFBUTtRQUFDO0FBQ3hILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFVBQUssRUFBRTtBQUNOLFdBQUssRUFBRSxZQUFZO0FBQ25CLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxVQUFVO0FBQ2xDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFVBQVU7QUFDekMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMENBQTBDLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVTtRQUFDO0FBQzVILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFdBQU0sRUFBRTtBQUNQLFdBQUssRUFBRSxhQUFhO0FBQ3BCLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxXQUFXO0FBQ25DLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFdBQVc7QUFDMUMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMkNBQTJDLENBQUMsSUFBSSxjQUFjLENBQUMsV0FBVztRQUFDO0FBQzlILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFNBQUksRUFBRTtBQUNMLFdBQUssRUFBRSxXQUFXO0FBQ2xCLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxTQUFTO0FBQ2pDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFNBQVM7QUFDeEMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMseUNBQXlDLENBQUMsSUFBSSxjQUFjLENBQUMsU0FBUztRQUFDO0FBQzFILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFlBQU8sRUFBRTtBQUNSLFdBQUssRUFBRSxjQUFjO0FBQ3JCLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxZQUFZO0FBQ3BDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFlBQVk7QUFDM0MsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsNENBQTRDLENBQUMsSUFBSSxjQUFjLENBQUMsWUFBWTtRQUFDO0FBQ2hJLHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFNBQUksRUFBRTtBQUNMLFdBQUssRUFBRSxXQUFXO0FBQ2xCLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxTQUFTO0FBQ2pDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFNBQVM7QUFDeEMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMseUNBQXlDLENBQUMsSUFBSSxjQUFjLENBQUMsU0FBUztRQUFDO0FBQzFILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELFVBQUssRUFBRTtBQUNOLFdBQUssRUFBRSxZQUFZO0FBQ25CLGlCQUFXLEVBQUUsYUFBYTtBQUMxQixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxVQUFVO0FBQ2xDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLFVBQVU7QUFDekMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMENBQTBDLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVTtRQUFDO0FBQzVILHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELGdCQUFXLEVBQUU7QUFDWixXQUFLLEVBQUUsbUJBQW1CO0FBQzFCLGlCQUFXLEVBQUUsZUFBZTtBQUM1QixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxnQkFBZ0I7QUFDeEMsaUJBQVcsRUFBRTtBQUNaLHVCQUFnQixFQUFFLElBQUk7QUFDdEIscUJBQWMsRUFBRSxjQUFjLENBQUMsZ0JBQWdCO0FBQy9DLGlCQUFVLEVBQUUsb0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUN4QixtQkFBWSxFQUFFLHNCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDMUIsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssSUFBSTtRQUFBO0FBQzVCLG9CQUFhLEVBQUUsdUJBQUMsYUFBYTtlQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxDQUFDLElBQUksY0FBYyxDQUFDLGdCQUFnQjtRQUFDO0FBQ3hJLHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELGNBQVMsRUFBRTtBQUNWLFdBQUssRUFBRSxpQkFBaUI7QUFDeEIsaUJBQVcsRUFBRSxlQUFlO0FBQzVCLFVBQUksRUFBRSxPQUFPO0FBQ2IsaUJBQVMsY0FBYyxDQUFDLGNBQWM7QUFDdEMsaUJBQVcsRUFBRTtBQUNaLHVCQUFnQixFQUFFLElBQUk7QUFDdEIscUJBQWMsRUFBRSxjQUFjLENBQUMsY0FBYztBQUM3QyxpQkFBVSxFQUFFLG9CQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDeEIsbUJBQVksRUFBRSxzQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQzFCLG9CQUFhLEVBQUUsdUJBQUMsR0FBRztlQUFLLElBQUk7UUFBQTtBQUM1QixvQkFBYSxFQUFFLHVCQUFDLGFBQWE7ZUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyw4Q0FBOEMsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxjQUFjO1FBQUM7QUFDcEksc0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUztlQUFNLE9BQU8sQ0FBQyxLQUFLLElBQUksU0FBUztRQUFDO0FBQ3JFLG9CQUFhLEVBQUUsdUJBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtPQUMzQjtNQUNEO0FBQ0QsZ0JBQVcsRUFBRTtBQUNaLFdBQUssRUFBRSxtQkFBbUI7QUFDMUIsaUJBQVcsRUFBRSxlQUFlO0FBQzVCLFVBQUksRUFBRSxPQUFPO0FBQ2IsaUJBQVMsY0FBYyxDQUFDLGdCQUFnQjtBQUN4QyxpQkFBVyxFQUFFO0FBQ1osdUJBQWdCLEVBQUUsSUFBSTtBQUN0QixxQkFBYyxFQUFFLGNBQWMsQ0FBQyxnQkFBZ0I7QUFDL0MsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsZ0RBQWdELENBQUMsSUFBSSxjQUFjLENBQUMsZ0JBQWdCO1FBQUM7QUFDeEksc0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUztlQUFNLE9BQU8sQ0FBQyxLQUFLLElBQUksU0FBUztRQUFDO0FBQ3JFLG9CQUFhLEVBQUUsdUJBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtPQUMzQjtNQUNEO0FBQ0QsaUJBQVksRUFBRTtBQUNiLFdBQUssRUFBRSxvQkFBb0I7QUFDM0IsaUJBQVcsRUFBRSxlQUFlO0FBQzVCLFVBQUksRUFBRSxPQUFPO0FBQ2IsaUJBQVMsY0FBYyxDQUFDLGlCQUFpQjtBQUN6QyxpQkFBVyxFQUFFO0FBQ1osdUJBQWdCLEVBQUUsSUFBSTtBQUN0QixxQkFBYyxFQUFFLGNBQWMsQ0FBQyxpQkFBaUI7QUFDaEQsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsaURBQWlELENBQUMsSUFBSSxjQUFjLENBQUMsaUJBQWlCO1FBQUM7QUFDMUksc0JBQWUsRUFBRSx5QkFBQyxPQUFPLEVBQUUsU0FBUztlQUFNLE9BQU8sQ0FBQyxLQUFLLElBQUksU0FBUztRQUFDO0FBQ3JFLG9CQUFhLEVBQUUsdUJBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtPQUMzQjtNQUNEO0FBQ0QsZUFBVSxFQUFFO0FBQ1gsV0FBSyxFQUFFLGtCQUFrQjtBQUN6QixpQkFBVyxFQUFFLGVBQWU7QUFDNUIsVUFBSSxFQUFFLE9BQU87QUFDYixpQkFBUyxjQUFjLENBQUMsZUFBZTtBQUN2QyxpQkFBVyxFQUFFO0FBQ1osdUJBQWdCLEVBQUUsSUFBSTtBQUN0QixxQkFBYyxFQUFFLGNBQWMsQ0FBQyxlQUFlO0FBQzlDLGlCQUFVLEVBQUUsb0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUN4QixtQkFBWSxFQUFFLHNCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDMUIsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssSUFBSTtRQUFBO0FBQzVCLG9CQUFhLEVBQUUsdUJBQUMsYUFBYTtlQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLCtDQUErQyxDQUFDLElBQUksY0FBYyxDQUFDLGVBQWU7UUFBQztBQUN0SSxzQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2VBQU0sT0FBTyxDQUFDLEtBQUssSUFBSSxTQUFTO1FBQUM7QUFDckUsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO09BQzNCO01BQ0Q7QUFDRCxrQkFBYSxFQUFFO0FBQ2QsV0FBSyxFQUFFLHFCQUFxQjtBQUM1QixpQkFBVyxFQUFFLGVBQWU7QUFDNUIsVUFBSSxFQUFFLE9BQU87QUFDYixpQkFBUyxjQUFjLENBQUMsa0JBQWtCO0FBQzFDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLGtCQUFrQjtBQUNqRCxpQkFBVSxFQUFFLG9CQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDeEIsbUJBQVksRUFBRSxzQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQzFCLG9CQUFhLEVBQUUsdUJBQUMsR0FBRztlQUFLLElBQUk7UUFBQTtBQUM1QixvQkFBYSxFQUFFLHVCQUFDLGFBQWE7ZUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxrREFBa0QsQ0FBQyxJQUFJLGNBQWMsQ0FBQyxrQkFBa0I7UUFBQztBQUM1SSxzQkFBZSxFQUFFLHlCQUFDLE9BQU8sRUFBRSxTQUFTO2VBQU0sT0FBTyxDQUFDLEtBQUssSUFBSSxTQUFTO1FBQUM7QUFDckUsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO09BQzNCO01BQ0Q7QUFDRCxlQUFVLEVBQUU7QUFDWCxXQUFLLEVBQUUsa0JBQWtCO0FBQ3pCLGlCQUFXLEVBQUUsZUFBZTtBQUM1QixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxlQUFlO0FBQ3ZDLGlCQUFXLEVBQUU7QUFDWix1QkFBZ0IsRUFBRSxJQUFJO0FBQ3RCLHFCQUFjLEVBQUUsY0FBYyxDQUFDLGVBQWU7QUFDOUMsaUJBQVUsRUFBRSxvQkFBQyxHQUFHO2VBQUssR0FBRztRQUFBO0FBQ3hCLG1CQUFZLEVBQUUsc0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUMxQixvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxJQUFJO1FBQUE7QUFDNUIsb0JBQWEsRUFBRSx1QkFBQyxhQUFhO2VBQU0sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsK0NBQStDLENBQUMsSUFBSSxjQUFjLENBQUMsZUFBZTtRQUFDO0FBQ3RJLHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtBQUNELGdCQUFXLEVBQUU7QUFDWixXQUFLLEVBQUUsbUJBQW1CO0FBQzFCLGlCQUFXLEVBQUUsZUFBZTtBQUM1QixVQUFJLEVBQUUsT0FBTztBQUNiLGlCQUFTLGNBQWMsQ0FBQyxnQkFBZ0I7QUFDeEMsaUJBQVcsRUFBRTtBQUNaLHVCQUFnQixFQUFFLElBQUk7QUFDdEIscUJBQWMsRUFBRSxjQUFjLENBQUMsZ0JBQWdCO0FBQy9DLGlCQUFVLEVBQUUsb0JBQUMsR0FBRztlQUFLLEdBQUc7UUFBQTtBQUN4QixtQkFBWSxFQUFFLHNCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7QUFDMUIsb0JBQWEsRUFBRSx1QkFBQyxHQUFHO2VBQUssSUFBSTtRQUFBO0FBQzVCLG9CQUFhLEVBQUUsdUJBQUMsYUFBYTtlQUFNLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxDQUFDLElBQUksY0FBYyxDQUFDLGdCQUFnQjtRQUFDO0FBQ3hJLHNCQUFlLEVBQUUseUJBQUMsT0FBTyxFQUFFLFNBQVM7ZUFBTSxPQUFPLENBQUMsS0FBSyxJQUFJLFNBQVM7UUFBQztBQUNyRSxvQkFBYSxFQUFFLHVCQUFDLEdBQUc7ZUFBSyxHQUFHO1FBQUE7T0FDM0I7TUFDRDtLQUNEO0lBQ0Q7R0FDRDtFQUNEO0NBQ0QsQ0FBQyxDQUFBOzs7QUFFRixTQUFTLHdCQUF3QixHQUFJO0FBQ3BDLEtBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsMkNBQTJDLENBQUMsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxtQkFBbUIsQ0FBQyxFQUFFO0FBQ3pHLFNBQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLENBQUMsQ0FBQTtFQUMzQztBQUNELFFBQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsd0NBQXdDLENBQUMsSUFBSSxjQUFjLENBQUMsVUFBVSxDQUFBO0NBQzdGOztBQUVELFNBQVMsNEJBQTRCLENBQUUsSUFBSSxFQUFFLFlBQVksRUFBRTtBQUMxRCxLQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUNuQyxRQUFRLE9BQU8sS0FBSyxLQUFLLFNBQVMsR0FBRyxLQUFLLEdBQUcsWUFBWSxDQUFDO0NBQzFEOztBQUVELFNBQVMseUJBQXlCLENBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLGFBQWEsRUFBRTtBQUMxRSxLQUFJLEtBQUssR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUNqQyxLQUFJO0FBQ0gsT0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxJQUFJLGdCQUFnQixDQUFDLElBQUksYUFBYSxDQUFBO0VBQzlELENBQUMsT0FBTyxDQUFDLEVBQUU7Ozs7QUFJWCxNQUFJLEVBQUUsQ0FBQyxZQUFZLFdBQVcsQ0FBQSxBQUFDLEVBQUU7QUFDaEMsU0FBTSxDQUFDLENBQUE7R0FDUDtBQUNELE9BQUssR0FBRyxhQUFhLENBQUE7RUFDckI7QUFDRCxRQUFPLEtBQUssQ0FBQTtDQUNaOztBQUVELFNBQVMsU0FBUyxDQUFFLEtBQUssRUFBRSxZQUFZLEVBQUUsSUFBSSxFQUFFO0FBQzlDLEtBQUksTUFBTSxHQUFHLEtBQUssQ0FBQTtBQUNsQixLQUFJO0FBQ0gsUUFBTSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLENBQUE7RUFDM0IsQ0FBQyxPQUFPLENBQUMsRUFBRTtBQUNYLE1BQUksRUFBRSxDQUFDLFlBQVksV0FBVyxDQUFBLEFBQUMsRUFBRTtBQUNoQyxTQUFNLENBQUMsQ0FBQTtHQUNQO0FBQ0QsUUFBTSxHQUFHLElBQUksQ0FBQTtFQUNiO0FBQ0QsS0FBSSxDQUFDLE1BQU0sSUFBSSxNQUFNLENBQUMsV0FBVyxLQUFLLElBQUksRUFBRTtBQUMzQyxRQUFNLEdBQUcsWUFBWSxDQUFBO0VBQ3JCO0FBQ0QsUUFBTyxNQUFNLENBQUE7Q0FDYjs7QUFFRCxTQUFTLHdCQUF3QixDQUFFLEtBQUssRUFBRTtBQUN6QyxLQUFJLEtBQUssS0FBSyxJQUFJLEVBQUU7QUFDbkIsU0FBTyxFQUFFLENBQUE7RUFDVDtBQUNELFFBQU8sSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQTtDQUM1Qjs7QUFFTSxJQUFNLE1BQU0sR0FBRztBQUNyQixXQUFVLEVBQUUsaUJBQWlCO0FBQzdCLFdBQVUsRUFBRSxpQkFBaUI7QUFDN0IsT0FBTSxFQUFFLGFBQWE7QUFDckIsYUFBWSxFQUFFLG1CQUFtQjtBQUNqQyxVQUFTLEVBQUUsZ0JBQWdCO0FBQzNCLE1BQUssRUFBRSxZQUFZO0FBQ25CLElBQUcsRUFBRSxVQUFVO0FBQ2YsTUFBSyxFQUFFLFlBQVk7QUFDbkIsT0FBTSxFQUFFLGFBQWE7QUFDckIsS0FBSSxFQUFFLFdBQVc7QUFDakIsUUFBTyxFQUFFLGNBQWM7QUFDdkIsS0FBSSxFQUFFLFdBQVc7QUFDakIsTUFBSyxFQUFFLFlBQVk7QUFDbkIsWUFBVyxFQUFFLGtCQUFrQjtBQUMvQixVQUFTLEVBQUUsZ0JBQWdCO0FBQzNCLFlBQVcsRUFBRSxrQkFBa0I7QUFDL0IsYUFBWSxFQUFFLG1CQUFtQjtBQUNqQyxXQUFVLEVBQUUsaUJBQWlCO0FBQzdCLGNBQWEsRUFBRSxvQkFBb0I7QUFDbkMsV0FBVSxFQUFFLGlCQUFpQjtBQUM3QixZQUFXLEVBQUUsa0JBQWtCO0NBQy9CLENBQUE7OztBQUVELFNBQVMsWUFBWSxDQUFFLEdBQUcsRUFBRSxNQUFNLEVBQUU7QUFDbkMsS0FBTSxJQUFJLEdBQUcsRUFBRSxDQUFBO0FBQ2YsTUFBSyxJQUFNLEdBQUcsSUFBSSxHQUFHLEVBQUU7QUFDdEIsTUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsSUFBSSxLQUFLLFFBQVEsRUFBRTtBQUMvQixPQUFJLENBQUMsSUFBSSxNQUFBLENBQVQsSUFBSSxxQkFBUyxZQUFZLENBQUMsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFVBQVUsRUFBSyxNQUFNLFNBQUksR0FBRyxDQUFHLEVBQUMsQ0FBQTtHQUNuRSxNQUFNO0FBQ04sT0FBTSxXQUFXLEdBQUcsR0FBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFdBQVcsQ0FBQTtBQUN4QyxPQUFJLFdBQVcsRUFBRTtBQUNoQixlQUFXLENBQUMsVUFBVSxHQUFHLEdBQUcsSUFBSSxNQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEdBQUcsQ0FBQTtBQUMxRCxXQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxXQUFXLENBQUE7SUFDM0I7QUFDRCxPQUFNLE9BQU8sR0FBTSxNQUFNLFNBQUksR0FBRyxBQUFFLENBQUE7QUFDbEMsT0FBSSxDQUFDLElBQUksY0FBTSxHQUFHLENBQUMsR0FBRyxDQUFDLEVBQUssV0FBVyxJQUFFLE9BQU8sRUFBUCxPQUFPLElBQUcsQ0FBQTtHQUNuRDtFQUNEO0FBQ0QsUUFBTyxJQUFJLENBQUE7Q0FDWDs7QUFFTSxJQUFNLFdBQVcsR0FBRyxZQUFZLENBQUMsTUFBTSxFQUFFLFlBQVksQ0FBQyxDQUFBOzs7QUFzQjdELElBQUksWUFBWSxDQUFDLE9BQU8sQ0FBQyw4QkFBOEIsQ0FBQyxLQUFLLElBQUksRUFBRTtBQUNsRSxhQUFZLENBQUMsT0FBTyxDQUFDLDhCQUE4QixFQUFFLE1BQU0sQ0FBQyxDQUFBO0FBQzVELGtCQUFpQixvQkFBTyxDQUFBO0NBQ3hCIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL2NvbmZpZy5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKiBAYmFiZWwgKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxNyBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IDIwMTctMjAxOCBBbmRyZXMgTWVqaWEgPGFtZWppYTAwNEBnbWFpbC5jb20+LiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIFV6aVRlY2ggQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBidXMtc3RvcCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpc1xuICogc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlXG4gKiB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksXG4gKiBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvXG4gKiBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28uXG4gKlxuICogVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUiBJTVBMSUVELFxuICogSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEFcbiAqIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFRcbiAqIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTlxuICogT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFXG4gKiBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiAqL1xuXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5pbXBvcnQgcGF0aCBmcm9tICdwYXRoJ1xuaW1wb3J0IHdoaWNoIGZyb20gJ3doaWNoJ1xuXG5leHBvcnQgZnVuY3Rpb24gcmVzZXRDb25maWdEZWZhdWx0cyAoKSB7XG5cdHJldHVybiB7XG5cdFx0Y29tbWFuZDogcHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ3dpbjMyJyA/IChwcm9jZXNzLmVudi5DT01TUEVDIHx8ICdjbWQuZXhlJykgOiAocHJvY2Vzcy5lbnYuU0hFTEwgfHwgJy9iaW4vc2gnKSxcblx0XHRhcmdzOiAnW10nLFxuXHRcdHRlcm1UeXBlOiBwcm9jZXNzLmVudi5URVJNIHx8ICd4dGVybS0yNTZjb2xvcicsXG5cdFx0Y3dkOiBwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInID8gcHJvY2Vzcy5lbnYuVVNFUlBST0ZJTEUgOiBwcm9jZXNzLmVudi5IT01FLFxuXHRcdHByb2plY3RDd2Q6IGZhbHNlLFxuXHRcdHdlYmdsOiBmYWxzZSxcblx0XHR3ZWJMaW5rczogdHJ1ZSxcblx0XHRlbnY6ICcnLFxuXHRcdHNldEVudjogJ3t9Jyxcblx0XHRkZWxldGVFbnY6ICdbXCJOT0RFX0VOVlwiXScsXG5cdFx0ZW5jb2Rpbmc6ICcnLFxuXHRcdGZvbnRTaXplOiAxNCxcblx0XHQvLyBOT1RFOiBBdG9tIHdpbGwgY3Jhc2ggaWYgdGhlIGZvbnQgaXMgc2V0IGJlbG93IDguXG5cdFx0bWluaW11bUZvbnRTaXplOiA4LFxuXHRcdG1heGltdW1Gb250U2l6ZTogMTAwLFxuXHRcdHVzZUVkaXRvckZvbnQ6IHRydWUsXG5cdFx0Zm9udEZhbWlseTogYXRvbS5jb25maWcuZ2V0KCdlZGl0b3IuZm9udEZhbWlseScpIHx8ICdtb25vc3BhY2UnLFxuXHRcdHRoZW1lOiAnQ3VzdG9tJyxcblx0XHRjb2xvckZvcmVncm91bmQ6ICcjZmZmZmZmJyxcblx0XHRjb2xvckJhY2tncm91bmQ6ICcjMDAwMDAwJyxcblx0XHRjb2xvckN1cnNvcjogJyNmZmZmZmYnLFxuXHRcdGNvbG9yQ3Vyc29yQWNjZW50OiAnIzAwMDAwMCcsXG5cdFx0Y29sb3JTZWxlY3Rpb246ICcjNGQ0ZDRkJyxcblx0XHRjb2xvckJsYWNrOiAnIzJlMzQzNicsXG5cdFx0Y29sb3JSZWQ6ICcjY2MwMDAwJyxcblx0XHRjb2xvckdyZWVuOiAnIzRlOWEwNicsXG5cdFx0Y29sb3JZZWxsb3c6ICcjYzRhMDAwJyxcblx0XHRjb2xvckJsdWU6ICcjMzQ2NWE0Jyxcblx0XHRjb2xvck1hZ2VudGE6ICcjNzU1MDdiJyxcblx0XHRjb2xvckN5YW46ICcjMDY5ODlhJyxcblx0XHRjb2xvcldoaXRlOiAnI2QzZDdjZicsXG5cdFx0Y29sb3JCcmlnaHRCbGFjazogJyM1NTU3NTMnLFxuXHRcdGNvbG9yQnJpZ2h0UmVkOiAnI2VmMjkyOScsXG5cdFx0Y29sb3JCcmlnaHRHcmVlbjogJyM4YWUyMzQnLFxuXHRcdGNvbG9yQnJpZ2h0WWVsbG93OiAnI2ZjZTk0ZicsXG5cdFx0Y29sb3JCcmlnaHRCbHVlOiAnIzcyOWZjZicsXG5cdFx0Y29sb3JCcmlnaHRNYWdlbnRhOiAnI2FkN2ZhOCcsXG5cdFx0Y29sb3JCcmlnaHRDeWFuOiAnIzM0ZTJlMicsXG5cdFx0Y29sb3JCcmlnaHRXaGl0ZTogJyNlZWVlZWMnLFxuXHRcdGFsbG93SGlkZGVuVG9TdGF5QWN0aXZlOiBmYWxzZSxcblx0XHRydW5JbkFjdGl2ZTogZmFsc2UsXG5cdFx0bGVhdmVPcGVuQWZ0ZXJFeGl0OiB0cnVlLFxuXHRcdGFsbG93UmVsYXVuY2hpbmdUZXJtaW5hbHNPblN0YXJ0dXA6IHRydWUsXG5cdFx0cmVsYXVuY2hUZXJtaW5hbE9uU3RhcnR1cDogdHJ1ZSxcblx0XHR1c2VyRGF0YVBhdGg6ICgoKSA9PiB7XG5cdFx0XHRsZXQgYXBwRGF0YVBhdGhcblx0XHRcdGlmIChwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInKSB7XG5cdFx0XHRcdGFwcERhdGFQYXRoID0gcHJvY2Vzcy5lbnYuQVBQREFUQSB8fCBwYXRoLmpvaW4ob3MuaG9tZWRpcigpLCAnQXBwRGF0YScsICdSb2FtaW5nJylcblx0XHRcdH0gZWxzZSBpZiAocHJvY2Vzcy5wbGF0Zm9ybSA9PT0gJ2RhcndpbicpIHtcblx0XHRcdFx0YXBwRGF0YVBhdGggPSBwYXRoLmpvaW4ob3MuaG9tZWRpcigpLCAnTGlicmFyeScsICdBcHBsaWNhdGlvbiBTdXBwb3J0Jylcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGFwcERhdGFQYXRoID0gcHJvY2Vzcy5lbnYuWERHX0NPTkZJR19IT01FIHx8IHBhdGguam9pbihvcy5ob21lZGlyKCksICcuY29uZmlnJylcblx0XHRcdH1cblx0XHRcdHJldHVybiBwYXRoLmpvaW4oYXBwRGF0YVBhdGgsICd4LXRlcm1pbmFsJylcblx0XHR9KSgpLFxuXHRcdHRpdGxlOiAnJyxcblx0XHR4dGVybU9wdGlvbnM6ICd7fScsXG5cdFx0cHJvbXB0VG9TdGFydHVwOiBmYWxzZSxcblx0XHRjb3B5T25TZWxlY3Q6IGZhbHNlLFxuXHRcdGFwaU9wZW5Qb3NpdGlvbjogJ0NlbnRlcicsXG5cdH1cbn1cblxuZXhwb3J0IGNvbnN0IGNvbmZpZ0RlZmF1bHRzID0gcmVzZXRDb25maWdEZWZhdWx0cygpXG5cbmZ1bmN0aW9uIGNvbmZpZ09yZGVyIChvYmopIHtcblx0bGV0IG9yZGVyID0gMVxuXHRmb3IgKGNvbnN0IG5hbWUgaW4gb2JqKSB7XG5cdFx0b2JqW25hbWVdLm9yZGVyID0gb3JkZXIrK1xuXHRcdGlmIChvYmpbbmFtZV0udHlwZSA9PT0gJ29iamVjdCcgJiYgJ3Byb3BlcnRpZXMnIGluIG9ialtuYW1lXSkge1xuXHRcdFx0Y29uZmlnT3JkZXIob2JqW25hbWVdLnByb3BlcnRpZXMpXG5cdFx0fVxuXHR9XG5cdHJldHVybiBvYmpcbn1cblxuZXhwb3J0IGNvbnN0IGNvbmZpZyA9IGNvbmZpZ09yZGVyKHtcblx0c3Bhd25QdHlTZXR0aW5nczoge1xuXHRcdHRpdGxlOiAnU2hlbGwgUHJvY2VzcyBTZXR0aW5ncycsXG5cdFx0ZGVzY3JpcHRpb246ICdTZXR0aW5ncyByZWxhdGVkIHRvIHRoZSBwcm9jZXNzIHJ1bm5pbmcgdGhlIHNoZWxsLicsXG5cdFx0dHlwZTogJ29iamVjdCcsXG5cdFx0cHJvcGVydGllczoge1xuXHRcdFx0Y29tbWFuZDoge1xuXHRcdFx0XHR0aXRsZTogJ0NvbW1hbmQnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ0NvbW1hbmQgdG8gcnVuJyxcblx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbW1hbmQsXG5cdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLmNvbW1hbmQsXG5cdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwuc3Bhd25QdHlTZXR0aW5ncy5jb21tYW5kJykgfHwgY29uZmlnRGVmYXVsdHMuY29tbWFuZCksXG5cdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC5nZXRNb2RlbCgpLmdldFRleHQoKSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0XHRhcmdzOiB7XG5cdFx0XHRcdHRpdGxlOiAnQXJndW1lbnRzJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdBcmd1bWVudHMgdG8gcGFzcyB0byBjb21tYW5kLCBtdXN0IGJlIGluIGEgW0pTT04gYXJyYXldKGh0dHBzOi8vd3d3Lnczc2Nob29scy5jb20vSlMvanNfanNvbl9hcnJheXMuYXNwKS4nLFxuXHRcdFx0XHR0eXBlOiAnc3RyaW5nJyxcblx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuYXJncyxcblx0XHRcdFx0cHJvZmlsZURhdGE6IHtcblx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogSlNPTi5wYXJzZShjb25maWdEZWZhdWx0cy5hcmdzKSxcblx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5wYXJzZSh2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+ICEhdmFsLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiB2YWxpZGF0ZUpzb25Db25maWdTZXR0aW5nKCd4LXRlcm1pbmFsLnNwYXduUHR5U2V0dGluZ3MuYXJncycsIGNvbmZpZ0RlZmF1bHRzLmFyZ3MsIHByZXZpb3VzVmFsdWUpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gcGFyc2VKc29uKGVsZW1lbnQuZ2V0TW9kZWwoKS5nZXRUZXh0KCksIGJhc2VWYWx1ZSwgQXJyYXkpLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0bmFtZToge1xuXHRcdFx0XHR0aXRsZTogJ1Rlcm1pbmFsIFR5cGUnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ1RoZSB0ZXJtaW5hbCB0eXBlIHRvIHVzZS4nLFxuXHRcdFx0XHR0eXBlOiAnc3RyaW5nJyxcblx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMudGVybVR5cGUsXG5cdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLnRlcm1UeXBlLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnNwYXduUHR5U2V0dGluZ3MubmFtZScpIHx8IGNvbmZpZ0RlZmF1bHRzLnRlcm1UeXBlKSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IChlbGVtZW50LmdldE1vZGVsKCkuZ2V0VGV4dCgpIHx8IGJhc2VWYWx1ZSksXG5cdFx0XHRcdFx0dG9NZW51U2V0dGluZzogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHR9LFxuXHRcdFx0fSxcblx0XHRcdGN3ZDoge1xuXHRcdFx0XHR0aXRsZTogJ1dvcmtpbmcgRGlyZWN0b3J5Jyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdUaGUgd29ya2luZyBkaXJlY3RvcnkgdG8gdXNlIHdoZW4gbGF1bmNoaW5nIGNvbW1hbmQuJyxcblx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmN3ZCxcblx0XHRcdFx0cHJvZmlsZURhdGE6IHtcblx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY3dkLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnNwYXduUHR5U2V0dGluZ3MuY3dkJykgfHwgY29uZmlnRGVmYXVsdHMuY3dkKSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IChlbGVtZW50LmdldE1vZGVsKCkuZ2V0VGV4dCgpIHx8IGJhc2VWYWx1ZSksXG5cdFx0XHRcdFx0dG9NZW51U2V0dGluZzogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHR9LFxuXHRcdFx0fSxcblx0XHRcdHByb2plY3RDd2Q6IHtcblx0XHRcdFx0dGl0bGU6ICdVc2UgUHJvamVjdCBEaXJlY3RvcnknLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ1VzZSBwcm9qZWN0IGRpcmVjdG9yeSBpZiBjd2QgaXMgaW4gYSBwcm9qZWN0IHdoZW4gbGF1bmNoaW5nIGNvbW1hbmQuJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5wcm9qZWN0Q3dkLFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy5wcm9qZWN0Q3dkLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiBKU09OLnBhcnNlKHZhbCksXG5cdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gKHZhbCAhPT0gbnVsbCAmJiB2YWwgIT09ICcnKSxcblx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gdmFsaWRhdGVCb29sZWFuQ29uZmlnU2V0dGluZygneC10ZXJtaW5hbC5zcGF3blB0eVNldHRpbmdzLnByb2plY3RDd2QnLCBjb25maWdEZWZhdWx0cy5wcm9qZWN0Q3dkKSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IGVsZW1lbnQuY2hlY2tlZCxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0ZW52OiB7XG5cdFx0XHRcdHRpdGxlOiAnRW52aXJvbm1lbnQnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ1RoZSBlbnZpcm9ubWVudCB0byB1c2Ugd2hlbiBsYXVuY2hpbmcgY29tbWFuZCwgbXVzdCBiZSBpbiBhIFtKU09OIG9iamVjdF0oaHR0cHM6Ly93d3cudzNzY2hvb2xzLmNvbS9KUy9qc19qc29uX29iamVjdHMuYXNwKS4gSWYgbm90IHNldCwgZGVmYXVsdHMgdG8gdGhlIGN1cnJlbnQgZW52aXJvbm1lbnQuJyxcblx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmVudixcblx0XHRcdFx0cHJvZmlsZURhdGE6IHtcblx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogbnVsbCxcblx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5wYXJzZSh2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+ICEhdmFsLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiB7XG5cdFx0XHRcdFx0XHRsZXQgZW52ID0gdmFsaWRhdGVKc29uQ29uZmlnU2V0dGluZygneC10ZXJtaW5hbC5zcGF3blB0eVNldHRpbmdzLmVudicsICdudWxsJylcblx0XHRcdFx0XHRcdGlmICghZW52IHx8IGVudi5jb25zdHJ1Y3RvciAhPT0gT2JqZWN0KSB7XG5cdFx0XHRcdFx0XHRcdGVudiA9IG51bGxcblx0XHRcdFx0XHRcdH1cblx0XHRcdFx0XHRcdHJldHVybiBlbnZcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gcGFyc2VKc29uKGVsZW1lbnQuZ2V0TW9kZWwoKS5nZXRUZXh0KCksIGJhc2VWYWx1ZSwgT2JqZWN0KSxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiBjb252ZXJ0TnVsbFRvRW1wdHlTdHJpbmcodmFsKSxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0XHRzZXRFbnY6IHtcblx0XHRcdFx0dGl0bGU6ICdFbnZpcm9ubWVudCBPdmVycmlkZXMnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ0Vudmlyb25tZW50IHZhcmlhYmxlcyB0byB1c2UgaW4gcGxhY2Ugb2YgdGhlIEF0b20gcHJvY2VzcyBlbnZpcm9ubWVudCwgbXVzdCBiZSBpbiBhIFtKU09OIG9iamVjdF0oaHR0cHM6Ly93d3cudzNzY2hvb2xzLmNvbS9KUy9qc19qc29uX29iamVjdHMuYXNwKS4nLFxuXHRcdFx0XHR0eXBlOiAnc3RyaW5nJyxcblx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuc2V0RW52LFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBKU09OLnBhcnNlKGNvbmZpZ0RlZmF1bHRzLnNldEVudiksXG5cdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5zdHJpbmdpZnkodmFsKSxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IEpTT04ucGFyc2UodmFsKSxcblx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiAhIXZhbCxcblx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gdmFsaWRhdGVKc29uQ29uZmlnU2V0dGluZygneC10ZXJtaW5hbC5zcGF3blB0eVNldHRpbmdzLnNldEVudicsIGNvbmZpZ0RlZmF1bHRzLnNldEVudiksXG5cdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiBwYXJzZUpzb24oZWxlbWVudC5nZXRNb2RlbCgpLmdldFRleHQoKSwgYmFzZVZhbHVlLCBPYmplY3QpLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0ZGVsZXRlRW52OiB7XG5cdFx0XHRcdHRpdGxlOiAnRW52aXJvbm1lbnQgRGVsZXRpb25zJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdFbnZpcm9ubWVudCB2YXJpYWJsZXMgdG8gZGVsZXRlIGZyb20gb3JpZ2luYWwgZW52aXJvbm1lbnQsIG11c3QgYmUgaW4gYSBbSlNPTiBhcnJheV0oaHR0cHM6Ly93d3cudzNzY2hvb2xzLmNvbS9KUy9qc19qc29uX2FycmF5cy5hc3ApLicsXG5cdFx0XHRcdHR5cGU6ICdzdHJpbmcnLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5kZWxldGVFbnYsXG5cdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IEpTT04ucGFyc2UoY29uZmlnRGVmYXVsdHMuZGVsZXRlRW52KSxcblx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5wYXJzZSh2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+ICEhdmFsLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiB2YWxpZGF0ZUpzb25Db25maWdTZXR0aW5nKCd4LXRlcm1pbmFsLnNwYXduUHR5U2V0dGluZ3MuZGVsZXRlRW52JywgY29uZmlnRGVmYXVsdHMuZGVsZXRlRW52KSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IHBhcnNlSnNvbihlbGVtZW50LmdldE1vZGVsKCkuZ2V0VGV4dCgpLCBiYXNlVmFsdWUsIEFycmF5KSxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHR9LFxuXHRcdFx0fSxcblx0XHRcdGVuY29kaW5nOiB7XG5cdFx0XHRcdHRpdGxlOiAnQ2hhcmFjdGVyIEVuY29kaW5nJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdDaGFyYWN0ZXIgZW5jb2RpbmcgdG8gdXNlIGluIHNwYXduZWQgdGVybWluYWwuJyxcblx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmVuY29kaW5nLFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBudWxsLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+ICh2YWwgPT09ICdudWxsJyA/IG51bGwgOiB2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwuc3Bhd25QdHlTZXR0aW5ncy5lbmNvZGluZycpIHx8IG51bGwpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gKGVsZW1lbnQuZ2V0TW9kZWwoKS5nZXRUZXh0KCkgfHwgYmFzZVZhbHVlKSxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiBjb252ZXJ0TnVsbFRvRW1wdHlTdHJpbmcodmFsKSxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0fSxcblx0fSxcblx0eHRlcm1BZGRvbnM6IHtcblx0XHR0aXRsZTogJ3h0ZXJtLmpzIEFkZG9ucycsXG5cdFx0ZGVzY3JpcHRpb246ICdTZWxlY3QgdGhlIHh0ZXJtLmpzIGFkZG9ucyB0byBlbmFibGUnLFxuXHRcdHR5cGU6ICdvYmplY3QnLFxuXHRcdHByb3BlcnRpZXM6IHtcblx0XHRcdHdlYmdsOiB7XG5cdFx0XHRcdHRpdGxlOiAnV2ViR0wgUmVuZGVyZXInLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ0VuYWJsZSB0aGUgV2ViR0wtYmFzZWQgcmVuZGVyZXIgdXNpbmcgdGhlICoqZXhwZXJpbWVudGFsKiogeHRlcm0uanMgW1dlYkdMIGFkZG9uXShodHRwczovL2dpdGh1Yi5jb20veHRlcm1qcy94dGVybS5qcy90cmVlL21hc3Rlci9hZGRvbnMveHRlcm0tYWRkb24td2ViZ2wpJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy53ZWJnbCxcblx0XHRcdFx0cHJvZmlsZURhdGE6IHtcblx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMud2ViZ2wsXG5cdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5zdHJpbmdpZnkodmFsKSxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IEpTT04ucGFyc2UodmFsKSxcblx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiAodmFsICE9PSBudWxsICYmIHZhbCAhPT0gJycpLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiB2YWxpZGF0ZUJvb2xlYW5Db25maWdTZXR0aW5nKCd4LXRlcm1pbmFsLnh0ZXJtQWRkb25zLndlYmdsJywgY29uZmlnRGVmYXVsdHMud2ViZ2wpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gZWxlbWVudC5jaGVja2VkLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0XHR3ZWJMaW5rczoge1xuXHRcdFx0XHR0aXRsZTogJ1dlYiBMaW5rcycsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnRW5hYmxlIGNsaWNrYWJsZSB3ZWIgbGlua3MgdXNpbmcgdGhlIHh0ZXJtLmpzIFtXZWIgbGlua3MgYWRkb25dKGh0dHBzOi8vZ2l0aHViLmNvbS94dGVybWpzL3h0ZXJtLmpzL3RyZWUvbWFzdGVyL2FkZG9ucy94dGVybS1hZGRvbi13ZWItbGlua3MpJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy53ZWJMaW5rcyxcblx0XHRcdFx0cHJvZmlsZURhdGE6IHtcblx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMud2ViTGlua3MsXG5cdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5zdHJpbmdpZnkodmFsKSxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IEpTT04ucGFyc2UodmFsKSxcblx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiAodmFsICE9PSBudWxsICYmIHZhbCAhPT0gJycpLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiB2YWxpZGF0ZUJvb2xlYW5Db25maWdTZXR0aW5nKCd4LXRlcm1pbmFsLnh0ZXJtQWRkb25zLndlYkxpbmtzJywgY29uZmlnRGVmYXVsdHMud2ViTGlua3MpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gZWxlbWVudC5jaGVja2VkLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0fSxcblx0fSxcblx0dGVybWluYWxTZXR0aW5nczoge1xuXHRcdHRpdGxlOiAnVGVybWluYWwgRW11bGF0b3IgU2V0dGluZ3MnLFxuXHRcdGRlc2NyaXB0aW9uOiAnU2V0dGluZ3MgZm9yIHRoZSB0ZXJtaW5hbCBlbXVsYXRvci4nLFxuXHRcdHR5cGU6ICdvYmplY3QnLFxuXHRcdHByb3BlcnRpZXM6IHtcblx0XHRcdHRpdGxlOiB7XG5cdFx0XHRcdHRpdGxlOiAnVGVybWluYWwgdGFiIHRpdGxlJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdUaXRsZSB0byB1c2UgZm9yIHRlcm1pbmFsIHRhYnMuJyxcblx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLnRpdGxlLFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBudWxsLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+ICh2YWwgPT09ICdudWxsJyA/IG51bGwgOiB2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy50aXRsZScpIHx8IGNvbmZpZ0RlZmF1bHRzLnRpdGxlIHx8IG51bGwpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gKGVsZW1lbnQuZ2V0TW9kZWwoKS5nZXRUZXh0KCkgfHwgYmFzZVZhbHVlKSxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiAodmFsIHx8ICcnKSxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0XHR4dGVybU9wdGlvbnM6IHtcblx0XHRcdFx0dGl0bGU6ICd4dGVybS5qcyBUZXJtaW5hbCBPcHRpb25zJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdPcHRpb25zIHRvIGFwcGx5IHRvIHh0ZXJtLmpzIHRlcm1pbmFsIG9iamVjdHMsIG11c3QgYmUgaW4gYSBbSlNPTiBvYmplY3RdKGh0dHBzOi8vd3d3Lnczc2Nob29scy5jb20vSlMvanNfanNvbl9vYmplY3RzLmFzcCkuIFJlYWQgbW9yZSBvbiB0aGUgc3VwcG9ydGVkIFt4dGVybS5qcyBBUEkgcHJvcGVydGllc10oaHR0cHM6Ly94dGVybWpzLm9yZy9kb2NzL2FwaS90ZXJtaW5hbC9pbnRlcmZhY2VzL2l0ZXJtaW5hbG9wdGlvbnMvI3Byb3BlcnRpZXMpLicsXG5cdFx0XHRcdHR5cGU6ICdzdHJpbmcnLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy54dGVybU9wdGlvbnMsXG5cdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0dGVybWluYWxGcm9udEVuZDogdHJ1ZSxcblx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogSlNPTi5wYXJzZShjb25maWdEZWZhdWx0cy54dGVybU9wdGlvbnMpLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiBKU09OLnBhcnNlKHZhbCksXG5cdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gISF2YWwsXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IHZhbGlkYXRlSnNvbkNvbmZpZ1NldHRpbmcoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy54dGVybU9wdGlvbnMnLCBjb25maWdEZWZhdWx0cy54dGVybU9wdGlvbnMsIHByZXZpb3VzVmFsdWUpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gcGFyc2VKc29uKGVsZW1lbnQuZ2V0TW9kZWwoKS5nZXRUZXh0KCksIGJhc2VWYWx1ZSwgT2JqZWN0KSxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHR9LFxuXHRcdFx0fSxcblx0XHRcdHVzZUVkaXRvckZvbnQ6IHtcblx0XHRcdFx0dGl0bGU6ICdVc2UgZWRpdG9yXFwncyBGb250IEZhbWlseScsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnVXNlIGVkaXRvclxcJ3MgRm9udCBGYW1pbHkgc2V0dGluZyBpbiB0aGUgdGVybWluYWwuIChPdmVycmlkZXMgRm9udCBGYW1pbHkgYmVsb3cpJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy51c2VFZGl0b3JGb250LFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy51c2VFZGl0b3JGb250LFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiBKU09OLnBhcnNlKHZhbCksXG5cdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gKHZhbCAhPT0gbnVsbCAmJiB2YWwgIT09ICcnKSxcblx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gdmFsaWRhdGVCb29sZWFuQ29uZmlnU2V0dGluZygneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLnVzZUVkaXRvckZvbnQnLCBjb25maWdEZWZhdWx0cy51c2VFZGl0b3JGb250KSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IGVsZW1lbnQuY2hlY2tlZCxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0Zm9udEZhbWlseToge1xuXHRcdFx0XHR0aXRsZTogJ0ZvbnQgRmFtaWx5Jyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdGb250IGZhbWlseSB1c2VkIGluIHRlcm1pbmFsIGVtdWxhdG9yLicsXG5cdFx0XHRcdHR5cGU6ICdzdHJpbmcnLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5mb250RmFtaWx5LFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdHRlcm1pbmFsRnJvbnRFbmQ6IHRydWUsXG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLmZvbnRGYW1pbHksXG5cdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IGdldEZvbnRGYW1pbHlCYXNlUHJvZmlsZSgpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gKGVsZW1lbnQuZ2V0TW9kZWwoKS5nZXRUZXh0KCkgfHwgYmFzZVZhbHVlKSxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0Zm9udFNpemU6IHtcblx0XHRcdFx0dGl0bGU6ICdGb250IFNpemUnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ0ZvbnQgc2l6ZSB1c2VkIGluIHRlcm1pbmFsIGVtdWxhdG9yLicsXG5cdFx0XHRcdHR5cGU6ICdpbnRlZ2VyJyxcblx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuZm9udFNpemUsXG5cdFx0XHRcdG1pbmltdW06IGNvbmZpZ0RlZmF1bHRzLm1pbmltdW1Gb250U2l6ZSxcblx0XHRcdFx0bWF4aW11bTogY29uZmlnRGVmYXVsdHMubWF4aW11bUZvbnRTaXplLFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdHRlcm1pbmFsRnJvbnRFbmQ6IHRydWUsXG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLmZvbnRTaXplLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiBKU09OLnBhcnNlKHZhbCksXG5cdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gISF2YWwsXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5mb250U2l6ZScpIHx8IGNvbmZpZ0RlZmF1bHRzLmZvbnRTaXplKSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IHBhcnNlSnNvbihlbGVtZW50LmdldE1vZGVsKCkuZ2V0VGV4dCgpLCBiYXNlVmFsdWUsIE51bWJlciksXG5cdFx0XHRcdFx0dG9NZW51U2V0dGluZzogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHR9LFxuXHRcdFx0fSxcblx0XHRcdGRlZmF1bHRPcGVuUG9zaXRpb246IHtcblx0XHRcdFx0dGl0bGU6ICdEZWZhdWx0IE9wZW4gUG9zaXRpb24nLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ1Bvc2l0aW9uIHRvIG9wZW4gdGVybWluYWwgdGhyb3VnaCBzZXJ2aWNlIEFQSSBvciB4LXRlcm1pbmFsOm9wZW4uJyxcblx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdGVudW06IFtcblx0XHRcdFx0XHQnQ2VudGVyJyxcblx0XHRcdFx0XHQnU3BsaXQgVXAnLFxuXHRcdFx0XHRcdCdTcGxpdCBEb3duJyxcblx0XHRcdFx0XHQnU3BsaXQgTGVmdCcsXG5cdFx0XHRcdFx0J1NwbGl0IFJpZ2h0Jyxcblx0XHRcdFx0XHQnQm90dG9tIERvY2snLFxuXHRcdFx0XHRcdCdMZWZ0IERvY2snLFxuXHRcdFx0XHRcdCdSaWdodCBEb2NrJyxcblx0XHRcdFx0XSxcblx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuYXBpT3BlblBvc2l0aW9uLFxuXHRcdFx0fSxcblx0XHRcdHByb21wdFRvU3RhcnR1cDoge1xuXHRcdFx0XHR0aXRsZTogJ1Byb21wdCB0byBzdGFydCBjb21tYW5kJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdXaGV0aGVyIHRvIHByb21wdCB0byBzdGFydCBjb21tYW5kIGluIHRlcm1pbmFsIG9uIHN0YXJ0dXAuJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5wcm9tcHRUb1N0YXJ0dXAsXG5cdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLnByb21wdFRvU3RhcnR1cCxcblx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5wYXJzZSh2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+ICh2YWwgIT09IG51bGwgJiYgdmFsICE9PSAnJyksXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IHZhbGlkYXRlQm9vbGVhbkNvbmZpZ1NldHRpbmcoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5wcm9tcHRUb1N0YXJ0dXAnLCBjb25maWdEZWZhdWx0cy5wcm9tcHRUb1N0YXJ0dXApLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gZWxlbWVudC5jaGVja2VkLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0XHRhbGxvd0hpZGRlblRvU3RheUFjdGl2ZToge1xuXHRcdFx0XHR0aXRsZTogJ0FsbG93IEhpZGRlbiBUZXJtaW5hbCBUbyBTdGF5IEFjdGl2ZScsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnV2hlbiBhbiBhY3RpdmUgdGVybWluYWwgaXMgaGlkZGVuIGtlZXAgaXQgYWN0aXZlIHVudGlsIGFub3RoZXIgdGVybWluYWwgaXMgZm9jdXNlZC4nLFxuXHRcdFx0XHR0eXBlOiAnYm9vbGVhbicsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmFsbG93SGlkZGVuVG9TdGF5QWN0aXZlLFxuXHRcdFx0fSxcblx0XHRcdHJ1bkluQWN0aXZlOiB7XG5cdFx0XHRcdHRpdGxlOiAnUnVuIGluIEFjdGl2ZSBUZXJtaW5hbCcsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnV2hldGhlciB0byBydW4gY29tbWFuZHMgZnJvbSB0aGUgc2VydmljZSBBUEkgaW4gdGhlIGFjdGl2ZSB0ZXJtaW5hbCBvciBpbiBhIG5ldyB0ZXJtaW5hbC4nLFxuXHRcdFx0XHR0eXBlOiAnYm9vbGVhbicsXG5cdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLnJ1bkluQWN0aXZlLFxuXHRcdFx0fSxcblx0XHRcdGxlYXZlT3BlbkFmdGVyRXhpdDoge1xuXHRcdFx0XHR0aXRsZTogJ0xlYXZlIE9wZW4gQWZ0ZXIgRXhpdCcsXG5cdFx0XHRcdGRlc2NyaXB0aW9uOiAnV2hldGhlciB0byBsZWF2ZSB0ZXJtaW5hbCBlbXVsYXRvcnMgb3BlbiBhZnRlciB0aGVpciBzaGVsbCBwcm9jZXNzZXMgaGF2ZSBleGl0ZWQuJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5sZWF2ZU9wZW5BZnRlckV4aXQsXG5cdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLmxlYXZlT3BlbkFmdGVyRXhpdCxcblx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiBKU09OLnN0cmluZ2lmeSh2YWwpLFxuXHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5wYXJzZSh2YWwpLFxuXHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+ICh2YWwgIT09IG51bGwgJiYgdmFsICE9PSAnJyksXG5cdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IHZhbGlkYXRlQm9vbGVhbkNvbmZpZ1NldHRpbmcoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5sZWF2ZU9wZW5BZnRlckV4aXQnLCBjb25maWdEZWZhdWx0cy5sZWF2ZU9wZW5BZnRlckV4aXQpLFxuXHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gZWxlbWVudC5jaGVja2VkLFxuXHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0fSxcblx0XHRcdH0sXG5cdFx0XHRhbGxvd1JlbGF1bmNoaW5nVGVybWluYWxzT25TdGFydHVwOiB7XG5cdFx0XHRcdHRpdGxlOiAnQWxsb3cgcmVsYXVuY2hpbmcgdGVybWluYWxzIG9uIHN0YXJ0dXAnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ1doZXRoZXIgdG8gYWxsb3cgcmVsYXVuY2hpbmcgdGVybWluYWxzIG9uIHN0YXJ0dXAuJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5hbGxvd1JlbGF1bmNoaW5nVGVybWluYWxzT25TdGFydHVwLFxuXHRcdFx0fSxcblx0XHRcdHJlbGF1bmNoVGVybWluYWxPblN0YXJ0dXA6IHtcblx0XHRcdFx0dGl0bGU6ICdSZWxhdW5jaCB0ZXJtaW5hbCBvbiBzdGFydHVwJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdXaGV0aGVyIHRvIHJlbGF1bmNoIHRlcm1pbmFsIG9uIHN0YXJ0dXAuJyxcblx0XHRcdFx0dHlwZTogJ2Jvb2xlYW4nLFxuXHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5yZWxhdW5jaFRlcm1pbmFsT25TdGFydHVwLFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy5yZWxhdW5jaFRlcm1pbmFsT25TdGFydHVwLFxuXHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IEpTT04uc3RyaW5naWZ5KHZhbCksXG5cdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiBKU09OLnBhcnNlKHZhbCksXG5cdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gKHZhbCAhPT0gbnVsbCAmJiB2YWwgIT09ICcnKSxcblx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gdmFsaWRhdGVCb29sZWFuQ29uZmlnU2V0dGluZygneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLnJlbGF1bmNoVGVybWluYWxPblN0YXJ0dXAnLCBjb25maWdEZWZhdWx0cy5yZWxhdW5jaFRlcm1pbmFsT25TdGFydHVwKSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IGVsZW1lbnQuY2hlY2tlZCxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0Y29weU9uU2VsZWN0OiB7XG5cdFx0XHRcdHRpdGxlOiAnQ29weSBPbiBTZWxlY3QnLFxuXHRcdFx0XHRkZXNjcmlwdGlvbjogJ0NvcHkgdGV4dCB0byBjbGlwYm9hcmQgb24gc2VsZWN0aW9uLicsXG5cdFx0XHRcdHR5cGU6ICdib29sZWFuJyxcblx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuY29weU9uU2VsZWN0LFxuXHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy5jb3B5T25TZWxlY3QsXG5cdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gSlNPTi5zdHJpbmdpZnkodmFsKSxcblx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IEpTT04ucGFyc2UodmFsKSxcblx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiAodmFsICE9PSBudWxsICYmIHZhbCAhPT0gJycpLFxuXHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiB2YWxpZGF0ZUJvb2xlYW5Db25maWdTZXR0aW5nKCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29weU9uU2VsZWN0JywgY29uZmlnRGVmYXVsdHMuY29weU9uU2VsZWN0KSxcblx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IGVsZW1lbnQuY2hlY2tlZCxcblx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdFx0Y29sb3JzOiB7XG5cdFx0XHRcdHRpdGxlOiAnQ29sb3JzJyxcblx0XHRcdFx0ZGVzY3JpcHRpb246ICdTZXR0aW5ncyBmb3IgdGhlIHRlcm1pbmFsIGNvbG9ycy4nLFxuXHRcdFx0XHR0eXBlOiAnb2JqZWN0Jyxcblx0XHRcdFx0cHJvcGVydGllczoge1xuXHRcdFx0XHRcdHRoZW1lOiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ1RoZW1lJyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnVGhlbWUgdXNlZCBpbiB0ZXJtaW5hbCBlbXVsYXRvci4nLFxuXHRcdFx0XHRcdFx0dHlwZTogJ3N0cmluZycsXG5cdFx0XHRcdFx0XHRlbnVtOiBbXG5cdFx0XHRcdFx0XHRcdCdDdXN0b20nLFxuXHRcdFx0XHRcdFx0XHQnQXRvbSBEYXJrJyxcblx0XHRcdFx0XHRcdFx0J0F0b20gTGlnaHQnLFxuXHRcdFx0XHRcdFx0XHQnQmFzZTE2IFRvbW9ycm93IERhcmsnLFxuXHRcdFx0XHRcdFx0XHQnQmFzZTE2IFRvbW9ycm93IExpZ2h0Jyxcblx0XHRcdFx0XHRcdFx0J0NocmlzdG1hcycsXG5cdFx0XHRcdFx0XHRcdCdDaXR5IExpZ2h0cycsXG5cdFx0XHRcdFx0XHRcdCdEcmFjdWxhJyxcblx0XHRcdFx0XHRcdFx0J0dyYXNzJyxcblx0XHRcdFx0XHRcdFx0J0hvbWVicmV3Jyxcblx0XHRcdFx0XHRcdFx0J0ludmVyc2UnLFxuXHRcdFx0XHRcdFx0XHQnTGludXgnLFxuXHRcdFx0XHRcdFx0XHQnTWFuIFBhZ2UnLFxuXHRcdFx0XHRcdFx0XHQnTm92ZWwnLFxuXHRcdFx0XHRcdFx0XHQnT2NlYW4nLFxuXHRcdFx0XHRcdFx0XHQnT25lIERhcmsnLFxuXHRcdFx0XHRcdFx0XHQnT25lIExpZ2h0Jyxcblx0XHRcdFx0XHRcdFx0J1ByZWRhd24nLFxuXHRcdFx0XHRcdFx0XHQnUHJvJyxcblx0XHRcdFx0XHRcdFx0J1JlZCBTYW5kcycsXG5cdFx0XHRcdFx0XHRcdCdSZWQnLFxuXHRcdFx0XHRcdFx0XHQnU2lsdmVyIEFlcm9nZWwnLFxuXHRcdFx0XHRcdFx0XHQnU29sYXJpemVkIERhcmsnLFxuXHRcdFx0XHRcdFx0XHQnU29sYXJpemVkIExpZ2h0Jyxcblx0XHRcdFx0XHRcdFx0J1NvbGlkIENvbG9ycycsXG5cdFx0XHRcdFx0XHRcdCdTdGFuZGFyZCcsXG5cdFx0XHRcdFx0XHRdLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMudGhlbWUsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMudGhlbWUsXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLnRoZW1lJykgfHwgY29uZmlnRGVmYXVsdHMudGhlbWUpLFxuXHRcdFx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IChlbGVtZW50LnZhbHVlIHx8IGJhc2VWYWx1ZSksXG5cdFx0XHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRmb3JlZ3JvdW5kOiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ1RleHQgQ29sb3InLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdUaGlzIHdpbGwgYmUgb3ZlcnJpZGRlbiBpZiB0aGUgdGhlbWUgaXMgbm90IFxcJ0N1c3RvbVxcJy4nLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yRm9yZWdyb3VuZCxcblx0XHRcdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0XHRcdHRlcm1pbmFsRnJvbnRFbmQ6IHRydWUsXG5cdFx0XHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy5jb2xvckZvcmVncm91bmQsXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLmZvcmVncm91bmQnKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckZvcmVncm91bmQpLFxuXHRcdFx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IChlbGVtZW50LnZhbHVlIHx8IGJhc2VWYWx1ZSksXG5cdFx0XHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRiYWNrZ3JvdW5kOiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ0JhY2tncm91bmQgQ29sb3InLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdUaGlzIHdpbGwgYmUgb3ZlcnJpZGRlbiBpZiB0aGUgdGhlbWUgaXMgbm90IFxcJ0N1c3RvbVxcJy4nLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQmFja2dyb3VuZCxcblx0XHRcdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0XHRcdHRlcm1pbmFsRnJvbnRFbmQ6IHRydWUsXG5cdFx0XHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy5jb2xvckJhY2tncm91bmQsXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLmJhY2tncm91bmQnKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckJhY2tncm91bmQpLFxuXHRcdFx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IChlbGVtZW50LnZhbHVlIHx8IGJhc2VWYWx1ZSksXG5cdFx0XHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRjdXJzb3I6IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQ3Vyc29yIENvbG9yJyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnQ2FuIGJlIHRyYW5zcGFyZW50LiBUaGlzIHdpbGwgYmUgb3ZlcnJpZGRlbiBpZiB0aGUgdGhlbWUgaXMgbm90IFxcJ0N1c3RvbVxcJy4nLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQ3Vyc29yLFxuXHRcdFx0XHRcdFx0cHJvZmlsZURhdGE6IHtcblx0XHRcdFx0XHRcdFx0dGVybWluYWxGcm9udEVuZDogdHJ1ZSxcblx0XHRcdFx0XHRcdFx0ZGVmYXVsdFByb2ZpbGU6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQ3Vyc29yLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5jdXJzb3InKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckN1cnNvciksXG5cdFx0XHRcdFx0XHRcdGZyb21NZW51U2V0dGluZzogKGVsZW1lbnQsIGJhc2VWYWx1ZSkgPT4gKGVsZW1lbnQudmFsdWUgfHwgYmFzZVZhbHVlKSxcblx0XHRcdFx0XHRcdFx0dG9NZW51U2V0dGluZzogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0fSxcblx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdGN1cnNvckFjY2VudDoge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdDdXJzb3IgVGV4dCBDb2xvcicsXG5cdFx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ0NhbiBiZSB0cmFuc3BhcmVudC4gVGhpcyB3aWxsIGJlIG92ZXJyaWRkZW4gaWYgdGhlIHRoZW1lIGlzIG5vdCBcXCdDdXN0b21cXCcuJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvckN1cnNvckFjY2VudCxcblx0XHRcdFx0XHRcdHByb2ZpbGVEYXRhOiB7XG5cdFx0XHRcdFx0XHRcdHRlcm1pbmFsRnJvbnRFbmQ6IHRydWUsXG5cdFx0XHRcdFx0XHRcdGRlZmF1bHRQcm9maWxlOiBjb25maWdEZWZhdWx0cy5jb2xvckN1cnNvckFjY2VudCxcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMuY3Vyc29yQWNjZW50JykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JDdXJzb3JBY2NlbnQpLFxuXHRcdFx0XHRcdFx0XHRmcm9tTWVudVNldHRpbmc6IChlbGVtZW50LCBiYXNlVmFsdWUpID0+IChlbGVtZW50LnZhbHVlIHx8IGJhc2VWYWx1ZSksXG5cdFx0XHRcdFx0XHRcdHRvTWVudVNldHRpbmc6ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0fSxcblx0XHRcdFx0XHRzZWxlY3Rpb246IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnU2VsZWN0aW9uIEJhY2tncm91bmQgQ29sb3InLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdDYW4gYmUgdHJhbnNwYXJlbnQuIFRoaXMgd2lsbCBiZSBvdmVycmlkZGVuIGlmIHRoZSB0aGVtZSBpcyBub3QgXFwnQ3VzdG9tXFwnLicsXG5cdFx0XHRcdFx0XHR0eXBlOiAnY29sb3InLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuY29sb3JTZWxlY3Rpb24sXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JTZWxlY3Rpb24sXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLnNlbGVjdGlvbicpIHx8IGNvbmZpZ0RlZmF1bHRzLmNvbG9yU2VsZWN0aW9uKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YmxhY2s6IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQU5TSSBCbGFjaycsXG5cdFx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ2BcXFxceDFiWzMwbWAnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQmxhY2ssXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCbGFjayxcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMuYmxhY2snKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckJsYWNrKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0cmVkOiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ0FOU0kgUmVkJyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnYFxcXFx4MWJbMzFtYCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnY29sb3InLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuY29sb3JSZWQsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JSZWQsXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLnJlZCcpIHx8IGNvbmZpZ0RlZmF1bHRzLmNvbG9yUmVkKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0Z3JlZW46IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQU5TSSBHcmVlbicsXG5cdFx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ2BcXFxceDFiWzMybWAnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yR3JlZW4sXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JHcmVlbixcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMuZ3JlZW4nKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckdyZWVuKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0eWVsbG93OiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ0FOU0kgWWVsbG93Jyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnYFxcXFx4MWJbMzNtYCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnY29sb3InLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuY29sb3JZZWxsb3csXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JZZWxsb3csXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLnllbGxvdycpIHx8IGNvbmZpZ0RlZmF1bHRzLmNvbG9yWWVsbG93KSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0Ymx1ZToge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdBTlNJIEJsdWUnLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdgXFxcXHgxYlszNG1gJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvckJsdWUsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCbHVlLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5ibHVlJykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JCbHVlKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0bWFnZW50YToge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdBTlNJIE1hZ2VudGEnLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdgXFxcXHgxYlszNW1gJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvck1hZ2VudGEsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JNYWdlbnRhLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5tYWdlbnRhJykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JNYWdlbnRhKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0Y3lhbjoge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdBTlNJIEN5YW4nLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdgXFxcXHgxYlszNm1gJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvckN5YW4sXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JDeWFuLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5jeWFuJykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JDeWFuKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0d2hpdGU6IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQU5TSSBXaGl0ZScsXG5cdFx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ2BcXFxceDFiWzM3bWAnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yV2hpdGUsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JXaGl0ZSxcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMud2hpdGUnKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvcldoaXRlKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0QmxhY2s6IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQU5TSSBCcmlnaHQgQmxhY2snLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdgXFxcXHgxYlsxOzMwbWAnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQnJpZ2h0QmxhY2ssXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRCbGFjayxcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMuYnJpZ2h0QmxhY2snKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckJyaWdodEJsYWNrKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0UmVkOiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ0FOU0kgQnJpZ2h0IFJlZCcsXG5cdFx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ2BcXFxceDFiWzE7MzFtYCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnY29sb3InLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRSZWQsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRSZWQsXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLmJyaWdodFJlZCcpIHx8IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQnJpZ2h0UmVkKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0R3JlZW46IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQU5TSSBCcmlnaHQgR3JlZW4nLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdgXFxcXHgxYlsxOzMybWAnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQnJpZ2h0R3JlZW4sXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRHcmVlbixcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMuYnJpZ2h0R3JlZW4nKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckJyaWdodEdyZWVuKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0WWVsbG93OiB7XG5cdFx0XHRcdFx0XHR0aXRsZTogJ0FOU0kgQnJpZ2h0IFllbGxvdycsXG5cdFx0XHRcdFx0XHRkZXNjcmlwdGlvbjogJ2BcXFxceDFiWzE7MzNtYCcsXG5cdFx0XHRcdFx0XHR0eXBlOiAnY29sb3InLFxuXHRcdFx0XHRcdFx0ZGVmYXVsdDogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRZZWxsb3csXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRZZWxsb3csXG5cdFx0XHRcdFx0XHRcdHRvVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0ZnJvbVVybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGNoZWNrVXJsUGFyYW06ICh2YWwpID0+IHRydWUsXG5cdFx0XHRcdFx0XHRcdHRvQmFzZVByb2ZpbGU6IChwcmV2aW91c1ZhbHVlKSA9PiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuY29sb3JzLmJyaWdodFllbGxvdycpIHx8IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQnJpZ2h0WWVsbG93KSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0Qmx1ZToge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdBTlNJIEJyaWdodCBCbHVlJyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnYFxcXFx4MWJbMTszNG1gJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvckJyaWdodEJsdWUsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRCbHVlLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5icmlnaHRCbHVlJykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRCbHVlKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0TWFnZW50YToge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdBTlNJIEJyaWdodCBNYWdlbnRhJyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnYFxcXFx4MWJbMTszNW1gJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvckJyaWdodE1hZ2VudGEsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRNYWdlbnRhLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5icmlnaHRNYWdlbnRhJykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRNYWdlbnRhKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0Q3lhbjoge1xuXHRcdFx0XHRcdFx0dGl0bGU6ICdBTlNJIEJyaWdodCBDeWFuJyxcblx0XHRcdFx0XHRcdGRlc2NyaXB0aW9uOiAnYFxcXFx4MWJbMTszNm1gJyxcblx0XHRcdFx0XHRcdHR5cGU6ICdjb2xvcicsXG5cdFx0XHRcdFx0XHRkZWZhdWx0OiBjb25maWdEZWZhdWx0cy5jb2xvckJyaWdodEN5YW4sXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRDeWFuLFxuXHRcdFx0XHRcdFx0XHR0b1VybFBhcmFtOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHRcdGZyb21VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRjaGVja1VybFBhcmFtOiAodmFsKSA9PiB0cnVlLFxuXHRcdFx0XHRcdFx0XHR0b0Jhc2VQcm9maWxlOiAocHJldmlvdXNWYWx1ZSkgPT4gKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmNvbG9ycy5icmlnaHRDeWFuJykgfHwgY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRDeWFuKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdFx0YnJpZ2h0V2hpdGU6IHtcblx0XHRcdFx0XHRcdHRpdGxlOiAnQU5TSSBCcmlnaHQgV2hpdGUnLFxuXHRcdFx0XHRcdFx0ZGVzY3JpcHRpb246ICdgXFxcXHgxYlsxOzM3bWAnLFxuXHRcdFx0XHRcdFx0dHlwZTogJ2NvbG9yJyxcblx0XHRcdFx0XHRcdGRlZmF1bHQ6IGNvbmZpZ0RlZmF1bHRzLmNvbG9yQnJpZ2h0V2hpdGUsXG5cdFx0XHRcdFx0XHRwcm9maWxlRGF0YToge1xuXHRcdFx0XHRcdFx0XHR0ZXJtaW5hbEZyb250RW5kOiB0cnVlLFxuXHRcdFx0XHRcdFx0XHRkZWZhdWx0UHJvZmlsZTogY29uZmlnRGVmYXVsdHMuY29sb3JCcmlnaHRXaGl0ZSxcblx0XHRcdFx0XHRcdFx0dG9VcmxQYXJhbTogKHZhbCkgPT4gdmFsLFxuXHRcdFx0XHRcdFx0XHRmcm9tVXJsUGFyYW06ICh2YWwpID0+IHZhbCxcblx0XHRcdFx0XHRcdFx0Y2hlY2tVcmxQYXJhbTogKHZhbCkgPT4gdHJ1ZSxcblx0XHRcdFx0XHRcdFx0dG9CYXNlUHJvZmlsZTogKHByZXZpb3VzVmFsdWUpID0+IChhdG9tLmNvbmZpZy5nZXQoJ3gtdGVybWluYWwudGVybWluYWxTZXR0aW5ncy5jb2xvcnMuYnJpZ2h0V2hpdGUnKSB8fCBjb25maWdEZWZhdWx0cy5jb2xvckJyaWdodFdoaXRlKSxcblx0XHRcdFx0XHRcdFx0ZnJvbU1lbnVTZXR0aW5nOiAoZWxlbWVudCwgYmFzZVZhbHVlKSA9PiAoZWxlbWVudC52YWx1ZSB8fCBiYXNlVmFsdWUpLFxuXHRcdFx0XHRcdFx0XHR0b01lbnVTZXR0aW5nOiAodmFsKSA9PiB2YWwsXG5cdFx0XHRcdFx0XHR9LFxuXHRcdFx0XHRcdH0sXG5cdFx0XHRcdH0sXG5cdFx0XHR9LFxuXHRcdH0sXG5cdH0sXG59KVxuXG5mdW5jdGlvbiBnZXRGb250RmFtaWx5QmFzZVByb2ZpbGUgKCkge1xuXHRpZiAoYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MudXNlRWRpdG9yRm9udCcpICYmIGF0b20uY29uZmlnLmdldCgnZWRpdG9yLmZvbnRGYW1pbHknKSkge1xuXHRcdHJldHVybiBhdG9tLmNvbmZpZy5nZXQoJ2VkaXRvci5mb250RmFtaWx5Jylcblx0fVxuXHRyZXR1cm4gYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuZm9udEZhbWlseScpIHx8IGNvbmZpZ0RlZmF1bHRzLmZvbnRGYW1pbHlcbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVCb29sZWFuQ29uZmlnU2V0dGluZyAobmFtZSwgZGVmYXVsdFZhbHVlKSB7XG5cdGNvbnN0IHZhbHVlID0gYXRvbS5jb25maWcuZ2V0KG5hbWUpXG5cdHJldHVybiAodHlwZW9mIHZhbHVlID09PSAnYm9vbGVhbicgPyB2YWx1ZSA6IGRlZmF1bHRWYWx1ZSlcbn1cblxuZnVuY3Rpb24gdmFsaWRhdGVKc29uQ29uZmlnU2V0dGluZyAobmFtZSwgZGVmYXVsdEpzb25WYWx1ZSwgcHJldmlvdXNWYWx1ZSkge1xuXHRsZXQgdmFsdWUgPSBhdG9tLmNvbmZpZy5nZXQobmFtZSlcblx0dHJ5IHtcblx0XHR2YWx1ZSA9IEpTT04ucGFyc2UodmFsdWUgfHwgZGVmYXVsdEpzb25WYWx1ZSkgfHwgcHJldmlvdXNWYWx1ZVxuXHR9IGNhdGNoIChlKSB7XG5cdFx0Ly8gVGhpcyBub3JtYWxseSBoYXBwZW5zIHdoZW4gdGhlIHVzZXIgaXMgaW4gdGhlIG1pZGRsZSBvZiB1cGRhdGluZyBzb21lXG5cdFx0Ly8gc2V0dGluZyB0aGF0IGlzIGEgSlNPTiBzdHJpbmcuIElnbm9yZSBzeW50YXggZXJyb3JzIGFuZCB1c2UgdGhlIGxhc3Rcblx0XHQvLyBrbm93biBnb29kIGNvbmZpZyBzZXR0aW5nLlxuXHRcdGlmICghKGUgaW5zdGFuY2VvZiBTeW50YXhFcnJvcikpIHtcblx0XHRcdHRocm93IGVcblx0XHR9XG5cdFx0dmFsdWUgPSBwcmV2aW91c1ZhbHVlXG5cdH1cblx0cmV0dXJuIHZhbHVlXG59XG5cbmZ1bmN0aW9uIHBhcnNlSnNvbiAodmFsdWUsIGRlZmF1bHRWYWx1ZSwgdHlwZSkge1xuXHRsZXQgcmV0dmFsID0gdmFsdWVcblx0dHJ5IHtcblx0XHRyZXR2YWwgPSBKU09OLnBhcnNlKHJldHZhbClcblx0fSBjYXRjaCAoZSkge1xuXHRcdGlmICghKGUgaW5zdGFuY2VvZiBTeW50YXhFcnJvcikpIHtcblx0XHRcdHRocm93IGVcblx0XHR9XG5cdFx0cmV0dmFsID0gbnVsbFxuXHR9XG5cdGlmICghcmV0dmFsIHx8IHJldHZhbC5jb25zdHJ1Y3RvciAhPT0gdHlwZSkge1xuXHRcdHJldHZhbCA9IGRlZmF1bHRWYWx1ZVxuXHR9XG5cdHJldHVybiByZXR2YWxcbn1cblxuZnVuY3Rpb24gY29udmVydE51bGxUb0VtcHR5U3RyaW5nICh2YWx1ZSkge1xuXHRpZiAodmFsdWUgPT09IG51bGwpIHtcblx0XHRyZXR1cm4gJydcblx0fVxuXHRyZXR1cm4gSlNPTi5zdHJpbmdpZnkodmFsdWUpXG59XG5cbmV4cG9ydCBjb25zdCBDT0xPUlMgPSB7XG5cdGZvcmVncm91bmQ6ICdjb2xvckZvcmVncm91bmQnLFxuXHRiYWNrZ3JvdW5kOiAnY29sb3JCYWNrZ3JvdW5kJyxcblx0Y3Vyc29yOiAnY29sb3JDdXJzb3InLFxuXHRjdXJzb3JBY2NlbnQ6ICdjb2xvckN1cnNvckFjY2VudCcsXG5cdHNlbGVjdGlvbjogJ2NvbG9yU2VsZWN0aW9uJyxcblx0YmxhY2s6ICdjb2xvckJsYWNrJyxcblx0cmVkOiAnY29sb3JSZWQnLFxuXHRncmVlbjogJ2NvbG9yR3JlZW4nLFxuXHR5ZWxsb3c6ICdjb2xvclllbGxvdycsXG5cdGJsdWU6ICdjb2xvckJsdWUnLFxuXHRtYWdlbnRhOiAnY29sb3JNYWdlbnRhJyxcblx0Y3lhbjogJ2NvbG9yQ3lhbicsXG5cdHdoaXRlOiAnY29sb3JXaGl0ZScsXG5cdGJyaWdodEJsYWNrOiAnY29sb3JCcmlnaHRCbGFjaycsXG5cdGJyaWdodFJlZDogJ2NvbG9yQnJpZ2h0UmVkJyxcblx0YnJpZ2h0R3JlZW46ICdjb2xvckJyaWdodEdyZWVuJyxcblx0YnJpZ2h0WWVsbG93OiAnY29sb3JCcmlnaHRZZWxsb3cnLFxuXHRicmlnaHRCbHVlOiAnY29sb3JCcmlnaHRCbHVlJyxcblx0YnJpZ2h0TWFnZW50YTogJ2NvbG9yQnJpZ2h0TWFnZW50YScsXG5cdGJyaWdodEN5YW46ICdjb2xvckJyaWdodEN5YW4nLFxuXHRicmlnaHRXaGl0ZTogJ2NvbG9yQnJpZ2h0V2hpdGUnLFxufVxuXG5mdW5jdGlvbiBjb25maWdUb0RhdGEgKG9iaiwgcHJlZml4KSB7XG5cdGNvbnN0IGRhdGEgPSBbXVxuXHRmb3IgKGNvbnN0IGtleSBpbiBvYmopIHtcblx0XHRpZiAob2JqW2tleV0udHlwZSA9PT0gJ29iamVjdCcpIHtcblx0XHRcdGRhdGEucHVzaCguLi5jb25maWdUb0RhdGEob2JqW2tleV0ucHJvcGVydGllcywgYCR7cHJlZml4fS4ke2tleX1gKSlcblx0XHR9IGVsc2Uge1xuXHRcdFx0Y29uc3QgcHJvZmlsZURhdGEgPSBvYmpba2V5XS5wcm9maWxlRGF0YVxuXHRcdFx0aWYgKHByb2ZpbGVEYXRhKSB7XG5cdFx0XHRcdHByb2ZpbGVEYXRhLnByb2ZpbGVLZXkgPSBrZXkgaW4gQ09MT1JTID8gQ09MT1JTW2tleV0gOiBrZXlcblx0XHRcdFx0ZGVsZXRlIG9ialtrZXldLnByb2ZpbGVEYXRhXG5cdFx0XHR9XG5cdFx0XHRjb25zdCBrZXlQYXRoID0gYCR7cHJlZml4fS4ke2tleX1gXG5cdFx0XHRkYXRhLnB1c2goeyAuLi5vYmpba2V5XSwgLi4ucHJvZmlsZURhdGEsIGtleVBhdGggfSlcblx0XHR9XG5cdH1cblx0cmV0dXJuIGRhdGFcbn1cblxuZXhwb3J0IGNvbnN0IENPTkZJR19EQVRBID0gY29uZmlnVG9EYXRhKGNvbmZpZywgJ3gtdGVybWluYWwnKVxuXG5leHBvcnQgYXN5bmMgZnVuY3Rpb24gc2V0SW5pdGlhbENvbW1hbmQgKHdoaWNoKSB7XG5cdGxldCBjb21tYW5kXG5cdGlmIChwcm9jZXNzLnBsYXRmb3JtID09PSAnd2luMzInKSB7XG5cdFx0dHJ5IHtcblx0XHRcdGNvbW1hbmQgPSBhd2FpdCB3aGljaCgncHdzaC5leGUnKVxuXHRcdH0gY2F0Y2ggKGUxKSB7XG5cdFx0XHR0cnkge1xuXHRcdFx0XHRjb21tYW5kID0gYXdhaXQgd2hpY2goJ3Bvd2Vyc2hlbGwuZXhlJylcblx0XHRcdH0gY2F0Y2ggKGUyKSB7XG5cdFx0XHRcdC8vIHBvd2Vyc2hlbGwgbm90IGZvdW5kXG5cdFx0XHR9XG5cdFx0fVxuXHR9XG5cblx0aWYgKGNvbW1hbmQgJiYgYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnNwYXduUHR5U2V0dGluZ3MuY29tbWFuZCcpID09PSBjb25maWdEZWZhdWx0cy5jb21tYW5kKSB7XG5cdFx0YXRvbS5jb25maWcuc2V0KCd4LXRlcm1pbmFsLnNwYXduUHR5U2V0dGluZ3MuY29tbWFuZCcsIGNvbW1hbmQpXG5cdH1cbn1cblxuLy8gc2V0IHNoZWxsIGNvbW1hbmQgYXV0b21hdGljYWxseSBvbiBmaXJzdCBpbnN0YWxsXG5pZiAobG9jYWxTdG9yYWdlLmdldEl0ZW0oJ3gtdGVybWluYWwuaW5pdGlhbENvbW1hbmRTZXQnKSA9PT0gbnVsbCkge1xuXHRsb2NhbFN0b3JhZ2Uuc2V0SXRlbSgneC10ZXJtaW5hbC5pbml0aWFsQ29tbWFuZFNldCcsICd0cnVlJylcblx0c2V0SW5pdGlhbENvbW1hbmQod2hpY2gpXG59XG4iXX0=