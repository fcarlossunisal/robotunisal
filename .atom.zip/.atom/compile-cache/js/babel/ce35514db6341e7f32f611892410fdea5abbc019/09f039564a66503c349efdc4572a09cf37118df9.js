Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x2, _x3, _x4) { var _again = true; _function: while (_again) { var object = _x2, property = _x3, receiver = _x4; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x2 = parent; _x3 = property; _x4 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _atom = require('atom');

var _marked = require('marked');

var _marked2 = _interopRequireDefault(_marked);

var _profiles = require('./profiles');

var _deleteProfileModel = require('./delete-profile-model');

var _saveProfileModel = require('./save-profile-model');

var _utils = require('./utils');

var _configJs = require('./config.js');

var XTerminalProfileMenuElementImpl = (function (_HTMLElement) {
	_inherits(XTerminalProfileMenuElementImpl, _HTMLElement);

	function XTerminalProfileMenuElementImpl() {
		_classCallCheck(this, XTerminalProfileMenuElementImpl);

		_get(Object.getPrototypeOf(XTerminalProfileMenuElementImpl.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(XTerminalProfileMenuElementImpl, [{
		key: 'initialize',
		value: _asyncToGenerator(function* (model) {
			var _this = this;

			this.model = model;
			this.model.setElement(this);
			this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;
			var topDiv = document.createElement('div');
			topDiv.classList.add('x-terminal-profile-menu-element-top-div');
			this.appendChild(topDiv);
			var leftDiv = document.createElement('div');
			leftDiv.classList.add('x-terminal-profile-menu-element-left-div');
			this.appendChild(leftDiv);
			this.mainDiv = document.createElement('div');
			this.mainDiv.classList.add('x-terminal-profile-menu-element-main-div');
			this.appendChild(this.mainDiv);
			var rightDiv = document.createElement('div');
			rightDiv.classList.add('x-terminal-profile-menu-element-right-div');
			this.appendChild(rightDiv);
			var bottomDiv = document.createElement('div');
			bottomDiv.classList.add('x-terminal-profile-menu-element-bottom-div');
			this.appendChild(bottomDiv);
			this.disposables = new _atom.CompositeDisposable();
			var resolveInit = undefined;
			this.initializedPromise = new Promise(function (resolve, reject) {
				resolveInit = resolve;
			});

			var profilesDiv = yield this.createProfilesDropDown();
			var modelProfile = this.getModelProfile();
			var baseProfile = this.profilesSingleton.getBaseProfile();
			// Profiles
			this.mainDiv.appendChild(profilesDiv);

			// Buttons div
			this.mainDiv.appendChild(this.createProfileMenuButtons());

			// Horizontal line.
			this.mainDiv.appendChild((0, _utils.createHorizontalLine)());

			this.createFromConfig(baseProfile, modelProfile);

			this.deleteProfileModel = new _deleteProfileModel.XTerminalDeleteProfileModel(this);
			this.saveProfileModel = new _saveProfileModel.XTerminalSaveProfileModel(this);

			this.disposables.add(this.profilesSingleton.onDidReloadProfiles(_asyncToGenerator(function* (profiles) {
				var select = yield _this.createProfilesDropDownSelectItem();
				var menuItemContainer = _this.mainDiv.querySelector('#profiles-selection');
				while (menuItemContainer.firstChild) {
					menuItemContainer.removeChild(menuItemContainer.firstChild);
				}
				menuItemContainer.appendChild(select);
			})));
			resolveInit();
		})
	}, {
		key: 'createFromConfig',
		value: function createFromConfig(baseProfile, modelProfile) {
			for (var data of _configJs.CONFIG_DATA) {
				if (!data.profileKey) continue;
				var title = data.title || data.profileKey.charAt(0).toUpperCase() + data.profileKey.substring(1).replace(/[A-Z]/g, ' $&');
				var description = data.description || '';
				if (data['enum']) {
					this.mainDiv.appendChild(this.createSelect(data.profileKey.toLowerCase() + '-select', title, description, baseProfile[data.profileKey], modelProfile[data.profileKey], data['enum']));
				} else if (data.type === 'color') {
					this.mainDiv.appendChild(this.createColor(data.profileKey.toLowerCase() + '-color', title, description, baseProfile[data.profileKey], modelProfile[data.profileKey]));
				} else if (data.type === 'boolean') {
					this.mainDiv.appendChild(this.createCheckbox(data.profileKey.toLowerCase() + '-checkbox', title, description, baseProfile[data.profileKey], modelProfile[data.profileKey]));
				} else {
					this.mainDiv.appendChild(this.createTextbox(data.profileKey.toLowerCase() + '-textbox', title, description, baseProfile[data.profileKey], modelProfile[data.profileKey]));
				}
			}
		}
	}, {
		key: 'destroy',
		value: function destroy() {
			if (this.disposables) {
				this.disposables.dispose();
			}
		}
	}, {
		key: 'getModelProfile',
		value: function getModelProfile() {
			return this.model.atomXtermModel.profile;
		}
	}, {
		key: 'getMenuElements',
		value: function getMenuElements() {
			var menuElements = {};
			for (var data of _configJs.CONFIG_DATA) {
				if (!data.profileKey) continue;

				var type = 'textbox > atom-text-editor';
				if (data['enum']) {
					type = 'select select';
				} else if (data.type === 'color') {
					type = 'color input';
				} else if (data.type === 'boolean') {
					type = 'checkbox input';
				}
				menuElements[data.profileKey] = this.mainDiv.querySelector('#' + data.profileKey.toLowerCase() + '-' + type);
			}
			return menuElements;
		}
	}, {
		key: 'getProfileMenuSettings',
		value: function getProfileMenuSettings() {
			var newProfile = {};
			var baseProfile = this.profilesSingleton.getBaseProfile();
			var menuElements = this.getMenuElements();
			for (var data of _configJs.CONFIG_DATA) {
				if (!data.profileKey) continue;
				newProfile[data.profileKey] = data.fromMenuSetting(menuElements[data.profileKey], baseProfile[data.profileKey]);
			}
			return newProfile;
		}
	}, {
		key: 'applyProfileChanges',
		value: function applyProfileChanges(profileChanges) {
			this.hideProfileMenu();
			this.model.getXTerminalModel().applyProfileChanges(profileChanges);
		}
	}, {
		key: 'restartTerminal',
		value: function restartTerminal() {
			this.hideProfileMenu();
			this.model.getXTerminalModelElement().restartPtyProcess();
		}
	}, {
		key: 'createMenuItemContainer',
		value: function createMenuItemContainer(id, labelTitle, labelDescription) {
			var menuItemContainer = document.createElement('div');
			menuItemContainer.classList.add('x-terminal-profile-menu-item');
			menuItemContainer.setAttribute('id', id);
			var menuItemLabel = document.createElement('label');
			menuItemLabel.classList.add('x-terminal-profile-menu-item-label');
			var titleDiv = document.createElement('div');
			titleDiv.classList.add('x-terminal-profile-menu-item-title');
			titleDiv.appendChild(document.createTextNode(labelTitle));
			menuItemLabel.appendChild(titleDiv);
			var descriptionDiv = document.createElement('div');
			descriptionDiv.classList.add('x-terminal-profile-menu-item-description');
			descriptionDiv.innerHTML = (0, _marked2['default'])(labelDescription);
			menuItemLabel.appendChild(descriptionDiv);
			menuItemContainer.appendChild(menuItemLabel);
			return menuItemContainer;
		}
	}, {
		key: 'createProfilesDropDownSelectItem',
		value: _asyncToGenerator(function* () {
			var _this2 = this;

			var profiles = yield this.profilesSingleton.getProfiles();
			var select = document.createElement('select');
			select.setAttribute('id', 'profiles-dropdown');
			select.classList.add('x-terminal-profile-menu-item-select');
			var option = document.createElement('option');
			var text = document.createTextNode('');
			option.setAttribute('value', text);
			option.appendChild(text);
			select.appendChild(option);
			for (var profile in profiles) {
				option = document.createElement('option');
				text = document.createTextNode(profile);
				option.setAttribute('value', text.textContent);
				option.appendChild(text);
				select.appendChild(option);
			}
			select.addEventListener('change', _asyncToGenerator(function* (event) {
				if (event.target.value) {
					var profile = yield _this2.profilesSingleton.getProfile(event.target.value);
					_this2.setNewMenuSettings(profile);
				} else {
					var profile = _this2.profilesSingleton.getBaseProfile();
					_this2.setNewMenuSettings(profile, true);
				}
			}), { passive: true });
			return select;
		})
	}, {
		key: 'createProfilesDropDown',
		value: _asyncToGenerator(function* () {
			var menuItemContainer = this.createMenuItemContainer('profiles-selection', 'Profiles', 'Available profiles');
			var select = yield this.createProfilesDropDownSelectItem();
			menuItemContainer.appendChild(select);
			return menuItemContainer;
		})
	}, {
		key: 'createProfileMenuButtons',
		value: function createProfileMenuButtons() {
			var _this3 = this;

			var buttonsContainer = document.createElement('div');
			buttonsContainer.classList.add('x-terminal-profile-menu-buttons-div');
			var button = this.createButton();
			button.appendChild(document.createTextNode('Load Settings'));
			button.classList.add('btn-load');
			button.addEventListener('click', function (event) {
				_this3.loadProfile();
			}, { passive: true });
			buttonsContainer.appendChild(button);
			button = this.createButton();
			button.appendChild(document.createTextNode('Save Settings'));
			button.classList.add('btn-save');
			button.addEventListener('click', function (event) {
				_this3.saveProfile();
			}, { passive: true });
			buttonsContainer.appendChild(button);
			button = this.createButton();
			button.appendChild(document.createTextNode('Delete Settings'));
			button.classList.add('btn-delete');
			button.addEventListener('click', function (event) {
				_this3.deleteProfile();
			}, { passive: true });
			buttonsContainer.appendChild(button);
			button = this.createButton();
			button.appendChild(document.createTextNode('Restart'));
			button.classList.add('btn-restart');
			button.addEventListener('click', function (event) {
				_this3.restartTerminal();
			}, { passive: true });
			buttonsContainer.appendChild(button);
			button = this.createButton();
			button.appendChild(document.createTextNode('Hide Menu'));
			button.classList.add('btn-hide');
			button.addEventListener('click', function (event) {
				_this3.hideProfileMenu();
			}, { passive: true });
			buttonsContainer.appendChild(button);
			return buttonsContainer;
		}
	}, {
		key: 'createButton',
		value: function createButton() {
			var button = document.createElement('button');
			button.classList.add('x-terminal-profile-menu-button');
			button.classList.add('btn');
			button.classList.add('inline-block-tight');
			return button;
		}
	}, {
		key: 'createTextbox',
		value: function createTextbox(id, labelTitle, labelDescription, defaultValue, initialValue) {
			var menuItemContainer = this.createMenuItemContainer(id, labelTitle, labelDescription);
			var textbox = new _atom.TextEditor({
				mini: true,
				placeholderText: defaultValue
			});
			if (initialValue) {
				if (initialValue.constructor === Array || initialValue.constructor === Object) {
					textbox.setText(JSON.stringify(initialValue));
				} else {
					textbox.setText(initialValue);
				}
			}
			menuItemContainer.appendChild(textbox.getElement());
			return menuItemContainer;
		}
	}, {
		key: 'toHex',
		value: function toHex(color) {
			color = color.replace(/rgba\(\s*(\d+)\s*,\s*(\d+)\s*,\s*(\d+)\s*,\s*[\d.]+\s*\)/, 'rgb($1, $2, $3)').trim();
			var ctx = document.createElement('canvas').getContext('2d');
			ctx.fillStyle = color;
			return ctx.fillStyle;
		}
	}, {
		key: 'createColor',
		value: function createColor(id, labelTitle, labelDescription, defaultValue, initialValue) {
			var menuItemContainer = document.createElement('div');
			menuItemContainer.classList.add('x-terminal-profile-menu-item');
			menuItemContainer.setAttribute('id', id);
			var menuItemLabel = document.createElement('label');
			menuItemLabel.classList.add('x-terminal-profile-menu-item-label');
			menuItemLabel.classList.add('x-terminal-profile-menu-item-label-color');
			var color = document.createElement('input');
			color.setAttribute('type', 'color');
			color.classList.add('x-terminal-profile-menu-item-color');
			color.value = this.toHex(defaultValue);
			if (initialValue !== undefined) {
				color.value = this.toHex(initialValue);
			}
			menuItemLabel.appendChild(color);
			var titleDiv = document.createElement('div');
			titleDiv.classList.add('x-terminal-profile-menu-item-title');
			titleDiv.appendChild(document.createTextNode(labelTitle));
			menuItemLabel.appendChild(titleDiv);
			menuItemContainer.appendChild(menuItemLabel);
			var descriptionDiv = document.createElement('div');
			descriptionDiv.classList.add('x-terminal-profile-menu-item-description');
			descriptionDiv.classList.add('x-terminal-profile-menu-item-description-color');
			descriptionDiv.innerHTML = (0, _marked2['default'])(labelDescription);
			menuItemContainer.appendChild(descriptionDiv);
			return menuItemContainer;
		}
	}, {
		key: 'createSelect',
		value: function createSelect(id, labelTitle, labelDescription, defaultValue, initialValue, possibleValues) {
			var menuItemContainer = this.createMenuItemContainer(id, labelTitle, labelDescription);
			var select = document.createElement('select');
			select.setAttribute('type', 'select');
			select.classList.add('x-terminal-profile-menu-item-select');
			select.classList.add('settings-view');
			for (var optionValue of possibleValues) {
				if (typeof optionValue !== 'object') {
					optionValue = {
						value: optionValue,
						description: optionValue
					};
				}
				var option = document.createElement('option');
				option.setAttribute('value', optionValue.value);
				option.textContent = optionValue.description;
				select.appendChild(option);
			}
			select.value = defaultValue;
			if (initialValue !== undefined) {
				select.value = initialValue;
			}
			menuItemContainer.appendChild(select);
			return menuItemContainer;
		}
	}, {
		key: 'createCheckbox',
		value: function createCheckbox(id, labelTitle, labelDescription, defaultValue, initialValue) {
			var menuItemContainer = document.createElement('div');
			menuItemContainer.classList.add('x-terminal-profile-menu-item');
			menuItemContainer.setAttribute('id', id);
			var menuItemLabel = document.createElement('label');
			menuItemLabel.classList.add('x-terminal-profile-menu-item-label');
			menuItemLabel.classList.add('x-terminal-profile-menu-item-label-checkbox');
			var checkbox = document.createElement('input');
			checkbox.setAttribute('type', 'checkbox');
			checkbox.classList.add('x-terminal-profile-menu-item-checkbox');
			checkbox.classList.add('input-checkbox');
			checkbox.checked = defaultValue;
			if (initialValue !== undefined) {
				checkbox.checked = initialValue;
			}
			menuItemLabel.appendChild(checkbox);
			var titleDiv = document.createElement('div');
			titleDiv.classList.add('x-terminal-profile-menu-item-title');
			titleDiv.appendChild(document.createTextNode(labelTitle));
			menuItemLabel.appendChild(titleDiv);
			menuItemContainer.appendChild(menuItemLabel);
			var descriptionDiv = document.createElement('div');
			descriptionDiv.classList.add('x-terminal-profile-menu-item-description');
			descriptionDiv.classList.add('x-terminal-profile-menu-item-description-checkbox');
			descriptionDiv.innerHTML = (0, _marked2['default'])(labelDescription);
			menuItemContainer.appendChild(descriptionDiv);
			return menuItemContainer;
		}
	}, {
		key: 'isVisible',
		value: function isVisible() {
			var style = window.getComputedStyle(this, null);
			return style.visibility === 'visible';
		}
	}, {
		key: 'hideProfileMenu',
		value: function hideProfileMenu() {
			this.style.visibility = 'hidden';
			var e = this.model.getXTerminalModelElement();
			e.showTerminal();
			e.focusOnTerminal();
		}
	}, {
		key: 'showProfileMenu',
		value: function showProfileMenu() {
			this.model.getXTerminalModelElement().hideTerminal();
			this.style.visibility = 'visible';
		}
	}, {
		key: 'toggleProfileMenu',
		value: function toggleProfileMenu() {
			if (!this.isVisible()) {
				this.showProfileMenu();
			} else {
				this.hideProfileMenu();
			}
		}
	}, {
		key: 'getNewProfileAndChanges',
		value: function getNewProfileAndChanges() {
			var newProfile = this.getProfileMenuSettings();
			var profileChanges = this.profilesSingleton.diffProfiles(this.model.getXTerminalModel().getProfile(), newProfile);
			return {
				newProfile: newProfile,
				profileChanges: profileChanges
			};
		}
	}, {
		key: 'loadProfile',
		value: function loadProfile() {
			var newProfileAndChanges = this.getNewProfileAndChanges();
			this.applyProfileChanges(newProfileAndChanges.profileChanges);
		}
	}, {
		key: 'saveProfile',
		value: function saveProfile() {
			// Get the current profile settings before entering the promise.
			var newProfileAndChanges = this.getNewProfileAndChanges();
			this.promptForNewProfileName(newProfileAndChanges.newProfile, newProfileAndChanges.profileChanges);
		}
	}, {
		key: 'deleteProfile',
		value: function deleteProfile() {
			var e = this.mainDiv.querySelector('#profiles-dropdown');
			var profileName = e.options[e.selectedIndex].text;
			if (!profileName) {
				atom.notifications.addWarning('Profile must be selected in order to delete it.');
				return;
			}
			this.promptDelete(profileName);
		}
	}, {
		key: 'promptDelete',
		value: _asyncToGenerator(function* (newProfile) {
			this.deleteProfileModel.promptDelete(newProfile);
		})
	}, {
		key: 'promptForNewProfileName',
		value: _asyncToGenerator(function* (newProfile, profileChanges) {
			this.saveProfileModel.promptForNewProfileName(newProfile, profileChanges);
		})
	}, {
		key: 'setNewMenuSettings',
		value: function setNewMenuSettings(profile) {
			var clear = arguments.length <= 1 || arguments[1] === undefined ? false : arguments[1];

			for (var data of _configJs.CONFIG_DATA) {
				if (!data.profileKey) continue;

				if (data['enum']) {
					var selector = '#' + data.profileKey.toLowerCase() + '-select select';
					var input = this.querySelector(selector);
					input.value = data.toMenuSetting(profile[data.profileKey]);
				} else if (data.type === 'color') {
					var selector = '#' + data.profileKey.toLowerCase() + '-color input';
					var input = this.querySelector(selector);
					input.value = data.toMenuSetting(profile[data.profileKey]);
				} else if (data.type === 'boolean') {
					var selector = '#' + data.profileKey.toLowerCase() + '-checkbox input';
					var checkbox = this.querySelector(selector);
					checkbox.checked = data.toMenuSetting(profile[data.profileKey]);
				} else {
					var selector = '#' + data.profileKey.toLowerCase() + '-textbox > atom-text-editor';
					var model = this.querySelector(selector).getModel();
					if (!clear) {
						model.setText(data.toMenuSetting(profile[data.profileKey]));
					} else {
						model.setText('');
					}
				}
			}
		}
	}]);

	return XTerminalProfileMenuElementImpl;
})(HTMLElement);

var XTerminalProfileMenuElement = document.registerElement('x-terminal-profile', {
	prototype: XTerminalProfileMenuElementImpl.prototype
});

exports.XTerminalProfileMenuElement = XTerminalProfileMenuElement;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3Byb2ZpbGUtbWVudS1lbGVtZW50LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7b0JBcUJnRCxNQUFNOztzQkFDbkMsUUFBUTs7Ozt3QkFFZ0IsWUFBWTs7a0NBQ1gsd0JBQXdCOztnQ0FDMUIsc0JBQXNCOztxQkFDM0IsU0FBUzs7d0JBQ2xCLGFBQWE7O0lBRW5DLCtCQUErQjtXQUEvQiwrQkFBK0I7O1VBQS9CLCtCQUErQjt3QkFBL0IsK0JBQStCOzs2QkFBL0IsK0JBQStCOzs7Y0FBL0IsK0JBQStCOzsyQkFDbkIsV0FBQyxLQUFLLEVBQUU7OztBQUN4QixPQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQTtBQUNsQixPQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUMzQixPQUFJLENBQUMsaUJBQWlCLEdBQUcscUNBQTJCLFFBQVEsQ0FBQTtBQUM1RCxPQUFNLE1BQU0sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzVDLFNBQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHlDQUF5QyxDQUFDLENBQUE7QUFDL0QsT0FBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUN4QixPQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzdDLFVBQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7QUFDakUsT0FBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUN6QixPQUFJLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDNUMsT0FBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7QUFDdEUsT0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUE7QUFDOUIsT0FBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUM5QyxXQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQywyQ0FBMkMsQ0FBQyxDQUFBO0FBQ25FLE9BQUksQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDMUIsT0FBTSxTQUFTLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUMvQyxZQUFTLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyw0Q0FBNEMsQ0FBQyxDQUFBO0FBQ3JFLE9BQUksQ0FBQyxXQUFXLENBQUMsU0FBUyxDQUFDLENBQUE7QUFDM0IsT0FBSSxDQUFDLFdBQVcsR0FBRywrQkFBeUIsQ0FBQTtBQUM1QyxPQUFJLFdBQVcsWUFBQSxDQUFBO0FBQ2YsT0FBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSztBQUMxRCxlQUFXLEdBQUcsT0FBTyxDQUFBO0lBQ3JCLENBQUMsQ0FBQTs7QUFFRixPQUFNLFdBQVcsR0FBRyxNQUFNLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFBO0FBQ3ZELE9BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQTtBQUMzQyxPQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxFQUFFLENBQUE7O0FBRTNELE9BQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFBOzs7QUFHckMsT0FBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLHdCQUF3QixFQUFFLENBQUMsQ0FBQTs7O0FBR3pELE9BQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLGtDQUFzQixDQUFDLENBQUE7O0FBRWhELE9BQUksQ0FBQyxnQkFBZ0IsQ0FBQyxXQUFXLEVBQUUsWUFBWSxDQUFDLENBQUE7O0FBRWhELE9BQUksQ0FBQyxrQkFBa0IsR0FBRyxvREFBZ0MsSUFBSSxDQUFDLENBQUE7QUFDL0QsT0FBSSxDQUFDLGdCQUFnQixHQUFHLGdEQUE4QixJQUFJLENBQUMsQ0FBQTs7QUFFM0QsT0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQixtQkFBQyxXQUFPLFFBQVEsRUFBSztBQUNuRixRQUFNLE1BQU0sR0FBRyxNQUFNLE1BQUssZ0NBQWdDLEVBQUUsQ0FBQTtBQUM1RCxRQUFNLGlCQUFpQixHQUFHLE1BQUssT0FBTyxDQUFDLGFBQWEsQ0FBQyxxQkFBcUIsQ0FBQyxDQUFBO0FBQzNFLFdBQU8saUJBQWlCLENBQUMsVUFBVSxFQUFFO0FBQ3BDLHNCQUFpQixDQUFDLFdBQVcsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBQTtLQUMzRDtBQUNELHFCQUFpQixDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNyQyxFQUFDLENBQUMsQ0FBQTtBQUNILGNBQVcsRUFBRSxDQUFBO0dBQ2I7OztTQUVnQiwwQkFBQyxXQUFXLEVBQUUsWUFBWSxFQUFFO0FBQzVDLFFBQUssSUFBTSxJQUFJLDJCQUFpQjtBQUMvQixRQUFJLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxTQUFRO0FBQzlCLFFBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLElBQUksSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxLQUFLLENBQUMsQ0FBQTtBQUMzSCxRQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsV0FBVyxJQUFJLEVBQUUsQ0FBQTtBQUMxQyxRQUFJLElBQUksUUFBSyxFQUFFO0FBQ2QsU0FBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FDdEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsY0FDaEMsS0FBSyxFQUNMLFdBQVcsRUFDWCxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUM1QixZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUM3QixJQUFJLFFBQUssQ0FDVCxDQUFDLENBQUE7S0FDRixNQUFNLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7QUFDakMsU0FBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FDckMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsYUFDaEMsS0FBSyxFQUNMLFdBQVcsRUFDWCxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxFQUM1QixZQUFZLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUM3QixDQUFDLENBQUE7S0FDRixNQUFNLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxTQUFTLEVBQUU7QUFDbkMsU0FBSSxDQUFDLE9BQU8sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FDeEMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsZ0JBQ2hDLEtBQUssRUFDTCxXQUFXLEVBQ1gsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFDNUIsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FDN0IsQ0FBQyxDQUFBO0tBQ0YsTUFBTTtBQUNOLFNBQUksQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxhQUFhLENBQ3ZDLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLGVBQ2hDLEtBQUssRUFDTCxXQUFXLEVBQ1gsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFDNUIsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FDN0IsQ0FBQyxDQUFBO0tBQ0Y7SUFDRDtHQUNEOzs7U0FFTyxtQkFBRztBQUNWLE9BQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUNyQixRQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFBO0lBQzFCO0dBQ0Q7OztTQUVlLDJCQUFHO0FBQ2xCLFVBQU8sSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFBO0dBQ3hDOzs7U0FFZSwyQkFBRztBQUNsQixPQUFNLFlBQVksR0FBRyxFQUFFLENBQUE7QUFDdkIsUUFBSyxJQUFNLElBQUksMkJBQWlCO0FBQy9CLFFBQUksQ0FBQyxJQUFJLENBQUMsVUFBVSxFQUFFLFNBQVE7O0FBRTlCLFFBQUksSUFBSSxHQUFHLDRCQUE0QixDQUFBO0FBQ3ZDLFFBQUksSUFBSSxRQUFLLEVBQUU7QUFDZCxTQUFJLEdBQUcsZUFBZSxDQUFBO0tBQ3RCLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtBQUNqQyxTQUFJLEdBQUcsYUFBYSxDQUFBO0tBQ3BCLE1BQU0sSUFBSSxJQUFJLENBQUMsSUFBSSxLQUFLLFNBQVMsRUFBRTtBQUNuQyxTQUFJLEdBQUcsZ0JBQWdCLENBQUE7S0FDdkI7QUFDRCxnQkFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLGFBQWEsT0FBSyxJQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsRUFBRSxTQUFJLElBQUksQ0FBRyxDQUFBO0lBQ3ZHO0FBQ0QsVUFBTyxZQUFZLENBQUE7R0FDbkI7OztTQUVzQixrQ0FBRztBQUN6QixPQUFNLFVBQVUsR0FBRyxFQUFFLENBQUE7QUFDckIsT0FBTSxXQUFXLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsRUFBRSxDQUFBO0FBQzNELE9BQU0sWUFBWSxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQTtBQUMzQyxRQUFLLElBQU0sSUFBSSwyQkFBaUI7QUFDL0IsUUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUTtBQUM5QixjQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsRUFBRSxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7SUFDL0c7QUFDRCxVQUFPLFVBQVUsQ0FBQTtHQUNqQjs7O1NBRW1CLDZCQUFDLGNBQWMsRUFBRTtBQUNwQyxPQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7QUFDdEIsT0FBSSxDQUFDLEtBQUssQ0FBQyxpQkFBaUIsRUFBRSxDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFBO0dBQ2xFOzs7U0FFZSwyQkFBRztBQUNsQixPQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7QUFDdEIsT0FBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLGlCQUFpQixFQUFFLENBQUE7R0FDekQ7OztTQUV1QixpQ0FBQyxFQUFFLEVBQUUsVUFBVSxFQUFFLGdCQUFnQixFQUFFO0FBQzFELE9BQU0saUJBQWlCLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUN2RCxvQkFBaUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUE7QUFDL0Qsb0JBQWlCLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBQTtBQUN4QyxPQUFNLGFBQWEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ3JELGdCQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFBO0FBQ2pFLE9BQU0sUUFBUSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDOUMsV0FBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQTtBQUM1RCxXQUFRLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtBQUN6RCxnQkFBYSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUNuQyxPQUFNLGNBQWMsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3BELGlCQUFjLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQywwQ0FBMEMsQ0FBQyxDQUFBO0FBQ3hFLGlCQUFjLENBQUMsU0FBUyxHQUFHLHlCQUFPLGdCQUFnQixDQUFDLENBQUE7QUFDbkQsZ0JBQWEsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUE7QUFDekMsb0JBQWlCLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0FBQzVDLFVBQU8saUJBQWlCLENBQUE7R0FDeEI7OzsyQkFFc0MsYUFBRzs7O0FBQ3pDLE9BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQzNELE9BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDL0MsU0FBTSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsbUJBQW1CLENBQUMsQ0FBQTtBQUM5QyxTQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxxQ0FBcUMsQ0FBQyxDQUFBO0FBQzNELE9BQUksTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDN0MsT0FBSSxJQUFJLEdBQUcsUUFBUSxDQUFDLGNBQWMsQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUN0QyxTQUFNLENBQUMsWUFBWSxDQUFDLE9BQU8sRUFBRSxJQUFJLENBQUMsQ0FBQTtBQUNsQyxTQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3hCLFNBQU0sQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDMUIsUUFBSyxJQUFNLE9BQU8sSUFBSSxRQUFRLEVBQUU7QUFDL0IsVUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDekMsUUFBSSxHQUFHLFFBQVEsQ0FBQyxjQUFjLENBQUMsT0FBTyxDQUFDLENBQUE7QUFDdkMsVUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQzlDLFVBQU0sQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDeEIsVUFBTSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUMxQjtBQUNELFNBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLG9CQUFFLFdBQU8sS0FBSyxFQUFLO0FBQ2xELFFBQUksS0FBSyxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7QUFDdkIsU0FBTSxPQUFPLEdBQUcsTUFBTSxPQUFLLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzNFLFlBQUssa0JBQWtCLENBQUMsT0FBTyxDQUFDLENBQUE7S0FDaEMsTUFBTTtBQUNOLFNBQU0sT0FBTyxHQUFHLE9BQUssaUJBQWlCLENBQUMsY0FBYyxFQUFFLENBQUE7QUFDdkQsWUFBSyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLENBQUE7S0FDdEM7SUFDRCxHQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7QUFDckIsVUFBTyxNQUFNLENBQUE7R0FDYjs7OzJCQUU0QixhQUFHO0FBQy9CLE9BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUNyRCxvQkFBb0IsRUFDcEIsVUFBVSxFQUNWLG9CQUFvQixDQUNwQixDQUFBO0FBQ0QsT0FBTSxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsZ0NBQWdDLEVBQUUsQ0FBQTtBQUM1RCxvQkFBaUIsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDckMsVUFBTyxpQkFBaUIsQ0FBQTtHQUN4Qjs7O1NBRXdCLG9DQUFHOzs7QUFDM0IsT0FBTSxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3RELG1CQUFnQixDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQTtBQUNyRSxPQUFJLE1BQU0sR0FBRyxJQUFJLENBQUMsWUFBWSxFQUFFLENBQUE7QUFDaEMsU0FBTSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUE7QUFDNUQsU0FBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBVSxDQUFDLENBQUE7QUFDaEMsU0FBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxVQUFDLEtBQUssRUFBSztBQUMzQyxXQUFLLFdBQVcsRUFBRSxDQUFBO0lBQ2xCLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUNyQixtQkFBZ0IsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDcEMsU0FBTSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQTtBQUM1QixTQUFNLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsZUFBZSxDQUFDLENBQUMsQ0FBQTtBQUM1RCxTQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUNoQyxTQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFVBQUMsS0FBSyxFQUFLO0FBQzNDLFdBQUssV0FBVyxFQUFFLENBQUE7SUFDbEIsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0FBQ3JCLG1CQUFnQixDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNwQyxTQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFBO0FBQzVCLFNBQU0sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxpQkFBaUIsQ0FBQyxDQUFDLENBQUE7QUFDOUQsU0FBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUE7QUFDbEMsU0FBTSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxVQUFDLEtBQUssRUFBSztBQUMzQyxXQUFLLGFBQWEsRUFBRSxDQUFBO0lBQ3BCLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUNyQixtQkFBZ0IsQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDcEMsU0FBTSxHQUFHLElBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQTtBQUM1QixTQUFNLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxjQUFjLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQTtBQUN0RCxTQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxhQUFhLENBQUMsQ0FBQTtBQUNuQyxTQUFNLENBQUMsZ0JBQWdCLENBQUMsT0FBTyxFQUFFLFVBQUMsS0FBSyxFQUFLO0FBQzNDLFdBQUssZUFBZSxFQUFFLENBQUE7SUFDdEIsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0FBQ3JCLG1CQUFnQixDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUNwQyxTQUFNLEdBQUcsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFBO0FBQzVCLFNBQU0sQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFBO0FBQ3hELFNBQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQ2hDLFNBQU0sQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsVUFBQyxLQUFLLEVBQUs7QUFDM0MsV0FBSyxlQUFlLEVBQUUsQ0FBQTtJQUN0QixFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7QUFDckIsbUJBQWdCLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ3BDLFVBQU8sZ0JBQWdCLENBQUE7R0FDdkI7OztTQUVZLHdCQUFHO0FBQ2YsT0FBTSxNQUFNLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUMvQyxTQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxnQ0FBZ0MsQ0FBQyxDQUFBO0FBQ3RELFNBQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzNCLFNBQU0sQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLG9CQUFvQixDQUFDLENBQUE7QUFDMUMsVUFBTyxNQUFNLENBQUE7R0FDYjs7O1NBRWEsdUJBQUMsRUFBRSxFQUFFLFVBQVUsRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFO0FBQzVFLE9BQU0saUJBQWlCLEdBQUcsSUFBSSxDQUFDLHVCQUF1QixDQUNyRCxFQUFFLEVBQ0YsVUFBVSxFQUNWLGdCQUFnQixDQUNoQixDQUFBO0FBQ0QsT0FBTSxPQUFPLEdBQUcscUJBQWU7QUFDOUIsUUFBSSxFQUFFLElBQUk7QUFDVixtQkFBZSxFQUFFLFlBQVk7SUFDN0IsQ0FBQyxDQUFBO0FBQ0YsT0FBSSxZQUFZLEVBQUU7QUFDakIsUUFBSSxZQUFZLENBQUMsV0FBVyxLQUFLLEtBQUssSUFBSSxZQUFZLENBQUMsV0FBVyxLQUFLLE1BQU0sRUFBRTtBQUM5RSxZQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQTtLQUM3QyxNQUFNO0FBQ04sWUFBTyxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUMsQ0FBQTtLQUM3QjtJQUNEO0FBQ0Qsb0JBQWlCLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxDQUFBO0FBQ25ELFVBQU8saUJBQWlCLENBQUE7R0FDeEI7OztTQUVLLGVBQUMsS0FBSyxFQUFFO0FBQ2IsUUFBSyxHQUFHLEtBQUssQ0FBQyxPQUFPLENBQUMsMERBQTBELEVBQUUsaUJBQWlCLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtBQUMzRyxPQUFNLEdBQUcsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUM3RCxNQUFHLENBQUMsU0FBUyxHQUFHLEtBQUssQ0FBQTtBQUNyQixVQUFPLEdBQUcsQ0FBQyxTQUFTLENBQUE7R0FDcEI7OztTQUVXLHFCQUFDLEVBQUUsRUFBRSxVQUFVLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRTtBQUMxRSxPQUFNLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDdkQsb0JBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFBO0FBQy9ELG9CQUFpQixDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUE7QUFDeEMsT0FBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUNyRCxnQkFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQTtBQUNqRSxnQkFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsMENBQTBDLENBQUMsQ0FBQTtBQUN2RSxPQUFNLEtBQUssR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQzdDLFFBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxDQUFBO0FBQ25DLFFBQUssQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUE7QUFDekQsUUFBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLFlBQVksQ0FBQyxDQUFBO0FBQ3RDLE9BQUksWUFBWSxLQUFLLFNBQVMsRUFBRTtBQUMvQixTQUFLLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsWUFBWSxDQUFDLENBQUE7SUFDdEM7QUFDRCxnQkFBYSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUNoQyxPQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzlDLFdBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUE7QUFDNUQsV0FBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7QUFDekQsZ0JBQWEsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDbkMsb0JBQWlCLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0FBQzVDLE9BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDcEQsaUJBQWMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7QUFDeEUsaUJBQWMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLGdEQUFnRCxDQUFDLENBQUE7QUFDOUUsaUJBQWMsQ0FBQyxTQUFTLEdBQUcseUJBQU8sZ0JBQWdCLENBQUMsQ0FBQTtBQUNuRCxvQkFBaUIsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUE7QUFDN0MsVUFBTyxpQkFBaUIsQ0FBQTtHQUN4Qjs7O1NBRVksc0JBQUMsRUFBRSxFQUFFLFVBQVUsRUFBRSxnQkFBZ0IsRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRTtBQUMzRixPQUFNLGlCQUFpQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsQ0FDckQsRUFBRSxFQUNGLFVBQVUsRUFDVixnQkFBZ0IsQ0FDaEIsQ0FBQTtBQUNELE9BQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDL0MsU0FBTSxDQUFDLFlBQVksQ0FBQyxNQUFNLEVBQUUsUUFBUSxDQUFDLENBQUE7QUFDckMsU0FBTSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMscUNBQXFDLENBQUMsQ0FBQTtBQUMzRCxTQUFNLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxlQUFlLENBQUMsQ0FBQTtBQUNyQyxRQUFLLElBQUksV0FBVyxJQUFJLGNBQWMsRUFBRTtBQUN2QyxRQUFJLE9BQU8sV0FBVyxLQUFLLFFBQVEsRUFBRTtBQUNwQyxnQkFBVyxHQUFHO0FBQ2IsV0FBSyxFQUFFLFdBQVc7QUFDbEIsaUJBQVcsRUFBRSxXQUFXO01BQ3hCLENBQUE7S0FDRDtBQUNELFFBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDL0MsVUFBTSxDQUFDLFlBQVksQ0FBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQy9DLFVBQU0sQ0FBQyxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQTtBQUM1QyxVQUFNLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQzFCO0FBQ0QsU0FBTSxDQUFDLEtBQUssR0FBRyxZQUFZLENBQUE7QUFDM0IsT0FBSSxZQUFZLEtBQUssU0FBUyxFQUFFO0FBQy9CLFVBQU0sQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFBO0lBQzNCO0FBQ0Qsb0JBQWlCLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ3JDLFVBQU8saUJBQWlCLENBQUE7R0FDeEI7OztTQUVjLHdCQUFDLEVBQUUsRUFBRSxVQUFVLEVBQUUsZ0JBQWdCLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRTtBQUM3RSxPQUFNLGlCQUFpQixHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDdkQsb0JBQWlCLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyw4QkFBOEIsQ0FBQyxDQUFBO0FBQy9ELG9CQUFpQixDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUE7QUFDeEMsT0FBTSxhQUFhLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsQ0FBQTtBQUNyRCxnQkFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsb0NBQW9DLENBQUMsQ0FBQTtBQUNqRSxnQkFBYSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsNkNBQTZDLENBQUMsQ0FBQTtBQUMxRSxPQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ2hELFdBQVEsQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLFVBQVUsQ0FBQyxDQUFBO0FBQ3pDLFdBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHVDQUF1QyxDQUFDLENBQUE7QUFDL0QsV0FBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtBQUN4QyxXQUFRLENBQUMsT0FBTyxHQUFHLFlBQVksQ0FBQTtBQUMvQixPQUFJLFlBQVksS0FBSyxTQUFTLEVBQUU7QUFDL0IsWUFBUSxDQUFDLE9BQU8sR0FBRyxZQUFZLENBQUE7SUFDL0I7QUFDRCxnQkFBYSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtBQUNuQyxPQUFNLFFBQVEsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQzlDLFdBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLG9DQUFvQyxDQUFDLENBQUE7QUFDNUQsV0FBUSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7QUFDekQsZ0JBQWEsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDbkMsb0JBQWlCLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0FBQzVDLE9BQU0sY0FBYyxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDcEQsaUJBQWMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDBDQUEwQyxDQUFDLENBQUE7QUFDeEUsaUJBQWMsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLG1EQUFtRCxDQUFDLENBQUE7QUFDakYsaUJBQWMsQ0FBQyxTQUFTLEdBQUcseUJBQU8sZ0JBQWdCLENBQUMsQ0FBQTtBQUNuRCxvQkFBaUIsQ0FBQyxXQUFXLENBQUMsY0FBYyxDQUFDLENBQUE7QUFDN0MsVUFBTyxpQkFBaUIsQ0FBQTtHQUN4Qjs7O1NBRVMscUJBQUc7QUFDWixPQUFNLEtBQUssR0FBRyxNQUFNLENBQUMsZ0JBQWdCLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFBO0FBQ2pELFVBQVEsS0FBSyxDQUFDLFVBQVUsS0FBSyxTQUFTLENBQUM7R0FDdkM7OztTQUVlLDJCQUFHO0FBQ2xCLE9BQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQTtBQUNoQyxPQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLHdCQUF3QixFQUFFLENBQUE7QUFDL0MsSUFBQyxDQUFDLFlBQVksRUFBRSxDQUFBO0FBQ2hCLElBQUMsQ0FBQyxlQUFlLEVBQUUsQ0FBQTtHQUNuQjs7O1NBRWUsMkJBQUc7QUFDbEIsT0FBSSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFBRSxDQUFDLFlBQVksRUFBRSxDQUFBO0FBQ3BELE9BQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxHQUFHLFNBQVMsQ0FBQTtHQUNqQzs7O1NBRWlCLDZCQUFHO0FBQ3BCLE9BQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLEVBQUU7QUFDdEIsUUFBSSxDQUFDLGVBQWUsRUFBRSxDQUFBO0lBQ3RCLE1BQU07QUFDTixRQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7SUFDdEI7R0FDRDs7O1NBRXVCLG1DQUFHO0FBQzFCLE9BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxzQkFBc0IsRUFBRSxDQUFBO0FBQ2hELE9BQU0sY0FBYyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxZQUFZLENBQ3pELElBQUksQ0FBQyxLQUFLLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxVQUFVLEVBQUUsRUFDM0MsVUFBVSxDQUNWLENBQUE7QUFDRCxVQUFPO0FBQ04sY0FBVSxFQUFFLFVBQVU7QUFDdEIsa0JBQWMsRUFBRSxjQUFjO0lBQzlCLENBQUE7R0FDRDs7O1NBRVcsdUJBQUc7QUFDZCxPQUFNLG9CQUFvQixHQUFHLElBQUksQ0FBQyx1QkFBdUIsRUFBRSxDQUFBO0FBQzNELE9BQUksQ0FBQyxtQkFBbUIsQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsQ0FBQTtHQUM3RDs7O1NBRVcsdUJBQUc7O0FBRWQsT0FBTSxvQkFBb0IsR0FBRyxJQUFJLENBQUMsdUJBQXVCLEVBQUUsQ0FBQTtBQUMzRCxPQUFJLENBQUMsdUJBQXVCLENBQzNCLG9CQUFvQixDQUFDLFVBQVUsRUFDL0Isb0JBQW9CLENBQUMsY0FBYyxDQUNuQyxDQUFBO0dBQ0Q7OztTQUVhLHlCQUFHO0FBQ2hCLE9BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLG9CQUFvQixDQUFDLENBQUE7QUFDMUQsT0FBTSxXQUFXLEdBQUcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsYUFBYSxDQUFDLENBQUMsSUFBSSxDQUFBO0FBQ25ELE9BQUksQ0FBQyxXQUFXLEVBQUU7QUFDakIsUUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsaURBQWlELENBQUMsQ0FBQTtBQUNoRixXQUFNO0lBQ047QUFDRCxPQUFJLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0dBQzlCOzs7MkJBRWtCLFdBQUMsVUFBVSxFQUFFO0FBQy9CLE9BQUksQ0FBQyxrQkFBa0IsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLENBQUE7R0FDaEQ7OzsyQkFFNkIsV0FBQyxVQUFVLEVBQUUsY0FBYyxFQUFFO0FBQzFELE9BQUksQ0FBQyxnQkFBZ0IsQ0FBQyx1QkFBdUIsQ0FBQyxVQUFVLEVBQUUsY0FBYyxDQUFDLENBQUE7R0FDekU7OztTQUVrQiw0QkFBQyxPQUFPLEVBQWlCO09BQWYsS0FBSyx5REFBRyxLQUFLOztBQUN6QyxRQUFLLElBQU0sSUFBSSwyQkFBaUI7QUFDL0IsUUFBSSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsU0FBUTs7QUFFOUIsUUFBSSxJQUFJLFFBQUssRUFBRTtBQUNkLFNBQU0sUUFBUSxTQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLG1CQUFnQixDQUFBO0FBQ2xFLFNBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDMUMsVUFBSyxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtLQUMxRCxNQUFNLElBQUksSUFBSSxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7QUFDakMsU0FBTSxRQUFRLFNBQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsaUJBQWMsQ0FBQTtBQUNoRSxTQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQzFDLFVBQUssQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUE7S0FDMUQsTUFBTSxJQUFJLElBQUksQ0FBQyxJQUFJLEtBQUssU0FBUyxFQUFFO0FBQ25DLFNBQU0sUUFBUSxTQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLG9CQUFpQixDQUFBO0FBQ25FLFNBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDN0MsYUFBUSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQTtLQUMvRCxNQUFNO0FBQ04sU0FBTSxRQUFRLFNBQU8sSUFBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsZ0NBQTZCLENBQUE7QUFDL0UsU0FBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQTtBQUNyRCxTQUFJLENBQUMsS0FBSyxFQUFFO0FBQ1gsV0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFBO01BQzNELE1BQU07QUFDTixXQUFLLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxDQUFBO01BQ2pCO0tBQ0Q7SUFDRDtHQUNEOzs7UUE5Y0ksK0JBQStCO0dBQVMsV0FBVzs7QUFpZHpELElBQU0sMkJBQTJCLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsRUFBRTtBQUNsRixVQUFTLEVBQUUsK0JBQStCLENBQUMsU0FBUztDQUNwRCxDQUFDLENBQUE7O1FBR0QsMkJBQTJCLEdBQTNCLDJCQUEyQiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy94LXRlcm1pbmFsL3NyYy9wcm9maWxlLW1lbnUtZWxlbWVudC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKiBAYmFiZWwgKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxNyBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IDIwMTctMjAxOCBBbmRyZXMgTWVqaWEgPGFtZWppYTAwNEBnbWFpbC5jb20+LiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIFV6aVRlY2ggQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBidXMtc3RvcCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpc1xuICogc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlXG4gKiB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksXG4gKiBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvXG4gKiBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28uXG4gKlxuICogVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUiBJTVBMSUVELFxuICogSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEFcbiAqIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFRcbiAqIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTlxuICogT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFXG4gKiBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiAqL1xuXG5pbXBvcnQgeyBDb21wb3NpdGVEaXNwb3NhYmxlLCBUZXh0RWRpdG9yIH0gZnJvbSAnYXRvbSdcbmltcG9ydCBtYXJrZWQgZnJvbSAnbWFya2VkJ1xuXG5pbXBvcnQgeyBYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbiB9IGZyb20gJy4vcHJvZmlsZXMnXG5pbXBvcnQgeyBYVGVybWluYWxEZWxldGVQcm9maWxlTW9kZWwgfSBmcm9tICcuL2RlbGV0ZS1wcm9maWxlLW1vZGVsJ1xuaW1wb3J0IHsgWFRlcm1pbmFsU2F2ZVByb2ZpbGVNb2RlbCB9IGZyb20gJy4vc2F2ZS1wcm9maWxlLW1vZGVsJ1xuaW1wb3J0IHsgY3JlYXRlSG9yaXpvbnRhbExpbmUgfSBmcm9tICcuL3V0aWxzJ1xuaW1wb3J0IHsgQ09ORklHX0RBVEEgfSBmcm9tICcuL2NvbmZpZy5qcydcblxuY2xhc3MgWFRlcm1pbmFsUHJvZmlsZU1lbnVFbGVtZW50SW1wbCBleHRlbmRzIEhUTUxFbGVtZW50IHtcblx0YXN5bmMgaW5pdGlhbGl6ZSAobW9kZWwpIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLm1vZGVsLnNldEVsZW1lbnQodGhpcylcblx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uID0gWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24uaW5zdGFuY2Vcblx0XHRjb25zdCB0b3BEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdHRvcERpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1lbGVtZW50LXRvcC1kaXYnKVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQodG9wRGl2KVxuXHRcdGNvbnN0IGxlZnREaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdGxlZnREaXYuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtZWxlbWVudC1sZWZ0LWRpdicpXG5cdFx0dGhpcy5hcHBlbmRDaGlsZChsZWZ0RGl2KVxuXHRcdHRoaXMubWFpbkRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5cdFx0dGhpcy5tYWluRGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWVsZW1lbnQtbWFpbi1kaXYnKVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQodGhpcy5tYWluRGl2KVxuXHRcdGNvbnN0IHJpZ2h0RGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHRyaWdodERpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1lbGVtZW50LXJpZ2h0LWRpdicpXG5cdFx0dGhpcy5hcHBlbmRDaGlsZChyaWdodERpdilcblx0XHRjb25zdCBib3R0b21EaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdGJvdHRvbURpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1lbGVtZW50LWJvdHRvbS1kaXYnKVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQoYm90dG9tRGl2KVxuXHRcdHRoaXMuZGlzcG9zYWJsZXMgPSBuZXcgQ29tcG9zaXRlRGlzcG9zYWJsZSgpXG5cdFx0bGV0IHJlc29sdmVJbml0XG5cdFx0dGhpcy5pbml0aWFsaXplZFByb21pc2UgPSBuZXcgUHJvbWlzZSgocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG5cdFx0XHRyZXNvbHZlSW5pdCA9IHJlc29sdmVcblx0XHR9KVxuXG5cdFx0Y29uc3QgcHJvZmlsZXNEaXYgPSBhd2FpdCB0aGlzLmNyZWF0ZVByb2ZpbGVzRHJvcERvd24oKVxuXHRcdGNvbnN0IG1vZGVsUHJvZmlsZSA9IHRoaXMuZ2V0TW9kZWxQcm9maWxlKClcblx0XHRjb25zdCBiYXNlUHJvZmlsZSA9IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2V0QmFzZVByb2ZpbGUoKVxuXHRcdC8vIFByb2ZpbGVzXG5cdFx0dGhpcy5tYWluRGl2LmFwcGVuZENoaWxkKHByb2ZpbGVzRGl2KVxuXG5cdFx0Ly8gQnV0dG9ucyBkaXZcblx0XHR0aGlzLm1haW5EaXYuYXBwZW5kQ2hpbGQodGhpcy5jcmVhdGVQcm9maWxlTWVudUJ1dHRvbnMoKSlcblxuXHRcdC8vIEhvcml6b250YWwgbGluZS5cblx0XHR0aGlzLm1haW5EaXYuYXBwZW5kQ2hpbGQoY3JlYXRlSG9yaXpvbnRhbExpbmUoKSlcblxuXHRcdHRoaXMuY3JlYXRlRnJvbUNvbmZpZyhiYXNlUHJvZmlsZSwgbW9kZWxQcm9maWxlKVxuXG5cdFx0dGhpcy5kZWxldGVQcm9maWxlTW9kZWwgPSBuZXcgWFRlcm1pbmFsRGVsZXRlUHJvZmlsZU1vZGVsKHRoaXMpXG5cdFx0dGhpcy5zYXZlUHJvZmlsZU1vZGVsID0gbmV3IFhUZXJtaW5hbFNhdmVQcm9maWxlTW9kZWwodGhpcylcblxuXHRcdHRoaXMuZGlzcG9zYWJsZXMuYWRkKHRoaXMucHJvZmlsZXNTaW5nbGV0b24ub25EaWRSZWxvYWRQcm9maWxlcyhhc3luYyAocHJvZmlsZXMpID0+IHtcblx0XHRcdGNvbnN0IHNlbGVjdCA9IGF3YWl0IHRoaXMuY3JlYXRlUHJvZmlsZXNEcm9wRG93blNlbGVjdEl0ZW0oKVxuXHRcdFx0Y29uc3QgbWVudUl0ZW1Db250YWluZXIgPSB0aGlzLm1haW5EaXYucXVlcnlTZWxlY3RvcignI3Byb2ZpbGVzLXNlbGVjdGlvbicpXG5cdFx0XHR3aGlsZSAobWVudUl0ZW1Db250YWluZXIuZmlyc3RDaGlsZCkge1xuXHRcdFx0XHRtZW51SXRlbUNvbnRhaW5lci5yZW1vdmVDaGlsZChtZW51SXRlbUNvbnRhaW5lci5maXJzdENoaWxkKVxuXHRcdFx0fVxuXHRcdFx0bWVudUl0ZW1Db250YWluZXIuYXBwZW5kQ2hpbGQoc2VsZWN0KVxuXHRcdH0pKVxuXHRcdHJlc29sdmVJbml0KClcblx0fVxuXG5cdGNyZWF0ZUZyb21Db25maWcgKGJhc2VQcm9maWxlLCBtb2RlbFByb2ZpbGUpIHtcblx0XHRmb3IgKGNvbnN0IGRhdGEgb2YgQ09ORklHX0RBVEEpIHtcblx0XHRcdGlmICghZGF0YS5wcm9maWxlS2V5KSBjb250aW51ZVxuXHRcdFx0Y29uc3QgdGl0bGUgPSBkYXRhLnRpdGxlIHx8IGRhdGEucHJvZmlsZUtleS5jaGFyQXQoMCkudG9VcHBlckNhc2UoKSArIGRhdGEucHJvZmlsZUtleS5zdWJzdHJpbmcoMSkucmVwbGFjZSgvW0EtWl0vZywgJyAkJicpXG5cdFx0XHRjb25zdCBkZXNjcmlwdGlvbiA9IGRhdGEuZGVzY3JpcHRpb24gfHwgJydcblx0XHRcdGlmIChkYXRhLmVudW0pIHtcblx0XHRcdFx0dGhpcy5tYWluRGl2LmFwcGVuZENoaWxkKHRoaXMuY3JlYXRlU2VsZWN0KFxuXHRcdFx0XHRcdGAke2RhdGEucHJvZmlsZUtleS50b0xvd2VyQ2FzZSgpfS1zZWxlY3RgLFxuXHRcdFx0XHRcdHRpdGxlLFxuXHRcdFx0XHRcdGRlc2NyaXB0aW9uLFxuXHRcdFx0XHRcdGJhc2VQcm9maWxlW2RhdGEucHJvZmlsZUtleV0sXG5cdFx0XHRcdFx0bW9kZWxQcm9maWxlW2RhdGEucHJvZmlsZUtleV0sXG5cdFx0XHRcdFx0ZGF0YS5lbnVtLFxuXHRcdFx0XHQpKVxuXHRcdFx0fSBlbHNlIGlmIChkYXRhLnR5cGUgPT09ICdjb2xvcicpIHtcblx0XHRcdFx0dGhpcy5tYWluRGl2LmFwcGVuZENoaWxkKHRoaXMuY3JlYXRlQ29sb3IoXG5cdFx0XHRcdFx0YCR7ZGF0YS5wcm9maWxlS2V5LnRvTG93ZXJDYXNlKCl9LWNvbG9yYCxcblx0XHRcdFx0XHR0aXRsZSxcblx0XHRcdFx0XHRkZXNjcmlwdGlvbixcblx0XHRcdFx0XHRiYXNlUHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldLFxuXHRcdFx0XHRcdG1vZGVsUHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldLFxuXHRcdFx0XHQpKVxuXHRcdFx0fSBlbHNlIGlmIChkYXRhLnR5cGUgPT09ICdib29sZWFuJykge1xuXHRcdFx0XHR0aGlzLm1haW5EaXYuYXBwZW5kQ2hpbGQodGhpcy5jcmVhdGVDaGVja2JveChcblx0XHRcdFx0XHRgJHtkYXRhLnByb2ZpbGVLZXkudG9Mb3dlckNhc2UoKX0tY2hlY2tib3hgLFxuXHRcdFx0XHRcdHRpdGxlLFxuXHRcdFx0XHRcdGRlc2NyaXB0aW9uLFxuXHRcdFx0XHRcdGJhc2VQcm9maWxlW2RhdGEucHJvZmlsZUtleV0sXG5cdFx0XHRcdFx0bW9kZWxQcm9maWxlW2RhdGEucHJvZmlsZUtleV0sXG5cdFx0XHRcdCkpXG5cdFx0XHR9IGVsc2Uge1xuXHRcdFx0XHR0aGlzLm1haW5EaXYuYXBwZW5kQ2hpbGQodGhpcy5jcmVhdGVUZXh0Ym94KFxuXHRcdFx0XHRcdGAke2RhdGEucHJvZmlsZUtleS50b0xvd2VyQ2FzZSgpfS10ZXh0Ym94YCxcblx0XHRcdFx0XHR0aXRsZSxcblx0XHRcdFx0XHRkZXNjcmlwdGlvbixcblx0XHRcdFx0XHRiYXNlUHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldLFxuXHRcdFx0XHRcdG1vZGVsUHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldLFxuXHRcdFx0XHQpKVxuXHRcdFx0fVxuXHRcdH1cblx0fVxuXG5cdGRlc3Ryb3kgKCkge1xuXHRcdGlmICh0aGlzLmRpc3Bvc2FibGVzKSB7XG5cdFx0XHR0aGlzLmRpc3Bvc2FibGVzLmRpc3Bvc2UoKVxuXHRcdH1cblx0fVxuXG5cdGdldE1vZGVsUHJvZmlsZSAoKSB7XG5cdFx0cmV0dXJuIHRoaXMubW9kZWwuYXRvbVh0ZXJtTW9kZWwucHJvZmlsZVxuXHR9XG5cblx0Z2V0TWVudUVsZW1lbnRzICgpIHtcblx0XHRjb25zdCBtZW51RWxlbWVudHMgPSB7fVxuXHRcdGZvciAoY29uc3QgZGF0YSBvZiBDT05GSUdfREFUQSkge1xuXHRcdFx0aWYgKCFkYXRhLnByb2ZpbGVLZXkpIGNvbnRpbnVlXG5cblx0XHRcdGxldCB0eXBlID0gJ3RleHRib3ggPiBhdG9tLXRleHQtZWRpdG9yJ1xuXHRcdFx0aWYgKGRhdGEuZW51bSkge1xuXHRcdFx0XHR0eXBlID0gJ3NlbGVjdCBzZWxlY3QnXG5cdFx0XHR9IGVsc2UgaWYgKGRhdGEudHlwZSA9PT0gJ2NvbG9yJykge1xuXHRcdFx0XHR0eXBlID0gJ2NvbG9yIGlucHV0J1xuXHRcdFx0fSBlbHNlIGlmIChkYXRhLnR5cGUgPT09ICdib29sZWFuJykge1xuXHRcdFx0XHR0eXBlID0gJ2NoZWNrYm94IGlucHV0J1xuXHRcdFx0fVxuXHRcdFx0bWVudUVsZW1lbnRzW2RhdGEucHJvZmlsZUtleV0gPSB0aGlzLm1haW5EaXYucXVlcnlTZWxlY3RvcihgIyR7ZGF0YS5wcm9maWxlS2V5LnRvTG93ZXJDYXNlKCl9LSR7dHlwZX1gKVxuXHRcdH1cblx0XHRyZXR1cm4gbWVudUVsZW1lbnRzXG5cdH1cblxuXHRnZXRQcm9maWxlTWVudVNldHRpbmdzICgpIHtcblx0XHRjb25zdCBuZXdQcm9maWxlID0ge31cblx0XHRjb25zdCBiYXNlUHJvZmlsZSA9IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2V0QmFzZVByb2ZpbGUoKVxuXHRcdGNvbnN0IG1lbnVFbGVtZW50cyA9IHRoaXMuZ2V0TWVudUVsZW1lbnRzKClcblx0XHRmb3IgKGNvbnN0IGRhdGEgb2YgQ09ORklHX0RBVEEpIHtcblx0XHRcdGlmICghZGF0YS5wcm9maWxlS2V5KSBjb250aW51ZVxuXHRcdFx0bmV3UHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldID0gZGF0YS5mcm9tTWVudVNldHRpbmcobWVudUVsZW1lbnRzW2RhdGEucHJvZmlsZUtleV0sIGJhc2VQcm9maWxlW2RhdGEucHJvZmlsZUtleV0pXG5cdFx0fVxuXHRcdHJldHVybiBuZXdQcm9maWxlXG5cdH1cblxuXHRhcHBseVByb2ZpbGVDaGFuZ2VzIChwcm9maWxlQ2hhbmdlcykge1xuXHRcdHRoaXMuaGlkZVByb2ZpbGVNZW51KClcblx0XHR0aGlzLm1vZGVsLmdldFhUZXJtaW5hbE1vZGVsKCkuYXBwbHlQcm9maWxlQ2hhbmdlcyhwcm9maWxlQ2hhbmdlcylcblx0fVxuXG5cdHJlc3RhcnRUZXJtaW5hbCAoKSB7XG5cdFx0dGhpcy5oaWRlUHJvZmlsZU1lbnUoKVxuXHRcdHRoaXMubW9kZWwuZ2V0WFRlcm1pbmFsTW9kZWxFbGVtZW50KCkucmVzdGFydFB0eVByb2Nlc3MoKVxuXHR9XG5cblx0Y3JlYXRlTWVudUl0ZW1Db250YWluZXIgKGlkLCBsYWJlbFRpdGxlLCBsYWJlbERlc2NyaXB0aW9uKSB7XG5cdFx0Y29uc3QgbWVudUl0ZW1Db250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdG1lbnVJdGVtQ29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0nKVxuXHRcdG1lbnVJdGVtQ29udGFpbmVyLnNldEF0dHJpYnV0ZSgnaWQnLCBpZClcblx0XHRjb25zdCBtZW51SXRlbUxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGFiZWwnKVxuXHRcdG1lbnVJdGVtTGFiZWwuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtaXRlbS1sYWJlbCcpXG5cdFx0Y29uc3QgdGl0bGVEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdHRpdGxlRGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0tdGl0bGUnKVxuXHRcdHRpdGxlRGl2LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGxhYmVsVGl0bGUpKVxuXHRcdG1lbnVJdGVtTGFiZWwuYXBwZW5kQ2hpbGQodGl0bGVEaXYpXG5cdFx0Y29uc3QgZGVzY3JpcHRpb25EaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdGRlc2NyaXB0aW9uRGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0tZGVzY3JpcHRpb24nKVxuXHRcdGRlc2NyaXB0aW9uRGl2LmlubmVySFRNTCA9IG1hcmtlZChsYWJlbERlc2NyaXB0aW9uKVxuXHRcdG1lbnVJdGVtTGFiZWwuYXBwZW5kQ2hpbGQoZGVzY3JpcHRpb25EaXYpXG5cdFx0bWVudUl0ZW1Db250YWluZXIuYXBwZW5kQ2hpbGQobWVudUl0ZW1MYWJlbClcblx0XHRyZXR1cm4gbWVudUl0ZW1Db250YWluZXJcblx0fVxuXG5cdGFzeW5jIGNyZWF0ZVByb2ZpbGVzRHJvcERvd25TZWxlY3RJdGVtICgpIHtcblx0XHRjb25zdCBwcm9maWxlcyA9IGF3YWl0IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2V0UHJvZmlsZXMoKVxuXHRcdGNvbnN0IHNlbGVjdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NlbGVjdCcpXG5cdFx0c2VsZWN0LnNldEF0dHJpYnV0ZSgnaWQnLCAncHJvZmlsZXMtZHJvcGRvd24nKVxuXHRcdHNlbGVjdC5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtLXNlbGVjdCcpXG5cdFx0bGV0IG9wdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ29wdGlvbicpXG5cdFx0bGV0IHRleHQgPSBkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnJylcblx0XHRvcHRpb24uc2V0QXR0cmlidXRlKCd2YWx1ZScsIHRleHQpXG5cdFx0b3B0aW9uLmFwcGVuZENoaWxkKHRleHQpXG5cdFx0c2VsZWN0LmFwcGVuZENoaWxkKG9wdGlvbilcblx0XHRmb3IgKGNvbnN0IHByb2ZpbGUgaW4gcHJvZmlsZXMpIHtcblx0XHRcdG9wdGlvbiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ29wdGlvbicpXG5cdFx0XHR0ZXh0ID0gZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUocHJvZmlsZSlcblx0XHRcdG9wdGlvbi5zZXRBdHRyaWJ1dGUoJ3ZhbHVlJywgdGV4dC50ZXh0Q29udGVudClcblx0XHRcdG9wdGlvbi5hcHBlbmRDaGlsZCh0ZXh0KVxuXHRcdFx0c2VsZWN0LmFwcGVuZENoaWxkKG9wdGlvbilcblx0XHR9XG5cdFx0c2VsZWN0LmFkZEV2ZW50TGlzdGVuZXIoJ2NoYW5nZScsIGFzeW5jIChldmVudCkgPT4ge1xuXHRcdFx0aWYgKGV2ZW50LnRhcmdldC52YWx1ZSkge1xuXHRcdFx0XHRjb25zdCBwcm9maWxlID0gYXdhaXQgdGhpcy5wcm9maWxlc1NpbmdsZXRvbi5nZXRQcm9maWxlKGV2ZW50LnRhcmdldC52YWx1ZSlcblx0XHRcdFx0dGhpcy5zZXROZXdNZW51U2V0dGluZ3MocHJvZmlsZSlcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGNvbnN0IHByb2ZpbGUgPSB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdldEJhc2VQcm9maWxlKClcblx0XHRcdFx0dGhpcy5zZXROZXdNZW51U2V0dGluZ3MocHJvZmlsZSwgdHJ1ZSlcblx0XHRcdH1cblx0XHR9LCB7IHBhc3NpdmU6IHRydWUgfSlcblx0XHRyZXR1cm4gc2VsZWN0XG5cdH1cblxuXHRhc3luYyBjcmVhdGVQcm9maWxlc0Ryb3BEb3duICgpIHtcblx0XHRjb25zdCBtZW51SXRlbUNvbnRhaW5lciA9IHRoaXMuY3JlYXRlTWVudUl0ZW1Db250YWluZXIoXG5cdFx0XHQncHJvZmlsZXMtc2VsZWN0aW9uJyxcblx0XHRcdCdQcm9maWxlcycsXG5cdFx0XHQnQXZhaWxhYmxlIHByb2ZpbGVzJyxcblx0XHQpXG5cdFx0Y29uc3Qgc2VsZWN0ID0gYXdhaXQgdGhpcy5jcmVhdGVQcm9maWxlc0Ryb3BEb3duU2VsZWN0SXRlbSgpXG5cdFx0bWVudUl0ZW1Db250YWluZXIuYXBwZW5kQ2hpbGQoc2VsZWN0KVxuXHRcdHJldHVybiBtZW51SXRlbUNvbnRhaW5lclxuXHR9XG5cblx0Y3JlYXRlUHJvZmlsZU1lbnVCdXR0b25zICgpIHtcblx0XHRjb25zdCBidXR0b25zQ29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHRidXR0b25zQ29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWJ1dHRvbnMtZGl2Jylcblx0XHRsZXQgYnV0dG9uID0gdGhpcy5jcmVhdGVCdXR0b24oKVxuXHRcdGJ1dHRvbi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnTG9hZCBTZXR0aW5ncycpKVxuXHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdidG4tbG9hZCcpXG5cdFx0YnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGV2ZW50KSA9PiB7XG5cdFx0XHR0aGlzLmxvYWRQcm9maWxlKClcblx0XHR9LCB7IHBhc3NpdmU6IHRydWUgfSlcblx0XHRidXR0b25zQ29udGFpbmVyLmFwcGVuZENoaWxkKGJ1dHRvbilcblx0XHRidXR0b24gPSB0aGlzLmNyZWF0ZUJ1dHRvbigpXG5cdFx0YnV0dG9uLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdTYXZlIFNldHRpbmdzJykpXG5cdFx0YnV0dG9uLmNsYXNzTGlzdC5hZGQoJ2J0bi1zYXZlJylcblx0XHRidXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuc2F2ZVByb2ZpbGUoKVxuXHRcdH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KVxuXHRcdGJ1dHRvbnNDb250YWluZXIuYXBwZW5kQ2hpbGQoYnV0dG9uKVxuXHRcdGJ1dHRvbiA9IHRoaXMuY3JlYXRlQnV0dG9uKClcblx0XHRidXR0b24uYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUoJ0RlbGV0ZSBTZXR0aW5ncycpKVxuXHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdidG4tZGVsZXRlJylcblx0XHRidXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuZGVsZXRlUHJvZmlsZSgpXG5cdFx0fSwgeyBwYXNzaXZlOiB0cnVlIH0pXG5cdFx0YnV0dG9uc0NvbnRhaW5lci5hcHBlbmRDaGlsZChidXR0b24pXG5cdFx0YnV0dG9uID0gdGhpcy5jcmVhdGVCdXR0b24oKVxuXHRcdGJ1dHRvbi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnUmVzdGFydCcpKVxuXHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdidG4tcmVzdGFydCcpXG5cdFx0YnV0dG9uLmFkZEV2ZW50TGlzdGVuZXIoJ2NsaWNrJywgKGV2ZW50KSA9PiB7XG5cdFx0XHR0aGlzLnJlc3RhcnRUZXJtaW5hbCgpXG5cdFx0fSwgeyBwYXNzaXZlOiB0cnVlIH0pXG5cdFx0YnV0dG9uc0NvbnRhaW5lci5hcHBlbmRDaGlsZChidXR0b24pXG5cdFx0YnV0dG9uID0gdGhpcy5jcmVhdGVCdXR0b24oKVxuXHRcdGJ1dHRvbi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnSGlkZSBNZW51JykpXG5cdFx0YnV0dG9uLmNsYXNzTGlzdC5hZGQoJ2J0bi1oaWRlJylcblx0XHRidXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuaGlkZVByb2ZpbGVNZW51KClcblx0XHR9LCB7IHBhc3NpdmU6IHRydWUgfSlcblx0XHRidXR0b25zQ29udGFpbmVyLmFwcGVuZENoaWxkKGJ1dHRvbilcblx0XHRyZXR1cm4gYnV0dG9uc0NvbnRhaW5lclxuXHR9XG5cblx0Y3JlYXRlQnV0dG9uICgpIHtcblx0XHRjb25zdCBidXR0b24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdidXR0b24nKVxuXHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1idXR0b24nKVxuXHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdidG4nKVxuXHRcdGJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdpbmxpbmUtYmxvY2stdGlnaHQnKVxuXHRcdHJldHVybiBidXR0b25cblx0fVxuXG5cdGNyZWF0ZVRleHRib3ggKGlkLCBsYWJlbFRpdGxlLCBsYWJlbERlc2NyaXB0aW9uLCBkZWZhdWx0VmFsdWUsIGluaXRpYWxWYWx1ZSkge1xuXHRcdGNvbnN0IG1lbnVJdGVtQ29udGFpbmVyID0gdGhpcy5jcmVhdGVNZW51SXRlbUNvbnRhaW5lcihcblx0XHRcdGlkLFxuXHRcdFx0bGFiZWxUaXRsZSxcblx0XHRcdGxhYmVsRGVzY3JpcHRpb24sXG5cdFx0KVxuXHRcdGNvbnN0IHRleHRib3ggPSBuZXcgVGV4dEVkaXRvcih7XG5cdFx0XHRtaW5pOiB0cnVlLFxuXHRcdFx0cGxhY2Vob2xkZXJUZXh0OiBkZWZhdWx0VmFsdWUsXG5cdFx0fSlcblx0XHRpZiAoaW5pdGlhbFZhbHVlKSB7XG5cdFx0XHRpZiAoaW5pdGlhbFZhbHVlLmNvbnN0cnVjdG9yID09PSBBcnJheSB8fCBpbml0aWFsVmFsdWUuY29uc3RydWN0b3IgPT09IE9iamVjdCkge1xuXHRcdFx0XHR0ZXh0Ym94LnNldFRleHQoSlNPTi5zdHJpbmdpZnkoaW5pdGlhbFZhbHVlKSlcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdHRleHRib3guc2V0VGV4dChpbml0aWFsVmFsdWUpXG5cdFx0XHR9XG5cdFx0fVxuXHRcdG1lbnVJdGVtQ29udGFpbmVyLmFwcGVuZENoaWxkKHRleHRib3guZ2V0RWxlbWVudCgpKVxuXHRcdHJldHVybiBtZW51SXRlbUNvbnRhaW5lclxuXHR9XG5cblx0dG9IZXggKGNvbG9yKSB7XG5cdFx0Y29sb3IgPSBjb2xvci5yZXBsYWNlKC9yZ2JhXFwoXFxzKihcXGQrKVxccyosXFxzKihcXGQrKVxccyosXFxzKihcXGQrKVxccyosXFxzKltcXGQuXStcXHMqXFwpLywgJ3JnYigkMSwgJDIsICQzKScpLnRyaW0oKVxuXHRcdGNvbnN0IGN0eCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2NhbnZhcycpLmdldENvbnRleHQoJzJkJylcblx0XHRjdHguZmlsbFN0eWxlID0gY29sb3Jcblx0XHRyZXR1cm4gY3R4LmZpbGxTdHlsZVxuXHR9XG5cblx0Y3JlYXRlQ29sb3IgKGlkLCBsYWJlbFRpdGxlLCBsYWJlbERlc2NyaXB0aW9uLCBkZWZhdWx0VmFsdWUsIGluaXRpYWxWYWx1ZSkge1xuXHRcdGNvbnN0IG1lbnVJdGVtQ29udGFpbmVyID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHRtZW51SXRlbUNvbnRhaW5lci5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtJylcblx0XHRtZW51SXRlbUNvbnRhaW5lci5zZXRBdHRyaWJ1dGUoJ2lkJywgaWQpXG5cdFx0Y29uc3QgbWVudUl0ZW1MYWJlbCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2xhYmVsJylcblx0XHRtZW51SXRlbUxhYmVsLmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0tbGFiZWwnKVxuXHRcdG1lbnVJdGVtTGFiZWwuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtaXRlbS1sYWJlbC1jb2xvcicpXG5cdFx0Y29uc3QgY29sb3IgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdpbnB1dCcpXG5cdFx0Y29sb3Iuc2V0QXR0cmlidXRlKCd0eXBlJywgJ2NvbG9yJylcblx0XHRjb2xvci5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtLWNvbG9yJylcblx0XHRjb2xvci52YWx1ZSA9IHRoaXMudG9IZXgoZGVmYXVsdFZhbHVlKVxuXHRcdGlmIChpbml0aWFsVmFsdWUgIT09IHVuZGVmaW5lZCkge1xuXHRcdFx0Y29sb3IudmFsdWUgPSB0aGlzLnRvSGV4KGluaXRpYWxWYWx1ZSlcblx0XHR9XG5cdFx0bWVudUl0ZW1MYWJlbC5hcHBlbmRDaGlsZChjb2xvcilcblx0XHRjb25zdCB0aXRsZURpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5cdFx0dGl0bGVEaXYuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtaXRlbS10aXRsZScpXG5cdFx0dGl0bGVEaXYuYXBwZW5kQ2hpbGQoZG9jdW1lbnQuY3JlYXRlVGV4dE5vZGUobGFiZWxUaXRsZSkpXG5cdFx0bWVudUl0ZW1MYWJlbC5hcHBlbmRDaGlsZCh0aXRsZURpdilcblx0XHRtZW51SXRlbUNvbnRhaW5lci5hcHBlbmRDaGlsZChtZW51SXRlbUxhYmVsKVxuXHRcdGNvbnN0IGRlc2NyaXB0aW9uRGl2ID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnZGl2Jylcblx0XHRkZXNjcmlwdGlvbkRpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtLWRlc2NyaXB0aW9uJylcblx0XHRkZXNjcmlwdGlvbkRpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtLWRlc2NyaXB0aW9uLWNvbG9yJylcblx0XHRkZXNjcmlwdGlvbkRpdi5pbm5lckhUTUwgPSBtYXJrZWQobGFiZWxEZXNjcmlwdGlvbilcblx0XHRtZW51SXRlbUNvbnRhaW5lci5hcHBlbmRDaGlsZChkZXNjcmlwdGlvbkRpdilcblx0XHRyZXR1cm4gbWVudUl0ZW1Db250YWluZXJcblx0fVxuXG5cdGNyZWF0ZVNlbGVjdCAoaWQsIGxhYmVsVGl0bGUsIGxhYmVsRGVzY3JpcHRpb24sIGRlZmF1bHRWYWx1ZSwgaW5pdGlhbFZhbHVlLCBwb3NzaWJsZVZhbHVlcykge1xuXHRcdGNvbnN0IG1lbnVJdGVtQ29udGFpbmVyID0gdGhpcy5jcmVhdGVNZW51SXRlbUNvbnRhaW5lcihcblx0XHRcdGlkLFxuXHRcdFx0bGFiZWxUaXRsZSxcblx0XHRcdGxhYmVsRGVzY3JpcHRpb24sXG5cdFx0KVxuXHRcdGNvbnN0IHNlbGVjdCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ3NlbGVjdCcpXG5cdFx0c2VsZWN0LnNldEF0dHJpYnV0ZSgndHlwZScsICdzZWxlY3QnKVxuXHRcdHNlbGVjdC5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtLXNlbGVjdCcpXG5cdFx0c2VsZWN0LmNsYXNzTGlzdC5hZGQoJ3NldHRpbmdzLXZpZXcnKVxuXHRcdGZvciAobGV0IG9wdGlvblZhbHVlIG9mIHBvc3NpYmxlVmFsdWVzKSB7XG5cdFx0XHRpZiAodHlwZW9mIG9wdGlvblZhbHVlICE9PSAnb2JqZWN0Jykge1xuXHRcdFx0XHRvcHRpb25WYWx1ZSA9IHtcblx0XHRcdFx0XHR2YWx1ZTogb3B0aW9uVmFsdWUsXG5cdFx0XHRcdFx0ZGVzY3JpcHRpb246IG9wdGlvblZhbHVlLFxuXHRcdFx0XHR9XG5cdFx0XHR9XG5cdFx0XHRjb25zdCBvcHRpb24gPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdvcHRpb24nKVxuXHRcdFx0b3B0aW9uLnNldEF0dHJpYnV0ZSgndmFsdWUnLCBvcHRpb25WYWx1ZS52YWx1ZSlcblx0XHRcdG9wdGlvbi50ZXh0Q29udGVudCA9IG9wdGlvblZhbHVlLmRlc2NyaXB0aW9uXG5cdFx0XHRzZWxlY3QuYXBwZW5kQ2hpbGQob3B0aW9uKVxuXHRcdH1cblx0XHRzZWxlY3QudmFsdWUgPSBkZWZhdWx0VmFsdWVcblx0XHRpZiAoaW5pdGlhbFZhbHVlICE9PSB1bmRlZmluZWQpIHtcblx0XHRcdHNlbGVjdC52YWx1ZSA9IGluaXRpYWxWYWx1ZVxuXHRcdH1cblx0XHRtZW51SXRlbUNvbnRhaW5lci5hcHBlbmRDaGlsZChzZWxlY3QpXG5cdFx0cmV0dXJuIG1lbnVJdGVtQ29udGFpbmVyXG5cdH1cblxuXHRjcmVhdGVDaGVja2JveCAoaWQsIGxhYmVsVGl0bGUsIGxhYmVsRGVzY3JpcHRpb24sIGRlZmF1bHRWYWx1ZSwgaW5pdGlhbFZhbHVlKSB7XG5cdFx0Y29uc3QgbWVudUl0ZW1Db250YWluZXIgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdG1lbnVJdGVtQ29udGFpbmVyLmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0nKVxuXHRcdG1lbnVJdGVtQ29udGFpbmVyLnNldEF0dHJpYnV0ZSgnaWQnLCBpZClcblx0XHRjb25zdCBtZW51SXRlbUxhYmVsID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnbGFiZWwnKVxuXHRcdG1lbnVJdGVtTGFiZWwuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtaXRlbS1sYWJlbCcpXG5cdFx0bWVudUl0ZW1MYWJlbC5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLXByb2ZpbGUtbWVudS1pdGVtLWxhYmVsLWNoZWNrYm94Jylcblx0XHRjb25zdCBjaGVja2JveCA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2lucHV0Jylcblx0XHRjaGVja2JveC5zZXRBdHRyaWJ1dGUoJ3R5cGUnLCAnY2hlY2tib3gnKVxuXHRcdGNoZWNrYm94LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0tY2hlY2tib3gnKVxuXHRcdGNoZWNrYm94LmNsYXNzTGlzdC5hZGQoJ2lucHV0LWNoZWNrYm94Jylcblx0XHRjaGVja2JveC5jaGVja2VkID0gZGVmYXVsdFZhbHVlXG5cdFx0aWYgKGluaXRpYWxWYWx1ZSAhPT0gdW5kZWZpbmVkKSB7XG5cdFx0XHRjaGVja2JveC5jaGVja2VkID0gaW5pdGlhbFZhbHVlXG5cdFx0fVxuXHRcdG1lbnVJdGVtTGFiZWwuYXBwZW5kQ2hpbGQoY2hlY2tib3gpXG5cdFx0Y29uc3QgdGl0bGVEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdHRpdGxlRGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtcHJvZmlsZS1tZW51LWl0ZW0tdGl0bGUnKVxuXHRcdHRpdGxlRGl2LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKGxhYmVsVGl0bGUpKVxuXHRcdG1lbnVJdGVtTGFiZWwuYXBwZW5kQ2hpbGQodGl0bGVEaXYpXG5cdFx0bWVudUl0ZW1Db250YWluZXIuYXBwZW5kQ2hpbGQobWVudUl0ZW1MYWJlbClcblx0XHRjb25zdCBkZXNjcmlwdGlvbkRpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5cdFx0ZGVzY3JpcHRpb25EaXYuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtaXRlbS1kZXNjcmlwdGlvbicpXG5cdFx0ZGVzY3JpcHRpb25EaXYuY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1wcm9maWxlLW1lbnUtaXRlbS1kZXNjcmlwdGlvbi1jaGVja2JveCcpXG5cdFx0ZGVzY3JpcHRpb25EaXYuaW5uZXJIVE1MID0gbWFya2VkKGxhYmVsRGVzY3JpcHRpb24pXG5cdFx0bWVudUl0ZW1Db250YWluZXIuYXBwZW5kQ2hpbGQoZGVzY3JpcHRpb25EaXYpXG5cdFx0cmV0dXJuIG1lbnVJdGVtQ29udGFpbmVyXG5cdH1cblxuXHRpc1Zpc2libGUgKCkge1xuXHRcdGNvbnN0IHN0eWxlID0gd2luZG93LmdldENvbXB1dGVkU3R5bGUodGhpcywgbnVsbClcblx0XHRyZXR1cm4gKHN0eWxlLnZpc2liaWxpdHkgPT09ICd2aXNpYmxlJylcblx0fVxuXG5cdGhpZGVQcm9maWxlTWVudSAoKSB7XG5cdFx0dGhpcy5zdHlsZS52aXNpYmlsaXR5ID0gJ2hpZGRlbidcblx0XHRjb25zdCBlID0gdGhpcy5tb2RlbC5nZXRYVGVybWluYWxNb2RlbEVsZW1lbnQoKVxuXHRcdGUuc2hvd1Rlcm1pbmFsKClcblx0XHRlLmZvY3VzT25UZXJtaW5hbCgpXG5cdH1cblxuXHRzaG93UHJvZmlsZU1lbnUgKCkge1xuXHRcdHRoaXMubW9kZWwuZ2V0WFRlcm1pbmFsTW9kZWxFbGVtZW50KCkuaGlkZVRlcm1pbmFsKClcblx0XHR0aGlzLnN0eWxlLnZpc2liaWxpdHkgPSAndmlzaWJsZSdcblx0fVxuXG5cdHRvZ2dsZVByb2ZpbGVNZW51ICgpIHtcblx0XHRpZiAoIXRoaXMuaXNWaXNpYmxlKCkpIHtcblx0XHRcdHRoaXMuc2hvd1Byb2ZpbGVNZW51KClcblx0XHR9IGVsc2Uge1xuXHRcdFx0dGhpcy5oaWRlUHJvZmlsZU1lbnUoKVxuXHRcdH1cblx0fVxuXG5cdGdldE5ld1Byb2ZpbGVBbmRDaGFuZ2VzICgpIHtcblx0XHRjb25zdCBuZXdQcm9maWxlID0gdGhpcy5nZXRQcm9maWxlTWVudVNldHRpbmdzKClcblx0XHRjb25zdCBwcm9maWxlQ2hhbmdlcyA9IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZGlmZlByb2ZpbGVzKFxuXHRcdFx0dGhpcy5tb2RlbC5nZXRYVGVybWluYWxNb2RlbCgpLmdldFByb2ZpbGUoKSxcblx0XHRcdG5ld1Byb2ZpbGUsXG5cdFx0KVxuXHRcdHJldHVybiB7XG5cdFx0XHRuZXdQcm9maWxlOiBuZXdQcm9maWxlLFxuXHRcdFx0cHJvZmlsZUNoYW5nZXM6IHByb2ZpbGVDaGFuZ2VzLFxuXHRcdH1cblx0fVxuXG5cdGxvYWRQcm9maWxlICgpIHtcblx0XHRjb25zdCBuZXdQcm9maWxlQW5kQ2hhbmdlcyA9IHRoaXMuZ2V0TmV3UHJvZmlsZUFuZENoYW5nZXMoKVxuXHRcdHRoaXMuYXBwbHlQcm9maWxlQ2hhbmdlcyhuZXdQcm9maWxlQW5kQ2hhbmdlcy5wcm9maWxlQ2hhbmdlcylcblx0fVxuXG5cdHNhdmVQcm9maWxlICgpIHtcblx0XHQvLyBHZXQgdGhlIGN1cnJlbnQgcHJvZmlsZSBzZXR0aW5ncyBiZWZvcmUgZW50ZXJpbmcgdGhlIHByb21pc2UuXG5cdFx0Y29uc3QgbmV3UHJvZmlsZUFuZENoYW5nZXMgPSB0aGlzLmdldE5ld1Byb2ZpbGVBbmRDaGFuZ2VzKClcblx0XHR0aGlzLnByb21wdEZvck5ld1Byb2ZpbGVOYW1lKFxuXHRcdFx0bmV3UHJvZmlsZUFuZENoYW5nZXMubmV3UHJvZmlsZSxcblx0XHRcdG5ld1Byb2ZpbGVBbmRDaGFuZ2VzLnByb2ZpbGVDaGFuZ2VzLFxuXHRcdClcblx0fVxuXG5cdGRlbGV0ZVByb2ZpbGUgKCkge1xuXHRcdGNvbnN0IGUgPSB0aGlzLm1haW5EaXYucXVlcnlTZWxlY3RvcignI3Byb2ZpbGVzLWRyb3Bkb3duJylcblx0XHRjb25zdCBwcm9maWxlTmFtZSA9IGUub3B0aW9uc1tlLnNlbGVjdGVkSW5kZXhdLnRleHRcblx0XHRpZiAoIXByb2ZpbGVOYW1lKSB7XG5cdFx0XHRhdG9tLm5vdGlmaWNhdGlvbnMuYWRkV2FybmluZygnUHJvZmlsZSBtdXN0IGJlIHNlbGVjdGVkIGluIG9yZGVyIHRvIGRlbGV0ZSBpdC4nKVxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXHRcdHRoaXMucHJvbXB0RGVsZXRlKHByb2ZpbGVOYW1lKVxuXHR9XG5cblx0YXN5bmMgcHJvbXB0RGVsZXRlIChuZXdQcm9maWxlKSB7XG5cdFx0dGhpcy5kZWxldGVQcm9maWxlTW9kZWwucHJvbXB0RGVsZXRlKG5ld1Byb2ZpbGUpXG5cdH1cblxuXHRhc3luYyBwcm9tcHRGb3JOZXdQcm9maWxlTmFtZSAobmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpIHtcblx0XHR0aGlzLnNhdmVQcm9maWxlTW9kZWwucHJvbXB0Rm9yTmV3UHJvZmlsZU5hbWUobmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpXG5cdH1cblxuXHRzZXROZXdNZW51U2V0dGluZ3MgKHByb2ZpbGUsIGNsZWFyID0gZmFsc2UpIHtcblx0XHRmb3IgKGNvbnN0IGRhdGEgb2YgQ09ORklHX0RBVEEpIHtcblx0XHRcdGlmICghZGF0YS5wcm9maWxlS2V5KSBjb250aW51ZVxuXG5cdFx0XHRpZiAoZGF0YS5lbnVtKSB7XG5cdFx0XHRcdGNvbnN0IHNlbGVjdG9yID0gYCMke2RhdGEucHJvZmlsZUtleS50b0xvd2VyQ2FzZSgpfS1zZWxlY3Qgc2VsZWN0YFxuXHRcdFx0XHRjb25zdCBpbnB1dCA9IHRoaXMucXVlcnlTZWxlY3RvcihzZWxlY3Rvcilcblx0XHRcdFx0aW5wdXQudmFsdWUgPSBkYXRhLnRvTWVudVNldHRpbmcocHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldKVxuXHRcdFx0fSBlbHNlIGlmIChkYXRhLnR5cGUgPT09ICdjb2xvcicpIHtcblx0XHRcdFx0Y29uc3Qgc2VsZWN0b3IgPSBgIyR7ZGF0YS5wcm9maWxlS2V5LnRvTG93ZXJDYXNlKCl9LWNvbG9yIGlucHV0YFxuXHRcdFx0XHRjb25zdCBpbnB1dCA9IHRoaXMucXVlcnlTZWxlY3RvcihzZWxlY3Rvcilcblx0XHRcdFx0aW5wdXQudmFsdWUgPSBkYXRhLnRvTWVudVNldHRpbmcocHJvZmlsZVtkYXRhLnByb2ZpbGVLZXldKVxuXHRcdFx0fSBlbHNlIGlmIChkYXRhLnR5cGUgPT09ICdib29sZWFuJykge1xuXHRcdFx0XHRjb25zdCBzZWxlY3RvciA9IGAjJHtkYXRhLnByb2ZpbGVLZXkudG9Mb3dlckNhc2UoKX0tY2hlY2tib3ggaW5wdXRgXG5cdFx0XHRcdGNvbnN0IGNoZWNrYm94ID0gdGhpcy5xdWVyeVNlbGVjdG9yKHNlbGVjdG9yKVxuXHRcdFx0XHRjaGVja2JveC5jaGVja2VkID0gZGF0YS50b01lbnVTZXR0aW5nKHByb2ZpbGVbZGF0YS5wcm9maWxlS2V5XSlcblx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdGNvbnN0IHNlbGVjdG9yID0gYCMke2RhdGEucHJvZmlsZUtleS50b0xvd2VyQ2FzZSgpfS10ZXh0Ym94ID4gYXRvbS10ZXh0LWVkaXRvcmBcblx0XHRcdFx0Y29uc3QgbW9kZWwgPSB0aGlzLnF1ZXJ5U2VsZWN0b3Ioc2VsZWN0b3IpLmdldE1vZGVsKClcblx0XHRcdFx0aWYgKCFjbGVhcikge1xuXHRcdFx0XHRcdG1vZGVsLnNldFRleHQoZGF0YS50b01lbnVTZXR0aW5nKHByb2ZpbGVbZGF0YS5wcm9maWxlS2V5XSkpXG5cdFx0XHRcdH0gZWxzZSB7XG5cdFx0XHRcdFx0bW9kZWwuc2V0VGV4dCgnJylcblx0XHRcdFx0fVxuXHRcdFx0fVxuXHRcdH1cblx0fVxufVxuXG5jb25zdCBYVGVybWluYWxQcm9maWxlTWVudUVsZW1lbnQgPSBkb2N1bWVudC5yZWdpc3RlckVsZW1lbnQoJ3gtdGVybWluYWwtcHJvZmlsZScsIHtcblx0cHJvdG90eXBlOiBYVGVybWluYWxQcm9maWxlTWVudUVsZW1lbnRJbXBsLnByb3RvdHlwZSxcbn0pXG5cbmV4cG9ydCB7XG5cdFhUZXJtaW5hbFByb2ZpbGVNZW51RWxlbWVudCxcbn1cbiJdfQ==