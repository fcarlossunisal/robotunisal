Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _utils = require('./utils');

var XTerminalDeleteProfileElementImpl = (function (_HTMLElement) {
	_inherits(XTerminalDeleteProfileElementImpl, _HTMLElement);

	function XTerminalDeleteProfileElementImpl() {
		_classCallCheck(this, XTerminalDeleteProfileElementImpl);

		_get(Object.getPrototypeOf(XTerminalDeleteProfileElementImpl.prototype), 'constructor', this).apply(this, arguments);
	}

	_createClass(XTerminalDeleteProfileElementImpl, [{
		key: 'initialize',
		value: function initialize(model) {
			this.model = model;
			this.model.setElement(this);
			this.messageDiv = document.createElement('div');
			this.messageDiv.classList.add('x-terminal-modal-message');
			this.appendChild(this.messageDiv);
			this.appendChild((0, _utils.createHorizontalLine)());
			this.promptButtonsDiv = document.createElement('div');
			this.promptButtonsDiv.classList.add('x-terminal-modal-buttons-div');
			this.appendChild(this.promptButtonsDiv);
		}
	}, {
		key: 'setNewPrompt',
		value: function setNewPrompt(profileName, confirmHandler, cancelHandler) {
			(0, _utils.clearDiv)(this.messageDiv);
			(0, _utils.clearDiv)(this.promptButtonsDiv);
			var text = 'Delete existing profile \'' + profileName + '\'?';
			this.messageDiv.appendChild(document.createTextNode(text));
			var confirmButton = document.createElement('button');
			confirmButton.classList.add('x-terminal-modal-button');
			confirmButton.classList.add('btn-primary');
			confirmButton.classList.add('btn-error');
			confirmButton.appendChild(document.createTextNode('Confirm'));
			confirmButton.addEventListener('click', confirmHandler, { passive: true });
			this.promptButtonsDiv.appendChild(confirmButton);
			var cancelButton = document.createElement('button');
			cancelButton.classList.add('x-terminal-modal-button');
			cancelButton.classList.add('btn-primary');
			cancelButton.appendChild(document.createTextNode('Cancel'));
			cancelButton.addEventListener('click', cancelHandler, { passive: true });
			this.promptButtonsDiv.appendChild(cancelButton);
		}
	}]);

	return XTerminalDeleteProfileElementImpl;
})(HTMLElement);

var XTerminalDeleteProfileElement = document.registerElement('x-terminal-delete-profile', {
	prototype: XTerminalDeleteProfileElementImpl.prototype
});

exports.XTerminalDeleteProfileElement = XTerminalDeleteProfileElement;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL2RlbGV0ZS1wcm9maWxlLWVsZW1lbnQuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQXFCK0MsU0FBUzs7SUFFbEQsaUNBQWlDO1dBQWpDLGlDQUFpQzs7VUFBakMsaUNBQWlDO3dCQUFqQyxpQ0FBaUM7OzZCQUFqQyxpQ0FBaUM7OztjQUFqQyxpQ0FBaUM7O1NBQzNCLG9CQUFDLEtBQUssRUFBRTtBQUNsQixPQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQTtBQUNsQixPQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUMzQixPQUFJLENBQUMsVUFBVSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDL0MsT0FBSSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDBCQUEwQixDQUFDLENBQUE7QUFDekQsT0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUE7QUFDakMsT0FBSSxDQUFDLFdBQVcsQ0FBQyxrQ0FBc0IsQ0FBQyxDQUFBO0FBQ3hDLE9BQUksQ0FBQyxnQkFBZ0IsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3JELE9BQUksQ0FBQyxnQkFBZ0IsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLDhCQUE4QixDQUFDLENBQUE7QUFDbkUsT0FBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtHQUN2Qzs7O1NBRVksc0JBQUMsV0FBVyxFQUFFLGNBQWMsRUFBRSxhQUFhLEVBQUU7QUFDekQsd0JBQVMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQ3pCLHdCQUFTLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQy9CLE9BQU0sSUFBSSxHQUFHLDRCQUE0QixHQUFHLFdBQVcsR0FBRyxLQUFLLENBQUE7QUFDL0QsT0FBSSxDQUFDLFVBQVUsQ0FBQyxXQUFXLENBQUMsUUFBUSxDQUFDLGNBQWMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFBO0FBQzFELE9BQU0sYUFBYSxHQUFHLFFBQVEsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDdEQsZ0JBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUE7QUFDdEQsZ0JBQWEsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFBO0FBQzFDLGdCQUFhLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxXQUFXLENBQUMsQ0FBQTtBQUN4QyxnQkFBYSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUE7QUFDN0QsZ0JBQWEsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLEVBQUUsY0FBYyxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7QUFDMUUsT0FBSSxDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsQ0FBQTtBQUNoRCxPQUFNLFlBQVksR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ3JELGVBQVksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLHlCQUF5QixDQUFDLENBQUE7QUFDckQsZUFBWSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsYUFBYSxDQUFDLENBQUE7QUFDekMsZUFBWSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUE7QUFDM0QsZUFBWSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxhQUFhLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUN4RSxPQUFJLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLFlBQVksQ0FBQyxDQUFBO0dBQy9DOzs7UUEvQkksaUNBQWlDO0dBQVMsV0FBVzs7QUFrQzNELElBQU0sNkJBQTZCLEdBQUcsUUFBUSxDQUFDLGVBQWUsQ0FBQywyQkFBMkIsRUFBRTtBQUMzRixVQUFTLEVBQUUsaUNBQWlDLENBQUMsU0FBUztDQUN0RCxDQUFDLENBQUE7O1FBR0QsNkJBQTZCLEdBQTdCLDZCQUE2QiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy94LXRlcm1pbmFsL3NyYy9kZWxldGUtcHJvZmlsZS1lbGVtZW50LmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqIEBiYWJlbCAqL1xuLypcbiAqIENvcHlyaWdodCAyMDE3IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgMjAxNy0yMDE4IEFuZHJlcyBNZWppYSA8YW1lamlhMDA0QGdtYWlsLmNvbT4uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgVXppVGVjaCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIGJ1cy1zdG9wIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzXG4gKiBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGUgXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmVcbiAqIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSxcbiAqIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG9cbiAqIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzby5cbiAqXG4gKiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SIElNUExJRUQsXG4gKiBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQVxuICogUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVFxuICogSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OXG4gKiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEVcbiAqIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuICovXG5cbmltcG9ydCB7IGNsZWFyRGl2LCBjcmVhdGVIb3Jpem9udGFsTGluZSB9IGZyb20gJy4vdXRpbHMnXG5cbmNsYXNzIFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVFbGVtZW50SW1wbCBleHRlbmRzIEhUTUxFbGVtZW50IHtcblx0aW5pdGlhbGl6ZSAobW9kZWwpIHtcblx0XHR0aGlzLm1vZGVsID0gbW9kZWxcblx0XHR0aGlzLm1vZGVsLnNldEVsZW1lbnQodGhpcylcblx0XHR0aGlzLm1lc3NhZ2VEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdHRoaXMubWVzc2FnZURpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLW1vZGFsLW1lc3NhZ2UnKVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQodGhpcy5tZXNzYWdlRGl2KVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQoY3JlYXRlSG9yaXpvbnRhbExpbmUoKSlcblx0XHR0aGlzLnByb21wdEJ1dHRvbnNEaXYgPSBkb2N1bWVudC5jcmVhdGVFbGVtZW50KCdkaXYnKVxuXHRcdHRoaXMucHJvbXB0QnV0dG9uc0Rpdi5jbGFzc0xpc3QuYWRkKCd4LXRlcm1pbmFsLW1vZGFsLWJ1dHRvbnMtZGl2Jylcblx0XHR0aGlzLmFwcGVuZENoaWxkKHRoaXMucHJvbXB0QnV0dG9uc0Rpdilcblx0fVxuXG5cdHNldE5ld1Byb21wdCAocHJvZmlsZU5hbWUsIGNvbmZpcm1IYW5kbGVyLCBjYW5jZWxIYW5kbGVyKSB7XG5cdFx0Y2xlYXJEaXYodGhpcy5tZXNzYWdlRGl2KVxuXHRcdGNsZWFyRGl2KHRoaXMucHJvbXB0QnV0dG9uc0Rpdilcblx0XHRjb25zdCB0ZXh0ID0gJ0RlbGV0ZSBleGlzdGluZyBwcm9maWxlIFxcJycgKyBwcm9maWxlTmFtZSArICdcXCc/J1xuXHRcdHRoaXMubWVzc2FnZURpdi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSh0ZXh0KSlcblx0XHRjb25zdCBjb25maXJtQnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJylcblx0XHRjb25maXJtQnV0dG9uLmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtbW9kYWwtYnV0dG9uJylcblx0XHRjb25maXJtQnV0dG9uLmNsYXNzTGlzdC5hZGQoJ2J0bi1wcmltYXJ5Jylcblx0XHRjb25maXJtQnV0dG9uLmNsYXNzTGlzdC5hZGQoJ2J0bi1lcnJvcicpXG5cdFx0Y29uZmlybUJ1dHRvbi5hcHBlbmRDaGlsZChkb2N1bWVudC5jcmVhdGVUZXh0Tm9kZSgnQ29uZmlybScpKVxuXHRcdGNvbmZpcm1CdXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBjb25maXJtSGFuZGxlciwgeyBwYXNzaXZlOiB0cnVlIH0pXG5cdFx0dGhpcy5wcm9tcHRCdXR0b25zRGl2LmFwcGVuZENoaWxkKGNvbmZpcm1CdXR0b24pXG5cdFx0Y29uc3QgY2FuY2VsQnV0dG9uID0gZG9jdW1lbnQuY3JlYXRlRWxlbWVudCgnYnV0dG9uJylcblx0XHRjYW5jZWxCdXR0b24uY2xhc3NMaXN0LmFkZCgneC10ZXJtaW5hbC1tb2RhbC1idXR0b24nKVxuXHRcdGNhbmNlbEJ1dHRvbi5jbGFzc0xpc3QuYWRkKCdidG4tcHJpbWFyeScpXG5cdFx0Y2FuY2VsQnV0dG9uLmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdDYW5jZWwnKSlcblx0XHRjYW5jZWxCdXR0b24uYWRkRXZlbnRMaXN0ZW5lcignY2xpY2snLCBjYW5jZWxIYW5kbGVyLCB7IHBhc3NpdmU6IHRydWUgfSlcblx0XHR0aGlzLnByb21wdEJ1dHRvbnNEaXYuYXBwZW5kQ2hpbGQoY2FuY2VsQnV0dG9uKVxuXHR9XG59XG5cbmNvbnN0IFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVFbGVtZW50ID0gZG9jdW1lbnQucmVnaXN0ZXJFbGVtZW50KCd4LXRlcm1pbmFsLWRlbGV0ZS1wcm9maWxlJywge1xuXHRwcm90b3R5cGU6IFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVFbGVtZW50SW1wbC5wcm90b3R5cGUsXG59KVxuXG5leHBvcnQge1xuXHRYVGVybWluYWxEZWxldGVQcm9maWxlRWxlbWVudCxcbn1cbiJdfQ==