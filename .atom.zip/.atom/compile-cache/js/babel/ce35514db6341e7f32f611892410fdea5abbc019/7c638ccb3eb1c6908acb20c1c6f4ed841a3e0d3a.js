Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var XTerminalProfileMenuModel = (function () {
	function XTerminalProfileMenuModel(atomXtermModel) {
		_classCallCheck(this, XTerminalProfileMenuModel);

		this.atomXtermModel = atomXtermModel;
		this.element = null;
	}

	_createClass(XTerminalProfileMenuModel, [{
		key: 'destroy',
		value: function destroy() {
			if (this.element) {
				this.element.destroy();
			}
		}
	}, {
		key: 'getTitle',
		value: function getTitle() {
			return 'X Terminal Profile Menu';
		}
	}, {
		key: 'getElement',
		value: function getElement() {
			return this.element;
		}
	}, {
		key: 'setElement',
		value: function setElement(element) {
			this.element = element;
		}
	}, {
		key: 'getXTerminalModelElement',
		value: function getXTerminalModelElement() {
			return this.atomXtermModel.getElement();
		}
	}, {
		key: 'getXTerminalModel',
		value: function getXTerminalModel() {
			return this.atomXtermModel;
		}
	}]);

	return XTerminalProfileMenuModel;
})();

exports.XTerminalProfileMenuModel = XTerminalProfileMenuModel;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3Byb2ZpbGUtbWVudS1tb2RlbC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQXFCTSx5QkFBeUI7QUFDbEIsVUFEUCx5QkFBeUIsQ0FDakIsY0FBYyxFQUFFO3dCQUR4Qix5QkFBeUI7O0FBRTdCLE1BQUksQ0FBQyxjQUFjLEdBQUcsY0FBYyxDQUFBO0FBQ3BDLE1BQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFBO0VBQ25COztjQUpJLHlCQUF5Qjs7U0FNdEIsbUJBQUc7QUFDVixPQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDakIsUUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUN0QjtHQUNEOzs7U0FFUSxvQkFBRztBQUNYLFVBQU8seUJBQXlCLENBQUE7R0FDaEM7OztTQUVVLHNCQUFHO0FBQ2IsVUFBTyxJQUFJLENBQUMsT0FBTyxDQUFBO0dBQ25COzs7U0FFVSxvQkFBQyxPQUFPLEVBQUU7QUFDcEIsT0FBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUE7R0FDdEI7OztTQUV3QixvQ0FBRztBQUMzQixVQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsVUFBVSxFQUFFLENBQUE7R0FDdkM7OztTQUVpQiw2QkFBRztBQUNwQixVQUFPLElBQUksQ0FBQyxjQUFjLENBQUE7R0FDMUI7OztRQTlCSSx5QkFBeUI7OztRQWtDOUIseUJBQXlCLEdBQXpCLHlCQUF5QiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy94LXRlcm1pbmFsL3NyYy9wcm9maWxlLW1lbnUtbW9kZWwuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiogQGJhYmVsICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTcgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAyMDE3LTIwMTggQW5kcmVzIE1lamlhIDxhbWVqaWEwMDRAZ21haWwuY29tPi4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBVemlUZWNoIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgYnVzLXN0b3AgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mIHRoaXNcbiAqIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZVxuICogd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LFxuICogbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0b1xuICogcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLlxuICpcbiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1MgT1IgSU1QTElFRCxcbiAqIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBXG4gKiBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUXG4gKiBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT05cbiAqIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRVxuICogU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4gKi9cblxuY2xhc3MgWFRlcm1pbmFsUHJvZmlsZU1lbnVNb2RlbCB7XG5cdGNvbnN0cnVjdG9yIChhdG9tWHRlcm1Nb2RlbCkge1xuXHRcdHRoaXMuYXRvbVh0ZXJtTW9kZWwgPSBhdG9tWHRlcm1Nb2RlbFxuXHRcdHRoaXMuZWxlbWVudCA9IG51bGxcblx0fVxuXG5cdGRlc3Ryb3kgKCkge1xuXHRcdGlmICh0aGlzLmVsZW1lbnQpIHtcblx0XHRcdHRoaXMuZWxlbWVudC5kZXN0cm95KClcblx0XHR9XG5cdH1cblxuXHRnZXRUaXRsZSAoKSB7XG5cdFx0cmV0dXJuICdYIFRlcm1pbmFsIFByb2ZpbGUgTWVudSdcblx0fVxuXG5cdGdldEVsZW1lbnQgKCkge1xuXHRcdHJldHVybiB0aGlzLmVsZW1lbnRcblx0fVxuXG5cdHNldEVsZW1lbnQgKGVsZW1lbnQpIHtcblx0XHR0aGlzLmVsZW1lbnQgPSBlbGVtZW50XG5cdH1cblxuXHRnZXRYVGVybWluYWxNb2RlbEVsZW1lbnQgKCkge1xuXHRcdHJldHVybiB0aGlzLmF0b21YdGVybU1vZGVsLmdldEVsZW1lbnQoKVxuXHR9XG5cblx0Z2V0WFRlcm1pbmFsTW9kZWwgKCkge1xuXHRcdHJldHVybiB0aGlzLmF0b21YdGVybU1vZGVsXG5cdH1cbn1cblxuZXhwb3J0IHtcblx0WFRlcm1pbmFsUHJvZmlsZU1lbnVNb2RlbCxcbn1cbiJdfQ==