Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _atom = require('atom');

var _common = require('./common');

var _common2 = _interopRequireDefault(_common);

'use babel';

function findImportAtPosition(line, column) {
  var cells = _common2['default'].splitCells(line);
  if (cells.length >= 2 && cells[0].toLowerCase() === 'library') {
    var _name = cells[1];
    var startCol = line.indexOf(_name);
    var endCol = startCol + _name.length;
    if (column > startCol && column < endCol) {
      return {
        startCol: startCol,
        endCol: endCol,
        name: _name
      };
    }
  }
  return undefined;
}

exports['default'] = {
  getKeywordSuggestions: function getKeywordSuggestions(textEditor, point, autocompleteRobotProvider) {
    var line = textEditor.lineTextForBufferRow(point.row);
    var importInfo = findImportAtPosition(line, point.column);
    if (importInfo === undefined) {
      return undefined;
    }

    var resource = autocompleteRobotProvider.getResourceByKey(importInfo.name.toLowerCase());
    if (!resource) {
      return undefined;
    }

    // build hyperclick callback
    var callback = function callback() {
      atom.workspace.open(resource.libraryPath || resource.path, { initialLine: 0, initialColumn: 0 }).then(function (editor) {
        return editor.scrollToCursorPosition({ center: true });
      })['catch'](function (error) {
        return console.log('Error opening editor: ' + error);
      });
    };

    return {
      range: new _atom.Range(new _atom.Point(point.row, importInfo.startCol), new _atom.Point(point.row, importInfo.endCol)),
      callback: callback
    };
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2h5cGVyY2xpY2stcm9ib3QtZnJhbWV3b3JrL2xpYi9oeXBlcmNsaWNrLWxpYnJhcnktaW1wb3J0cy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7b0JBQzZCLE1BQU07O3NCQUNoQixVQUFVOzs7O0FBRjdCLFdBQVcsQ0FBQTs7QUFJWCxTQUFTLG9CQUFvQixDQUFDLElBQUksRUFBRSxNQUFNLEVBQUM7QUFDekMsTUFBTSxLQUFLLEdBQUcsb0JBQU8sVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ3RDLE1BQUcsS0FBSyxDQUFDLE1BQU0sSUFBRSxDQUFDLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsRUFBRSxLQUFHLFNBQVMsRUFBQztBQUN2RCxRQUFNLEtBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDckIsUUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxLQUFJLENBQUMsQ0FBQztBQUNwQyxRQUFNLE1BQU0sR0FBRyxRQUFRLEdBQUMsS0FBSSxDQUFDLE1BQU0sQ0FBQztBQUNwQyxRQUFJLEFBQUMsTUFBTSxHQUFDLFFBQVEsSUFBTSxNQUFNLEdBQUMsTUFBTSxBQUFDLEVBQUU7QUFDeEMsYUFBTztBQUNMLGdCQUFRLEVBQVIsUUFBUTtBQUNSLGNBQU0sRUFBTixNQUFNO0FBQ04sWUFBSSxFQUFKLEtBQUk7T0FDTCxDQUFDO0tBQ0g7R0FDRjtBQUNELFNBQU8sU0FBUyxDQUFBO0NBQ2pCOztxQkFFYztBQUNiLHVCQUFxQixFQUFBLCtCQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUseUJBQXlCLEVBQUM7QUFDakUsUUFBTSxJQUFJLEdBQUcsVUFBVSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4RCxRQUFNLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQzNELFFBQUcsVUFBVSxLQUFHLFNBQVMsRUFBQztBQUN4QixhQUFPLFNBQVMsQ0FBQTtLQUNqQjs7QUFHRCxRQUFNLFFBQVEsR0FBRyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUE7QUFDMUYsUUFBRyxDQUFDLFFBQVEsRUFBQztBQUNYLGFBQU8sU0FBUyxDQUFDO0tBQ2xCOzs7QUFHRCxRQUFNLFFBQVEsR0FBRyxTQUFYLFFBQVEsR0FBUztBQUNyQixVQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsV0FBVyxJQUFJLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLGFBQWEsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUM3RixJQUFJLENBQUMsVUFBQSxNQUFNO2VBQUksTUFBTSxDQUFDLHNCQUFzQixDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDO09BQUEsQ0FBQyxTQUN4RCxDQUFDLFVBQUEsS0FBSztlQUFJLE9BQU8sQ0FBQyxHQUFHLDRCQUEwQixLQUFLLENBQUc7T0FBQSxDQUFDLENBQUE7S0FDL0QsQ0FBQTs7QUFFRCxXQUFPO0FBQ0wsV0FBSyxFQUFFLGdCQUFVLGdCQUFVLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLFFBQVEsQ0FBQyxFQUFFLGdCQUFVLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBVSxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3BHLGNBQVEsRUFBUixRQUFRO0tBQ1QsQ0FBQztHQUNIO0NBQ0YiLCJmaWxlIjoiZmlsZTovLy9DOi9Vc2Vycy9GcmFuY2lzY28vLmF0b20vcGFja2FnZXMvaHlwZXJjbGljay1yb2JvdC1mcmFtZXdvcmsvbGliL2h5cGVyY2xpY2stbGlicmFyeS1pbXBvcnRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCdcbmltcG9ydCB7IFBvaW50LCBSYW5nZSB9IGZyb20gJ2F0b20nXG5pbXBvcnQgY29tbW9uIGZyb20gJy4vY29tbW9uJ1xuXG5mdW5jdGlvbiBmaW5kSW1wb3J0QXRQb3NpdGlvbihsaW5lLCBjb2x1bW4pe1xuICBjb25zdCBjZWxscyA9IGNvbW1vbi5zcGxpdENlbGxzKGxpbmUpO1xuICBpZihjZWxscy5sZW5ndGg+PTIgJiYgY2VsbHNbMF0udG9Mb3dlckNhc2UoKT09PSdsaWJyYXJ5Jyl7XG4gICAgY29uc3QgbmFtZSA9IGNlbGxzWzFdXG4gICAgY29uc3Qgc3RhcnRDb2wgPSBsaW5lLmluZGV4T2YobmFtZSk7XG4gICAgY29uc3QgZW5kQ29sID0gc3RhcnRDb2wrbmFtZS5sZW5ndGg7XG4gICAgaWYgKChjb2x1bW4+c3RhcnRDb2wpICYmIChjb2x1bW48ZW5kQ29sKSkge1xuICAgICAgcmV0dXJuIHtcbiAgICAgICAgc3RhcnRDb2wsXG4gICAgICAgIGVuZENvbCxcbiAgICAgICAgbmFtZSxcbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB1bmRlZmluZWRcbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICBnZXRLZXl3b3JkU3VnZ2VzdGlvbnModGV4dEVkaXRvciwgcG9pbnQsIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIpe1xuICAgIGNvbnN0IGxpbmUgPSB0ZXh0RWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KHBvaW50LnJvdyk7XG4gICAgY29uc3QgaW1wb3J0SW5mbyA9IGZpbmRJbXBvcnRBdFBvc2l0aW9uKGxpbmUsIHBvaW50LmNvbHVtbilcbiAgICBpZihpbXBvcnRJbmZvPT09dW5kZWZpbmVkKXtcbiAgICAgIHJldHVybiB1bmRlZmluZWRcbiAgICB9XG5cblxuICAgIGNvbnN0IHJlc291cmNlID0gYXV0b2NvbXBsZXRlUm9ib3RQcm92aWRlci5nZXRSZXNvdXJjZUJ5S2V5KGltcG9ydEluZm8ubmFtZS50b0xvd2VyQ2FzZSgpKVxuICAgIGlmKCFyZXNvdXJjZSl7XG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xuICAgIH1cblxuICAgIC8vIGJ1aWxkIGh5cGVyY2xpY2sgY2FsbGJhY2tcbiAgICBjb25zdCBjYWxsYmFjayA9ICgpID0+IHtcbiAgICAgIGF0b20ud29ya3NwYWNlLm9wZW4ocmVzb3VyY2UubGlicmFyeVBhdGggfHwgcmVzb3VyY2UucGF0aCwge2luaXRpYWxMaW5lOiAwLCBpbml0aWFsQ29sdW1uOiAwfSlcbiAgICAgIC50aGVuKGVkaXRvciA9PiBlZGl0b3Iuc2Nyb2xsVG9DdXJzb3JQb3NpdGlvbih7Y2VudGVyOiB0cnVlfSkpXG4gICAgICAuY2F0Y2goZXJyb3IgPT4gY29uc29sZS5sb2coYEVycm9yIG9wZW5pbmcgZWRpdG9yOiAke2Vycm9yfWApKVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICByYW5nZTogbmV3IFJhbmdlKG5ldyBQb2ludChwb2ludC5yb3csIGltcG9ydEluZm8uc3RhcnRDb2wpLCBuZXcgUG9pbnQocG9pbnQucm93LCBpbXBvcnRJbmZvLmVuZENvbCkpLFxuICAgICAgY2FsbGJhY2tcbiAgICB9O1xuICB9XG59XG4iXX0=