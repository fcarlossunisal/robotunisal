Object.defineProperty(exports, '__esModule', {
	value: true
});

var _extends = Object.assign || function (target) { for (var i = 1; i < arguments.length; i++) { var source = arguments[i]; for (var key in source) { if (Object.prototype.hasOwnProperty.call(source, key)) { target[key] = source[key]; } } } return target; };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _atom = require('atom');

var _utils = require('./utils');

var _profiles = require('./profiles');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _os = require('os');

var _os2 = _interopRequireDefault(_os);

var _whatwgUrl = require('whatwg-url');

var DEFAULT_TITLE = 'X Terminal';

/**
 * The main terminal model, or rather item, displayed in the Atom workspace.
 *
 * @class
 */

var XTerminalModel = (function () {
	// NOTE: Though the class is publically accessible, all methods except for the
	// ones defined at the very bottom of the class should be considered private
	// and subject to change at any time.

	function XTerminalModel(options) {
		var _this = this;

		_classCallCheck(this, XTerminalModel);

		this.options = options;
		this.uri = this.options.uri;
		var url = new _whatwgUrl.URL(this.uri);
		this.sessionId = url.host;
		this.uriCwd = url.searchParams.get('cwd');
		this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;
		this.profile = this.profilesSingleton.createProfileDataFromUri(this.uri);
		this.terminals_set = this.options.terminals_set;
		this.activeIndex = this.terminals_set.size;
		this.element = null;
		this.pane = null;
		this.title = DEFAULT_TITLE;
		if (this.profile.title !== null) {
			this.title = this.profile.title;
		}
		this.modified = false;
		this.emitter = new _atom.Emitter();
		this.terminals_set.add(this);

		// Determine appropriate initial working directory based on previous
		// active item. Since this involves async operations on the file
		// system, a Promise will be used to indicate when initialization is
		// done.
		this.isInitialized = false;
		this.initializedPromise = this.initialize().then(function () {
			_this.isInitialized = true;
		});
	}

	_createClass(XTerminalModel, [{
		key: 'initialize',
		value: _asyncToGenerator(function* () {
			var cwd = undefined;

			if (this.uriCwd) {
				cwd = this.uriCwd;
			} else if (this.profile.projectCwd) {
				var previousActiveItem = atom.workspace.getActivePaneItem();
				if (typeof previousActiveItem !== 'undefined' && typeof previousActiveItem.getPath === 'function') {
					cwd = previousActiveItem.getPath();
					var dir = atom.project.relativizePath(cwd)[0];
					if (dir) {
						this.profile.cwd = dir;
						return;
					}
				} else {
					cwd = atom.project.getPaths()[0];
				}
			} else {
				cwd = this.profile.cwd;
			}

			var baseProfile = this.profilesSingleton.getBaseProfile();
			if (!cwd) {
				this.profile.cwd = baseProfile.cwd;
				return;
			}
			var exists = yield _fsExtra2['default'].exists(cwd);
			if (!exists) {
				this.profile.cwd = baseProfile.cwd;
				return;
			}

			// Otherwise, if the path exists on the local file system, use the
			// path or parent directory as appropriate.
			var stats = yield _fsExtra2['default'].stat(cwd);
			if (stats.isDirectory()) {
				this.profile.cwd = cwd;
				return;
			}

			cwd = _path2['default'].dirname(cwd);
			var dirStats = yield _fsExtra2['default'].stat(cwd);
			if (dirStats.isDirectory) {
				this.profile.cwd = cwd;
				return;
			}

			this.profile.cwd = baseProfile.cwd;
		})
	}, {
		key: 'serialize',
		value: function serialize() {
			return {
				deserializer: 'XTerminalModel',
				version: '2017-09-17',
				uri: this.profilesSingleton.generateNewUrlFromProfileData(this.profile).href
			};
		}
	}, {
		key: 'destroy',
		value: function destroy() {
			if (this.element) {
				this.element.destroy();
			}
			this.terminals_set['delete'](this);
		}
	}, {
		key: 'getTitle',
		value: function getTitle() {
			return (this.isActiveTerminal() ? '* ' : '') + this.title;
			// return this.activeIndex + '|' + this.title
		}
	}, {
		key: 'getElement',
		value: function getElement() {
			return this.element;
		}
	}, {
		key: 'getURI',
		value: function getURI() {
			return this.uri;
		}
	}, {
		key: 'getLongTitle',
		value: function getLongTitle() {
			if (this.title === DEFAULT_TITLE) {
				return DEFAULT_TITLE;
			}
			return DEFAULT_TITLE + ' (' + this.title + ')';
		}
	}, {
		key: 'onDidChangeTitle',
		value: function onDidChangeTitle(callback) {
			return this.emitter.on('did-change-title', callback);
		}
	}, {
		key: 'getIconName',
		value: function getIconName() {
			return 'terminal';
		}
	}, {
		key: 'getPath',
		value: function getPath() {
			return this.profile.cwd;
		}
	}, {
		key: 'isModified',
		value: function isModified() {
			return this.modified;
		}
	}, {
		key: 'onDidChangeModified',
		value: function onDidChangeModified(callback) {
			return this.emitter.on('did-change-modified', callback);
		}
	}, {
		key: 'handleNewDataArrival',
		value: function handleNewDataArrival() {
			if (!this.pane) {
				this.pane = atom.workspace.paneForItem(this);
			}
			var oldIsModified = this.modified;
			var item = undefined;
			if (this.pane) {
				item = this.pane.getActiveItem();
			}
			if (item === this) {
				this.modified = false;
			} else {
				this.modified = true;
			}
			if (oldIsModified !== this.modified) {
				this.emitter.emit('did-change-modified', this.modified);
			}
		}
	}, {
		key: 'getSessionId',
		value: function getSessionId() {
			return this.sessionId;
		}
	}, {
		key: 'getSessionParameters',
		value: function getSessionParameters() {
			var url = this.profilesSingleton.generateNewUrlFromProfileData(this.profile);
			url.searchParams.sort();
			return url.searchParams.toString();
		}
	}, {
		key: 'refitTerminal',
		value: function refitTerminal() {
			// Only refit if there's a DOM element attached to the model.
			if (this.element) {
				this.element.refitTerminal();
			}
		}
	}, {
		key: 'focusOnTerminal',
		value: function focusOnTerminal(double) {
			this.element.focusOnTerminal(double);
			if (this.modified) {
				this.modified = false;
				this.emitter.emit('did-change-modified', this.modified);
			}
		}
	}, {
		key: 'exit',
		value: function exit() {
			this.pane.destroyItem(this, true);
		}
	}, {
		key: 'restartPtyProcess',
		value: function restartPtyProcess() {
			if (this.element) {
				this.element.restartPtyProcess();
			}
		}
	}, {
		key: 'copyFromTerminal',
		value: function copyFromTerminal() {
			return this.element.terminal.getSelection();
		}
	}, {
		key: 'runCommand',
		value: function runCommand(cmd) {
			this.pasteToTerminal(cmd + _os2['default'].EOL.charAt(0));
		}
	}, {
		key: 'pasteToTerminal',
		value: function pasteToTerminal(text) {
			this.element.ptyProcess.write(text);
		}
	}, {
		key: 'clear',
		value: function clear() {
			if (this.element) {
				return this.element.clear();
			}
		}
	}, {
		key: 'setActive',
		value: function setActive() {
			(0, _utils.recalculateActive)(this.terminals_set, this);
		}
	}, {
		key: 'isVisible',
		value: function isVisible() {
			return this.pane && this.pane.getActiveItem() === this && (!this.dock || this.dock.isVisible());
		}
	}, {
		key: 'isActiveTerminal',
		value: function isActiveTerminal() {
			return this.activeIndex === 0 && (atom.config.get('x-terminal.terminalSettings.allowHiddenToStayActive') || this.isVisible());
		}
	}, {
		key: 'setNewPane',
		value: function setNewPane(pane) {
			this.pane = pane;
			var location = this.pane.getContainer().getLocation();
			switch (location) {
				case 'left':
					this.dock = atom.workspace.getLeftDock();
					break;
				case 'right':
					this.dock = atom.workspace.getRightDock();
					break;
				case 'bottom':
					this.dock = atom.workspace.getBottomDock();
					break;
				default:
					this.dock = null;
			}
		}
	}, {
		key: 'toggleProfileMenu',
		value: function toggleProfileMenu() {
			this.element.toggleProfileMenu();
		}

		/* Public methods are defined below this line. */

		/**
   * Retrieve profile for this {@link XTerminalModel} instance.
   *
   * @function
   * @return {Object} Profile for {@link XTerminalModel} instance.
   */
	}, {
		key: 'getProfile',
		value: function getProfile() {
			return this.profile;
		}

		/**
   * Apply profile changes to {@link XTerminalModel} instance.
   *
   * @function
   * @param {Object} profileChanges Profile changes to apply.
   */
	}, {
		key: 'applyProfileChanges',
		value: function applyProfileChanges(profileChanges) {
			profileChanges = this.profilesSingleton.sanitizeData(profileChanges);
			this.profile = this.profilesSingleton.deepClone(_extends({}, this.profile, profileChanges));
			this.element.queueNewProfileChanges(profileChanges);
		}
	}]);

	return XTerminalModel;
})();

function isXTerminalModel(item) {
	return item instanceof XTerminalModel;
}

function currentItemIsXTerminalModel() {
	return isXTerminalModel(atom.workspace.getActivePaneItem());
}

exports.XTerminalModel = XTerminalModel;
exports.isXTerminalModel = isXTerminalModel;
exports.currentItemIsXTerminalModel = currentItemIsXTerminalModel;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL21vZGVsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CQXFCd0IsTUFBTTs7cUJBRUksU0FBUzs7d0JBQ0EsWUFBWTs7dUJBRXhDLFVBQVU7Ozs7b0JBQ1IsTUFBTTs7OztrQkFDUixJQUFJOzs7O3lCQUVDLFlBQVk7O0FBRWhDLElBQU0sYUFBYSxHQUFHLFlBQVksQ0FBQTs7Ozs7Ozs7SUFPNUIsY0FBYzs7Ozs7QUFJUCxVQUpQLGNBQWMsQ0FJTixPQUFPLEVBQUU7Ozt3QkFKakIsY0FBYzs7QUFLbEIsTUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUE7QUFDdEIsTUFBSSxDQUFDLEdBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQTtBQUMzQixNQUFNLEdBQUcsR0FBRyxtQkFBUSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDN0IsTUFBSSxDQUFDLFNBQVMsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFBO0FBQ3pCLE1BQUksQ0FBQyxNQUFNLEdBQUcsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDekMsTUFBSSxDQUFDLGlCQUFpQixHQUFHLHFDQUEyQixRQUFRLENBQUE7QUFDNUQsTUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsd0JBQXdCLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3hFLE1BQUksQ0FBQyxhQUFhLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUE7QUFDL0MsTUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQTtBQUMxQyxNQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNuQixNQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQTtBQUNoQixNQUFJLENBQUMsS0FBSyxHQUFHLGFBQWEsQ0FBQTtBQUMxQixNQUFJLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxLQUFLLElBQUksRUFBRTtBQUNoQyxPQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxDQUFBO0dBQy9CO0FBQ0QsTUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUE7QUFDckIsTUFBSSxDQUFDLE9BQU8sR0FBRyxtQkFBYSxDQUFBO0FBQzVCLE1BQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxDQUFBOzs7Ozs7QUFNNUIsTUFBSSxDQUFDLGFBQWEsR0FBRyxLQUFLLENBQUE7QUFDMUIsTUFBSSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUMsWUFBTTtBQUN0RCxTQUFLLGFBQWEsR0FBRyxJQUFJLENBQUE7R0FDekIsQ0FBQyxDQUFBO0VBQ0Y7O2NBaENJLGNBQWM7OzJCQWtDRixhQUFHO0FBQ25CLE9BQUksR0FBRyxZQUFBLENBQUE7O0FBRVAsT0FBSSxJQUFJLENBQUMsTUFBTSxFQUFFO0FBQ2hCLE9BQUcsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFBO0lBQ2pCLE1BQU0sSUFBSSxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsRUFBRTtBQUNuQyxRQUFNLGtCQUFrQixHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUM3RCxRQUFJLE9BQU8sa0JBQWtCLEtBQUssV0FBVyxJQUFJLE9BQU8sa0JBQWtCLENBQUMsT0FBTyxLQUFLLFVBQVUsRUFBRTtBQUNsRyxRQUFHLEdBQUcsa0JBQWtCLENBQUMsT0FBTyxFQUFFLENBQUE7QUFDbEMsU0FBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDL0MsU0FBSSxHQUFHLEVBQUU7QUFDUixVQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUE7QUFDdEIsYUFBTTtNQUNOO0tBQ0QsTUFBTTtBQUNOLFFBQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFBO0tBQ2hDO0lBQ0QsTUFBTTtBQUNOLE9BQUcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsQ0FBQTtJQUN0Qjs7QUFFRCxPQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxFQUFFLENBQUE7QUFDM0QsT0FBSSxDQUFDLEdBQUcsRUFBRTtBQUNULFFBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUE7QUFDbEMsV0FBTTtJQUNOO0FBQ0QsT0FBTSxNQUFNLEdBQUcsTUFBTSxxQkFBRyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDbkMsT0FBSSxDQUFDLE1BQU0sRUFBRTtBQUNaLFFBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUE7QUFDbEMsV0FBTTtJQUNOOzs7O0FBSUQsT0FBTSxLQUFLLEdBQUcsTUFBTSxxQkFBRyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDaEMsT0FBSSxLQUFLLENBQUMsV0FBVyxFQUFFLEVBQUU7QUFDeEIsUUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLEdBQUcsR0FBRyxDQUFBO0FBQ3RCLFdBQU07SUFDTjs7QUFFRCxNQUFHLEdBQUcsa0JBQUssT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ3ZCLE9BQU0sUUFBUSxHQUFHLE1BQU0scUJBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0FBQ25DLE9BQUksUUFBUSxDQUFDLFdBQVcsRUFBRTtBQUN6QixRQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUE7QUFDdEIsV0FBTTtJQUNOOztBQUVELE9BQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxHQUFHLFdBQVcsQ0FBQyxHQUFHLENBQUE7R0FDbEM7OztTQUVTLHFCQUFHO0FBQ1osVUFBTztBQUNOLGdCQUFZLEVBQUUsZ0JBQWdCO0FBQzlCLFdBQU8sRUFBRSxZQUFZO0FBQ3JCLE9BQUcsRUFBRSxJQUFJLENBQUMsaUJBQWlCLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFDLElBQUk7SUFDNUUsQ0FBQTtHQUNEOzs7U0FFTyxtQkFBRztBQUNWLE9BQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtBQUNqQixRQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFBO0lBQ3RCO0FBQ0QsT0FBSSxDQUFDLGFBQWEsVUFBTyxDQUFDLElBQUksQ0FBQyxDQUFBO0dBQy9COzs7U0FFUSxvQkFBRztBQUNYLFVBQU8sQ0FBQyxJQUFJLENBQUMsZ0JBQWdCLEVBQUUsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFBLEdBQUksSUFBSSxDQUFDLEtBQUssQ0FBQTs7R0FFekQ7OztTQUVVLHNCQUFHO0FBQ2IsVUFBTyxJQUFJLENBQUMsT0FBTyxDQUFBO0dBQ25COzs7U0FFTSxrQkFBRztBQUNULFVBQU8sSUFBSSxDQUFDLEdBQUcsQ0FBQTtHQUNmOzs7U0FFWSx3QkFBRztBQUNmLE9BQUksSUFBSSxDQUFDLEtBQUssS0FBSyxhQUFhLEVBQUU7QUFDakMsV0FBTyxhQUFhLENBQUE7SUFDcEI7QUFDRCxVQUFPLGFBQWEsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUE7R0FDOUM7OztTQUVnQiwwQkFBQyxRQUFRLEVBQUU7QUFDM0IsVUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUMsQ0FBQTtHQUNwRDs7O1NBRVcsdUJBQUc7QUFDZCxVQUFPLFVBQVUsQ0FBQTtHQUNqQjs7O1NBRU8sbUJBQUc7QUFDVixVQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxDQUFBO0dBQ3ZCOzs7U0FFVSxzQkFBRztBQUNiLFVBQU8sSUFBSSxDQUFDLFFBQVEsQ0FBQTtHQUNwQjs7O1NBRW1CLDZCQUFDLFFBQVEsRUFBRTtBQUM5QixVQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLHFCQUFxQixFQUFFLFFBQVEsQ0FBQyxDQUFBO0dBQ3ZEOzs7U0FFb0IsZ0NBQUc7QUFDdkIsT0FBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUU7QUFDZixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxDQUFBO0lBQzVDO0FBQ0QsT0FBTSxhQUFhLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQTtBQUNuQyxPQUFJLElBQUksWUFBQSxDQUFBO0FBQ1IsT0FBSSxJQUFJLENBQUMsSUFBSSxFQUFFO0FBQ2QsUUFBSSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsYUFBYSxFQUFFLENBQUE7SUFDaEM7QUFDRCxPQUFJLElBQUksS0FBSyxJQUFJLEVBQUU7QUFDbEIsUUFBSSxDQUFDLFFBQVEsR0FBRyxLQUFLLENBQUE7SUFDckIsTUFBTTtBQUNOLFFBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxDQUFBO0lBQ3BCO0FBQ0QsT0FBSSxhQUFhLEtBQUssSUFBSSxDQUFDLFFBQVEsRUFBRTtBQUNwQyxRQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDdkQ7R0FDRDs7O1NBRVksd0JBQUc7QUFDZixVQUFPLElBQUksQ0FBQyxTQUFTLENBQUE7R0FDckI7OztTQUVvQixnQ0FBRztBQUN2QixPQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQzlFLE1BQUcsQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFLENBQUE7QUFDdkIsVUFBTyxHQUFHLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxDQUFBO0dBQ2xDOzs7U0FFYSx5QkFBRzs7QUFFaEIsT0FBSSxJQUFJLENBQUMsT0FBTyxFQUFFO0FBQ2pCLFFBQUksQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLENBQUE7SUFDNUI7R0FDRDs7O1NBRWUseUJBQUMsTUFBTSxFQUFFO0FBQ3hCLE9BQUksQ0FBQyxPQUFPLENBQUMsZUFBZSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ3BDLE9BQUksSUFBSSxDQUFDLFFBQVEsRUFBRTtBQUNsQixRQUFJLENBQUMsUUFBUSxHQUFHLEtBQUssQ0FBQTtBQUNyQixRQUFJLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxxQkFBcUIsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDdkQ7R0FDRDs7O1NBRUksZ0JBQUc7QUFDUCxPQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUE7R0FDakM7OztTQUVpQiw2QkFBRztBQUNwQixPQUFJLElBQUksQ0FBQyxPQUFPLEVBQUU7QUFDakIsUUFBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0lBQ2hDO0dBQ0Q7OztTQUVnQiw0QkFBRztBQUNuQixVQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLFlBQVksRUFBRSxDQUFBO0dBQzNDOzs7U0FFVSxvQkFBQyxHQUFHLEVBQUU7QUFDaEIsT0FBSSxDQUFDLGVBQWUsQ0FBQyxHQUFHLEdBQUcsZ0JBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0dBQzVDOzs7U0FFZSx5QkFBQyxJQUFJLEVBQUU7QUFDdEIsT0FBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO0dBQ25DOzs7U0FFSyxpQkFBRztBQUNSLE9BQUksSUFBSSxDQUFDLE9BQU8sRUFBRTtBQUNqQixXQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsS0FBSyxFQUFFLENBQUE7SUFDM0I7R0FDRDs7O1NBRVMscUJBQUc7QUFDWixpQ0FBa0IsSUFBSSxDQUFDLGFBQWEsRUFBRSxJQUFJLENBQUMsQ0FBQTtHQUMzQzs7O1NBRVMscUJBQUc7QUFDWixVQUFPLElBQUksQ0FBQyxJQUFJLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsS0FBSyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsSUFBSSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLENBQUEsQUFBQyxDQUFBO0dBQy9GOzs7U0FFZ0IsNEJBQUc7QUFDbkIsVUFBTyxJQUFJLENBQUMsV0FBVyxLQUFLLENBQUMsS0FBSyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxxREFBcUQsQ0FBQyxJQUFJLElBQUksQ0FBQyxTQUFTLEVBQUUsQ0FBQSxBQUFDLENBQUE7R0FDN0g7OztTQUVVLG9CQUFDLElBQUksRUFBRTtBQUNqQixPQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQTtBQUNoQixPQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksRUFBRSxDQUFDLFdBQVcsRUFBRSxDQUFBO0FBQ3ZELFdBQVEsUUFBUTtBQUNmLFNBQUssTUFBTTtBQUNWLFNBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUN4QyxXQUFLO0FBQUEsQUFDTixTQUFLLE9BQU87QUFDWCxTQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUE7QUFDekMsV0FBSztBQUFBLEFBQ04sU0FBSyxRQUFRO0FBQ1osU0FBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQzFDLFdBQUs7QUFBQSxBQUNOO0FBQ0MsU0FBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7QUFBQSxJQUNqQjtHQUNEOzs7U0FFaUIsNkJBQUc7QUFDcEIsT0FBSSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0dBQ2hDOzs7Ozs7Ozs7Ozs7U0FVVSxzQkFBRztBQUNiLFVBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQTtHQUNuQjs7Ozs7Ozs7OztTQVFtQiw2QkFBQyxjQUFjLEVBQUU7QUFDcEMsaUJBQWMsR0FBRyxJQUFJLENBQUMsaUJBQWlCLENBQUMsWUFBWSxDQUFDLGNBQWMsQ0FBQyxDQUFBO0FBQ3BFLE9BQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFDLGlCQUFpQixDQUFDLFNBQVMsY0FDM0MsSUFBSSxDQUFDLE9BQU8sRUFDWixjQUFjLEVBQ2hCLENBQUE7QUFDRixPQUFJLENBQUMsT0FBTyxDQUFDLHNCQUFzQixDQUFDLGNBQWMsQ0FBQyxDQUFBO0dBQ25EOzs7UUE5UUksY0FBYzs7O0FBaVJwQixTQUFTLGdCQUFnQixDQUFFLElBQUksRUFBRTtBQUNoQyxRQUFRLElBQUksWUFBWSxjQUFjLENBQUM7Q0FDdkM7O0FBRUQsU0FBUywyQkFBMkIsR0FBSTtBQUN2QyxRQUFPLGdCQUFnQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsaUJBQWlCLEVBQUUsQ0FBQyxDQUFBO0NBQzNEOztRQUdBLGNBQWMsR0FBZCxjQUFjO1FBQ2QsZ0JBQWdCLEdBQWhCLGdCQUFnQjtRQUNoQiwyQkFBMkIsR0FBM0IsMkJBQTJCIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL21vZGVsLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLyoqIEBiYWJlbCAqL1xuLypcbiAqIENvcHlyaWdodCAyMDE3IEFtYXpvbi5jb20sIEluYy4gb3IgaXRzIGFmZmlsaWF0ZXMuIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgMjAxNy0yMDE4IEFuZHJlcyBNZWppYSA8YW1lamlhMDA0QGdtYWlsLmNvbT4uIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgVXppVGVjaCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIGJ1cy1zdG9wIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKlxuICogUGVybWlzc2lvbiBpcyBoZXJlYnkgZ3JhbnRlZCwgZnJlZSBvZiBjaGFyZ2UsIHRvIGFueSBwZXJzb24gb2J0YWluaW5nIGEgY29weSBvZiB0aGlzXG4gKiBzb2Z0d2FyZSBhbmQgYXNzb2NpYXRlZCBkb2N1bWVudGF0aW9uIGZpbGVzICh0aGUgXCJTb2Z0d2FyZVwiKSwgdG8gZGVhbCBpbiB0aGUgU29mdHdhcmVcbiAqIHdpdGhvdXQgcmVzdHJpY3Rpb24sIGluY2x1ZGluZyB3aXRob3V0IGxpbWl0YXRpb24gdGhlIHJpZ2h0cyB0byB1c2UsIGNvcHksIG1vZGlmeSxcbiAqIG1lcmdlLCBwdWJsaXNoLCBkaXN0cmlidXRlLCBzdWJsaWNlbnNlLCBhbmQvb3Igc2VsbCBjb3BpZXMgb2YgdGhlIFNvZnR3YXJlLCBhbmQgdG9cbiAqIHBlcm1pdCBwZXJzb25zIHRvIHdob20gdGhlIFNvZnR3YXJlIGlzIGZ1cm5pc2hlZCB0byBkbyBzby5cbiAqXG4gKiBUSEUgU09GVFdBUkUgSVMgUFJPVklERUQgXCJBUyBJU1wiLCBXSVRIT1VUIFdBUlJBTlRZIE9GIEFOWSBLSU5ELCBFWFBSRVNTIE9SIElNUExJRUQsXG4gKiBJTkNMVURJTkcgQlVUIE5PVCBMSU1JVEVEIFRPIFRIRSBXQVJSQU5USUVTIE9GIE1FUkNIQU5UQUJJTElUWSwgRklUTkVTUyBGT1IgQVxuICogUEFSVElDVUxBUiBQVVJQT1NFIEFORCBOT05JTkZSSU5HRU1FTlQuIElOIE5PIEVWRU5UIFNIQUxMIFRIRSBBVVRIT1JTIE9SIENPUFlSSUdIVFxuICogSE9MREVSUyBCRSBMSUFCTEUgRk9SIEFOWSBDTEFJTSwgREFNQUdFUyBPUiBPVEhFUiBMSUFCSUxJVFksIFdIRVRIRVIgSU4gQU4gQUNUSU9OXG4gKiBPRiBDT05UUkFDVCwgVE9SVCBPUiBPVEhFUldJU0UsIEFSSVNJTkcgRlJPTSwgT1VUIE9GIE9SIElOIENPTk5FQ1RJT04gV0lUSCBUSEVcbiAqIFNPRlRXQVJFIE9SIFRIRSBVU0UgT1IgT1RIRVIgREVBTElOR1MgSU4gVEhFIFNPRlRXQVJFLlxuICovXG5cbmltcG9ydCB7IEVtaXR0ZXIgfSBmcm9tICdhdG9tJ1xuXG5pbXBvcnQgeyByZWNhbGN1bGF0ZUFjdGl2ZSB9IGZyb20gJy4vdXRpbHMnXG5pbXBvcnQgeyBYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbiB9IGZyb20gJy4vcHJvZmlsZXMnXG5cbmltcG9ydCBmcyBmcm9tICdmcy1leHRyYSdcbmltcG9ydCBwYXRoIGZyb20gJ3BhdGgnXG5pbXBvcnQgb3MgZnJvbSAnb3MnXG5cbmltcG9ydCB7IFVSTCB9IGZyb20gJ3doYXR3Zy11cmwnXG5cbmNvbnN0IERFRkFVTFRfVElUTEUgPSAnWCBUZXJtaW5hbCdcblxuLyoqXG4gKiBUaGUgbWFpbiB0ZXJtaW5hbCBtb2RlbCwgb3IgcmF0aGVyIGl0ZW0sIGRpc3BsYXllZCBpbiB0aGUgQXRvbSB3b3Jrc3BhY2UuXG4gKlxuICogQGNsYXNzXG4gKi9cbmNsYXNzIFhUZXJtaW5hbE1vZGVsIHtcblx0Ly8gTk9URTogVGhvdWdoIHRoZSBjbGFzcyBpcyBwdWJsaWNhbGx5IGFjY2Vzc2libGUsIGFsbCBtZXRob2RzIGV4Y2VwdCBmb3IgdGhlXG5cdC8vIG9uZXMgZGVmaW5lZCBhdCB0aGUgdmVyeSBib3R0b20gb2YgdGhlIGNsYXNzIHNob3VsZCBiZSBjb25zaWRlcmVkIHByaXZhdGVcblx0Ly8gYW5kIHN1YmplY3QgdG8gY2hhbmdlIGF0IGFueSB0aW1lLlxuXHRjb25zdHJ1Y3RvciAob3B0aW9ucykge1xuXHRcdHRoaXMub3B0aW9ucyA9IG9wdGlvbnNcblx0XHR0aGlzLnVyaSA9IHRoaXMub3B0aW9ucy51cmlcblx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKHRoaXMudXJpKVxuXHRcdHRoaXMuc2Vzc2lvbklkID0gdXJsLmhvc3Rcblx0XHR0aGlzLnVyaUN3ZCA9IHVybC5zZWFyY2hQYXJhbXMuZ2V0KCdjd2QnKVxuXHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24gPSBYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbi5pbnN0YW5jZVxuXHRcdHRoaXMucHJvZmlsZSA9IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uY3JlYXRlUHJvZmlsZURhdGFGcm9tVXJpKHRoaXMudXJpKVxuXHRcdHRoaXMudGVybWluYWxzX3NldCA9IHRoaXMub3B0aW9ucy50ZXJtaW5hbHNfc2V0XG5cdFx0dGhpcy5hY3RpdmVJbmRleCA9IHRoaXMudGVybWluYWxzX3NldC5zaXplXG5cdFx0dGhpcy5lbGVtZW50ID0gbnVsbFxuXHRcdHRoaXMucGFuZSA9IG51bGxcblx0XHR0aGlzLnRpdGxlID0gREVGQVVMVF9USVRMRVxuXHRcdGlmICh0aGlzLnByb2ZpbGUudGl0bGUgIT09IG51bGwpIHtcblx0XHRcdHRoaXMudGl0bGUgPSB0aGlzLnByb2ZpbGUudGl0bGVcblx0XHR9XG5cdFx0dGhpcy5tb2RpZmllZCA9IGZhbHNlXG5cdFx0dGhpcy5lbWl0dGVyID0gbmV3IEVtaXR0ZXIoKVxuXHRcdHRoaXMudGVybWluYWxzX3NldC5hZGQodGhpcylcblxuXHRcdC8vIERldGVybWluZSBhcHByb3ByaWF0ZSBpbml0aWFsIHdvcmtpbmcgZGlyZWN0b3J5IGJhc2VkIG9uIHByZXZpb3VzXG5cdFx0Ly8gYWN0aXZlIGl0ZW0uIFNpbmNlIHRoaXMgaW52b2x2ZXMgYXN5bmMgb3BlcmF0aW9ucyBvbiB0aGUgZmlsZVxuXHRcdC8vIHN5c3RlbSwgYSBQcm9taXNlIHdpbGwgYmUgdXNlZCB0byBpbmRpY2F0ZSB3aGVuIGluaXRpYWxpemF0aW9uIGlzXG5cdFx0Ly8gZG9uZS5cblx0XHR0aGlzLmlzSW5pdGlhbGl6ZWQgPSBmYWxzZVxuXHRcdHRoaXMuaW5pdGlhbGl6ZWRQcm9taXNlID0gdGhpcy5pbml0aWFsaXplKCkudGhlbigoKSA9PiB7XG5cdFx0XHR0aGlzLmlzSW5pdGlhbGl6ZWQgPSB0cnVlXG5cdFx0fSlcblx0fVxuXG5cdGFzeW5jIGluaXRpYWxpemUgKCkge1xuXHRcdGxldCBjd2RcblxuXHRcdGlmICh0aGlzLnVyaUN3ZCkge1xuXHRcdFx0Y3dkID0gdGhpcy51cmlDd2Rcblx0XHR9IGVsc2UgaWYgKHRoaXMucHJvZmlsZS5wcm9qZWN0Q3dkKSB7XG5cdFx0XHRjb25zdCBwcmV2aW91c0FjdGl2ZUl0ZW0gPSBhdG9tLndvcmtzcGFjZS5nZXRBY3RpdmVQYW5lSXRlbSgpXG5cdFx0XHRpZiAodHlwZW9mIHByZXZpb3VzQWN0aXZlSXRlbSAhPT0gJ3VuZGVmaW5lZCcgJiYgdHlwZW9mIHByZXZpb3VzQWN0aXZlSXRlbS5nZXRQYXRoID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRcdGN3ZCA9IHByZXZpb3VzQWN0aXZlSXRlbS5nZXRQYXRoKClcblx0XHRcdFx0Y29uc3QgZGlyID0gYXRvbS5wcm9qZWN0LnJlbGF0aXZpemVQYXRoKGN3ZClbMF1cblx0XHRcdFx0aWYgKGRpcikge1xuXHRcdFx0XHRcdHRoaXMucHJvZmlsZS5jd2QgPSBkaXJcblx0XHRcdFx0XHRyZXR1cm5cblx0XHRcdFx0fVxuXHRcdFx0fSBlbHNlIHtcblx0XHRcdFx0Y3dkID0gYXRvbS5wcm9qZWN0LmdldFBhdGhzKClbMF1cblx0XHRcdH1cblx0XHR9IGVsc2Uge1xuXHRcdFx0Y3dkID0gdGhpcy5wcm9maWxlLmN3ZFxuXHRcdH1cblxuXHRcdGNvbnN0IGJhc2VQcm9maWxlID0gdGhpcy5wcm9maWxlc1NpbmdsZXRvbi5nZXRCYXNlUHJvZmlsZSgpXG5cdFx0aWYgKCFjd2QpIHtcblx0XHRcdHRoaXMucHJvZmlsZS5jd2QgPSBiYXNlUHJvZmlsZS5jd2Rcblx0XHRcdHJldHVyblxuXHRcdH1cblx0XHRjb25zdCBleGlzdHMgPSBhd2FpdCBmcy5leGlzdHMoY3dkKVxuXHRcdGlmICghZXhpc3RzKSB7XG5cdFx0XHR0aGlzLnByb2ZpbGUuY3dkID0gYmFzZVByb2ZpbGUuY3dkXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cblx0XHQvLyBPdGhlcndpc2UsIGlmIHRoZSBwYXRoIGV4aXN0cyBvbiB0aGUgbG9jYWwgZmlsZSBzeXN0ZW0sIHVzZSB0aGVcblx0XHQvLyBwYXRoIG9yIHBhcmVudCBkaXJlY3RvcnkgYXMgYXBwcm9wcmlhdGUuXG5cdFx0Y29uc3Qgc3RhdHMgPSBhd2FpdCBmcy5zdGF0KGN3ZClcblx0XHRpZiAoc3RhdHMuaXNEaXJlY3RvcnkoKSkge1xuXHRcdFx0dGhpcy5wcm9maWxlLmN3ZCA9IGN3ZFxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0Y3dkID0gcGF0aC5kaXJuYW1lKGN3ZClcblx0XHRjb25zdCBkaXJTdGF0cyA9IGF3YWl0IGZzLnN0YXQoY3dkKVxuXHRcdGlmIChkaXJTdGF0cy5pc0RpcmVjdG9yeSkge1xuXHRcdFx0dGhpcy5wcm9maWxlLmN3ZCA9IGN3ZFxuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXG5cdFx0dGhpcy5wcm9maWxlLmN3ZCA9IGJhc2VQcm9maWxlLmN3ZFxuXHR9XG5cblx0c2VyaWFsaXplICgpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0ZGVzZXJpYWxpemVyOiAnWFRlcm1pbmFsTW9kZWwnLFxuXHRcdFx0dmVyc2lvbjogJzIwMTctMDktMTcnLFxuXHRcdFx0dXJpOiB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdlbmVyYXRlTmV3VXJsRnJvbVByb2ZpbGVEYXRhKHRoaXMucHJvZmlsZSkuaHJlZixcblx0XHR9XG5cdH1cblxuXHRkZXN0cm95ICgpIHtcblx0XHRpZiAodGhpcy5lbGVtZW50KSB7XG5cdFx0XHR0aGlzLmVsZW1lbnQuZGVzdHJveSgpXG5cdFx0fVxuXHRcdHRoaXMudGVybWluYWxzX3NldC5kZWxldGUodGhpcylcblx0fVxuXG5cdGdldFRpdGxlICgpIHtcblx0XHRyZXR1cm4gKHRoaXMuaXNBY3RpdmVUZXJtaW5hbCgpID8gJyogJyA6ICcnKSArIHRoaXMudGl0bGVcblx0XHQvLyByZXR1cm4gdGhpcy5hY3RpdmVJbmRleCArICd8JyArIHRoaXMudGl0bGVcblx0fVxuXG5cdGdldEVsZW1lbnQgKCkge1xuXHRcdHJldHVybiB0aGlzLmVsZW1lbnRcblx0fVxuXG5cdGdldFVSSSAoKSB7XG5cdFx0cmV0dXJuIHRoaXMudXJpXG5cdH1cblxuXHRnZXRMb25nVGl0bGUgKCkge1xuXHRcdGlmICh0aGlzLnRpdGxlID09PSBERUZBVUxUX1RJVExFKSB7XG5cdFx0XHRyZXR1cm4gREVGQVVMVF9USVRMRVxuXHRcdH1cblx0XHRyZXR1cm4gREVGQVVMVF9USVRMRSArICcgKCcgKyB0aGlzLnRpdGxlICsgJyknXG5cdH1cblxuXHRvbkRpZENoYW5nZVRpdGxlIChjYWxsYmFjaykge1xuXHRcdHJldHVybiB0aGlzLmVtaXR0ZXIub24oJ2RpZC1jaGFuZ2UtdGl0bGUnLCBjYWxsYmFjaylcblx0fVxuXG5cdGdldEljb25OYW1lICgpIHtcblx0XHRyZXR1cm4gJ3Rlcm1pbmFsJ1xuXHR9XG5cblx0Z2V0UGF0aCAoKSB7XG5cdFx0cmV0dXJuIHRoaXMucHJvZmlsZS5jd2Rcblx0fVxuXG5cdGlzTW9kaWZpZWQgKCkge1xuXHRcdHJldHVybiB0aGlzLm1vZGlmaWVkXG5cdH1cblxuXHRvbkRpZENoYW5nZU1vZGlmaWVkIChjYWxsYmFjaykge1xuXHRcdHJldHVybiB0aGlzLmVtaXR0ZXIub24oJ2RpZC1jaGFuZ2UtbW9kaWZpZWQnLCBjYWxsYmFjaylcblx0fVxuXG5cdGhhbmRsZU5ld0RhdGFBcnJpdmFsICgpIHtcblx0XHRpZiAoIXRoaXMucGFuZSkge1xuXHRcdFx0dGhpcy5wYW5lID0gYXRvbS53b3Jrc3BhY2UucGFuZUZvckl0ZW0odGhpcylcblx0XHR9XG5cdFx0Y29uc3Qgb2xkSXNNb2RpZmllZCA9IHRoaXMubW9kaWZpZWRcblx0XHRsZXQgaXRlbVxuXHRcdGlmICh0aGlzLnBhbmUpIHtcblx0XHRcdGl0ZW0gPSB0aGlzLnBhbmUuZ2V0QWN0aXZlSXRlbSgpXG5cdFx0fVxuXHRcdGlmIChpdGVtID09PSB0aGlzKSB7XG5cdFx0XHR0aGlzLm1vZGlmaWVkID0gZmFsc2Vcblx0XHR9IGVsc2Uge1xuXHRcdFx0dGhpcy5tb2RpZmllZCA9IHRydWVcblx0XHR9XG5cdFx0aWYgKG9sZElzTW9kaWZpZWQgIT09IHRoaXMubW9kaWZpZWQpIHtcblx0XHRcdHRoaXMuZW1pdHRlci5lbWl0KCdkaWQtY2hhbmdlLW1vZGlmaWVkJywgdGhpcy5tb2RpZmllZClcblx0XHR9XG5cdH1cblxuXHRnZXRTZXNzaW9uSWQgKCkge1xuXHRcdHJldHVybiB0aGlzLnNlc3Npb25JZFxuXHR9XG5cblx0Z2V0U2Vzc2lvblBhcmFtZXRlcnMgKCkge1xuXHRcdGNvbnN0IHVybCA9IHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2VuZXJhdGVOZXdVcmxGcm9tUHJvZmlsZURhdGEodGhpcy5wcm9maWxlKVxuXHRcdHVybC5zZWFyY2hQYXJhbXMuc29ydCgpXG5cdFx0cmV0dXJuIHVybC5zZWFyY2hQYXJhbXMudG9TdHJpbmcoKVxuXHR9XG5cblx0cmVmaXRUZXJtaW5hbCAoKSB7XG5cdFx0Ly8gT25seSByZWZpdCBpZiB0aGVyZSdzIGEgRE9NIGVsZW1lbnQgYXR0YWNoZWQgdG8gdGhlIG1vZGVsLlxuXHRcdGlmICh0aGlzLmVsZW1lbnQpIHtcblx0XHRcdHRoaXMuZWxlbWVudC5yZWZpdFRlcm1pbmFsKClcblx0XHR9XG5cdH1cblxuXHRmb2N1c09uVGVybWluYWwgKGRvdWJsZSkge1xuXHRcdHRoaXMuZWxlbWVudC5mb2N1c09uVGVybWluYWwoZG91YmxlKVxuXHRcdGlmICh0aGlzLm1vZGlmaWVkKSB7XG5cdFx0XHR0aGlzLm1vZGlmaWVkID0gZmFsc2Vcblx0XHRcdHRoaXMuZW1pdHRlci5lbWl0KCdkaWQtY2hhbmdlLW1vZGlmaWVkJywgdGhpcy5tb2RpZmllZClcblx0XHR9XG5cdH1cblxuXHRleGl0ICgpIHtcblx0XHR0aGlzLnBhbmUuZGVzdHJveUl0ZW0odGhpcywgdHJ1ZSlcblx0fVxuXG5cdHJlc3RhcnRQdHlQcm9jZXNzICgpIHtcblx0XHRpZiAodGhpcy5lbGVtZW50KSB7XG5cdFx0XHR0aGlzLmVsZW1lbnQucmVzdGFydFB0eVByb2Nlc3MoKVxuXHRcdH1cblx0fVxuXG5cdGNvcHlGcm9tVGVybWluYWwgKCkge1xuXHRcdHJldHVybiB0aGlzLmVsZW1lbnQudGVybWluYWwuZ2V0U2VsZWN0aW9uKClcblx0fVxuXG5cdHJ1bkNvbW1hbmQgKGNtZCkge1xuXHRcdHRoaXMucGFzdGVUb1Rlcm1pbmFsKGNtZCArIG9zLkVPTC5jaGFyQXQoMCkpXG5cdH1cblxuXHRwYXN0ZVRvVGVybWluYWwgKHRleHQpIHtcblx0XHR0aGlzLmVsZW1lbnQucHR5UHJvY2Vzcy53cml0ZSh0ZXh0KVxuXHR9XG5cblx0Y2xlYXIgKCkge1xuXHRcdGlmICh0aGlzLmVsZW1lbnQpIHtcblx0XHRcdHJldHVybiB0aGlzLmVsZW1lbnQuY2xlYXIoKVxuXHRcdH1cblx0fVxuXG5cdHNldEFjdGl2ZSAoKSB7XG5cdFx0cmVjYWxjdWxhdGVBY3RpdmUodGhpcy50ZXJtaW5hbHNfc2V0LCB0aGlzKVxuXHR9XG5cblx0aXNWaXNpYmxlICgpIHtcblx0XHRyZXR1cm4gdGhpcy5wYW5lICYmIHRoaXMucGFuZS5nZXRBY3RpdmVJdGVtKCkgPT09IHRoaXMgJiYgKCF0aGlzLmRvY2sgfHwgdGhpcy5kb2NrLmlzVmlzaWJsZSgpKVxuXHR9XG5cblx0aXNBY3RpdmVUZXJtaW5hbCAoKSB7XG5cdFx0cmV0dXJuIHRoaXMuYWN0aXZlSW5kZXggPT09IDAgJiYgKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmFsbG93SGlkZGVuVG9TdGF5QWN0aXZlJykgfHwgdGhpcy5pc1Zpc2libGUoKSlcblx0fVxuXG5cdHNldE5ld1BhbmUgKHBhbmUpIHtcblx0XHR0aGlzLnBhbmUgPSBwYW5lXG5cdFx0Y29uc3QgbG9jYXRpb24gPSB0aGlzLnBhbmUuZ2V0Q29udGFpbmVyKCkuZ2V0TG9jYXRpb24oKVxuXHRcdHN3aXRjaCAobG9jYXRpb24pIHtcblx0XHRcdGNhc2UgJ2xlZnQnOlxuXHRcdFx0XHR0aGlzLmRvY2sgPSBhdG9tLndvcmtzcGFjZS5nZXRMZWZ0RG9jaygpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdyaWdodCc6XG5cdFx0XHRcdHRoaXMuZG9jayA9IGF0b20ud29ya3NwYWNlLmdldFJpZ2h0RG9jaygpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdib3R0b20nOlxuXHRcdFx0XHR0aGlzLmRvY2sgPSBhdG9tLndvcmtzcGFjZS5nZXRCb3R0b21Eb2NrKClcblx0XHRcdFx0YnJlYWtcblx0XHRcdGRlZmF1bHQ6XG5cdFx0XHRcdHRoaXMuZG9jayA9IG51bGxcblx0XHR9XG5cdH1cblxuXHR0b2dnbGVQcm9maWxlTWVudSAoKSB7XG5cdFx0dGhpcy5lbGVtZW50LnRvZ2dsZVByb2ZpbGVNZW51KClcblx0fVxuXG5cdC8qIFB1YmxpYyBtZXRob2RzIGFyZSBkZWZpbmVkIGJlbG93IHRoaXMgbGluZS4gKi9cblxuXHQvKipcblx0ICogUmV0cmlldmUgcHJvZmlsZSBmb3IgdGhpcyB7QGxpbmsgWFRlcm1pbmFsTW9kZWx9IGluc3RhbmNlLlxuXHQgKlxuXHQgKiBAZnVuY3Rpb25cblx0ICogQHJldHVybiB7T2JqZWN0fSBQcm9maWxlIGZvciB7QGxpbmsgWFRlcm1pbmFsTW9kZWx9IGluc3RhbmNlLlxuXHQgKi9cblx0Z2V0UHJvZmlsZSAoKSB7XG5cdFx0cmV0dXJuIHRoaXMucHJvZmlsZVxuXHR9XG5cblx0LyoqXG5cdCAqIEFwcGx5IHByb2ZpbGUgY2hhbmdlcyB0byB7QGxpbmsgWFRlcm1pbmFsTW9kZWx9IGluc3RhbmNlLlxuXHQgKlxuXHQgKiBAZnVuY3Rpb25cblx0ICogQHBhcmFtIHtPYmplY3R9IHByb2ZpbGVDaGFuZ2VzIFByb2ZpbGUgY2hhbmdlcyB0byBhcHBseS5cblx0ICovXG5cdGFwcGx5UHJvZmlsZUNoYW5nZXMgKHByb2ZpbGVDaGFuZ2VzKSB7XG5cdFx0cHJvZmlsZUNoYW5nZXMgPSB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLnNhbml0aXplRGF0YShwcm9maWxlQ2hhbmdlcylcblx0XHR0aGlzLnByb2ZpbGUgPSB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmRlZXBDbG9uZSh7XG5cdFx0XHQuLi50aGlzLnByb2ZpbGUsXG5cdFx0XHQuLi5wcm9maWxlQ2hhbmdlcyxcblx0XHR9KVxuXHRcdHRoaXMuZWxlbWVudC5xdWV1ZU5ld1Byb2ZpbGVDaGFuZ2VzKHByb2ZpbGVDaGFuZ2VzKVxuXHR9XG59XG5cbmZ1bmN0aW9uIGlzWFRlcm1pbmFsTW9kZWwgKGl0ZW0pIHtcblx0cmV0dXJuIChpdGVtIGluc3RhbmNlb2YgWFRlcm1pbmFsTW9kZWwpXG59XG5cbmZ1bmN0aW9uIGN1cnJlbnRJdGVtSXNYVGVybWluYWxNb2RlbCAoKSB7XG5cdHJldHVybiBpc1hUZXJtaW5hbE1vZGVsKGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVBhbmVJdGVtKCkpXG59XG5cbmV4cG9ydCB7XG5cdFhUZXJtaW5hbE1vZGVsLFxuXHRpc1hUZXJtaW5hbE1vZGVsLFxuXHRjdXJyZW50SXRlbUlzWFRlcm1pbmFsTW9kZWwsXG59XG4iXX0=