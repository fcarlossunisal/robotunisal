Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x, _x2, _x3) { var _again = true; _function: while (_again) { var object = _x, property = _x2, receiver = _x3; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x = parent; _x2 = property; _x3 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _utils = require('./utils');

var XTerminalSaveProfileElementImpl = (function (_HTMLElement) {
  _inherits(XTerminalSaveProfileElementImpl, _HTMLElement);

  function XTerminalSaveProfileElementImpl() {
    _classCallCheck(this, XTerminalSaveProfileElementImpl);

    _get(Object.getPrototypeOf(XTerminalSaveProfileElementImpl.prototype), 'constructor', this).apply(this, arguments);
  }

  _createClass(XTerminalSaveProfileElementImpl, [{
    key: 'initialize',
    value: function initialize(model) {
      this.model = model;
      this.model.setElement(this);
      this.textboxDiv = document.createElement('div');
      this.textboxDiv.classList.add('x-terminal-save-profile-textbox');
      this.appendChild(this.textboxDiv);
      this.messageDiv = document.createElement('div');
      this.messageDiv.classList.add('x-terminal-modal-message');
      this.messageDiv.appendChild(document.createTextNode('Enter new profile name'));
      this.appendChild(this.messageDiv);
    }
  }, {
    key: 'setNewTextbox',
    value: function setNewTextbox(textbox) {
      (0, _utils.clearDiv)(this.textboxDiv);
      this.textboxDiv.appendChild(textbox.getElement());
    }
  }]);

  return XTerminalSaveProfileElementImpl;
})(HTMLElement);

var XTerminalSaveProfileElement = document.registerElement('x-terminal-save-profile', {
  prototype: XTerminalSaveProfileElementImpl.prototype
});

exports.XTerminalSaveProfileElement = XTerminalSaveProfileElement;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3NhdmUtcHJvZmlsZS1lbGVtZW50LmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFxQnlCLFNBQVM7O0lBRTVCLCtCQUErQjtZQUEvQiwrQkFBK0I7O1dBQS9CLCtCQUErQjswQkFBL0IsK0JBQStCOzsrQkFBL0IsK0JBQStCOzs7ZUFBL0IsK0JBQStCOztXQUN6QixvQkFBQyxLQUFLLEVBQUU7QUFDbEIsVUFBSSxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUE7QUFDbEIsVUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDM0IsVUFBSSxDQUFDLFVBQVUsR0FBRyxRQUFRLENBQUMsYUFBYSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQy9DLFVBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxpQ0FBaUMsQ0FBQyxDQUFBO0FBQ2hFLFVBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0FBQ2pDLFVBQUksQ0FBQyxVQUFVLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtBQUMvQyxVQUFJLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsMEJBQTBCLENBQUMsQ0FBQTtBQUN6RCxVQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsY0FBYyxDQUFDLHdCQUF3QixDQUFDLENBQUMsQ0FBQTtBQUM5RSxVQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtLQUNqQzs7O1dBRWEsdUJBQUMsT0FBTyxFQUFFO0FBQ3ZCLDJCQUFTLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUN6QixVQUFJLENBQUMsVUFBVSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsQ0FBQTtLQUNqRDs7O1NBaEJJLCtCQUErQjtHQUFTLFdBQVc7O0FBbUJ6RCxJQUFNLDJCQUEyQixHQUFHLFFBQVEsQ0FBQyxlQUFlLENBQUMseUJBQXlCLEVBQUU7QUFDdkYsV0FBUyxFQUFFLCtCQUErQixDQUFDLFNBQVM7Q0FDcEQsQ0FBQyxDQUFBOztRQUdELDJCQUEyQixHQUEzQiwyQkFBMkIiLCJmaWxlIjoiZmlsZTovLy9DOi9Vc2Vycy9GcmFuY2lzY28vLmF0b20vcGFja2FnZXMveC10ZXJtaW5hbC9zcmMvc2F2ZS1wcm9maWxlLWVsZW1lbnQuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiogQGJhYmVsICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTcgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAyMDE3LTIwMTggQW5kcmVzIE1lamlhIDxhbWVqaWEwMDRAZ21haWwuY29tPi4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBVemlUZWNoIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgYnVzLXN0b3AgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mIHRoaXNcbiAqIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZVxuICogd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LFxuICogbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0b1xuICogcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLlxuICpcbiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1MgT1IgSU1QTElFRCxcbiAqIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBXG4gKiBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUXG4gKiBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT05cbiAqIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRVxuICogU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4gKi9cblxuaW1wb3J0IHsgY2xlYXJEaXYgfSBmcm9tICcuL3V0aWxzJ1xuXG5jbGFzcyBYVGVybWluYWxTYXZlUHJvZmlsZUVsZW1lbnRJbXBsIGV4dGVuZHMgSFRNTEVsZW1lbnQge1xuXHRpbml0aWFsaXplIChtb2RlbCkge1xuXHRcdHRoaXMubW9kZWwgPSBtb2RlbFxuXHRcdHRoaXMubW9kZWwuc2V0RWxlbWVudCh0aGlzKVxuXHRcdHRoaXMudGV4dGJveERpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5cdFx0dGhpcy50ZXh0Ym94RGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtc2F2ZS1wcm9maWxlLXRleHRib3gnKVxuXHRcdHRoaXMuYXBwZW5kQ2hpbGQodGhpcy50ZXh0Ym94RGl2KVxuXHRcdHRoaXMubWVzc2FnZURpdiA9IGRvY3VtZW50LmNyZWF0ZUVsZW1lbnQoJ2RpdicpXG5cdFx0dGhpcy5tZXNzYWdlRGl2LmNsYXNzTGlzdC5hZGQoJ3gtdGVybWluYWwtbW9kYWwtbWVzc2FnZScpXG5cdFx0dGhpcy5tZXNzYWdlRGl2LmFwcGVuZENoaWxkKGRvY3VtZW50LmNyZWF0ZVRleHROb2RlKCdFbnRlciBuZXcgcHJvZmlsZSBuYW1lJykpXG5cdFx0dGhpcy5hcHBlbmRDaGlsZCh0aGlzLm1lc3NhZ2VEaXYpXG5cdH1cblxuXHRzZXROZXdUZXh0Ym94ICh0ZXh0Ym94KSB7XG5cdFx0Y2xlYXJEaXYodGhpcy50ZXh0Ym94RGl2KVxuXHRcdHRoaXMudGV4dGJveERpdi5hcHBlbmRDaGlsZCh0ZXh0Ym94LmdldEVsZW1lbnQoKSlcblx0fVxufVxuXG5jb25zdCBYVGVybWluYWxTYXZlUHJvZmlsZUVsZW1lbnQgPSBkb2N1bWVudC5yZWdpc3RlckVsZW1lbnQoJ3gtdGVybWluYWwtc2F2ZS1wcm9maWxlJywge1xuXHRwcm90b3R5cGU6IFhUZXJtaW5hbFNhdmVQcm9maWxlRWxlbWVudEltcGwucHJvdG90eXBlLFxufSlcblxuZXhwb3J0IHtcblx0WFRlcm1pbmFsU2F2ZVByb2ZpbGVFbGVtZW50LFxufVxuIl19