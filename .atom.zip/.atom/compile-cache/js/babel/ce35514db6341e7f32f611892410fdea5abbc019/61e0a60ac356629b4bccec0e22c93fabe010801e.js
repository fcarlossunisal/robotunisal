Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _atom = require('atom');

var _profiles = require('./profiles');

var _overwriteProfileModel = require('./overwrite-profile-model');

var _model = require('./model');

var XTerminalSaveProfileModel = (function () {
	function XTerminalSaveProfileModel(atomXtermProfileMenuElement) {
		_classCallCheck(this, XTerminalSaveProfileModel);

		this.atomXtermProfileMenuElement = atomXtermProfileMenuElement;
		this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;
		this.element = null;
		this.panel = atom.workspace.addModalPanel({
			item: this,
			visible: false
		});
		this.overwriteProfileModel = new _overwriteProfileModel.XTerminalOverwriteProfileModel(this);
	}

	_createClass(XTerminalSaveProfileModel, [{
		key: 'getTitle',
		value: function getTitle() {
			return 'X Terminal Save Profile Model';
		}
	}, {
		key: 'getElement',
		value: function getElement() {
			return this.element;
		}
	}, {
		key: 'setElement',
		value: function setElement(element) {
			this.element = element;
		}
	}, {
		key: 'getTextbox',
		value: function getTextbox() {
			return this.textbox;
		}
	}, {
		key: 'updateProfile',
		value: _asyncToGenerator(function* (profileName, newProfile, profileChanges) {
			yield this.profilesSingleton.setProfile(profileName, newProfile);
			this.profilesSingleton.reloadProfiles();
			yield this.profilesSingleton.profilesLoadPromise;
			this.close();
			this.atomXtermProfileMenuElement.applyProfileChanges(profileChanges);
		})
	}, {
		key: 'confirm',
		value: _asyncToGenerator(function* (newProfile, profileChanges) {
			var profileName = this.textbox.getText();
			if (!profileName) {
				// Simply do nothing.
				return;
			}
			var exists = yield this.profilesSingleton.isProfileExists(profileName);
			if (exists) {
				this.close(false);
				this.overwriteProfileModel.promptOverwrite(profileName, newProfile, profileChanges);
			} else {
				this.updateProfile(profileName, newProfile, profileChanges);
			}
		})
	}, {
		key: 'close',
		value: function close() {
			var focusMenuElement = arguments.length <= 0 || arguments[0] === undefined ? true : arguments[0];

			if (!this.panel.isVisible()) {
				return;
			}
			this.textbox.setText('');
			this.panel.hide();
			if (this.atomXtermProfileMenuElement.isVisible() && focusMenuElement) {
				this.atomXtermProfileMenuElement.focus();
			}
		}
	}, {
		key: 'promptForNewProfileName',
		value: function promptForNewProfileName(newProfile, profileChanges) {
			var _this = this;

			// TODO: Is it possible for the active item to change while the
			// modal is displayed.
			if (this.panel.isVisible() || !(0, _model.currentItemIsXTerminalModel)()) {
				return;
			}
			this.textbox = new _atom.TextEditor({ mini: true });
			this.textbox.getElement().addEventListener('blur', function (event) {
				_this.close();
			}, { passive: true });
			atom.commands.add(this.textbox.getElement(), 'core:confirm', function () {
				_this.confirm(newProfile, profileChanges);
			});
			atom.commands.add(this.textbox.getElement(), 'core:cancel', function () {
				_this.close();
			});
			this.element.setNewTextbox(this.textbox);
			this.panel.show();
			this.textbox.getElement().focus();
		}
	}]);

	return XTerminalSaveProfileModel;
})();

exports.XTerminalSaveProfileModel = XTerminalSaveProfileModel;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3NhdmUtcHJvZmlsZS1tb2RlbC5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CQXFCMkIsTUFBTTs7d0JBRVUsWUFBWTs7cUNBQ1IsMkJBQTJCOztxQkFDOUIsU0FBUzs7SUFFL0MseUJBQXlCO0FBQ2xCLFVBRFAseUJBQXlCLENBQ2pCLDJCQUEyQixFQUFFO3dCQURyQyx5QkFBeUI7O0FBRTdCLE1BQUksQ0FBQywyQkFBMkIsR0FBRywyQkFBMkIsQ0FBQTtBQUM5RCxNQUFJLENBQUMsaUJBQWlCLEdBQUcscUNBQTJCLFFBQVEsQ0FBQTtBQUM1RCxNQUFJLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQTtBQUNuQixNQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxDQUFDO0FBQ3pDLE9BQUksRUFBRSxJQUFJO0FBQ1YsVUFBTyxFQUFFLEtBQUs7R0FDZCxDQUFDLENBQUE7QUFDRixNQUFJLENBQUMscUJBQXFCLEdBQUcsMERBQW1DLElBQUksQ0FBQyxDQUFBO0VBQ3JFOztjQVZJLHlCQUF5Qjs7U0FZckIsb0JBQUc7QUFDWCxVQUFPLCtCQUErQixDQUFBO0dBQ3RDOzs7U0FFVSxzQkFBRztBQUNiLFVBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQTtHQUNuQjs7O1NBRVUsb0JBQUMsT0FBTyxFQUFFO0FBQ3BCLE9BQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO0dBQ3RCOzs7U0FFVSxzQkFBRztBQUNiLFVBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQTtHQUNuQjs7OzJCQUVtQixXQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsY0FBYyxFQUFFO0FBQzdELFNBQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLFVBQVUsQ0FBQyxXQUFXLEVBQUUsVUFBVSxDQUFDLENBQUE7QUFDaEUsT0FBSSxDQUFDLGlCQUFpQixDQUFDLGNBQWMsRUFBRSxDQUFBO0FBQ3ZDLFNBQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLG1CQUFtQixDQUFBO0FBQ2hELE9BQUksQ0FBQyxLQUFLLEVBQUUsQ0FBQTtBQUNaLE9BQUksQ0FBQywyQkFBMkIsQ0FBQyxtQkFBbUIsQ0FBQyxjQUFjLENBQUMsQ0FBQTtHQUNwRTs7OzJCQUVhLFdBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRTtBQUMxQyxPQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFBO0FBQzFDLE9BQUksQ0FBQyxXQUFXLEVBQUU7O0FBRWpCLFdBQU07SUFDTjtBQUNELE9BQU0sTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLGlCQUFpQixDQUFDLGVBQWUsQ0FBQyxXQUFXLENBQUMsQ0FBQTtBQUN4RSxPQUFJLE1BQU0sRUFBRTtBQUNYLFFBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDakIsUUFBSSxDQUFDLHFCQUFxQixDQUFDLGVBQWUsQ0FBQyxXQUFXLEVBQUUsVUFBVSxFQUFFLGNBQWMsQ0FBQyxDQUFBO0lBQ25GLE1BQU07QUFDTixRQUFJLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxVQUFVLEVBQUUsY0FBYyxDQUFDLENBQUE7SUFDM0Q7R0FDRDs7O1NBRUssaUJBQTBCO09BQXpCLGdCQUFnQix5REFBRyxJQUFJOztBQUM3QixPQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsRUFBRTtBQUM1QixXQUFNO0lBQ047QUFDRCxPQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLENBQUMsQ0FBQTtBQUN4QixPQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFBO0FBQ2pCLE9BQUksSUFBSSxDQUFDLDJCQUEyQixDQUFDLFNBQVMsRUFBRSxJQUFJLGdCQUFnQixFQUFFO0FBQ3JFLFFBQUksQ0FBQywyQkFBMkIsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtJQUN4QztHQUNEOzs7U0FFdUIsaUNBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRTs7Ozs7QUFHcEQsT0FBSSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMseUNBQTZCLEVBQUU7QUFDN0QsV0FBTTtJQUNOO0FBQ0QsT0FBSSxDQUFDLE9BQU8sR0FBRyxxQkFBZSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0FBQzdDLE9BQUksQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxFQUFFLFVBQUMsS0FBSyxFQUFLO0FBQzdELFVBQUssS0FBSyxFQUFFLENBQUE7SUFDWixFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDLENBQUE7QUFDckIsT0FBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxjQUFjLEVBQUUsWUFBTTtBQUNsRSxVQUFLLE9BQU8sQ0FBQyxVQUFVLEVBQUUsY0FBYyxDQUFDLENBQUE7SUFDeEMsQ0FBQyxDQUFBO0FBQ0YsT0FBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsRUFBRSxhQUFhLEVBQUUsWUFBTTtBQUNqRSxVQUFLLEtBQUssRUFBRSxDQUFBO0lBQ1osQ0FBQyxDQUFBO0FBQ0YsT0FBSSxDQUFDLE9BQU8sQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQ3hDLE9BQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUE7QUFDakIsT0FBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtHQUNqQzs7O1FBakZJLHlCQUF5Qjs7O1FBcUY5Qix5QkFBeUIsR0FBekIseUJBQXlCIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3NhdmUtcHJvZmlsZS1tb2RlbC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKiBAYmFiZWwgKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxNyBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IDIwMTctMjAxOCBBbmRyZXMgTWVqaWEgPGFtZWppYTAwNEBnbWFpbC5jb20+LiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIFV6aVRlY2ggQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBidXMtc3RvcCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpc1xuICogc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlXG4gKiB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksXG4gKiBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvXG4gKiBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28uXG4gKlxuICogVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUiBJTVBMSUVELFxuICogSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEFcbiAqIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFRcbiAqIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTlxuICogT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFXG4gKiBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiAqL1xuXG5pbXBvcnQgeyBUZXh0RWRpdG9yIH0gZnJvbSAnYXRvbSdcblxuaW1wb3J0IHsgWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24gfSBmcm9tICcuL3Byb2ZpbGVzJ1xuaW1wb3J0IHsgWFRlcm1pbmFsT3ZlcndyaXRlUHJvZmlsZU1vZGVsIH0gZnJvbSAnLi9vdmVyd3JpdGUtcHJvZmlsZS1tb2RlbCdcbmltcG9ydCB7IGN1cnJlbnRJdGVtSXNYVGVybWluYWxNb2RlbCB9IGZyb20gJy4vbW9kZWwnXG5cbmNsYXNzIFhUZXJtaW5hbFNhdmVQcm9maWxlTW9kZWwge1xuXHRjb25zdHJ1Y3RvciAoYXRvbVh0ZXJtUHJvZmlsZU1lbnVFbGVtZW50KSB7XG5cdFx0dGhpcy5hdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnQgPSBhdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnRcblx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uID0gWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24uaW5zdGFuY2Vcblx0XHR0aGlzLmVsZW1lbnQgPSBudWxsXG5cdFx0dGhpcy5wYW5lbCA9IGF0b20ud29ya3NwYWNlLmFkZE1vZGFsUGFuZWwoe1xuXHRcdFx0aXRlbTogdGhpcyxcblx0XHRcdHZpc2libGU6IGZhbHNlLFxuXHRcdH0pXG5cdFx0dGhpcy5vdmVyd3JpdGVQcm9maWxlTW9kZWwgPSBuZXcgWFRlcm1pbmFsT3ZlcndyaXRlUHJvZmlsZU1vZGVsKHRoaXMpXG5cdH1cblxuXHRnZXRUaXRsZSAoKSB7XG5cdFx0cmV0dXJuICdYIFRlcm1pbmFsIFNhdmUgUHJvZmlsZSBNb2RlbCdcblx0fVxuXG5cdGdldEVsZW1lbnQgKCkge1xuXHRcdHJldHVybiB0aGlzLmVsZW1lbnRcblx0fVxuXG5cdHNldEVsZW1lbnQgKGVsZW1lbnQpIHtcblx0XHR0aGlzLmVsZW1lbnQgPSBlbGVtZW50XG5cdH1cblxuXHRnZXRUZXh0Ym94ICgpIHtcblx0XHRyZXR1cm4gdGhpcy50ZXh0Ym94XG5cdH1cblxuXHRhc3luYyB1cGRhdGVQcm9maWxlIChwcm9maWxlTmFtZSwgbmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpIHtcblx0XHRhd2FpdCB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLnNldFByb2ZpbGUocHJvZmlsZU5hbWUsIG5ld1Byb2ZpbGUpXG5cdFx0dGhpcy5wcm9maWxlc1NpbmdsZXRvbi5yZWxvYWRQcm9maWxlcygpXG5cdFx0YXdhaXQgdGhpcy5wcm9maWxlc1NpbmdsZXRvbi5wcm9maWxlc0xvYWRQcm9taXNlXG5cdFx0dGhpcy5jbG9zZSgpXG5cdFx0dGhpcy5hdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnQuYXBwbHlQcm9maWxlQ2hhbmdlcyhwcm9maWxlQ2hhbmdlcylcblx0fVxuXG5cdGFzeW5jIGNvbmZpcm0gKG5ld1Byb2ZpbGUsIHByb2ZpbGVDaGFuZ2VzKSB7XG5cdFx0Y29uc3QgcHJvZmlsZU5hbWUgPSB0aGlzLnRleHRib3guZ2V0VGV4dCgpXG5cdFx0aWYgKCFwcm9maWxlTmFtZSkge1xuXHRcdFx0Ly8gU2ltcGx5IGRvIG5vdGhpbmcuXG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cdFx0Y29uc3QgZXhpc3RzID0gYXdhaXQgdGhpcy5wcm9maWxlc1NpbmdsZXRvbi5pc1Byb2ZpbGVFeGlzdHMocHJvZmlsZU5hbWUpXG5cdFx0aWYgKGV4aXN0cykge1xuXHRcdFx0dGhpcy5jbG9zZShmYWxzZSlcblx0XHRcdHRoaXMub3ZlcndyaXRlUHJvZmlsZU1vZGVsLnByb21wdE92ZXJ3cml0ZShwcm9maWxlTmFtZSwgbmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpXG5cdFx0fSBlbHNlIHtcblx0XHRcdHRoaXMudXBkYXRlUHJvZmlsZShwcm9maWxlTmFtZSwgbmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpXG5cdFx0fVxuXHR9XG5cblx0Y2xvc2UgKGZvY3VzTWVudUVsZW1lbnQgPSB0cnVlKSB7XG5cdFx0aWYgKCF0aGlzLnBhbmVsLmlzVmlzaWJsZSgpKSB7XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cdFx0dGhpcy50ZXh0Ym94LnNldFRleHQoJycpXG5cdFx0dGhpcy5wYW5lbC5oaWRlKClcblx0XHRpZiAodGhpcy5hdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnQuaXNWaXNpYmxlKCkgJiYgZm9jdXNNZW51RWxlbWVudCkge1xuXHRcdFx0dGhpcy5hdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnQuZm9jdXMoKVxuXHRcdH1cblx0fVxuXG5cdHByb21wdEZvck5ld1Byb2ZpbGVOYW1lIChuZXdQcm9maWxlLCBwcm9maWxlQ2hhbmdlcykge1xuXHRcdC8vIFRPRE86IElzIGl0IHBvc3NpYmxlIGZvciB0aGUgYWN0aXZlIGl0ZW0gdG8gY2hhbmdlIHdoaWxlIHRoZVxuXHRcdC8vIG1vZGFsIGlzIGRpc3BsYXllZC5cblx0XHRpZiAodGhpcy5wYW5lbC5pc1Zpc2libGUoKSB8fCAhY3VycmVudEl0ZW1Jc1hUZXJtaW5hbE1vZGVsKCkpIHtcblx0XHRcdHJldHVyblxuXHRcdH1cblx0XHR0aGlzLnRleHRib3ggPSBuZXcgVGV4dEVkaXRvcih7IG1pbmk6IHRydWUgfSlcblx0XHR0aGlzLnRleHRib3guZ2V0RWxlbWVudCgpLmFkZEV2ZW50TGlzdGVuZXIoJ2JsdXInLCAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuY2xvc2UoKVxuXHRcdH0sIHsgcGFzc2l2ZTogdHJ1ZSB9KVxuXHRcdGF0b20uY29tbWFuZHMuYWRkKHRoaXMudGV4dGJveC5nZXRFbGVtZW50KCksICdjb3JlOmNvbmZpcm0nLCAoKSA9PiB7XG5cdFx0XHR0aGlzLmNvbmZpcm0obmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpXG5cdFx0fSlcblx0XHRhdG9tLmNvbW1hbmRzLmFkZCh0aGlzLnRleHRib3guZ2V0RWxlbWVudCgpLCAnY29yZTpjYW5jZWwnLCAoKSA9PiB7XG5cdFx0XHR0aGlzLmNsb3NlKClcblx0XHR9KVxuXHRcdHRoaXMuZWxlbWVudC5zZXROZXdUZXh0Ym94KHRoaXMudGV4dGJveClcblx0XHR0aGlzLnBhbmVsLnNob3coKVxuXHRcdHRoaXMudGV4dGJveC5nZXRFbGVtZW50KCkuZm9jdXMoKVxuXHR9XG59XG5cbmV4cG9ydCB7XG5cdFhUZXJtaW5hbFNhdmVQcm9maWxlTW9kZWwsXG59XG4iXX0=