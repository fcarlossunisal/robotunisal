Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _atom = require('atom');

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _common = require('./common');

var _common2 = _interopRequireDefault(_common);

'use babel';

function findImportAtPosition(line, column) {
  var cells = _common2['default'].splitCells(line);
  if (cells.length >= 2 && cells[0].toLowerCase() === 'resource') {
    var path = cells[1];
    var startCol = line.indexOf(path);
    var endCol = startCol + path.length;
    var extension = _path2['default'].extname(path);
    var _name = _path2['default'].basename(path, extension);
    if (column > startCol && column < endCol) {
      return {
        startCol: startCol,
        endCol: endCol,
        path: path,
        name: _name,
        extension: extension
      };
    }
  }
  return undefined;
}

exports['default'] = {
  getKeywordSuggestions: function getKeywordSuggestions(textEditor, point, autocompleteRobotProvider) {
    var line = textEditor.lineTextForBufferRow(point.row);
    var importInfo = findImportAtPosition(line, point.column);
    if (importInfo === undefined) {
      return undefined;
    }

    var matchingImportedResources = new Set();

    // accurate import
    var activeResource = _common2['default'].getCurrentResource(textEditor.getPath(), autocompleteRobotProvider);
    if (activeResource) {
      for (var importedResource of activeResource.imports.resources) {
        var importAbsolutePath = _path2['default'].join(_path2['default'].dirname(activeResource.path), importInfo.path);
        importedResource = autocompleteRobotProvider.getResourceByKey(importedResource.resourceKey);
        if (importedResource && importedResource.path === _path2['default'].normalize(importAbsolutePath)) {
          matchingImportedResources.add(importedResource);
          break;
        }
      }
    }

    if (matchingImportedResources.size === 0) {
      // approximate import
      var resourceKeys = autocompleteRobotProvider.getResourceKeys();
      for (var resourceKey of resourceKeys) {
        var resource = autocompleteRobotProvider.getResourceByKey(resourceKey);
        if (resource && resource.name === importInfo.name && resource.extension === importInfo.extension) {
          matchingImportedResources.add(resource);
        }
      }
    }

    if (matchingImportedResources.size === 0) {
      return undefined;
    }

    // build hyperclick callback
    var callback = undefined;
    if (matchingImportedResources.size === 1) {
      (function () {
        var resource = Array.from(matchingImportedResources)[0];
        callback = function () {
          atom.workspace.open(resource.path, { initialLine: 0, initialColumn: 0 }).then(function (editor) {
            return editor.scrollToCursorPosition({ center: true });
          })['catch'](function (error) {
            return console.log('Error opening editor: ' + error);
          });
        };
      })();
    } else {
      callback = [];

      var _loop = function (resource) {
        callback.push({
          title: resource.path,
          callback: function callback() {
            atom.workspace.open(resource.path, { initialLine: 0, initialColumn: 0 }).then(function (editor) {
              return editor.scrollToCursorPosition({ center: true });
            })['catch'](function (error) {
              return console.log('Error opening editor: ' + error);
            });
          }
        });
      };

      for (var resource of Array.from(matchingImportedResources)) {
        _loop(resource);
      }
    }

    return {
      range: new _atom.Range(new _atom.Point(point.row, importInfo.startCol), new _atom.Point(point.row, importInfo.endCol)),
      callback: callback
    };
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2h5cGVyY2xpY2stcm9ib3QtZnJhbWV3b3JrL2xpYi9oeXBlcmNsaWNrLXJlc291cmNlLWltcG9ydHMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7O29CQUM2QixNQUFNOztvQkFDYixNQUFNOzs7O2tCQUNiLElBQUk7Ozs7c0JBQ0EsVUFBVTs7OztBQUo3QixXQUFXLENBQUE7O0FBTVgsU0FBUyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsTUFBTSxFQUFDO0FBQ3pDLE1BQU0sS0FBSyxHQUFHLG9CQUFPLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUN0QyxNQUFHLEtBQUssQ0FBQyxNQUFNLElBQUUsQ0FBQyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLEVBQUUsS0FBRyxVQUFVLEVBQUM7QUFDeEQsUUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3JCLFFBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDcEMsUUFBTSxNQUFNLEdBQUcsUUFBUSxHQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDcEMsUUFBTSxTQUFTLEdBQUcsa0JBQVUsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3pDLFFBQU0sS0FBSSxHQUFHLGtCQUFVLFFBQVEsQ0FBQyxJQUFJLEVBQUUsU0FBUyxDQUFDLENBQUE7QUFDaEQsUUFBSSxBQUFDLE1BQU0sR0FBQyxRQUFRLElBQU0sTUFBTSxHQUFDLE1BQU0sQUFBQyxFQUFFO0FBQ3hDLGFBQU87QUFDTCxnQkFBUSxFQUFSLFFBQVE7QUFDUixjQUFNLEVBQU4sTUFBTTtBQUNOLFlBQUksRUFBSixJQUFJO0FBQ0osWUFBSSxFQUFKLEtBQUk7QUFDSixpQkFBUyxFQUFULFNBQVM7T0FDVixDQUFDO0tBQ0g7R0FDRjtBQUNELFNBQU8sU0FBUyxDQUFBO0NBQ2pCOztxQkFFYztBQUNiLHVCQUFxQixFQUFBLCtCQUFDLFVBQVUsRUFBRSxLQUFLLEVBQUUseUJBQXlCLEVBQUM7QUFDakUsUUFBTSxJQUFJLEdBQUcsVUFBVSxDQUFDLG9CQUFvQixDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUN4RCxRQUFNLFVBQVUsR0FBRyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQzNELFFBQUcsVUFBVSxLQUFHLFNBQVMsRUFBQztBQUN4QixhQUFPLFNBQVMsQ0FBQTtLQUNqQjs7QUFFRCxRQUFNLHlCQUF5QixHQUFHLElBQUksR0FBRyxFQUFFLENBQUE7OztBQUczQyxRQUFNLGNBQWMsR0FBRyxvQkFBTyxrQkFBa0IsQ0FBQyxVQUFVLENBQUMsT0FBTyxFQUFFLEVBQUUseUJBQXlCLENBQUMsQ0FBQTtBQUNqRyxRQUFHLGNBQWMsRUFBQztBQUNoQixXQUFJLElBQUksZ0JBQWdCLElBQUksY0FBYyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEVBQUM7QUFDM0QsWUFBTSxrQkFBa0IsR0FBRyxrQkFBVSxJQUFJLENBQ3ZDLGtCQUFVLE9BQU8sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQzFELHdCQUFnQixHQUFHLHlCQUF5QixDQUFDLGdCQUFnQixDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQzNGLFlBQUcsZ0JBQWdCLElBQUksZ0JBQWdCLENBQUMsSUFBSSxLQUFHLGtCQUFVLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxFQUFDO0FBQ3JGLG1DQUF5QixDQUFDLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQy9DLGdCQUFLO1NBQ047T0FDRjtLQUNGOztBQUVELFFBQUcseUJBQXlCLENBQUMsSUFBSSxLQUFHLENBQUMsRUFBQzs7QUFFcEMsVUFBTSxZQUFZLEdBQUcseUJBQXlCLENBQUMsZUFBZSxFQUFFLENBQUE7QUFDaEUsV0FBSSxJQUFNLFdBQVcsSUFBSSxZQUFZLEVBQUM7QUFDcEMsWUFBTSxRQUFRLEdBQUcseUJBQXlCLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDeEUsWUFBRyxRQUFRLElBQUksUUFBUSxDQUFDLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSSxJQUFJLFFBQVEsQ0FBQyxTQUFTLEtBQUssVUFBVSxDQUFDLFNBQVMsRUFBQztBQUM5RixtQ0FBeUIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7U0FDeEM7T0FDRjtLQUNGOztBQUVELFFBQUkseUJBQXlCLENBQUMsSUFBSSxLQUFHLENBQUMsRUFBRTtBQUN0QyxhQUFPLFNBQVMsQ0FBQztLQUNsQjs7O0FBR0QsUUFBSSxRQUFRLEdBQUcsU0FBUyxDQUFDO0FBQ3pCLFFBQUcseUJBQXlCLENBQUMsSUFBSSxLQUFHLENBQUMsRUFBRTs7QUFDckMsWUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyx5QkFBeUIsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQ3pELGdCQUFRLEdBQUcsWUFBTTtBQUNmLGNBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxJQUFJLEVBQUUsRUFBQyxXQUFXLEVBQUUsQ0FBQyxFQUFFLGFBQWEsRUFBRSxDQUFDLEVBQUMsQ0FBQyxDQUNyRSxJQUFJLENBQUMsVUFBQSxNQUFNO21CQUFJLE1BQU0sQ0FBQyxzQkFBc0IsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQztXQUFBLENBQUMsU0FDeEQsQ0FBQyxVQUFBLEtBQUs7bUJBQUksT0FBTyxDQUFDLEdBQUcsNEJBQTBCLEtBQUssQ0FBRztXQUFBLENBQUMsQ0FBQTtTQUMvRCxDQUFBOztLQUNGLE1BQU07QUFDTCxjQUFRLEdBQUcsRUFBRSxDQUFDOzs0QkFDSCxRQUFRO0FBQ2pCLGdCQUFRLENBQUMsSUFBSSxDQUFDO0FBQ1osZUFBSyxFQUFFLFFBQVEsQ0FBQyxJQUFJO0FBQ3BCLGtCQUFRLEVBQUEsb0JBQUc7QUFDVCxnQkFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLElBQUksRUFBRSxFQUFDLFdBQVcsRUFBRSxDQUFDLEVBQUUsYUFBYSxFQUFFLENBQUMsRUFBQyxDQUFDLENBQ3JFLElBQUksQ0FBQyxVQUFBLE1BQU07cUJBQUksTUFBTSxDQUFDLHNCQUFzQixDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDO2FBQUEsQ0FBQyxTQUN4RCxDQUFDLFVBQUEsS0FBSztxQkFBSSxPQUFPLENBQUMsR0FBRyw0QkFBMEIsS0FBSyxDQUFHO2FBQUEsQ0FBQyxDQUFBO1dBQy9EO1NBQ0YsQ0FBQyxDQUFBOzs7QUFSSixXQUFLLElBQU0sUUFBUSxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMseUJBQXlCLENBQUMsRUFBRTtjQUFuRCxRQUFRO09BU2xCO0tBQ0Y7O0FBRUQsV0FBTztBQUNMLFdBQUssRUFBRSxnQkFBVSxnQkFBVSxLQUFLLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxRQUFRLENBQUMsRUFBRSxnQkFBVSxLQUFLLENBQUMsR0FBRyxFQUFFLFVBQVUsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNwRyxjQUFRLEVBQVIsUUFBUTtLQUNULENBQUM7R0FDSDtDQUNGIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2h5cGVyY2xpY2stcm9ib3QtZnJhbWV3b3JrL2xpYi9oeXBlcmNsaWNrLXJlc291cmNlLWltcG9ydHMuanMiLCJzb3VyY2VzQ29udGVudCI6WyIndXNlIGJhYmVsJ1xuaW1wb3J0IHsgUG9pbnQsIFJhbmdlIH0gZnJvbSAnYXRvbSdcbmltcG9ydCBwYXRoVXRpbHMgZnJvbSAncGF0aCdcbmltcG9ydCBmcyBmcm9tICdmcydcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24nXG5cbmZ1bmN0aW9uIGZpbmRJbXBvcnRBdFBvc2l0aW9uKGxpbmUsIGNvbHVtbil7XG4gIGNvbnN0IGNlbGxzID0gY29tbW9uLnNwbGl0Q2VsbHMobGluZSk7XG4gIGlmKGNlbGxzLmxlbmd0aD49MiAmJiBjZWxsc1swXS50b0xvd2VyQ2FzZSgpPT09J3Jlc291cmNlJyl7XG4gICAgY29uc3QgcGF0aCA9IGNlbGxzWzFdXG4gICAgY29uc3Qgc3RhcnRDb2wgPSBsaW5lLmluZGV4T2YocGF0aCk7XG4gICAgY29uc3QgZW5kQ29sID0gc3RhcnRDb2wrcGF0aC5sZW5ndGg7XG4gICAgY29uc3QgZXh0ZW5zaW9uID0gcGF0aFV0aWxzLmV4dG5hbWUocGF0aClcbiAgICBjb25zdCBuYW1lID0gcGF0aFV0aWxzLmJhc2VuYW1lKHBhdGgsIGV4dGVuc2lvbilcbiAgICBpZiAoKGNvbHVtbj5zdGFydENvbCkgJiYgKGNvbHVtbjxlbmRDb2wpKSB7XG4gICAgICByZXR1cm4ge1xuICAgICAgICBzdGFydENvbCxcbiAgICAgICAgZW5kQ29sLFxuICAgICAgICBwYXRoLFxuICAgICAgICBuYW1lLFxuICAgICAgICBleHRlbnNpb25cbiAgICAgIH07XG4gICAgfVxuICB9XG4gIHJldHVybiB1bmRlZmluZWRcbn1cblxuZXhwb3J0IGRlZmF1bHQge1xuICBnZXRLZXl3b3JkU3VnZ2VzdGlvbnModGV4dEVkaXRvciwgcG9pbnQsIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIpe1xuICAgIGNvbnN0IGxpbmUgPSB0ZXh0RWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KHBvaW50LnJvdyk7XG4gICAgY29uc3QgaW1wb3J0SW5mbyA9IGZpbmRJbXBvcnRBdFBvc2l0aW9uKGxpbmUsIHBvaW50LmNvbHVtbilcbiAgICBpZihpbXBvcnRJbmZvPT09dW5kZWZpbmVkKXtcbiAgICAgIHJldHVybiB1bmRlZmluZWRcbiAgICB9XG5cbiAgICBjb25zdCBtYXRjaGluZ0ltcG9ydGVkUmVzb3VyY2VzID0gbmV3IFNldCgpXG5cbiAgICAvLyBhY2N1cmF0ZSBpbXBvcnRcbiAgICBjb25zdCBhY3RpdmVSZXNvdXJjZSA9IGNvbW1vbi5nZXRDdXJyZW50UmVzb3VyY2UodGV4dEVkaXRvci5nZXRQYXRoKCksIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIpXG4gICAgaWYoYWN0aXZlUmVzb3VyY2Upe1xuICAgICAgZm9yKGxldCBpbXBvcnRlZFJlc291cmNlIG9mIGFjdGl2ZVJlc291cmNlLmltcG9ydHMucmVzb3VyY2VzKXtcbiAgICAgICAgY29uc3QgaW1wb3J0QWJzb2x1dGVQYXRoID0gcGF0aFV0aWxzLmpvaW4oXG4gICAgICAgICAgcGF0aFV0aWxzLmRpcm5hbWUoYWN0aXZlUmVzb3VyY2UucGF0aCksIGltcG9ydEluZm8ucGF0aClcbiAgICAgICAgaW1wb3J0ZWRSZXNvdXJjZSA9IGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VCeUtleShpbXBvcnRlZFJlc291cmNlLnJlc291cmNlS2V5KVxuICAgICAgICBpZihpbXBvcnRlZFJlc291cmNlICYmIGltcG9ydGVkUmVzb3VyY2UucGF0aD09PXBhdGhVdGlscy5ub3JtYWxpemUoaW1wb3J0QWJzb2x1dGVQYXRoKSl7XG4gICAgICAgICAgbWF0Y2hpbmdJbXBvcnRlZFJlc291cmNlcy5hZGQoaW1wb3J0ZWRSZXNvdXJjZSlcbiAgICAgICAgICBicmVha1xuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYobWF0Y2hpbmdJbXBvcnRlZFJlc291cmNlcy5zaXplPT09MCl7XG4gICAgICAvLyBhcHByb3hpbWF0ZSBpbXBvcnRcbiAgICAgIGNvbnN0IHJlc291cmNlS2V5cyA9IGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VLZXlzKClcbiAgICAgIGZvcihjb25zdCByZXNvdXJjZUtleSBvZiByZXNvdXJjZUtleXMpe1xuICAgICAgICBjb25zdCByZXNvdXJjZSA9IGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VCeUtleShyZXNvdXJjZUtleSlcbiAgICAgICAgaWYocmVzb3VyY2UgJiYgcmVzb3VyY2UubmFtZSA9PT0gaW1wb3J0SW5mby5uYW1lICYmIHJlc291cmNlLmV4dGVuc2lvbiA9PT0gaW1wb3J0SW5mby5leHRlbnNpb24pe1xuICAgICAgICAgIG1hdGNoaW5nSW1wb3J0ZWRSZXNvdXJjZXMuYWRkKHJlc291cmNlKVxuICAgICAgICB9XG4gICAgICB9XG4gICAgfVxuXG4gICAgaWYgKG1hdGNoaW5nSW1wb3J0ZWRSZXNvdXJjZXMuc2l6ZT09PTApIHtcbiAgICAgIHJldHVybiB1bmRlZmluZWQ7XG4gICAgfVxuXG4gICAgLy8gYnVpbGQgaHlwZXJjbGljayBjYWxsYmFja1xuICAgIGxldCBjYWxsYmFjayA9IHVuZGVmaW5lZDtcbiAgICBpZihtYXRjaGluZ0ltcG9ydGVkUmVzb3VyY2VzLnNpemU9PT0xKSB7XG4gICAgICBjb25zdCByZXNvdXJjZSA9IEFycmF5LmZyb20obWF0Y2hpbmdJbXBvcnRlZFJlc291cmNlcylbMF1cbiAgICAgIGNhbGxiYWNrID0gKCkgPT4ge1xuICAgICAgICBhdG9tLndvcmtzcGFjZS5vcGVuKHJlc291cmNlLnBhdGgsIHtpbml0aWFsTGluZTogMCwgaW5pdGlhbENvbHVtbjogMH0pXG4gICAgICAgIC50aGVuKGVkaXRvciA9PiBlZGl0b3Iuc2Nyb2xsVG9DdXJzb3JQb3NpdGlvbih7Y2VudGVyOiB0cnVlfSkpXG4gICAgICAgIC5jYXRjaChlcnJvciA9PiBjb25zb2xlLmxvZyhgRXJyb3Igb3BlbmluZyBlZGl0b3I6ICR7ZXJyb3J9YCkpXG4gICAgICB9XG4gICAgfSBlbHNlIHtcbiAgICAgIGNhbGxiYWNrID0gW107XG4gICAgICBmb3IgKGNvbnN0IHJlc291cmNlIG9mIEFycmF5LmZyb20obWF0Y2hpbmdJbXBvcnRlZFJlc291cmNlcykpIHtcbiAgICAgICAgY2FsbGJhY2sucHVzaCh7XG4gICAgICAgICAgdGl0bGU6IHJlc291cmNlLnBhdGgsXG4gICAgICAgICAgY2FsbGJhY2soKSB7XG4gICAgICAgICAgICBhdG9tLndvcmtzcGFjZS5vcGVuKHJlc291cmNlLnBhdGgsIHtpbml0aWFsTGluZTogMCwgaW5pdGlhbENvbHVtbjogMH0pXG4gICAgICAgICAgICAudGhlbihlZGl0b3IgPT4gZWRpdG9yLnNjcm9sbFRvQ3Vyc29yUG9zaXRpb24oe2NlbnRlcjogdHJ1ZX0pKVxuICAgICAgICAgICAgLmNhdGNoKGVycm9yID0+IGNvbnNvbGUubG9nKGBFcnJvciBvcGVuaW5nIGVkaXRvcjogJHtlcnJvcn1gKSlcbiAgICAgICAgICB9XG4gICAgICAgIH0pXG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJhbmdlOiBuZXcgUmFuZ2UobmV3IFBvaW50KHBvaW50LnJvdywgaW1wb3J0SW5mby5zdGFydENvbCksIG5ldyBQb2ludChwb2ludC5yb3csIGltcG9ydEluZm8uZW5kQ29sKSksXG4gICAgICBjYWxsYmFja1xuICAgIH07XG4gIH1cbn1cbiJdfQ==