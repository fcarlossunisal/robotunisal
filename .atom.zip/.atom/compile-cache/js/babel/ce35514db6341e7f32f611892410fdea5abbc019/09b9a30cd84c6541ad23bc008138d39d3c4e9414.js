function _interopRequireWildcard(obj) { if (obj && obj.__esModule) { return obj; } else { var newObj = {}; if (obj != null) { for (var key in obj) { if (Object.prototype.hasOwnProperty.call(obj, key)) newObj[key] = obj[key]; } } newObj['default'] = obj; return newObj; } }

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _util = require('util');

var _util2 = _interopRequireDefault(_util);

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fuzzaldrinPlus = require('fuzzaldrin-plus');

var _fuzzaldrinPlus2 = _interopRequireDefault(_fuzzaldrinPlus);

var _commonJs = require('./common.js');

var _commonJs2 = _interopRequireDefault(_commonJs);

var _pathResolver = require('./path-resolver');

var pathResolver = _interopRequireWildcard(_pathResolver);

/**
 *
 * Keywords mapped by Robot resource files
 * Format:
 * {
 *     '/dir1/dir2/builtin.xml': {
 *         resourceKey: 'builtin',
 *         name: 'BuiltIn',
 *         extension: '.xml',
 *         path: '/dir1/dir2/BuiltIn.xml',  # normalized
 *         libraryPath: '/dir1/dir2/BuiltIn.py'
 *         hasTestCases: false,
 *         hasKeywords: true,
 *         isLibrary: true
 *         imports: {
 *           libraries: [{name: 'libraryName', alias: 'withNameAlias'}, ...],
 *           resources: [{
 *             path: 'resource path'  // as found in 'Resource' declaration
 *             name: 'resourceName',
 *             extension: '.robot',
 *             resourceKey: 'resource key'}, ...], // 'resourceKey' is undefined if it could not be found in parsed resourcesMap
 *         },
 *         keywords: [{
 *                 name: '',
 *                 documentation: '',
 *                 arguments: ['', '', ...],
 *                 rowNo: 0,
 *                 colNo: 0,
 *                 local: true/false # Whether keyword is only visible locally
 *                 resource:{resourceKey: '', ...} // parent resource
 *             }, ...
 *         ],
 *     },
 *     ...
 * }
 */
'use babel';
var resourcesMap = {};

// Keywords mapped by keyword name
var keywordsMap = {};

// Removes keywords depending on resourceFilter.
// Undefined resourceFilter will cause all keywords to be cleared.
var reset = function reset(resourceFilter) {
  if (resourceFilter) {
    resourceFilter = _commonJs2['default'].getResourceKey(resourceFilter);
    for (var key in resourcesMap) {
      if (key.indexOf(resourceFilter) === 0) {
        delete resourcesMap[key];
      }
    }
  } else {
    clearObj(resourcesMap);
  }
  rebuildKeywordsMap();
};

var resetKeywordsMap = function resetKeywordsMap(resourceKey, keywords) {
  resourceKey = _commonJs2['default'].getResourceKey(resourceKey);
  var newKwList;
  keywords.forEach(function (keyword) {
    var kwname = keyword.name.toLowerCase();
    var kwList = keywordsMap[kwname];
    if (kwList) {
      newKwList = [];
      kwList.forEach(function (kw) {
        if (kw.resource.resourceKey !== resourceKey) {
          newKwList.push(kw);
        }
      });
      if (newKwList.length > 0) {
        keywordsMap[kwname] = newKwList;
      } else {
        delete keywordsMap[kwname];
      }
    }
  });
};

var rebuildKeywordsMap = function rebuildKeywordsMap() {
  var resourceKey, resource, keywordList;
  clearObj(keywordsMap);
  for (resourceKey in resourcesMap) {
    resource = resourcesMap[resourceKey];
    addKeywordsToMap(resource.keywords);
  }
};

var addKeywordsToMap = function addKeywordsToMap(keywords) {
  var keywordList;
  keywords.forEach(function (keyword) {
    var kwname = keyword.name.toLowerCase();
    keywordList = keywordsMap[kwname];
    if (!keywordList) {
      keywordList = [];
      keywordsMap[kwname] = keywordList;
    }
    keywordList.push(keyword);
  });
};

var addResource = function addResource(parsedRobotInfo, resourcePath) {
  var resourceName = _path2['default'].basename(resourcePath, _path2['default'].extname(resourcePath));
  addKeywords(parsedRobotInfo, _commonJs2['default'].getResourceKey(resourcePath), resourcePath, resourceName);
};

var addLibrary = function addLibrary(parsedRobotInfo, libdocPath, libraryName, sourcePath) {
  addKeywords(parsedRobotInfo, _commonJs2['default'].getResourceKey(libraryName), libdocPath, libraryName, true, sourcePath);
};

// Adds keywords to repository under resource specified by resourceKey.
var addKeywords = function addKeywords(parsedRobotInfo, resourceKey, path, name) {
  var isLibrary = arguments.length <= 4 || arguments[4] === undefined ? false : arguments[4];
  var libraryPath = arguments.length <= 5 || arguments[5] === undefined ? undefined : arguments[5];

  path = _path2['default'].normalize(path);
  var extension = _path2['default'].extname(path);
  hasTestCases = parsedRobotInfo.testCases.length > 0, hasKeywords = parsedRobotInfo.keywords.length > 0;
  var importedResources = parsedRobotInfo.resources.map(function (res) {
    return {
      name: _path2['default'].basename(res.path, _path2['default'].extname(res.path)),
      extension: _path2['default'].extname(res.path),
      path: res.path
    };
  });
  var resource = {
    resourceKey: resourceKey,
    path: path,
    libraryPath: libraryPath,
    name: name,
    extension: extension,
    imports: {
      libraries: parsedRobotInfo.libraries,
      resources: importedResources
    },
    hasTestCases: hasTestCases,
    hasKeywords: hasKeywords,
    isLibrary: isLibrary
  };

  // Add some helper properties to each keyword
  for (var i = 0; i < parsedRobotInfo.keywords.length; i++) {
    parsedRobotInfo.keywords[i].resource = resource;
    parsedRobotInfo.keywords[i].local = hasTestCases;
  }

  // Populate keywordsMap
  if (resourcesMap[resourceKey]) {
    resetKeywordsMap(resourceKey, resourcesMap[resourceKey].keywords);
  }
  addKeywordsToMap(parsedRobotInfo.keywords);

  // Populate resourcesMap
  resourcesMap[resourceKey] = {
    resourceKey: resourceKey,
    name: name,
    path: path,
    libraryPath: libraryPath,
    extension: extension,
    keywords: parsedRobotInfo.keywords,
    imports: {
      libraries: parsedRobotInfo.libraries,
      resources: importedResources
    },
    hasTestCases: hasTestCases,
    hasKeywords: hasKeywords,
    isLibrary: isLibrary
  };
  return;
};

// Returns a list of keywords scored by query string.
// resourceKeys - Set: limits suggestions to only these resources
// If 'query' is not defined or is '', returns all keywords. Scores will be identical for each entry.
var score = function score(query, resourceKeys) {
  query = query || '';
  query = query.trim().toLowerCase();
  var suggestions = [];
  var prepQuery = _fuzzaldrinPlus2['default'].prepQuery(query);
  for (var resourceKey in resourcesMap) {
    if (resourceKeys.size > 0 && !resourceKeys.has(resourceKey)) {
      continue;
    }
    var resource = resourcesMap[resourceKey];
    if (resource) {
      for (var i = 0; i < resource.keywords.length; i++) {
        var keyword = resource.keywords[i];
        var score = query === '' ? 1 : _fuzzaldrinPlus2['default'].score(keyword.name, query, prepQuery); // If query is empty string, we will show all keywords.
        if (score) {
          suggestions.push({
            keyword: keyword,
            score: score
          });
        }
      }
    }
  }

  return suggestions;
};

function printDebugInfo(options) {
  options = options || {
    showLibdocFiles: true,
    showRobotFiles: true,
    showAllSuggestions: false
  };
  var robotFiles = [],
      libdocFiles = [];
  var ext;
  for (key in resourcesMap) {
    ext = _path2['default'].extname(key);
    if (ext === '.xml' || ext === '.html') {
      libdocFiles.push(_path2['default'].basename(key));
    } else {
      robotFiles.push(_path2['default'].basename(key));
    }
  }
  if (options.showRobotFiles) {
    console.log('Autocomplete robot files:' + robotFiles);
  }
  if (options.showLibdocFiles) {
    console.log('Autocomplete libdoc files:' + libdocFiles);
  }
  if (options.showAllSuggestions) {
    console.log('All suggestions: ' + JSON.stringify(resourcesMap, null, 2));
    // console.log('All suggestions: ' + JSON.stringify(keywordsMap, null, 2));
  }
}

var clearObj = function clearObj(obj) {
  for (var key in obj) {
    if (obj.hasOwnProperty(key)) {
      delete obj[key];
    }
  }
};

/**
 * Returns Maps of resources grouped by path and by name:
 * {resourcesByName: Map(path, resource), resourcesByName: Map(name, [resource])}
 * lowerCase: if true, all names will be lowercased.
 * Path is normalized in both key and value.
 */
var computeGroupedResources = function computeGroupedResources() {
  var lowerCaseName = arguments.length <= 0 || arguments[0] === undefined ? false : arguments[0];

  var resourcesByName = new Map();
  var resourcesByPath = new Map();
  for (var resourceKey in resourcesMap) {
    var _resource = resourcesMap[resourceKey];
    var resourceName = lowerCaseName ? _resource.name.toLowerCase() : _resource.name;

    // group by name
    var names = resourcesByName.get(resourceName);
    if (!names) {
      names = [];
      resourcesByName.set(resourceName, names);
    }
    names.push(_resource);

    // group by path
    var resourcePath = _resource.path;
    resourcesByPath.set(_resource.path, _resource);
  }
  return { resourcesByName: resourcesByName, resourcesByPath: resourcesByPath };
};

/**
 * Updates imports with corresponding parsed robot resource files.
 * {... imports:{
 *   resources: [{path, name, extenaion, resourceKey}]  // 'resourceKey' element will be added if import is resolved.
 * }}
 * Returns Set of valid imported robot paths that are not found in this project.
 * These cross project resources could be parsed and resolved as imports in a
 * second pass.
 */
function resolveImports(resource) {
  var resourcePath = _path2['default'].dirname(resource.path);
  var res = new Set();
  if (resource) {
    for (var importedResourceInfo of resource.imports.resources) {
      var importedPath = pathResolver.resolve(importedResourceInfo.path, resourcePath);
      if (importedPath) {
        // import path points to valid robot resource
        var importedResourceKey = _commonJs2['default'].getResourceKey(importedPath);
        var importedResource = resourcesMap[importedResourceKey];
        if (importedResource) {
          // resource is already parsed
          importedResourceInfo.resourceKey = importedResourceKey;
        } else {
          // resource missing. probably is not part of this project.
          res.add(importedPath);
        }
      }
    }
  }
  return res;
}

function resolveAllImports() {
  var res = new Set();
  for (var resourceKey in resourcesMap) {
    resource = resourcesMap[resourceKey];
    var missingRessourcePaths = resolveImports(resource);
    missingRessourcePaths.forEach(function (path) {
      return res.add(path);
    });
  }
  return res;
}

module.exports = {
  reset: reset,
  addResource: addResource,
  addLibrary: addLibrary,
  score: score,
  printDebugInfo: printDebugInfo,
  resourcesMap: resourcesMap,
  keywordsMap: keywordsMap,
  computeGroupedResources: computeGroupedResources,
  resolveImports: resolveImports,
  resolveAllImports: resolveAllImports
};
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1yb2JvdC1mcmFtZXdvcmsvbGliL2tleXdvcmRzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7b0JBQ2lCLE1BQU07Ozs7b0JBQ0QsTUFBTTs7Ozs4QkFDTCxpQkFBaUI7Ozs7d0JBQ3JCLGFBQWE7Ozs7NEJBQ0YsaUJBQWlCOztJQUFuQyxZQUFZOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUx4QixXQUFXLENBQUE7QUE0Q1gsSUFBSSxZQUFZLEdBQUcsRUFBRSxDQUFDOzs7QUFHdEIsSUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDOzs7O0FBSXJCLElBQUksS0FBSyxHQUFHLFNBQVIsS0FBSyxDQUFZLGNBQWMsRUFBRTtBQUNuQyxNQUFHLGNBQWMsRUFBQztBQUNoQixrQkFBYyxHQUFHLHNCQUFPLGNBQWMsQ0FBQyxjQUFjLENBQUMsQ0FBQztBQUN2RCxTQUFJLElBQUksR0FBRyxJQUFJLFlBQVksRUFBQztBQUMxQixVQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsY0FBYyxDQUFDLEtBQUcsQ0FBQyxFQUFDO0FBQ2pDLGVBQU8sWUFBWSxDQUFDLEdBQUcsQ0FBQyxDQUFDO09BQzFCO0tBQ0Y7R0FDRixNQUFLO0FBQ0osWUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDO0dBQ3hCO0FBQ0Qsb0JBQWtCLEVBQUUsQ0FBQztDQUN0QixDQUFBOztBQUVELElBQUksZ0JBQWdCLEdBQUcsU0FBbkIsZ0JBQWdCLENBQVksV0FBVyxFQUFFLFFBQVEsRUFBQztBQUNwRCxhQUFXLEdBQUcsc0JBQU8sY0FBYyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ2pELE1BQUksU0FBUyxDQUFDO0FBQ2QsVUFBUSxDQUFDLE9BQU8sQ0FBQyxVQUFTLE9BQU8sRUFBQztBQUNoQyxRQUFJLE1BQU0sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDO0FBQ3hDLFFBQUksTUFBTSxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNqQyxRQUFHLE1BQU0sRUFBQztBQUNSLGVBQVMsR0FBRyxFQUFFLENBQUM7QUFDZixZQUFNLENBQUMsT0FBTyxDQUFDLFVBQVMsRUFBRSxFQUFDO0FBQ3pCLFlBQUcsRUFBRSxDQUFDLFFBQVEsQ0FBQyxXQUFXLEtBQUcsV0FBVyxFQUFDO0FBQ3ZDLG1CQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO1NBQ3BCO09BQ0YsQ0FBQyxDQUFDO0FBQ0gsVUFBRyxTQUFTLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBQztBQUNwQixtQkFBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFNBQVMsQ0FBQztPQUNqQyxNQUFLO0FBQ0osZUFBTyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7T0FDNUI7S0FDRjtHQUNGLENBQUMsQ0FBQztDQUNKLENBQUE7O0FBRUQsSUFBSSxrQkFBa0IsR0FBRyxTQUFyQixrQkFBa0IsR0FBYTtBQUNqQyxNQUFJLFdBQVcsRUFBRSxRQUFRLEVBQUUsV0FBVyxDQUFDO0FBQ3ZDLFVBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN0QixPQUFJLFdBQVcsSUFBSSxZQUFZLEVBQUM7QUFDOUIsWUFBUSxHQUFHLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUNyQyxvQkFBZ0IsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7R0FDckM7Q0FDRixDQUFBOztBQUVELElBQUksZ0JBQWdCLEdBQUcsU0FBbkIsZ0JBQWdCLENBQVksUUFBUSxFQUFDO0FBQ3ZDLE1BQUksV0FBVyxDQUFDO0FBQ2hCLFVBQVEsQ0FBQyxPQUFPLENBQUMsVUFBUyxPQUFPLEVBQUM7QUFDaEMsUUFBSSxNQUFNLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUN4QyxlQUFXLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ2xDLFFBQUcsQ0FBQyxXQUFXLEVBQUM7QUFDZCxpQkFBVyxHQUFHLEVBQUUsQ0FBQTtBQUNoQixpQkFBVyxDQUFDLE1BQU0sQ0FBQyxHQUFHLFdBQVcsQ0FBQztLQUNuQztBQUNELGVBQVcsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQUM7R0FDM0IsQ0FBQyxDQUFDO0NBQ0osQ0FBQTs7QUFFRCxJQUFJLFdBQVcsR0FBRyxTQUFkLFdBQVcsQ0FBWSxlQUFlLEVBQUUsWUFBWSxFQUFFO0FBQ3hELE1BQUksWUFBWSxHQUFHLGtCQUFVLFFBQVEsQ0FBQyxZQUFZLEVBQUUsa0JBQVUsT0FBTyxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUM7QUFDckYsYUFBVyxDQUFDLGVBQWUsRUFBRSxzQkFBTyxjQUFjLENBQUMsWUFBWSxDQUFDLEVBQUUsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFBO0NBQzlGLENBQUE7O0FBRUQsSUFBSSxVQUFVLEdBQUcsU0FBYixVQUFVLENBQVksZUFBZSxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsVUFBVSxFQUFFO0FBQzlFLGFBQVcsQ0FBQyxlQUFlLEVBQUUsc0JBQU8sY0FBYyxDQUFDLFdBQVcsQ0FBQyxFQUFFLFVBQVUsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLFVBQVUsQ0FBQyxDQUFBO0NBQzVHLENBQUE7OztBQUdELElBQUksV0FBVyxHQUFHLFNBQWQsV0FBVyxDQUFZLGVBQWUsRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBOEM7TUFBNUMsU0FBUyx5REFBRyxLQUFLO01BQUUsV0FBVyx5REFBRyxTQUFTOztBQUM3RyxNQUFJLEdBQUcsa0JBQVUsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ2hDLE1BQU0sU0FBUyxHQUFHLGtCQUFVLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUMxQyxjQUFZLEdBQUcsZUFBZSxDQUFDLFNBQVMsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxFQUNqRCxXQUFXLEdBQUcsZUFBZSxDQUFDLFFBQVEsQ0FBQyxNQUFNLEdBQUMsQ0FBQyxDQUFBO0FBQy9DLE1BQU0saUJBQWlCLEdBQUcsZUFBZSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBQSxHQUFHO1dBQUs7QUFDOUQsVUFBSSxFQUFFLGtCQUFVLFFBQVEsQ0FBQyxHQUFHLENBQUMsSUFBSSxFQUFFLGtCQUFVLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDL0QsZUFBUyxFQUFFLGtCQUFVLE9BQU8sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ3RDLFVBQUksRUFBRSxHQUFHLENBQUMsSUFBSTtLQUNmO0dBQUMsQ0FBQyxDQUFBO0FBQ0gsTUFBSSxRQUFRLEdBQUc7QUFDYixlQUFXLEVBQVgsV0FBVztBQUNYLFFBQUksRUFBSixJQUFJO0FBQ0osZUFBVyxFQUFYLFdBQVc7QUFDWCxRQUFJLEVBQUosSUFBSTtBQUNKLGFBQVMsRUFBVCxTQUFTO0FBQ1QsV0FBTyxFQUFFO0FBQ1AsZUFBUyxFQUFFLGVBQWUsQ0FBQyxTQUFTO0FBQ3BDLGVBQVMsRUFBRSxpQkFBaUI7S0FDN0I7QUFDRCxnQkFBWSxFQUFaLFlBQVk7QUFDWixlQUFXLEVBQVgsV0FBVztBQUNYLGFBQVMsRUFBVCxTQUFTO0dBQ1YsQ0FBQTs7O0FBR0QsT0FBSSxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFDO0FBQ3BELG1CQUFlLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7QUFDaEQsbUJBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxHQUFHLFlBQVksQ0FBQztHQUNsRDs7O0FBR0QsTUFBRyxZQUFZLENBQUMsV0FBVyxDQUFDLEVBQUM7QUFDM0Isb0JBQWdCLENBQUMsV0FBVyxFQUFFLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztHQUNuRTtBQUNELGtCQUFnQixDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7O0FBRzNDLGNBQVksQ0FBQyxXQUFXLENBQUMsR0FBRztBQUMxQixlQUFXLEVBQVgsV0FBVztBQUNYLFFBQUksRUFBSixJQUFJO0FBQ0osUUFBSSxFQUFKLElBQUk7QUFDSixlQUFXLEVBQVgsV0FBVztBQUNYLGFBQVMsRUFBVCxTQUFTO0FBQ1QsWUFBUSxFQUFFLGVBQWUsQ0FBQyxRQUFRO0FBQ2xDLFdBQU8sRUFBRTtBQUNQLGVBQVMsRUFBRSxlQUFlLENBQUMsU0FBUztBQUNwQyxlQUFTLEVBQUUsaUJBQWlCO0tBQzdCO0FBQ0QsZ0JBQVksRUFBWixZQUFZO0FBQ1osZUFBVyxFQUFYLFdBQVc7QUFDWCxhQUFTLEVBQVQsU0FBUztHQUNWLENBQUM7QUFDRixTQUFNO0NBQ1AsQ0FBQTs7Ozs7QUFLRCxJQUFJLEtBQUssR0FBRyxlQUFTLEtBQUssRUFBRSxZQUFZLEVBQUU7QUFDeEMsT0FBSyxHQUFHLEtBQUssSUFBSSxFQUFFLENBQUM7QUFDcEIsT0FBSyxHQUFHLEtBQUssQ0FBQyxJQUFJLEVBQUUsQ0FBQyxXQUFXLEVBQUUsQ0FBQztBQUNuQyxNQUFJLFdBQVcsR0FBRyxFQUFFLENBQUM7QUFDckIsTUFBSSxTQUFTLEdBQUcsNEJBQVcsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVDLE9BQU0sSUFBSSxXQUFXLElBQUksWUFBWSxFQUFFO0FBQ3JDLFFBQUcsWUFBWSxDQUFDLElBQUksR0FBQyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxFQUFDO0FBQ3ZELGVBQVM7S0FDVjtBQUNELFFBQUksUUFBUSxHQUFHLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQztBQUN6QyxRQUFJLFFBQVEsRUFBRTtBQUNaLFdBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNqRCxZQUFJLE9BQU8sR0FBRyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ25DLFlBQUksS0FBSyxHQUFHLEtBQUssS0FBRyxFQUFFLEdBQUMsQ0FBQyxHQUFDLDRCQUFXLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLEtBQUssRUFBRSxTQUFTLENBQUMsQ0FBQztBQUMxRSxZQUFJLEtBQUssRUFBRTtBQUNULHFCQUFXLENBQUMsSUFBSSxDQUFDO0FBQ2YsbUJBQU8sRUFBRyxPQUFPO0FBQ2pCLGlCQUFLLEVBQUUsS0FBSztXQUNiLENBQUMsQ0FBQztTQUNKO09BQ0Y7S0FDRjtHQUNGOztBQUVELFNBQU8sV0FBVyxDQUFDO0NBQ3BCLENBQUM7O0FBRUYsU0FBUyxjQUFjLENBQUMsT0FBTyxFQUFFO0FBQy9CLFNBQU8sR0FBRyxPQUFPLElBQUk7QUFDbkIsbUJBQWUsRUFBRSxJQUFJO0FBQ3JCLGtCQUFjLEVBQUUsSUFBSTtBQUNwQixzQkFBa0IsRUFBRSxLQUFLO0dBQzFCLENBQUM7QUFDRixNQUFJLFVBQVUsR0FBRyxFQUFFO01BQUUsV0FBVyxHQUFHLEVBQUUsQ0FBQztBQUN0QyxNQUFJLEdBQUcsQ0FBQztBQUNSLE9BQUksR0FBRyxJQUFJLFlBQVksRUFBQztBQUN0QixPQUFHLEdBQUcsa0JBQVUsT0FBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQzdCLFFBQUcsR0FBRyxLQUFHLE1BQU0sSUFBSSxHQUFHLEtBQUcsT0FBTyxFQUFDO0FBQy9CLGlCQUFXLENBQUMsSUFBSSxDQUFDLGtCQUFVLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDO0tBQzNDLE1BQUs7QUFDSixnQkFBVSxDQUFDLElBQUksQ0FBQyxrQkFBVSxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQztLQUMxQztHQUNGO0FBQ0QsTUFBRyxPQUFPLENBQUMsY0FBYyxFQUFDO0FBQ3hCLFdBQU8sQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEdBQUcsVUFBVSxDQUFDLENBQUM7R0FDdkQ7QUFDRCxNQUFHLE9BQU8sQ0FBQyxlQUFlLEVBQUM7QUFDekIsV0FBTyxDQUFDLEdBQUcsQ0FBQyw0QkFBNEIsR0FBRyxXQUFXLENBQUMsQ0FBQztHQUN6RDtBQUNELE1BQUcsT0FBTyxDQUFDLGtCQUFrQixFQUFDO0FBQzVCLFdBQU8sQ0FBQyxHQUFHLENBQUMsbUJBQW1CLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUM7O0dBRTFFO0NBQ0Y7O0FBRUQsSUFBSSxRQUFRLEdBQUcsU0FBWCxRQUFRLENBQVksR0FBRyxFQUFDO0FBQzFCLE9BQUssSUFBSSxHQUFHLElBQUksR0FBRyxFQUFDO0FBQ2xCLFFBQUksR0FBRyxDQUFDLGNBQWMsQ0FBQyxHQUFHLENBQUMsRUFBQztBQUMxQixhQUFPLEdBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQztLQUNqQjtHQUNGO0NBQ0YsQ0FBQTs7Ozs7Ozs7QUFRRCxJQUFJLHVCQUF1QixHQUFHLFNBQTFCLHVCQUF1QixHQUFrQztNQUF0QixhQUFhLHlEQUFHLEtBQUs7O0FBQzFELE1BQU0sZUFBZSxHQUFHLElBQUksR0FBRyxFQUFFLENBQUE7QUFDakMsTUFBTSxlQUFlLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQTtBQUNqQyxPQUFJLElBQU0sV0FBVyxJQUFJLFlBQVksRUFBQztBQUNwQyxRQUFNLFNBQVEsR0FBRyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDMUMsUUFBTSxZQUFZLEdBQUcsYUFBYSxHQUFDLFNBQVEsQ0FBQyxJQUFJLENBQUMsV0FBVyxFQUFFLEdBQUMsU0FBUSxDQUFDLElBQUksQ0FBQTs7O0FBRzVFLFFBQUksS0FBSyxHQUFHLGVBQWUsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUE7QUFDN0MsUUFBRyxDQUFDLEtBQUssRUFBQztBQUNSLFdBQUssR0FBRyxFQUFFLENBQUE7QUFDVixxQkFBZSxDQUFDLEdBQUcsQ0FBQyxZQUFZLEVBQUUsS0FBSyxDQUFDLENBQUE7S0FDekM7QUFDRCxTQUFLLENBQUMsSUFBSSxDQUFDLFNBQVEsQ0FBQyxDQUFBOzs7QUFHcEIsUUFBTSxZQUFZLEdBQUcsU0FBUSxDQUFDLElBQUksQ0FBQTtBQUNsQyxtQkFBZSxDQUFDLEdBQUcsQ0FBQyxTQUFRLENBQUMsSUFBSSxFQUFFLFNBQVEsQ0FBQyxDQUFBO0dBQzdDO0FBQ0QsU0FBTyxFQUFDLGVBQWUsRUFBZixlQUFlLEVBQUUsZUFBZSxFQUFmLGVBQWUsRUFBQyxDQUFDO0NBQzNDLENBQUE7Ozs7Ozs7Ozs7O0FBV0QsU0FBUyxjQUFjLENBQUMsUUFBUSxFQUFDO0FBQy9CLE1BQU0sWUFBWSxHQUFHLGtCQUFVLE9BQU8sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDckQsTUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQTtBQUNuQixNQUFHLFFBQVEsRUFBQztBQUNWLFNBQUksSUFBTSxvQkFBb0IsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBQztBQUMzRCxVQUFNLFlBQVksR0FBRyxZQUFZLENBQUMsT0FBTyxDQUFDLG9CQUFvQixDQUFDLElBQUksRUFBRSxZQUFZLENBQUMsQ0FBQTtBQUNsRixVQUFHLFlBQVksRUFBQzs7QUFFZCxZQUFNLG1CQUFtQixHQUFHLHNCQUFPLGNBQWMsQ0FBQyxZQUFZLENBQUMsQ0FBQTtBQUMvRCxZQUFNLGdCQUFnQixHQUFHLFlBQVksQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0FBQzFELFlBQUcsZ0JBQWdCLEVBQUM7O0FBRWxCLDhCQUFvQixDQUFDLFdBQVcsR0FBRyxtQkFBbUIsQ0FBQTtTQUN2RCxNQUFLOztBQUVKLGFBQUcsQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLENBQUE7U0FDdEI7T0FDRjtLQUNGO0dBQ0Y7QUFDRCxTQUFPLEdBQUcsQ0FBQTtDQUNYOztBQUVELFNBQVMsaUJBQWlCLEdBQUU7QUFDMUIsTUFBSSxHQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQTtBQUNuQixPQUFJLElBQU0sV0FBVyxJQUFJLFlBQVksRUFBQztBQUNwQyxZQUFRLEdBQUcsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQ3BDLFFBQU0scUJBQXFCLEdBQUcsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ3RELHlCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFBLElBQUk7YUFBSSxHQUFHLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQztLQUFBLENBQUMsQ0FBQTtHQUNyRDtBQUNELFNBQU8sR0FBRyxDQUFBO0NBQ1g7O0FBR0QsTUFBTSxDQUFDLE9BQU8sR0FBRztBQUNmLE9BQUssRUFBTCxLQUFLO0FBQ0wsYUFBVyxFQUFYLFdBQVc7QUFDWCxZQUFVLEVBQVYsVUFBVTtBQUNWLE9BQUssRUFBTCxLQUFLO0FBQ0wsZ0JBQWMsRUFBZCxjQUFjO0FBQ2QsY0FBWSxFQUFaLFlBQVk7QUFDWixhQUFXLEVBQVgsV0FBVztBQUNYLHlCQUF1QixFQUF2Qix1QkFBdUI7QUFDdkIsZ0JBQWMsRUFBZCxjQUFjO0FBQ2QsbUJBQWlCLEVBQWpCLGlCQUFpQjtDQUNsQixDQUFBIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1yb2JvdC1mcmFtZXdvcmsvbGliL2tleXdvcmRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCdcclxuaW1wb3J0IHV0aWwgZnJvbSAndXRpbCdcclxuaW1wb3J0IHBhdGhVdGlscyBmcm9tICdwYXRoJ1xyXG5pbXBvcnQgZnV6emFsZHJpbiBmcm9tICdmdXp6YWxkcmluLXBsdXMnXHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24uanMnXHJcbmltcG9ydCAqIGFzIHBhdGhSZXNvbHZlciBmcm9tICcuL3BhdGgtcmVzb2x2ZXInXHJcblxyXG5cclxuLyoqXHJcbiAqXHJcbiAqIEtleXdvcmRzIG1hcHBlZCBieSBSb2JvdCByZXNvdXJjZSBmaWxlc1xyXG4gKiBGb3JtYXQ6XHJcbiAqIHtcclxuICogICAgICcvZGlyMS9kaXIyL2J1aWx0aW4ueG1sJzoge1xyXG4gKiAgICAgICAgIHJlc291cmNlS2V5OiAnYnVpbHRpbicsXHJcbiAqICAgICAgICAgbmFtZTogJ0J1aWx0SW4nLFxyXG4gKiAgICAgICAgIGV4dGVuc2lvbjogJy54bWwnLFxyXG4gKiAgICAgICAgIHBhdGg6ICcvZGlyMS9kaXIyL0J1aWx0SW4ueG1sJywgICMgbm9ybWFsaXplZFxyXG4gKiAgICAgICAgIGxpYnJhcnlQYXRoOiAnL2RpcjEvZGlyMi9CdWlsdEluLnB5J1xyXG4gKiAgICAgICAgIGhhc1Rlc3RDYXNlczogZmFsc2UsXHJcbiAqICAgICAgICAgaGFzS2V5d29yZHM6IHRydWUsXHJcbiAqICAgICAgICAgaXNMaWJyYXJ5OiB0cnVlXHJcbiAqICAgICAgICAgaW1wb3J0czoge1xyXG4gKiAgICAgICAgICAgbGlicmFyaWVzOiBbe25hbWU6ICdsaWJyYXJ5TmFtZScsIGFsaWFzOiAnd2l0aE5hbWVBbGlhcyd9LCAuLi5dLFxyXG4gKiAgICAgICAgICAgcmVzb3VyY2VzOiBbe1xyXG4gKiAgICAgICAgICAgICBwYXRoOiAncmVzb3VyY2UgcGF0aCcgIC8vIGFzIGZvdW5kIGluICdSZXNvdXJjZScgZGVjbGFyYXRpb25cclxuICogICAgICAgICAgICAgbmFtZTogJ3Jlc291cmNlTmFtZScsXHJcbiAqICAgICAgICAgICAgIGV4dGVuc2lvbjogJy5yb2JvdCcsXHJcbiAqICAgICAgICAgICAgIHJlc291cmNlS2V5OiAncmVzb3VyY2Uga2V5J30sIC4uLl0sIC8vICdyZXNvdXJjZUtleScgaXMgdW5kZWZpbmVkIGlmIGl0IGNvdWxkIG5vdCBiZSBmb3VuZCBpbiBwYXJzZWQgcmVzb3VyY2VzTWFwXHJcbiAqICAgICAgICAgfSxcclxuICogICAgICAgICBrZXl3b3JkczogW3tcclxuICogICAgICAgICAgICAgICAgIG5hbWU6ICcnLFxyXG4gKiAgICAgICAgICAgICAgICAgZG9jdW1lbnRhdGlvbjogJycsXHJcbiAqICAgICAgICAgICAgICAgICBhcmd1bWVudHM6IFsnJywgJycsIC4uLl0sXHJcbiAqICAgICAgICAgICAgICAgICByb3dObzogMCxcclxuICogICAgICAgICAgICAgICAgIGNvbE5vOiAwLFxyXG4gKiAgICAgICAgICAgICAgICAgbG9jYWw6IHRydWUvZmFsc2UgIyBXaGV0aGVyIGtleXdvcmQgaXMgb25seSB2aXNpYmxlIGxvY2FsbHlcclxuICogICAgICAgICAgICAgICAgIHJlc291cmNlOntyZXNvdXJjZUtleTogJycsIC4uLn0gLy8gcGFyZW50IHJlc291cmNlXHJcbiAqICAgICAgICAgICAgIH0sIC4uLlxyXG4gKiAgICAgICAgIF0sXHJcbiAqICAgICB9LFxyXG4gKiAgICAgLi4uXHJcbiAqIH1cclxuICovXHJcbnZhciByZXNvdXJjZXNNYXAgPSB7fTtcclxuXHJcbi8vIEtleXdvcmRzIG1hcHBlZCBieSBrZXl3b3JkIG5hbWVcclxudmFyIGtleXdvcmRzTWFwID0ge307XHJcblxyXG4vLyBSZW1vdmVzIGtleXdvcmRzIGRlcGVuZGluZyBvbiByZXNvdXJjZUZpbHRlci5cclxuLy8gVW5kZWZpbmVkIHJlc291cmNlRmlsdGVyIHdpbGwgY2F1c2UgYWxsIGtleXdvcmRzIHRvIGJlIGNsZWFyZWQuXHJcbnZhciByZXNldCA9IGZ1bmN0aW9uKHJlc291cmNlRmlsdGVyKSB7XHJcbiAgaWYocmVzb3VyY2VGaWx0ZXIpe1xyXG4gICAgcmVzb3VyY2VGaWx0ZXIgPSBjb21tb24uZ2V0UmVzb3VyY2VLZXkocmVzb3VyY2VGaWx0ZXIpO1xyXG4gICAgZm9yKHZhciBrZXkgaW4gcmVzb3VyY2VzTWFwKXtcclxuICAgICAgaWYoa2V5LmluZGV4T2YocmVzb3VyY2VGaWx0ZXIpPT09MCl7XHJcbiAgICAgICAgZGVsZXRlIHJlc291cmNlc01hcFtrZXldO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSBlbHNle1xyXG4gICAgY2xlYXJPYmoocmVzb3VyY2VzTWFwKTtcclxuICB9XHJcbiAgcmVidWlsZEtleXdvcmRzTWFwKCk7XHJcbn1cclxuXHJcbnZhciByZXNldEtleXdvcmRzTWFwID0gZnVuY3Rpb24ocmVzb3VyY2VLZXksIGtleXdvcmRzKXtcclxuICByZXNvdXJjZUtleSA9IGNvbW1vbi5nZXRSZXNvdXJjZUtleShyZXNvdXJjZUtleSk7XHJcbiAgdmFyIG5ld0t3TGlzdDtcclxuICBrZXl3b3Jkcy5mb3JFYWNoKGZ1bmN0aW9uKGtleXdvcmQpe1xyXG4gICAgdmFyIGt3bmFtZSA9IGtleXdvcmQubmFtZS50b0xvd2VyQ2FzZSgpO1xyXG4gICAgdmFyIGt3TGlzdCA9IGtleXdvcmRzTWFwW2t3bmFtZV07XHJcbiAgICBpZihrd0xpc3Qpe1xyXG4gICAgICBuZXdLd0xpc3QgPSBbXTtcclxuICAgICAga3dMaXN0LmZvckVhY2goZnVuY3Rpb24oa3cpe1xyXG4gICAgICAgIGlmKGt3LnJlc291cmNlLnJlc291cmNlS2V5IT09cmVzb3VyY2VLZXkpe1xyXG4gICAgICAgICAgbmV3S3dMaXN0LnB1c2goa3cpO1xyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcbiAgICAgIGlmKG5ld0t3TGlzdC5sZW5ndGg+MCl7XHJcbiAgICAgICAga2V5d29yZHNNYXBba3duYW1lXSA9IG5ld0t3TGlzdDtcclxuICAgICAgfSBlbHNle1xyXG4gICAgICAgIGRlbGV0ZSBrZXl3b3Jkc01hcFtrd25hbWVdO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfSk7XHJcbn1cclxuXHJcbnZhciByZWJ1aWxkS2V5d29yZHNNYXAgPSBmdW5jdGlvbigpe1xyXG4gIHZhciByZXNvdXJjZUtleSwgcmVzb3VyY2UsIGtleXdvcmRMaXN0O1xyXG4gIGNsZWFyT2JqKGtleXdvcmRzTWFwKTtcclxuICBmb3IocmVzb3VyY2VLZXkgaW4gcmVzb3VyY2VzTWFwKXtcclxuICAgIHJlc291cmNlID0gcmVzb3VyY2VzTWFwW3Jlc291cmNlS2V5XTtcclxuICAgIGFkZEtleXdvcmRzVG9NYXAocmVzb3VyY2Uua2V5d29yZHMpO1xyXG4gIH1cclxufVxyXG5cclxudmFyIGFkZEtleXdvcmRzVG9NYXAgPSBmdW5jdGlvbihrZXl3b3Jkcyl7XHJcbiAgdmFyIGtleXdvcmRMaXN0O1xyXG4gIGtleXdvcmRzLmZvckVhY2goZnVuY3Rpb24oa2V5d29yZCl7XHJcbiAgICB2YXIga3duYW1lID0ga2V5d29yZC5uYW1lLnRvTG93ZXJDYXNlKCk7XHJcbiAgICBrZXl3b3JkTGlzdCA9IGtleXdvcmRzTWFwW2t3bmFtZV07XHJcbiAgICBpZigha2V5d29yZExpc3Qpe1xyXG4gICAgICBrZXl3b3JkTGlzdCA9IFtdXHJcbiAgICAgIGtleXdvcmRzTWFwW2t3bmFtZV0gPSBrZXl3b3JkTGlzdDtcclxuICAgIH1cclxuICAgIGtleXdvcmRMaXN0LnB1c2goa2V5d29yZCk7XHJcbiAgfSk7XHJcbn1cclxuXHJcbnZhciBhZGRSZXNvdXJjZSA9IGZ1bmN0aW9uKHBhcnNlZFJvYm90SW5mbywgcmVzb3VyY2VQYXRoKSB7XHJcbiAgdmFyIHJlc291cmNlTmFtZSA9IHBhdGhVdGlscy5iYXNlbmFtZShyZXNvdXJjZVBhdGgsIHBhdGhVdGlscy5leHRuYW1lKHJlc291cmNlUGF0aCkpO1xyXG4gIGFkZEtleXdvcmRzKHBhcnNlZFJvYm90SW5mbywgY29tbW9uLmdldFJlc291cmNlS2V5KHJlc291cmNlUGF0aCksIHJlc291cmNlUGF0aCwgcmVzb3VyY2VOYW1lKVxyXG59XHJcblxyXG52YXIgYWRkTGlicmFyeSA9IGZ1bmN0aW9uKHBhcnNlZFJvYm90SW5mbywgbGliZG9jUGF0aCwgbGlicmFyeU5hbWUsIHNvdXJjZVBhdGgpIHtcclxuICBhZGRLZXl3b3JkcyhwYXJzZWRSb2JvdEluZm8sIGNvbW1vbi5nZXRSZXNvdXJjZUtleShsaWJyYXJ5TmFtZSksIGxpYmRvY1BhdGgsIGxpYnJhcnlOYW1lLCB0cnVlLCBzb3VyY2VQYXRoKVxyXG59XHJcblxyXG4vLyBBZGRzIGtleXdvcmRzIHRvIHJlcG9zaXRvcnkgdW5kZXIgcmVzb3VyY2Ugc3BlY2lmaWVkIGJ5IHJlc291cmNlS2V5LlxyXG52YXIgYWRkS2V5d29yZHMgPSBmdW5jdGlvbihwYXJzZWRSb2JvdEluZm8sIHJlc291cmNlS2V5LCBwYXRoLCBuYW1lLCBpc0xpYnJhcnkgPSBmYWxzZSwgbGlicmFyeVBhdGggPSB1bmRlZmluZWQpIHtcclxuICBwYXRoID0gcGF0aFV0aWxzLm5vcm1hbGl6ZShwYXRoKVxyXG4gIGNvbnN0IGV4dGVuc2lvbiA9IHBhdGhVdGlscy5leHRuYW1lKHBhdGgpO1xyXG4gIGhhc1Rlc3RDYXNlcyA9IHBhcnNlZFJvYm90SW5mby50ZXN0Q2FzZXMubGVuZ3RoPjAsXHJcbiAgaGFzS2V5d29yZHMgPSBwYXJzZWRSb2JvdEluZm8ua2V5d29yZHMubGVuZ3RoPjBcclxuICBjb25zdCBpbXBvcnRlZFJlc291cmNlcyA9IHBhcnNlZFJvYm90SW5mby5yZXNvdXJjZXMubWFwKHJlcyA9PiAoe1xyXG4gICAgbmFtZTogcGF0aFV0aWxzLmJhc2VuYW1lKHJlcy5wYXRoLCBwYXRoVXRpbHMuZXh0bmFtZShyZXMucGF0aCkpLFxyXG4gICAgZXh0ZW5zaW9uOiBwYXRoVXRpbHMuZXh0bmFtZShyZXMucGF0aCksXHJcbiAgICBwYXRoOiByZXMucGF0aFxyXG4gIH0pKVxyXG4gIHZhciByZXNvdXJjZSA9IHtcclxuICAgIHJlc291cmNlS2V5LFxyXG4gICAgcGF0aCxcclxuICAgIGxpYnJhcnlQYXRoLFxyXG4gICAgbmFtZSxcclxuICAgIGV4dGVuc2lvbixcclxuICAgIGltcG9ydHM6IHtcclxuICAgICAgbGlicmFyaWVzOiBwYXJzZWRSb2JvdEluZm8ubGlicmFyaWVzLFxyXG4gICAgICByZXNvdXJjZXM6IGltcG9ydGVkUmVzb3VyY2VzXHJcbiAgICB9LFxyXG4gICAgaGFzVGVzdENhc2VzLFxyXG4gICAgaGFzS2V5d29yZHMsXG4gICAgaXNMaWJyYXJ5XG4gIH1cblxyXG4gIC8vIEFkZCBzb21lIGhlbHBlciBwcm9wZXJ0aWVzIHRvIGVhY2gga2V5d29yZFxyXG4gIGZvcih2YXIgaSA9IDA7IGk8cGFyc2VkUm9ib3RJbmZvLmtleXdvcmRzLmxlbmd0aDsgaSsrKXtcclxuICAgIHBhcnNlZFJvYm90SW5mby5rZXl3b3Jkc1tpXS5yZXNvdXJjZSA9IHJlc291cmNlO1xyXG4gICAgcGFyc2VkUm9ib3RJbmZvLmtleXdvcmRzW2ldLmxvY2FsID0gaGFzVGVzdENhc2VzO1xyXG4gIH1cclxuXHJcbiAgLy8gUG9wdWxhdGUga2V5d29yZHNNYXBcclxuICBpZihyZXNvdXJjZXNNYXBbcmVzb3VyY2VLZXldKXtcclxuICAgIHJlc2V0S2V5d29yZHNNYXAocmVzb3VyY2VLZXksIHJlc291cmNlc01hcFtyZXNvdXJjZUtleV0ua2V5d29yZHMpO1xyXG4gIH1cclxuICBhZGRLZXl3b3Jkc1RvTWFwKHBhcnNlZFJvYm90SW5mby5rZXl3b3Jkcyk7XHJcblxyXG4gIC8vIFBvcHVsYXRlIHJlc291cmNlc01hcFxyXG4gIHJlc291cmNlc01hcFtyZXNvdXJjZUtleV0gPSB7XHJcbiAgICByZXNvdXJjZUtleSxcclxuICAgIG5hbWUsXHJcbiAgICBwYXRoLFxyXG4gICAgbGlicmFyeVBhdGgsXHJcbiAgICBleHRlbnNpb24sXHJcbiAgICBrZXl3b3JkczogcGFyc2VkUm9ib3RJbmZvLmtleXdvcmRzLFxyXG4gICAgaW1wb3J0czoge1xyXG4gICAgICBsaWJyYXJpZXM6IHBhcnNlZFJvYm90SW5mby5saWJyYXJpZXMsXHJcbiAgICAgIHJlc291cmNlczogaW1wb3J0ZWRSZXNvdXJjZXNcclxuICAgIH0sXHJcbiAgICBoYXNUZXN0Q2FzZXMsXHJcbiAgICBoYXNLZXl3b3JkcyxcclxuICAgIGlzTGlicmFyeVxyXG4gIH07XHJcbiAgcmV0dXJuXHJcbn1cclxuXHJcbi8vIFJldHVybnMgYSBsaXN0IG9mIGtleXdvcmRzIHNjb3JlZCBieSBxdWVyeSBzdHJpbmcuXHJcbi8vIHJlc291cmNlS2V5cyAtIFNldDogbGltaXRzIHN1Z2dlc3Rpb25zIHRvIG9ubHkgdGhlc2UgcmVzb3VyY2VzXHJcbi8vIElmICdxdWVyeScgaXMgbm90IGRlZmluZWQgb3IgaXMgJycsIHJldHVybnMgYWxsIGtleXdvcmRzLiBTY29yZXMgd2lsbCBiZSBpZGVudGljYWwgZm9yIGVhY2ggZW50cnkuXHJcbnZhciBzY29yZSA9IGZ1bmN0aW9uKHF1ZXJ5LCByZXNvdXJjZUtleXMpIHtcclxuICBxdWVyeSA9IHF1ZXJ5IHx8ICcnO1xyXG4gIHF1ZXJ5ID0gcXVlcnkudHJpbSgpLnRvTG93ZXJDYXNlKCk7XHJcbiAgdmFyIHN1Z2dlc3Rpb25zID0gW107XHJcbiAgdmFyIHByZXBRdWVyeSA9IGZ1enphbGRyaW4ucHJlcFF1ZXJ5KHF1ZXJ5KTtcclxuICBmb3IgKCB2YXIgcmVzb3VyY2VLZXkgaW4gcmVzb3VyY2VzTWFwKSB7XHJcbiAgICBpZihyZXNvdXJjZUtleXMuc2l6ZT4wICYmICFyZXNvdXJjZUtleXMuaGFzKHJlc291cmNlS2V5KSl7XHJcbiAgICAgIGNvbnRpbnVlO1xyXG4gICAgfVxyXG4gICAgdmFyIHJlc291cmNlID0gcmVzb3VyY2VzTWFwW3Jlc291cmNlS2V5XTtcclxuICAgIGlmIChyZXNvdXJjZSkge1xyXG4gICAgICBmb3IgKHZhciBpID0gMDsgaSA8IHJlc291cmNlLmtleXdvcmRzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgICAgdmFyIGtleXdvcmQgPSByZXNvdXJjZS5rZXl3b3Jkc1tpXTtcclxuICAgICAgICB2YXIgc2NvcmUgPSBxdWVyeT09PScnPzE6ZnV6emFsZHJpbi5zY29yZShrZXl3b3JkLm5hbWUsIHF1ZXJ5LCBwcmVwUXVlcnkpOyAvLyBJZiBxdWVyeSBpcyBlbXB0eSBzdHJpbmcsIHdlIHdpbGwgc2hvdyBhbGwga2V5d29yZHMuXHJcbiAgICAgICAgaWYgKHNjb3JlKSB7XHJcbiAgICAgICAgICBzdWdnZXN0aW9ucy5wdXNoKHtcclxuICAgICAgICAgICAga2V5d29yZCA6IGtleXdvcmQsXHJcbiAgICAgICAgICAgIHNjb3JlOiBzY29yZVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICByZXR1cm4gc3VnZ2VzdGlvbnM7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBwcmludERlYnVnSW5mbyhvcHRpb25zKSB7XHJcbiAgb3B0aW9ucyA9IG9wdGlvbnMgfHwge1xyXG4gICAgc2hvd0xpYmRvY0ZpbGVzOiB0cnVlLFxyXG4gICAgc2hvd1JvYm90RmlsZXM6IHRydWUsXHJcbiAgICBzaG93QWxsU3VnZ2VzdGlvbnM6IGZhbHNlXHJcbiAgfTtcclxuICB2YXIgcm9ib3RGaWxlcyA9IFtdLCBsaWJkb2NGaWxlcyA9IFtdO1xyXG4gIHZhciBleHQ7XHJcbiAgZm9yKGtleSBpbiByZXNvdXJjZXNNYXApe1xyXG4gICAgZXh0ID0gcGF0aFV0aWxzLmV4dG5hbWUoa2V5KTtcclxuICAgIGlmKGV4dD09PScueG1sJyB8fCBleHQ9PT0nLmh0bWwnKXtcclxuICAgICAgbGliZG9jRmlsZXMucHVzaChwYXRoVXRpbHMuYmFzZW5hbWUoa2V5KSk7XHJcbiAgICB9IGVsc2V7XHJcbiAgICAgIHJvYm90RmlsZXMucHVzaChwYXRoVXRpbHMuYmFzZW5hbWUoa2V5KSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGlmKG9wdGlvbnMuc2hvd1JvYm90RmlsZXMpe1xyXG4gICAgY29uc29sZS5sb2coJ0F1dG9jb21wbGV0ZSByb2JvdCBmaWxlczonICsgcm9ib3RGaWxlcyk7XHJcbiAgfVxyXG4gIGlmKG9wdGlvbnMuc2hvd0xpYmRvY0ZpbGVzKXtcclxuICAgIGNvbnNvbGUubG9nKCdBdXRvY29tcGxldGUgbGliZG9jIGZpbGVzOicgKyBsaWJkb2NGaWxlcyk7XHJcbiAgfVxyXG4gIGlmKG9wdGlvbnMuc2hvd0FsbFN1Z2dlc3Rpb25zKXtcclxuICAgIGNvbnNvbGUubG9nKCdBbGwgc3VnZ2VzdGlvbnM6ICcgKyBKU09OLnN0cmluZ2lmeShyZXNvdXJjZXNNYXAsIG51bGwsIDIpKTtcclxuICAgIC8vIGNvbnNvbGUubG9nKCdBbGwgc3VnZ2VzdGlvbnM6ICcgKyBKU09OLnN0cmluZ2lmeShrZXl3b3Jkc01hcCwgbnVsbCwgMikpO1xyXG4gIH1cclxufVxyXG5cclxudmFyIGNsZWFyT2JqID0gZnVuY3Rpb24ob2JqKXtcclxuICBmb3IgKHZhciBrZXkgaW4gb2JqKXtcclxuICAgIGlmIChvYmouaGFzT3duUHJvcGVydHkoa2V5KSl7XHJcbiAgICAgIGRlbGV0ZSBvYmpba2V5XTtcclxuICAgIH1cclxuICB9XHJcbn1cclxuXHJcbi8qKlxyXG4gKiBSZXR1cm5zIE1hcHMgb2YgcmVzb3VyY2VzIGdyb3VwZWQgYnkgcGF0aCBhbmQgYnkgbmFtZTpcclxuICoge3Jlc291cmNlc0J5TmFtZTogTWFwKHBhdGgsIHJlc291cmNlKSwgcmVzb3VyY2VzQnlOYW1lOiBNYXAobmFtZSwgW3Jlc291cmNlXSl9XHJcbiAqIGxvd2VyQ2FzZTogaWYgdHJ1ZSwgYWxsIG5hbWVzIHdpbGwgYmUgbG93ZXJjYXNlZC5cclxuICogUGF0aCBpcyBub3JtYWxpemVkIGluIGJvdGgga2V5IGFuZCB2YWx1ZS5cclxuICovXHJcbnZhciBjb21wdXRlR3JvdXBlZFJlc291cmNlcyA9IGZ1bmN0aW9uKGxvd2VyQ2FzZU5hbWUgPSBmYWxzZSl7XHJcbiAgY29uc3QgcmVzb3VyY2VzQnlOYW1lID0gbmV3IE1hcCgpXHJcbiAgY29uc3QgcmVzb3VyY2VzQnlQYXRoID0gbmV3IE1hcCgpXHJcbiAgZm9yKGNvbnN0IHJlc291cmNlS2V5IGluIHJlc291cmNlc01hcCl7XHJcbiAgICBjb25zdCByZXNvdXJjZSA9IHJlc291cmNlc01hcFtyZXNvdXJjZUtleV1cclxuICAgIGNvbnN0IHJlc291cmNlTmFtZSA9IGxvd2VyQ2FzZU5hbWU/cmVzb3VyY2UubmFtZS50b0xvd2VyQ2FzZSgpOnJlc291cmNlLm5hbWVcclxuXHJcbiAgICAvLyBncm91cCBieSBuYW1lXHJcbiAgICBsZXQgbmFtZXMgPSByZXNvdXJjZXNCeU5hbWUuZ2V0KHJlc291cmNlTmFtZSlcclxuICAgIGlmKCFuYW1lcyl7XHJcbiAgICAgIG5hbWVzID0gW11cclxuICAgICAgcmVzb3VyY2VzQnlOYW1lLnNldChyZXNvdXJjZU5hbWUsIG5hbWVzKVxyXG4gICAgfVxyXG4gICAgbmFtZXMucHVzaChyZXNvdXJjZSlcclxuXHJcbiAgICAvLyBncm91cCBieSBwYXRoXHJcbiAgICBjb25zdCByZXNvdXJjZVBhdGggPSByZXNvdXJjZS5wYXRoXHJcbiAgICByZXNvdXJjZXNCeVBhdGguc2V0KHJlc291cmNlLnBhdGgsIHJlc291cmNlKVxyXG4gIH1cclxuICByZXR1cm4ge3Jlc291cmNlc0J5TmFtZSwgcmVzb3VyY2VzQnlQYXRofTtcclxufVxyXG5cclxuLyoqXHJcbiAqIFVwZGF0ZXMgaW1wb3J0cyB3aXRoIGNvcnJlc3BvbmRpbmcgcGFyc2VkIHJvYm90IHJlc291cmNlIGZpbGVzLlxyXG4gKiB7Li4uIGltcG9ydHM6e1xyXG4gKiAgIHJlc291cmNlczogW3twYXRoLCBuYW1lLCBleHRlbmFpb24sIHJlc291cmNlS2V5fV0gIC8vICdyZXNvdXJjZUtleScgZWxlbWVudCB3aWxsIGJlIGFkZGVkIGlmIGltcG9ydCBpcyByZXNvbHZlZC5cclxuICogfX1cclxuICogUmV0dXJucyBTZXQgb2YgdmFsaWQgaW1wb3J0ZWQgcm9ib3QgcGF0aHMgdGhhdCBhcmUgbm90IGZvdW5kIGluIHRoaXMgcHJvamVjdC5cclxuICogVGhlc2UgY3Jvc3MgcHJvamVjdCByZXNvdXJjZXMgY291bGQgYmUgcGFyc2VkIGFuZCByZXNvbHZlZCBhcyBpbXBvcnRzIGluIGFcclxuICogc2Vjb25kIHBhc3MuXHJcbiAqL1xyXG5mdW5jdGlvbiByZXNvbHZlSW1wb3J0cyhyZXNvdXJjZSl7XHJcbiAgY29uc3QgcmVzb3VyY2VQYXRoID0gcGF0aFV0aWxzLmRpcm5hbWUocmVzb3VyY2UucGF0aClcclxuICBsZXQgcmVzID0gbmV3IFNldCgpXHJcbiAgaWYocmVzb3VyY2Upe1xyXG4gICAgZm9yKGNvbnN0IGltcG9ydGVkUmVzb3VyY2VJbmZvIG9mIHJlc291cmNlLmltcG9ydHMucmVzb3VyY2VzKXtcclxuICAgICAgY29uc3QgaW1wb3J0ZWRQYXRoID0gcGF0aFJlc29sdmVyLnJlc29sdmUoaW1wb3J0ZWRSZXNvdXJjZUluZm8ucGF0aCwgcmVzb3VyY2VQYXRoKVxyXG4gICAgICBpZihpbXBvcnRlZFBhdGgpe1xyXG4gICAgICAgIC8vIGltcG9ydCBwYXRoIHBvaW50cyB0byB2YWxpZCByb2JvdCByZXNvdXJjZVxyXG4gICAgICAgIGNvbnN0IGltcG9ydGVkUmVzb3VyY2VLZXkgPSBjb21tb24uZ2V0UmVzb3VyY2VLZXkoaW1wb3J0ZWRQYXRoKVxyXG4gICAgICAgIGNvbnN0IGltcG9ydGVkUmVzb3VyY2UgPSByZXNvdXJjZXNNYXBbaW1wb3J0ZWRSZXNvdXJjZUtleV1cclxuICAgICAgICBpZihpbXBvcnRlZFJlc291cmNlKXtcclxuICAgICAgICAgIC8vIHJlc291cmNlIGlzIGFscmVhZHkgcGFyc2VkXHJcbiAgICAgICAgICBpbXBvcnRlZFJlc291cmNlSW5mby5yZXNvdXJjZUtleSA9IGltcG9ydGVkUmVzb3VyY2VLZXlcclxuICAgICAgICB9IGVsc2V7XHJcbiAgICAgICAgICAvLyByZXNvdXJjZSBtaXNzaW5nLiBwcm9iYWJseSBpcyBub3QgcGFydCBvZiB0aGlzIHByb2plY3QuXHJcbiAgICAgICAgICByZXMuYWRkKGltcG9ydGVkUGF0aClcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHJlc1xyXG59XHJcblxyXG5mdW5jdGlvbiByZXNvbHZlQWxsSW1wb3J0cygpe1xyXG4gIGxldCByZXMgPSBuZXcgU2V0KClcclxuICBmb3IoY29uc3QgcmVzb3VyY2VLZXkgaW4gcmVzb3VyY2VzTWFwKXtcclxuICAgIHJlc291cmNlID0gcmVzb3VyY2VzTWFwW3Jlc291cmNlS2V5XVxyXG4gICAgY29uc3QgbWlzc2luZ1Jlc3NvdXJjZVBhdGhzID0gcmVzb2x2ZUltcG9ydHMocmVzb3VyY2UpXHJcbiAgICBtaXNzaW5nUmVzc291cmNlUGF0aHMuZm9yRWFjaChwYXRoID0+IHJlcy5hZGQocGF0aCkpXHJcbiAgfVxyXG4gIHJldHVybiByZXNcclxufVxyXG5cclxuXHJcbm1vZHVsZS5leHBvcnRzID0ge1xyXG4gIHJlc2V0LFxyXG4gIGFkZFJlc291cmNlLFxyXG4gIGFkZExpYnJhcnksXHJcbiAgc2NvcmUsXHJcbiAgcHJpbnREZWJ1Z0luZm8sXHJcbiAgcmVzb3VyY2VzTWFwLFxyXG4gIGtleXdvcmRzTWFwLFxyXG4gIGNvbXB1dGVHcm91cGVkUmVzb3VyY2VzLFxyXG4gIHJlc29sdmVJbXBvcnRzLFxyXG4gIHJlc29sdmVBbGxJbXBvcnRzXHJcbn1cclxuIl19