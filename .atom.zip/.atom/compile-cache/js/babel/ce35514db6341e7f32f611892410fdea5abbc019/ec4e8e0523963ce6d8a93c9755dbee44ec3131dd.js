Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

exports.getInstance = getInstance;
exports.activate = activate;
exports.deactivate = deactivate;
exports.deserializeXTerminalModel = deserializeXTerminalModel;
exports.provideAtomXtermService = provideAtomXtermService;
exports.providePlatformIOIDEService = providePlatformIOIDEService;
exports.provideTerminalService = provideTerminalService;

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/** @module x-terminal */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _atom = require('atom');

var _config = require('./config');

var _utils = require('./utils');

var _element = require('./element');

var _model = require('./model');

var _profiles = require('./profiles');

var _profileMenuElement = require('./profile-menu-element');

var _profileMenuModel = require('./profile-menu-model');

var _deleteProfileElement = require('./delete-profile-element');

var _deleteProfileModel = require('./delete-profile-model');

var _overwriteProfileElement = require('./overwrite-profile-element');

var _overwriteProfileModel = require('./overwrite-profile-model');

var _saveProfileElement = require('./save-profile-element');

var _saveProfileModel = require('./save-profile-model');

var _whatwgUrl = require('whatwg-url');

var XTerminalSingletonSymbol = Symbol('XTerminalSingleton sentinel');

var XTerminalSingleton = (function () {
	function XTerminalSingleton(symbolCheck) {
		_classCallCheck(this, XTerminalSingleton);

		if (XTerminalSingletonSymbol !== symbolCheck) {
			throw new Error('XTerminalSingleton cannot be instantiated directly.');
		}
	}

	_createClass(XTerminalSingleton, [{
		key: 'activate',
		value: function activate(state) {
			var _this = this;

			// Load profiles configuration.
			this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;

			// Reset base profile in case this package was deactivated then
			// reactivated.
			this.profilesSingleton.resetBaseProfile();

			// Disposables for this plugin.
			this.disposables = new _atom.CompositeDisposable();

			// Set holding all terminals available at any moment.
			this.terminals_set = new Set();

			// Monitor for changes to all config values.
			for (var data of _config.CONFIG_DATA) {
				this.disposables.add(atom.config.onDidChange(data.keyPath, function (_ref) {
					var newValue = _ref.newValue;
					var oldValue = _ref.oldValue;

					_this.profilesSingleton.resetBaseProfile();
				}));
			}
			// Monitor for editor.fontFamily changes for the useEditorFont setting.
			this.disposables.add(atom.config.onDidChange('editor.fontFamily', function (_ref2) {
				var newValue = _ref2.newValue;
				var oldValue = _ref2.oldValue;

				_this.profilesSingleton.resetBaseProfile();
			}));

			this.disposables.add(
			// Register view provider for terminal emulator item.
			atom.views.addViewProvider(_model.XTerminalModel, function (atomXtermModel) {
				var atomXtermElement = new _element.XTerminalElement();
				atomXtermElement.initialize(atomXtermModel);
				return atomXtermElement;
			}),
			// Register view provider for terminal emulator profile menu item.
			atom.views.addViewProvider(_profileMenuModel.XTerminalProfileMenuModel, function (atomXtermProfileMenuModel) {
				var atomXtermProfileMenuElement = new _profileMenuElement.XTerminalProfileMenuElement();
				atomXtermProfileMenuElement.initialize(atomXtermProfileMenuModel);
				return atomXtermProfileMenuElement;
			}),
			// Register view profile for modal items.
			atom.views.addViewProvider(_deleteProfileModel.XTerminalDeleteProfileModel, function (atomXtermDeleteProfileModel) {
				var atomXtermDeleteProfileElement = new _deleteProfileElement.XTerminalDeleteProfileElement();
				atomXtermDeleteProfileElement.initialize(atomXtermDeleteProfileModel);
				return atomXtermDeleteProfileElement;
			}), atom.views.addViewProvider(_overwriteProfileModel.XTerminalOverwriteProfileModel, function (atomXtermOverwriteProfileModel) {
				var atomXtermOverwriteProfileElement = new _overwriteProfileElement.XTerminalOverwriteProfileElement();
				atomXtermOverwriteProfileElement.initialize(atomXtermOverwriteProfileModel);
				return atomXtermOverwriteProfileElement;
			}), atom.views.addViewProvider(_saveProfileModel.XTerminalSaveProfileModel, function (atomXtermSaveProfileModel) {
				var atomXtermSaveProfileElement = new _saveProfileElement.XTerminalSaveProfileElement();
				atomXtermSaveProfileElement.initialize(atomXtermSaveProfileModel);
				return atomXtermSaveProfileElement;
			}),

			// Add opener for terminal emulator item.
			atom.workspace.addOpener(function (uri) {
				if (uri.startsWith(_profiles.X_TERMINAL_BASE_URI)) {
					var item = new _model.XTerminalModel({
						uri: uri,
						terminals_set: _this.terminals_set
					});
					return item;
				}
			}),

			// Set callback to run on current and future panes.
			atom.workspace.observePanes(function (pane) {
				// In callback, set another callback to run on current and future items.
				_this.disposables.add(pane.observeItems(function (item) {
					// In callback, set current pane for terminal items.
					if ((0, _model.isXTerminalModel)(item)) {
						item.setNewPane(pane);
					}
					(0, _utils.recalculateActive)(_this.terminals_set);
				}));
				(0, _utils.recalculateActive)(_this.terminals_set);
			}),

			// Add callbacks to run for current and future active items on active panes.
			atom.workspace.observeActivePaneItem(function (item) {
				// In callback, focus specifically on terminal when item is terminal item.
				if ((0, _model.isXTerminalModel)(item)) {
					item.focusOnTerminal();
				}
				(0, _utils.recalculateActive)(_this.terminals_set);
			}), atom.workspace.getRightDock().observeVisible(function (visible) {
				if (visible) {
					var item = atom.workspace.getRightDock().getActivePaneItem();
					if ((0, _model.isXTerminalModel)(item)) {
						item.focusOnTerminal();
					}
				}
				(0, _utils.recalculateActive)(_this.terminals_set);
			}), atom.workspace.getLeftDock().observeVisible(function (visible) {
				if (visible) {
					var item = atom.workspace.getLeftDock().getActivePaneItem();
					if ((0, _model.isXTerminalModel)(item)) {
						item.focusOnTerminal();
					}
				}
				(0, _utils.recalculateActive)(_this.terminals_set);
			}), atom.workspace.getBottomDock().observeVisible(function (visible) {
				if (visible) {
					var item = atom.workspace.getBottomDock().getActivePaneItem();
					if ((0, _model.isXTerminalModel)(item)) {
						item.focusOnTerminal();
					}
				}
				(0, _utils.recalculateActive)(_this.terminals_set);
			}),

			// Add commands.
			atom.commands.add('atom-workspace', {
				'x-terminal:open': function xTerminalOpen() {
					return _this.open(_this.profilesSingleton.generateNewUri(), _this.addDefaultPosition());
				},
				'x-terminal:open-center': function xTerminalOpenCenter() {
					return _this.openInCenterOrDock(atom.workspace);
				},
				'x-terminal:open-split-up': function xTerminalOpenSplitUp() {
					return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'up' });
				},
				'x-terminal:open-split-down': function xTerminalOpenSplitDown() {
					return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'down' });
				},
				'x-terminal:open-split-left': function xTerminalOpenSplitLeft() {
					return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'left' });
				},
				'x-terminal:open-split-right': function xTerminalOpenSplitRight() {
					return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'right' });
				},
				'x-terminal:open-split-bottom-dock': function xTerminalOpenSplitBottomDock() {
					return _this.openInCenterOrDock(atom.workspace.getBottomDock());
				},
				'x-terminal:open-split-left-dock': function xTerminalOpenSplitLeftDock() {
					return _this.openInCenterOrDock(atom.workspace.getLeftDock());
				},
				'x-terminal:open-split-right-dock': function xTerminalOpenSplitRightDock() {
					return _this.openInCenterOrDock(atom.workspace.getRightDock());
				},
				'x-terminal:toggle-profile-menu': function xTerminalToggleProfileMenu() {
					return _this.toggleProfileMenu();
				},
				'x-terminal:reorganize': function xTerminalReorganize() {
					return _this.reorganize('current');
				},
				'x-terminal:reorganize-top': function xTerminalReorganizeTop() {
					return _this.reorganize('top');
				},
				'x-terminal:reorganize-bottom': function xTerminalReorganizeBottom() {
					return _this.reorganize('bottom');
				},
				'x-terminal:reorganize-left': function xTerminalReorganizeLeft() {
					return _this.reorganize('left');
				},
				'x-terminal:reorganize-right': function xTerminalReorganizeRight() {
					return _this.reorganize('right');
				},
				'x-terminal:reorganize-bottom-dock': function xTerminalReorganizeBottomDock() {
					return _this.reorganize('bottom-dock');
				},
				'x-terminal:reorganize-left-dock': function xTerminalReorganizeLeftDock() {
					return _this.reorganize('left-dock');
				},
				'x-terminal:reorganize-right-dock': function xTerminalReorganizeRightDock() {
					return _this.reorganize('right-dock');
				},
				'x-terminal:close-all': function xTerminalCloseAll() {
					return _this.exitAllTerminals();
				},
				'x-terminal:insert-selected-text': function xTerminalInsertSelectedText() {
					return _this.insertSelection();
				},
				'x-terminal:run-selected-text': function xTerminalRunSelectedText() {
					return _this.runSelection();
				},
				'x-terminal:focus': function xTerminalFocus() {
					return _this.focus();
				}
			}), atom.commands.add('atom-text-editor, .tree-view, .tab-bar', {
				'x-terminal:open-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref3) {
						var target = _ref3.target;
						return _this.open(_this.profilesSingleton.generateNewUri(), _this.addDefaultPosition({ target: target }));
					}
				},
				'x-terminal:open-center-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref4) {
						var target = _ref4.target;
						return _this.openInCenterOrDock(atom.workspace, { target: target });
					}
				},
				'x-terminal:open-split-up-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref5) {
						var target = _ref5.target;
						return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'up', target: target });
					}
				},
				'x-terminal:open-split-down-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref6) {
						var target = _ref6.target;
						return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'down', target: target });
					}
				},
				'x-terminal:open-split-left-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref7) {
						var target = _ref7.target;
						return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'left', target: target });
					}
				},
				'x-terminal:open-split-right-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref8) {
						var target = _ref8.target;
						return _this.open(_this.profilesSingleton.generateNewUri(), { split: 'right', target: target });
					}
				},
				'x-terminal:open-split-bottom-dock-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref9) {
						var target = _ref9.target;
						return _this.openInCenterOrDock(atom.workspace.getBottomDock(), { target: target });
					}
				},
				'x-terminal:open-split-left-dock-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref10) {
						var target = _ref10.target;
						return _this.openInCenterOrDock(atom.workspace.getLeftDock(), { target: target });
					}
				},
				'x-terminal:open-split-right-dock-context-menu': {
					hiddenInCommandPalette: true,
					didDispatch: function didDispatch(_ref11) {
						var target = _ref11.target;
						return _this.openInCenterOrDock(atom.workspace.getRightDock(), { target: target });
					}
				}
			}), atom.commands.add('x-terminal', {
				'x-terminal:close': function xTerminalClose() {
					return _this.close();
				},
				'x-terminal:restart': function xTerminalRestart() {
					return _this.restart();
				},
				'x-terminal:copy': function xTerminalCopy() {
					return _this.copy();
				},
				'x-terminal:paste': function xTerminalPaste() {
					return _this.paste();
				},
				'x-terminal:unfocus': function xTerminalUnfocus() {
					return _this.unfocus();
				},
				'x-terminal:clear': function xTerminalClear() {
					return _this.clear();
				}
			}));
		}
	}, {
		key: 'deactivate',
		value: function deactivate() {
			this.exitAllTerminals();
			this.disposables.dispose();
		}
	}, {
		key: 'deserializeXTerminalModel',
		value: function deserializeXTerminalModel(serializedModel, atomEnvironment) {
			var pack = atom.packages.enablePackage('x-terminal');
			pack.preload();
			pack.activateNow();
			var allowRelaunchingTerminalsOnStartup = atom.config.get('x-terminal.terminalSettings.allowRelaunchingTerminalsOnStartup');
			if (!allowRelaunchingTerminalsOnStartup) {
				return;
			}
			var url = new _whatwgUrl.URL(serializedModel.uri);
			var relaunchTerminalOnStartup = url.searchParams.get('relaunchTerminalOnStartup');
			if (relaunchTerminalOnStartup === 'false') {
				return;
			}
			return new _model.XTerminalModel({
				uri: url.href,
				terminals_set: this.terminals_set
			});
		}
	}, {
		key: 'openInCenterOrDock',
		value: function openInCenterOrDock(centerOrDock) {
			var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

			var pane = centerOrDock.getActivePane();
			if (pane) {
				options.pane = pane;
			}
			return this.open(this.profilesSingleton.generateNewUri(), options);
		}
	}, {
		key: 'getPath',
		value: function getPath(target) {
			if (!target) {
				var paths = atom.project.getPaths();
				if (paths && paths.length > 0) {
					return paths[0];
				}
				return null;
			}

			var treeView = target.closest('.tree-view');
			if (treeView) {
				// called from treeview
				var selected = treeView.querySelector('.selected > .list-item > .name, .selected > .name');
				if (selected) {
					return selected.dataset.path;
				}
				return null;
			}

			var tab = target.closest('.tab-bar > .tab');
			if (tab) {
				// called from tab
				var title = tab.querySelector('.title');
				if (title && title.dataset.path) {
					return title.dataset.path;
				}
				return null;
			}

			var textEditor = target.closest('atom-text-editor');
			if (textEditor && typeof textEditor.getModel === 'function') {
				// called from atom-text-editor
				var model = textEditor.getModel();
				if (model && typeof model.getPath === 'function') {
					return model.getPath();
				}
				return null;
			}

			return null;
		}
	}, {
		key: 'refitAllTerminals',
		value: function refitAllTerminals() {
			var currentActivePane = atom.workspace.getActivePane();
			var currentActiveItem = currentActivePane.getActiveItem();
			for (var terminal of this.terminals_set) {
				// To refit, simply bring the terminal in focus in order for the
				// resize event to refit the terminal.
				var paneActiveItem = terminal.pane.getActiveItem();
				terminal.pane.getElement().focus();
				terminal.pane.setActiveItem(terminal);
				terminal.pane.setActiveItem(paneActiveItem);
			}
			currentActivePane.getElement().focus();
			currentActivePane.setActiveItem(currentActiveItem);
		}
	}, {
		key: 'exitAllTerminals',
		value: function exitAllTerminals() {
			for (var terminal of this.terminals_set) {
				terminal.exit();
			}
		}
	}, {
		key: 'getSelectedText',
		value: function getSelectedText() {
			var editor = atom.workspace.getActiveTextEditor();
			if (!editor) {
				return '';
			}

			var selectedText = '';
			var selection = editor.getSelectedText();
			if (selection) {
				selectedText = selection.replace(/[\r\n]+$/, '');
			} else {
				var cursor = editor.getCursorBufferPosition();
				if (cursor) {
					var line = editor.lineTextForBufferRow(cursor.row);
					selectedText = line;
					editor.moveDown(1);
				}
			}

			return selectedText;
		}
	}, {
		key: 'getActiveTerminal',
		value: function getActiveTerminal() {
			var terminals = [].concat(_toConsumableArray(this.terminals_set));
			return terminals.find(function (t) {
				return t.isActiveTerminal();
			});
		}
	}, {
		key: 'performOnActiveTerminal',
		value: function performOnActiveTerminal(operation) {
			var terminal = this.getActiveTerminal();
			if (terminal) {
				operation(terminal);
			}
		}
	}, {
		key: 'insertSelection',
		value: function insertSelection() {
			var selection = this.getSelectedText();
			if (selection) {
				this.performOnActiveTerminal(function (t) {
					return t.pasteToTerminal(selection);
				});
			}
		}
	}, {
		key: 'runSelection',
		value: function runSelection() {
			var selection = this.getSelectedText();
			if (selection) {
				this.performOnActiveTerminal(function (t) {
					return t.runCommand(selection);
				});
			}
		}
	}, {
		key: 'open',
		value: _asyncToGenerator(function* (uri) {
			var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

			var url = new _whatwgUrl.URL(uri);
			if (url.searchParams.get('relaunchTerminalOnStartup') === null) {
				if (!this.profilesSingleton.getBaseProfile().relaunchTerminalOnStartup) {
					url.searchParams.set('relaunchTerminalOnStartup', false);
				}
			}

			if (options.target) {
				var target = this.getPath(options.target);
				if (target) {
					url.searchParams.set('cwd', target);
				}
			}

			return atom.workspace.open(url.href, options);
		})

		/**
   * Service function which is a wrapper around 'atom.workspace.open()'. The
   * only difference with this function from 'atom.workspace.open()' is that it
   * accepts a profile Object as the first argument.
   *
   * @async
   * @function
   * @param {Object} profile Profile data to use when opening terminal.
   * @param {Object} options Options to pass to call to 'atom.workspace.open()'.
   * @return {XTerminalModel} Instance of XTerminalModel.
   */
	}, {
		key: 'openTerminal',
		value: _asyncToGenerator(function* (profile) {
			var options = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];

			options = this.addDefaultPosition(options);
			return this.open(_profiles.XTerminalProfilesSingleton.instance.generateNewUrlFromProfileData(profile), options);
		})

		/**
   * Service function which opens a terminal and runs the commands.
   *
   * @async
   * @function
   * @param {string[]} commands Commands to run in the terminal.
   * @return {XTerminalModel} Instance of XTerminalModel.
   */
	}, {
		key: 'runCommands',
		value: _asyncToGenerator(function* (commands) {
			var terminal = undefined;
			if (atom.config.get('x-terminal.terminalSettings.runInActive')) {
				terminal = this.getActiveTerminal();
			}

			if (!terminal) {
				var options = this.addDefaultPosition();
				terminal = yield this.open(_profiles.XTerminalProfilesSingleton.instance.generateNewUri(), options);
			}

			yield terminal.element.initializedPromise;
			for (var command of commands) {
				terminal.runCommand(command);
			}
		})
	}, {
		key: 'addDefaultPosition',
		value: function addDefaultPosition() {
			var options = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

			var position = atom.config.get('x-terminal.terminalSettings.defaultOpenPosition');
			switch (position) {
				case 'Center':
					{
						var pane = atom.workspace.getActivePane();
						if (pane && !('pane' in options)) {
							options.pane = pane;
						}
						break;
					}
				case 'Split Up':
					if (!('split' in options)) {
						options.split = 'up';
					}
					break;
				case 'Split Down':
					if (!('split' in options)) {
						options.split = 'down';
					}
					break;
				case 'Split Left':
					if (!('split' in options)) {
						options.split = 'left';
					}
					break;
				case 'Split Right':
					if (!('split' in options)) {
						options.split = 'right';
					}
					break;
				case 'Bottom Dock':
					{
						var pane = atom.workspace.getBottomDock().getActivePane();
						if (pane && !('pane' in options)) {
							options.pane = pane;
						}
						break;
					}
				case 'Left Dock':
					{
						var pane = atom.workspace.getLeftDock().getActivePane();
						if (pane && !('pane' in options)) {
							options.pane = pane;
						}
						break;
					}
				case 'Right Dock':
					{
						var pane = atom.workspace.getRightDock().getActivePane();
						if (pane && !('pane' in options)) {
							options.pane = pane;
						}
						break;
					}
			}
			return options;
		}

		/**
   * Function providing service functions offered by 'atom-xterm' service.
   *
   * @function
   * @returns {Object} Object holding service functions.
   */
	}, {
		key: 'provideAtomXtermService',
		value: function provideAtomXtermService() {
			var _this2 = this;

			return {
				openTerminal: _asyncToGenerator(function* () {
					return _this2.openTerminal.apply(_this2, arguments);
				})
			};
		}

		/**
   * Function providing service functions offered by 'platformioIDETerminal' service.
   *
   * @function
   * @returns {Object} Object holding service functions.
   */
	}, {
		key: 'providePlatformIOIDEService',
		value: function providePlatformIOIDEService() {
			var _this3 = this;

			return {
				updateProcessEnv: function updateProcessEnv(vars) {
					for (var _name in vars) {
						process.env[_name] = vars[_name];
					}
				},
				run: function run(commands) {
					return _this3.runCommands(commands);
				},
				getTerminalViews: function getTerminalViews() {
					return _this3.terminals_set;
				},
				open: function open() {
					return _this3.openTerminal();
				}
			};
		}

		/**
   * Function providing service functions offered by 'terminal' service.
   *
   * @function
   * @returns {Object} Object holding service functions.
   */
	}, {
		key: 'provideTerminalService',
		value: function provideTerminalService() {
			// for now it is the same as platformioIDETerminal service
			return this.providePlatformIOIDEService();
		}
	}, {
		key: 'close',
		value: function close() {
			this.performOnActiveTerminal(function (t) {
				return t.exit();
			});
		}
	}, {
		key: 'restart',
		value: function restart() {
			this.performOnActiveTerminal(function (t) {
				return t.restartPtyProcess();
			});
		}
	}, {
		key: 'copy',
		value: function copy() {
			this.performOnActiveTerminal(function (t) {
				return atom.clipboard.write(t.copyFromTerminal());
			});
		}
	}, {
		key: 'paste',
		value: function paste() {
			this.performOnActiveTerminal(function (t) {
				return t.pasteToTerminal(atom.clipboard.read());
			});
		}
	}, {
		key: 'unfocus',
		value: function unfocus() {
			atom.views.getView(atom.workspace).focus();
		}
	}, {
		key: 'clear',
		value: function clear() {
			this.performOnActiveTerminal(function (t) {
				return t.clear();
			});
		}
	}, {
		key: 'focus',
		value: function focus() {
			if (this.terminals_set.size === 0) {
				this.openTerminal();
			} else {
				var activeTerminal = [].concat(_toConsumableArray(this.terminals_set)).find(function (t) {
					return t.activeIndex === 0;
				});
				activeTerminal.focusOnTerminal(true);
			}
		}
	}, {
		key: 'toggleProfileMenu',
		value: function toggleProfileMenu() {
			var item = atom.workspace.getActivePaneItem();
			if ((0, _model.isXTerminalModel)(item)) {
				item.toggleProfileMenu();
			}
		}
	}, {
		key: 'reorganize',
		value: function reorganize(orientation) {
			if (this.terminals_set.size === 0) {
				return;
			}
			var activePane = atom.workspace.getActivePane();
			var activeItem = activePane.getActiveItem();
			var newPane = undefined;
			switch (orientation) {
				case 'current':
					newPane = activePane;
					break;
				case 'top':
					newPane = activePane.findTopmostSibling().splitUp();
					break;
				case 'bottom':
					newPane = activePane.findBottommostSibling().splitDown();
					break;
				case 'left':
					newPane = activePane.findLeftmostSibling().splitLeft();
					break;
				case 'right':
					newPane = activePane.findRightmostSibling().splitRight();
					break;
				case 'bottom-dock':
					newPane = atom.workspace.getBottomDock().getActivePane();
					break;
				case 'left-dock':
					newPane = atom.workspace.getLeftDock().getActivePane();
					break;
				case 'right-dock':
					newPane = atom.workspace.getRightDock().getActivePane();
					break;
				default:
					throw new Error('Unknown orientation: ' + orientation);
			}
			for (var item of this.terminals_set) {
				item.pane.moveItemToPane(item, newPane, -1);
			}
			if ((0, _model.isXTerminalModel)(activeItem)) {
				if (atom.workspace.getPanes().length > 1) {
					// When reorganizing still leaves more than one pane in the
					// workspace, another pane that doesn't include the newly
					// reorganized terminal tabs needs to be focused in order for
					// the terminal views to get properly resized in the new pane.
					// All this is yet another quirk.
					for (var pane of atom.workspace.getPanes()) {
						if (pane !== activeItem.pane) {
							pane.getElement().focus();
							break;
						}
					}
				}
				activeItem.pane.getElement().focus();
				activeItem.pane.setActiveItem(activeItem);
			} else if (activeItem instanceof HTMLElement) {
				activeItem.focus();
			} else if (typeof activeItem.getElement === 'function') {
				activeItem = activeItem.getElement();
				activeItem.focus();
			}
		}
	}], [{
		key: 'instance',
		get: function get() {
			if (!this[XTerminalSingletonSymbol]) {
				this[XTerminalSingletonSymbol] = new XTerminalSingleton(XTerminalSingletonSymbol);
			}
			return this[XTerminalSingletonSymbol];
		}
	}]);

	return XTerminalSingleton;
})();

Object.defineProperty(exports, 'config', {
	enumerable: true,
	get: function get() {
		return _config.config;
	}
});

function getInstance() {
	return XTerminalSingleton.instance;
}

function activate(state) {
	return XTerminalSingleton.instance.activate(state);
}

function deactivate() {
	return XTerminalSingleton.instance.deactivate();
}

function deserializeXTerminalModel(serializedModel, atomEnvironment) {
	return XTerminalSingleton.instance.deserializeXTerminalModel(serializedModel, atomEnvironment);
}

function provideAtomXtermService() {
	return XTerminalSingleton.instance.provideAtomXtermService();
}

function providePlatformIOIDEService() {
	return XTerminalSingleton.instance.providePlatformIOIDEService();
}

function provideTerminalService() {
	return XTerminalSingleton.instance.provideTerminalService();
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3gtdGVybWluYWwuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O29CQXNCb0MsTUFBTTs7c0JBRWQsVUFBVTs7cUJBQ0osU0FBUzs7dUJBQ1YsV0FBVzs7cUJBQ0ssU0FBUzs7d0JBQ00sWUFBWTs7a0NBQ2hDLHdCQUF3Qjs7Z0NBQzFCLHNCQUFzQjs7b0NBQ2xCLDBCQUEwQjs7a0NBQzVCLHdCQUF3Qjs7dUNBQ25CLDZCQUE2Qjs7cUNBQy9CLDJCQUEyQjs7a0NBQzlCLHdCQUF3Qjs7Z0NBQzFCLHNCQUFzQjs7eUJBRTVDLFlBQVk7O0FBRWhDLElBQU0sd0JBQXdCLEdBQUcsTUFBTSxDQUFDLDZCQUE2QixDQUFDLENBQUE7O0lBRWhFLGtCQUFrQjtBQUNYLFVBRFAsa0JBQWtCLENBQ1YsV0FBVyxFQUFFO3dCQURyQixrQkFBa0I7O0FBRXRCLE1BQUksd0JBQXdCLEtBQUssV0FBVyxFQUFFO0FBQzdDLFNBQU0sSUFBSSxLQUFLLENBQUMscURBQXFELENBQUMsQ0FBQTtHQUN0RTtFQUNEOztjQUxJLGtCQUFrQjs7U0FjZCxrQkFBQyxLQUFLLEVBQUU7Ozs7QUFFaEIsT0FBSSxDQUFDLGlCQUFpQixHQUFHLHFDQUEyQixRQUFRLENBQUE7Ozs7QUFJNUQsT0FBSSxDQUFDLGlCQUFpQixDQUFDLGdCQUFnQixFQUFFLENBQUE7OztBQUd6QyxPQUFJLENBQUMsV0FBVyxHQUFHLCtCQUF5QixDQUFBOzs7QUFHNUMsT0FBSSxDQUFDLGFBQWEsR0FBRyxJQUFJLEdBQUcsRUFBRSxDQUFBOzs7QUFHOUIsUUFBSyxJQUFNLElBQUkseUJBQWlCO0FBQy9CLFFBQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxPQUFPLEVBQUUsVUFBQyxJQUFzQixFQUFLO1NBQXpCLFFBQVEsR0FBVixJQUFzQixDQUFwQixRQUFRO1NBQUUsUUFBUSxHQUFwQixJQUFzQixDQUFWLFFBQVE7O0FBQy9FLFdBQUssaUJBQWlCLENBQUMsZ0JBQWdCLEVBQUUsQ0FBQTtLQUN6QyxDQUFDLENBQUMsQ0FBQTtJQUNIOztBQUVELE9BQUksQ0FBQyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLG1CQUFtQixFQUFFLFVBQUMsS0FBc0IsRUFBSztRQUF6QixRQUFRLEdBQVYsS0FBc0IsQ0FBcEIsUUFBUTtRQUFFLFFBQVEsR0FBcEIsS0FBc0IsQ0FBVixRQUFROztBQUN0RixVQUFLLGlCQUFpQixDQUFDLGdCQUFnQixFQUFFLENBQUE7SUFDekMsQ0FBQyxDQUFDLENBQUE7O0FBRUgsT0FBSSxDQUFDLFdBQVcsQ0FBQyxHQUFHOztBQUVuQixPQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsd0JBQWlCLFVBQUMsY0FBYyxFQUFLO0FBQzlELFFBQU0sZ0JBQWdCLEdBQUcsK0JBQXNCLENBQUE7QUFDL0Msb0JBQWdCLENBQUMsVUFBVSxDQUFDLGNBQWMsQ0FBQyxDQUFBO0FBQzNDLFdBQU8sZ0JBQWdCLENBQUE7SUFDdkIsQ0FBQzs7QUFFRixPQUFJLENBQUMsS0FBSyxDQUFDLGVBQWUsOENBQTRCLFVBQUMseUJBQXlCLEVBQUs7QUFDcEYsUUFBTSwyQkFBMkIsR0FBRyxxREFBaUMsQ0FBQTtBQUNyRSwrQkFBMkIsQ0FBQyxVQUFVLENBQUMseUJBQXlCLENBQUMsQ0FBQTtBQUNqRSxXQUFPLDJCQUEyQixDQUFBO0lBQ2xDLENBQUM7O0FBRUYsT0FBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLGtEQUE4QixVQUFDLDJCQUEyQixFQUFLO0FBQ3hGLFFBQU0sNkJBQTZCLEdBQUcseURBQW1DLENBQUE7QUFDekUsaUNBQTZCLENBQUMsVUFBVSxDQUFDLDJCQUEyQixDQUFDLENBQUE7QUFDckUsV0FBTyw2QkFBNkIsQ0FBQTtJQUNwQyxDQUFDLEVBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLHdEQUFpQyxVQUFDLDhCQUE4QixFQUFLO0FBQzlGLFFBQU0sZ0NBQWdDLEdBQUcsK0RBQXNDLENBQUE7QUFDL0Usb0NBQWdDLENBQUMsVUFBVSxDQUFDLDhCQUE4QixDQUFDLENBQUE7QUFDM0UsV0FBTyxnQ0FBZ0MsQ0FBQTtJQUN2QyxDQUFDLEVBQ0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxlQUFlLDhDQUE0QixVQUFDLHlCQUF5QixFQUFLO0FBQ3BGLFFBQU0sMkJBQTJCLEdBQUcscURBQWlDLENBQUE7QUFDckUsK0JBQTJCLENBQUMsVUFBVSxDQUFDLHlCQUF5QixDQUFDLENBQUE7QUFDakUsV0FBTywyQkFBMkIsQ0FBQTtJQUNsQyxDQUFDOzs7QUFHRixPQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxVQUFDLEdBQUcsRUFBSztBQUNqQyxRQUFJLEdBQUcsQ0FBQyxVQUFVLCtCQUFxQixFQUFFO0FBQ3hDLFNBQU0sSUFBSSxHQUFHLDBCQUFtQjtBQUMvQixTQUFHLEVBQUgsR0FBRztBQUNILG1CQUFhLEVBQUUsTUFBSyxhQUFhO01BQ2pDLENBQUMsQ0FBQTtBQUNGLFlBQU8sSUFBSSxDQUFBO0tBQ1g7SUFDRCxDQUFDOzs7QUFHRixPQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksQ0FBQyxVQUFDLElBQUksRUFBSzs7QUFFckMsVUFBSyxXQUFXLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsVUFBQyxJQUFJLEVBQUs7O0FBRWhELFNBQUksNkJBQWlCLElBQUksQ0FBQyxFQUFFO0FBQzNCLFVBQUksQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUE7TUFDckI7QUFDRCxtQ0FBa0IsTUFBSyxhQUFhLENBQUMsQ0FBQTtLQUNyQyxDQUFDLENBQUMsQ0FBQTtBQUNILGtDQUFrQixNQUFLLGFBQWEsQ0FBQyxDQUFBO0lBQ3JDLENBQUM7OztBQUdGLE9BQUksQ0FBQyxTQUFTLENBQUMscUJBQXFCLENBQUMsVUFBQyxJQUFJLEVBQUs7O0FBRTlDLFFBQUksNkJBQWlCLElBQUksQ0FBQyxFQUFFO0FBQzNCLFNBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQTtLQUN0QjtBQUNELGtDQUFrQixNQUFLLGFBQWEsQ0FBQyxDQUFBO0lBQ3JDLENBQUMsRUFFRixJQUFJLENBQUMsU0FBUyxDQUFDLFlBQVksRUFBRSxDQUFDLGNBQWMsQ0FBQyxVQUFDLE9BQU8sRUFBSztBQUN6RCxRQUFJLE9BQU8sRUFBRTtBQUNaLFNBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUM5RCxTQUFJLDZCQUFpQixJQUFJLENBQUMsRUFBRTtBQUMzQixVQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7TUFDdEI7S0FDRDtBQUNELGtDQUFrQixNQUFLLGFBQWEsQ0FBQyxDQUFBO0lBQ3JDLENBQUMsRUFFRixJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLGNBQWMsQ0FBQyxVQUFDLE9BQU8sRUFBSztBQUN4RCxRQUFJLE9BQU8sRUFBRTtBQUNaLFNBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUM3RCxTQUFJLDZCQUFpQixJQUFJLENBQUMsRUFBRTtBQUMzQixVQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7TUFDdEI7S0FDRDtBQUNELGtDQUFrQixNQUFLLGFBQWEsQ0FBQyxDQUFBO0lBQ3JDLENBQUMsRUFFRixJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDLGNBQWMsQ0FBQyxVQUFDLE9BQU8sRUFBSztBQUMxRCxRQUFJLE9BQU8sRUFBRTtBQUNaLFNBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtBQUMvRCxTQUFJLDZCQUFpQixJQUFJLENBQUMsRUFBRTtBQUMzQixVQUFJLENBQUMsZUFBZSxFQUFFLENBQUE7TUFDdEI7S0FDRDtBQUNELGtDQUFrQixNQUFLLGFBQWEsQ0FBQyxDQUFBO0lBQ3JDLENBQUM7OztBQUdGLE9BQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGdCQUFnQixFQUFFO0FBQ25DLHFCQUFpQixFQUFFO1lBQU0sTUFBSyxJQUFJLENBQ2pDLE1BQUssaUJBQWlCLENBQUMsY0FBYyxFQUFFLEVBQ3ZDLE1BQUssa0JBQWtCLEVBQUUsQ0FDekI7S0FBQTtBQUNELDRCQUF3QixFQUFFO1lBQU0sTUFBSyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0tBQUE7QUFDdkUsOEJBQTBCLEVBQUU7WUFBTSxNQUFLLElBQUksQ0FDMUMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLENBQ2Y7S0FBQTtBQUNELGdDQUE0QixFQUFFO1lBQU0sTUFBSyxJQUFJLENBQzVDLE1BQUssaUJBQWlCLENBQUMsY0FBYyxFQUFFLEVBQ3ZDLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxDQUNqQjtLQUFBO0FBQ0QsZ0NBQTRCLEVBQUU7WUFBTSxNQUFLLElBQUksQ0FDNUMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQ2pCO0tBQUE7QUFDRCxpQ0FBNkIsRUFBRTtZQUFNLE1BQUssSUFBSSxDQUM3QyxNQUFLLGlCQUFpQixDQUFDLGNBQWMsRUFBRSxFQUN2QyxFQUFFLEtBQUssRUFBRSxPQUFPLEVBQUUsQ0FDbEI7S0FBQTtBQUNELHVDQUFtQyxFQUFFO1lBQU0sTUFBSyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDO0tBQUE7QUFDbEcscUNBQWlDLEVBQUU7WUFBTSxNQUFLLGtCQUFrQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLENBQUM7S0FBQTtBQUM5RixzQ0FBa0MsRUFBRTtZQUFNLE1BQUssa0JBQWtCLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQztLQUFBO0FBQ2hHLG9DQUFnQyxFQUFFO1lBQU0sTUFBSyxpQkFBaUIsRUFBRTtLQUFBO0FBQ2hFLDJCQUF1QixFQUFFO1lBQU0sTUFBSyxVQUFVLENBQUMsU0FBUyxDQUFDO0tBQUE7QUFDekQsK0JBQTJCLEVBQUU7WUFBTSxNQUFLLFVBQVUsQ0FBQyxLQUFLLENBQUM7S0FBQTtBQUN6RCxrQ0FBOEIsRUFBRTtZQUFNLE1BQUssVUFBVSxDQUFDLFFBQVEsQ0FBQztLQUFBO0FBQy9ELGdDQUE0QixFQUFFO1lBQU0sTUFBSyxVQUFVLENBQUMsTUFBTSxDQUFDO0tBQUE7QUFDM0QsaUNBQTZCLEVBQUU7WUFBTSxNQUFLLFVBQVUsQ0FBQyxPQUFPLENBQUM7S0FBQTtBQUM3RCx1Q0FBbUMsRUFBRTtZQUFNLE1BQUssVUFBVSxDQUFDLGFBQWEsQ0FBQztLQUFBO0FBQ3pFLHFDQUFpQyxFQUFFO1lBQU0sTUFBSyxVQUFVLENBQUMsV0FBVyxDQUFDO0tBQUE7QUFDckUsc0NBQWtDLEVBQUU7WUFBTSxNQUFLLFVBQVUsQ0FBQyxZQUFZLENBQUM7S0FBQTtBQUN2RSwwQkFBc0IsRUFBRTtZQUFNLE1BQUssZ0JBQWdCLEVBQUU7S0FBQTtBQUNyRCxxQ0FBaUMsRUFBRTtZQUFNLE1BQUssZUFBZSxFQUFFO0tBQUE7QUFDL0Qsa0NBQThCLEVBQUU7WUFBTSxNQUFLLFlBQVksRUFBRTtLQUFBO0FBQ3pELHNCQUFrQixFQUFFO1lBQU0sTUFBSyxLQUFLLEVBQUU7S0FBQTtJQUN0QyxDQUFDLEVBQ0YsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsd0NBQXdDLEVBQUU7QUFDM0Qsa0NBQThCLEVBQUU7QUFDL0IsMkJBQXNCLEVBQUUsSUFBSTtBQUM1QixnQkFBVyxFQUFFLHFCQUFDLEtBQVU7VUFBUixNQUFNLEdBQVIsS0FBVSxDQUFSLE1BQU07YUFBTyxNQUFLLElBQUksQ0FDckMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsTUFBSyxrQkFBa0IsQ0FBQyxFQUFFLE1BQU0sRUFBTixNQUFNLEVBQUUsQ0FBQyxDQUNuQztNQUFBO0tBQ0Q7QUFDRCx5Q0FBcUMsRUFBRTtBQUN0QywyQkFBc0IsRUFBRSxJQUFJO0FBQzVCLGdCQUFXLEVBQUUscUJBQUMsS0FBVTtVQUFSLE1BQU0sR0FBUixLQUFVLENBQVIsTUFBTTthQUFPLE1BQUssa0JBQWtCLENBQ25ELElBQUksQ0FBQyxTQUFTLEVBQ2QsRUFBRSxNQUFNLEVBQU4sTUFBTSxFQUFFLENBQ1Y7TUFBQTtLQUNEO0FBQ0QsMkNBQXVDLEVBQUU7QUFDeEMsMkJBQXNCLEVBQUUsSUFBSTtBQUM1QixnQkFBVyxFQUFFLHFCQUFDLEtBQVU7VUFBUixNQUFNLEdBQVIsS0FBVSxDQUFSLE1BQU07YUFBTyxNQUFLLElBQUksQ0FDckMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBTixNQUFNLEVBQUUsQ0FDdkI7TUFBQTtLQUNEO0FBQ0QsNkNBQXlDLEVBQUU7QUFDMUMsMkJBQXNCLEVBQUUsSUFBSTtBQUM1QixnQkFBVyxFQUFFLHFCQUFDLEtBQVU7VUFBUixNQUFNLEdBQVIsS0FBVSxDQUFSLE1BQU07YUFBTyxNQUFLLElBQUksQ0FDckMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBTixNQUFNLEVBQUUsQ0FDekI7TUFBQTtLQUNEO0FBQ0QsNkNBQXlDLEVBQUU7QUFDMUMsMkJBQXNCLEVBQUUsSUFBSTtBQUM1QixnQkFBVyxFQUFFLHFCQUFDLEtBQVU7VUFBUixNQUFNLEdBQVIsS0FBVSxDQUFSLE1BQU07YUFBTyxNQUFLLElBQUksQ0FDckMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBTixNQUFNLEVBQUUsQ0FDekI7TUFBQTtLQUNEO0FBQ0QsOENBQTBDLEVBQUU7QUFDM0MsMkJBQXNCLEVBQUUsSUFBSTtBQUM1QixnQkFBVyxFQUFFLHFCQUFDLEtBQVU7VUFBUixNQUFNLEdBQVIsS0FBVSxDQUFSLE1BQU07YUFBTyxNQUFLLElBQUksQ0FDckMsTUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBTixNQUFNLEVBQUUsQ0FDMUI7TUFBQTtLQUNEO0FBQ0Qsb0RBQWdELEVBQUU7QUFDakQsMkJBQXNCLEVBQUUsSUFBSTtBQUM1QixnQkFBVyxFQUFFLHFCQUFDLEtBQVU7VUFBUixNQUFNLEdBQVIsS0FBVSxDQUFSLE1BQU07YUFBTyxNQUFLLGtCQUFrQixDQUNuRCxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxFQUM5QixFQUFFLE1BQU0sRUFBTixNQUFNLEVBQUUsQ0FDVjtNQUFBO0tBQ0Q7QUFDRCxrREFBOEMsRUFBRTtBQUMvQywyQkFBc0IsRUFBRSxJQUFJO0FBQzVCLGdCQUFXLEVBQUUscUJBQUMsTUFBVTtVQUFSLE1BQU0sR0FBUixNQUFVLENBQVIsTUFBTTthQUFPLE1BQUssa0JBQWtCLENBQ25ELElBQUksQ0FBQyxTQUFTLENBQUMsV0FBVyxFQUFFLEVBQzVCLEVBQUUsTUFBTSxFQUFOLE1BQU0sRUFBRSxDQUNWO01BQUE7S0FDRDtBQUNELG1EQUErQyxFQUFFO0FBQ2hELDJCQUFzQixFQUFFLElBQUk7QUFDNUIsZ0JBQVcsRUFBRSxxQkFBQyxNQUFVO1VBQVIsTUFBTSxHQUFSLE1BQVUsQ0FBUixNQUFNO2FBQU8sTUFBSyxrQkFBa0IsQ0FDbkQsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsRUFDN0IsRUFBRSxNQUFNLEVBQU4sTUFBTSxFQUFFLENBQ1Y7TUFBQTtLQUNEO0lBQ0QsQ0FBQyxFQUNGLElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLFlBQVksRUFBRTtBQUMvQixzQkFBa0IsRUFBRTtZQUFNLE1BQUssS0FBSyxFQUFFO0tBQUE7QUFDdEMsd0JBQW9CLEVBQUU7WUFBTSxNQUFLLE9BQU8sRUFBRTtLQUFBO0FBQzFDLHFCQUFpQixFQUFFO1lBQU0sTUFBSyxJQUFJLEVBQUU7S0FBQTtBQUNwQyxzQkFBa0IsRUFBRTtZQUFNLE1BQUssS0FBSyxFQUFFO0tBQUE7QUFDdEMsd0JBQW9CLEVBQUU7WUFBTSxNQUFLLE9BQU8sRUFBRTtLQUFBO0FBQzFDLHNCQUFrQixFQUFFO1lBQU0sTUFBSyxLQUFLLEVBQUU7S0FBQTtJQUN0QyxDQUFDLENBQ0YsQ0FBQTtHQUNEOzs7U0FFVSxzQkFBRztBQUNiLE9BQUksQ0FBQyxnQkFBZ0IsRUFBRSxDQUFBO0FBQ3ZCLE9BQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxFQUFFLENBQUE7R0FDMUI7OztTQUV5QixtQ0FBQyxlQUFlLEVBQUUsZUFBZSxFQUFFO0FBQzVELE9BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUFDLFlBQVksQ0FBQyxDQUFBO0FBQ3RELE9BQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQTtBQUNkLE9BQUksQ0FBQyxXQUFXLEVBQUUsQ0FBQTtBQUNsQixPQUFNLGtDQUFrQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLGdFQUFnRSxDQUFDLENBQUE7QUFDNUgsT0FBSSxDQUFDLGtDQUFrQyxFQUFFO0FBQ3hDLFdBQU07SUFDTjtBQUNELE9BQU0sR0FBRyxHQUFHLG1CQUFRLGVBQWUsQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUN4QyxPQUFNLHlCQUF5QixHQUFHLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUE7QUFDbkYsT0FBSSx5QkFBeUIsS0FBSyxPQUFPLEVBQUU7QUFDMUMsV0FBTTtJQUNOO0FBQ0QsVUFBTywwQkFBbUI7QUFDekIsT0FBRyxFQUFFLEdBQUcsQ0FBQyxJQUFJO0FBQ2IsaUJBQWEsRUFBRSxJQUFJLENBQUMsYUFBYTtJQUNqQyxDQUFDLENBQUE7R0FDRjs7O1NBRWtCLDRCQUFDLFlBQVksRUFBZ0I7T0FBZCxPQUFPLHlEQUFHLEVBQUU7O0FBQzdDLE9BQU0sSUFBSSxHQUFHLFlBQVksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtBQUN6QyxPQUFJLElBQUksRUFBRTtBQUNULFdBQU8sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO0lBQ25CO0FBQ0QsVUFBTyxJQUFJLENBQUMsSUFBSSxDQUNmLElBQUksQ0FBQyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsRUFDdkMsT0FBTyxDQUNQLENBQUE7R0FDRDs7O1NBRU8saUJBQUMsTUFBTSxFQUFFO0FBQ2hCLE9BQUksQ0FBQyxNQUFNLEVBQUU7QUFDWixRQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFBO0FBQ3JDLFFBQUksS0FBSyxJQUFJLEtBQUssQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFO0FBQzlCLFlBQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0tBQ2Y7QUFDRCxXQUFPLElBQUksQ0FBQTtJQUNYOztBQUVELE9BQU0sUUFBUSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUE7QUFDN0MsT0FBSSxRQUFRLEVBQUU7O0FBRWIsUUFBTSxRQUFRLEdBQUcsUUFBUSxDQUFDLGFBQWEsQ0FBQyxtREFBbUQsQ0FBQyxDQUFBO0FBQzVGLFFBQUksUUFBUSxFQUFFO0FBQ2IsWUFBTyxRQUFRLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQTtLQUM1QjtBQUNELFdBQU8sSUFBSSxDQUFBO0lBQ1g7O0FBRUQsT0FBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxDQUFBO0FBQzdDLE9BQUksR0FBRyxFQUFFOztBQUVSLFFBQU0sS0FBSyxHQUFHLEdBQUcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDLENBQUE7QUFDekMsUUFBSSxLQUFLLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUU7QUFDaEMsWUFBTyxLQUFLLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQTtLQUN6QjtBQUNELFdBQU8sSUFBSSxDQUFBO0lBQ1g7O0FBRUQsT0FBTSxVQUFVLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQyxDQUFBO0FBQ3JELE9BQUksVUFBVSxJQUFJLE9BQU8sVUFBVSxDQUFDLFFBQVEsS0FBSyxVQUFVLEVBQUU7O0FBRTVELFFBQU0sS0FBSyxHQUFHLFVBQVUsQ0FBQyxRQUFRLEVBQUUsQ0FBQTtBQUNuQyxRQUFJLEtBQUssSUFBSSxPQUFPLEtBQUssQ0FBQyxPQUFPLEtBQUssVUFBVSxFQUFFO0FBQ2pELFlBQU8sS0FBSyxDQUFDLE9BQU8sRUFBRSxDQUFBO0tBQ3RCO0FBQ0QsV0FBTyxJQUFJLENBQUE7SUFDWDs7QUFFRCxVQUFPLElBQUksQ0FBQTtHQUNYOzs7U0FFaUIsNkJBQUc7QUFDcEIsT0FBTSxpQkFBaUIsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQ3hELE9BQU0saUJBQWlCLEdBQUcsaUJBQWlCLENBQUMsYUFBYSxFQUFFLENBQUE7QUFDM0QsUUFBSyxJQUFNLFFBQVEsSUFBSSxJQUFJLENBQUMsYUFBYSxFQUFFOzs7QUFHMUMsUUFBTSxjQUFjLEdBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxhQUFhLEVBQUUsQ0FBQTtBQUNwRCxZQUFRLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLEtBQUssRUFBRSxDQUFBO0FBQ2xDLFlBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ3JDLFlBQVEsQ0FBQyxJQUFJLENBQUMsYUFBYSxDQUFDLGNBQWMsQ0FBQyxDQUFBO0lBQzNDO0FBQ0Qsb0JBQWlCLENBQUMsVUFBVSxFQUFFLENBQUMsS0FBSyxFQUFFLENBQUE7QUFDdEMsb0JBQWlCLENBQUMsYUFBYSxDQUFDLGlCQUFpQixDQUFDLENBQUE7R0FDbEQ7OztTQUVnQiw0QkFBRztBQUNuQixRQUFLLElBQU0sUUFBUSxJQUFJLElBQUksQ0FBQyxhQUFhLEVBQUU7QUFDMUMsWUFBUSxDQUFDLElBQUksRUFBRSxDQUFBO0lBQ2Y7R0FDRDs7O1NBRWUsMkJBQUc7QUFDbEIsT0FBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxtQkFBbUIsRUFBRSxDQUFBO0FBQ25ELE9BQUksQ0FBQyxNQUFNLEVBQUU7QUFDWixXQUFPLEVBQUUsQ0FBQTtJQUNUOztBQUVELE9BQUksWUFBWSxHQUFHLEVBQUUsQ0FBQTtBQUNyQixPQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsZUFBZSxFQUFFLENBQUE7QUFDMUMsT0FBSSxTQUFTLEVBQUU7QUFDZCxnQkFBWSxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBQ2hELE1BQU07QUFDTixRQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsdUJBQXVCLEVBQUUsQ0FBQTtBQUMvQyxRQUFJLE1BQU0sRUFBRTtBQUNYLFNBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUE7QUFDcEQsaUJBQVksR0FBRyxJQUFJLENBQUE7QUFDbkIsV0FBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQTtLQUNsQjtJQUNEOztBQUVELFVBQU8sWUFBWSxDQUFBO0dBQ25COzs7U0FFaUIsNkJBQUc7QUFDcEIsT0FBTSxTQUFTLGdDQUFPLElBQUksQ0FBQyxhQUFhLEVBQUMsQ0FBQTtBQUN6QyxVQUFPLFNBQVMsQ0FBQyxJQUFJLENBQUMsVUFBQSxDQUFDO1dBQUksQ0FBQyxDQUFDLGdCQUFnQixFQUFFO0lBQUEsQ0FBQyxDQUFBO0dBQ2hEOzs7U0FFdUIsaUNBQUMsU0FBUyxFQUFFO0FBQ25DLE9BQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0FBQ3pDLE9BQUksUUFBUSxFQUFFO0FBQ2IsYUFBUyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0lBQ25CO0dBQ0Q7OztTQUVlLDJCQUFHO0FBQ2xCLE9BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQTtBQUN4QyxPQUFJLFNBQVMsRUFBRTtBQUNkLFFBQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFBLENBQUM7WUFBSSxDQUFDLENBQUMsZUFBZSxDQUFDLFNBQVMsQ0FBQztLQUFBLENBQUMsQ0FBQTtJQUMvRDtHQUNEOzs7U0FFWSx3QkFBRztBQUNmLE9BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxlQUFlLEVBQUUsQ0FBQTtBQUN4QyxPQUFJLFNBQVMsRUFBRTtBQUNkLFFBQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFBLENBQUM7WUFBSSxDQUFDLENBQUMsVUFBVSxDQUFDLFNBQVMsQ0FBQztLQUFBLENBQUMsQ0FBQTtJQUMxRDtHQUNEOzs7MkJBRVUsV0FBQyxHQUFHLEVBQWdCO09BQWQsT0FBTyx5REFBRyxFQUFFOztBQUM1QixPQUFNLEdBQUcsR0FBRyxtQkFBUSxHQUFHLENBQUMsQ0FBQTtBQUN4QixPQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLEtBQUssSUFBSSxFQUFFO0FBQy9ELFFBQUksQ0FBQyxJQUFJLENBQUMsaUJBQWlCLENBQUMsY0FBYyxFQUFFLENBQUMseUJBQXlCLEVBQUU7QUFDdkUsUUFBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsMkJBQTJCLEVBQUUsS0FBSyxDQUFDLENBQUE7S0FDeEQ7SUFDRDs7QUFFRCxPQUFJLE9BQU8sQ0FBQyxNQUFNLEVBQUU7QUFDbkIsUUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDM0MsUUFBSSxNQUFNLEVBQUU7QUFDWCxRQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsTUFBTSxDQUFDLENBQUE7S0FDbkM7SUFDRDs7QUFFRCxVQUFPLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUE7R0FDN0M7Ozs7Ozs7Ozs7Ozs7OzsyQkFha0IsV0FBQyxPQUFPLEVBQWdCO09BQWQsT0FBTyx5REFBRyxFQUFFOztBQUN4QyxVQUFPLEdBQUcsSUFBSSxDQUFDLGtCQUFrQixDQUFDLE9BQU8sQ0FBQyxDQUFBO0FBQzFDLFVBQU8sSUFBSSxDQUFDLElBQUksQ0FDZixxQ0FBMkIsUUFBUSxDQUFDLDZCQUE2QixDQUFDLE9BQU8sQ0FBQyxFQUMxRSxPQUFPLENBQ1AsQ0FBQTtHQUNEOzs7Ozs7Ozs7Ozs7MkJBVWlCLFdBQUMsUUFBUSxFQUFFO0FBQzVCLE9BQUksUUFBUSxZQUFBLENBQUE7QUFDWixPQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLHlDQUF5QyxDQUFDLEVBQUU7QUFDL0QsWUFBUSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFBO0lBQ25DOztBQUVELE9BQUksQ0FBQyxRQUFRLEVBQUU7QUFDZCxRQUFNLE9BQU8sR0FBRyxJQUFJLENBQUMsa0JBQWtCLEVBQUUsQ0FBQTtBQUN6QyxZQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsSUFBSSxDQUN6QixxQ0FBMkIsUUFBUSxDQUFDLGNBQWMsRUFBRSxFQUNwRCxPQUFPLENBQ1AsQ0FBQTtJQUNEOztBQUVELFNBQU0sUUFBUSxDQUFDLE9BQU8sQ0FBQyxrQkFBa0IsQ0FBQTtBQUN6QyxRQUFLLElBQU0sT0FBTyxJQUFJLFFBQVEsRUFBRTtBQUMvQixZQUFRLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQzVCO0dBQ0Q7OztTQUVrQiw4QkFBZTtPQUFkLE9BQU8seURBQUcsRUFBRTs7QUFDL0IsT0FBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsaURBQWlELENBQUMsQ0FBQTtBQUNuRixXQUFRLFFBQVE7QUFDZixTQUFLLFFBQVE7QUFBRTtBQUNkLFVBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUE7QUFDM0MsVUFBSSxJQUFJLElBQUksRUFBRSxNQUFNLElBQUksT0FBTyxDQUFBLEFBQUMsRUFBRTtBQUNqQyxjQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQTtPQUNuQjtBQUNELFlBQUs7TUFDTDtBQUFBLEFBQ0QsU0FBSyxVQUFVO0FBQ2QsU0FBSSxFQUFFLE9BQU8sSUFBSSxPQUFPLENBQUEsQUFBQyxFQUFFO0FBQzFCLGFBQU8sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFBO01BQ3BCO0FBQ0QsV0FBSztBQUFBLEFBQ04sU0FBSyxZQUFZO0FBQ2hCLFNBQUksRUFBRSxPQUFPLElBQUksT0FBTyxDQUFBLEFBQUMsRUFBRTtBQUMxQixhQUFPLENBQUMsS0FBSyxHQUFHLE1BQU0sQ0FBQTtNQUN0QjtBQUNELFdBQUs7QUFBQSxBQUNOLFNBQUssWUFBWTtBQUNoQixTQUFJLEVBQUUsT0FBTyxJQUFJLE9BQU8sQ0FBQSxBQUFDLEVBQUU7QUFDMUIsYUFBTyxDQUFDLEtBQUssR0FBRyxNQUFNLENBQUE7TUFDdEI7QUFDRCxXQUFLO0FBQUEsQUFDTixTQUFLLGFBQWE7QUFDakIsU0FBSSxFQUFFLE9BQU8sSUFBSSxPQUFPLENBQUEsQUFBQyxFQUFFO0FBQzFCLGFBQU8sQ0FBQyxLQUFLLEdBQUcsT0FBTyxDQUFBO01BQ3ZCO0FBQ0QsV0FBSztBQUFBLEFBQ04sU0FBSyxhQUFhO0FBQUU7QUFDbkIsVUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQTtBQUMzRCxVQUFJLElBQUksSUFBSSxFQUFFLE1BQU0sSUFBSSxPQUFPLENBQUEsQUFBQyxFQUFFO0FBQ2pDLGNBQU8sQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFBO09BQ25CO0FBQ0QsWUFBSztNQUNMO0FBQUEsQUFDRCxTQUFLLFdBQVc7QUFBRTtBQUNqQixVQUFNLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQ3pELFVBQUksSUFBSSxJQUFJLEVBQUUsTUFBTSxJQUFJLE9BQU8sQ0FBQSxBQUFDLEVBQUU7QUFDakMsY0FBTyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUE7T0FDbkI7QUFDRCxZQUFLO01BQ0w7QUFBQSxBQUNELFNBQUssWUFBWTtBQUFFO0FBQ2xCLFVBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsWUFBWSxFQUFFLENBQUMsYUFBYSxFQUFFLENBQUE7QUFDMUQsVUFBSSxJQUFJLElBQUksRUFBRSxNQUFNLElBQUksT0FBTyxDQUFBLEFBQUMsRUFBRTtBQUNqQyxjQUFPLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQTtPQUNuQjtBQUNELFlBQUs7TUFDTDtBQUFBLElBQ0Q7QUFDRCxVQUFPLE9BQU8sQ0FBQTtHQUNkOzs7Ozs7Ozs7O1NBUXVCLG1DQUFHOzs7QUFDMUIsVUFBTztBQUNOLGdCQUFZLG9CQUFFLGFBQW1CO0FBQ2hDLFlBQU8sT0FBSyxZQUFZLE1BQUEsbUJBQVMsQ0FBQTtLQUNqQyxDQUFBO0lBQ0QsQ0FBQTtHQUNEOzs7Ozs7Ozs7O1NBUTJCLHVDQUFHOzs7QUFDOUIsVUFBTztBQUNOLG9CQUFnQixFQUFDLDBCQUFDLElBQUksRUFBRTtBQUN2QixVQUFLLElBQU0sS0FBSSxJQUFJLElBQUksRUFBRTtBQUN4QixhQUFPLENBQUMsR0FBRyxDQUFDLEtBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxLQUFJLENBQUMsQ0FBQTtNQUM5QjtLQUNEO0FBQ0QsT0FBRyxFQUFFLGFBQUMsUUFBUSxFQUFLO0FBQ2xCLFlBQU8sT0FBSyxXQUFXLENBQUMsUUFBUSxDQUFDLENBQUE7S0FDakM7QUFDRCxvQkFBZ0IsRUFBRSw0QkFBTTtBQUN2QixZQUFPLE9BQUssYUFBYSxDQUFBO0tBQ3pCO0FBQ0QsUUFBSSxFQUFFLGdCQUFNO0FBQ1gsWUFBTyxPQUFLLFlBQVksRUFBRSxDQUFBO0tBQzFCO0lBQ0QsQ0FBQTtHQUNEOzs7Ozs7Ozs7O1NBUXNCLGtDQUFHOztBQUV6QixVQUFPLElBQUksQ0FBQywyQkFBMkIsRUFBRSxDQUFBO0dBQ3pDOzs7U0FFSyxpQkFBRztBQUNSLE9BQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFBLENBQUM7V0FBSSxDQUFDLENBQUMsSUFBSSxFQUFFO0lBQUEsQ0FBQyxDQUFBO0dBQzNDOzs7U0FFTyxtQkFBRztBQUNWLE9BQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFBLENBQUM7V0FBSSxDQUFDLENBQUMsaUJBQWlCLEVBQUU7SUFBQSxDQUFDLENBQUE7R0FDeEQ7OztTQUVJLGdCQUFHO0FBQ1AsT0FBSSxDQUFDLHVCQUF1QixDQUFDLFVBQUEsQ0FBQztXQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFDO0lBQUEsQ0FBQyxDQUFBO0dBQzdFOzs7U0FFSyxpQkFBRztBQUNSLE9BQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFBLENBQUM7V0FBSSxDQUFDLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLENBQUM7SUFBQSxDQUFDLENBQUE7R0FDM0U7OztTQUVPLG1CQUFHO0FBQ1YsT0FBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFBO0dBQzFDOzs7U0FFSyxpQkFBRztBQUNSLE9BQUksQ0FBQyx1QkFBdUIsQ0FBQyxVQUFBLENBQUM7V0FBSSxDQUFDLENBQUMsS0FBSyxFQUFFO0lBQUEsQ0FBQyxDQUFBO0dBQzVDOzs7U0FFSyxpQkFBRztBQUNSLE9BQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFO0FBQ2xDLFFBQUksQ0FBQyxZQUFZLEVBQUUsQ0FBQTtJQUNuQixNQUFNO0FBQ04sUUFBTSxjQUFjLEdBQUcsNkJBQUksSUFBSSxDQUFDLGFBQWEsR0FBRSxJQUFJLENBQUMsVUFBQSxDQUFDO1lBQUksQ0FBQyxDQUFDLFdBQVcsS0FBSyxDQUFDO0tBQUEsQ0FBQyxDQUFBO0FBQzdFLGtCQUFjLENBQUMsZUFBZSxDQUFDLElBQUksQ0FBQyxDQUFBO0lBQ3BDO0dBQ0Q7OztTQUVpQiw2QkFBRztBQUNwQixPQUFNLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGlCQUFpQixFQUFFLENBQUE7QUFDL0MsT0FBSSw2QkFBaUIsSUFBSSxDQUFDLEVBQUU7QUFDM0IsUUFBSSxDQUFDLGlCQUFpQixFQUFFLENBQUE7SUFDeEI7R0FDRDs7O1NBRVUsb0JBQUMsV0FBVyxFQUFFO0FBQ3hCLE9BQUksSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLEtBQUssQ0FBQyxFQUFFO0FBQ2xDLFdBQU07SUFDTjtBQUNELE9BQU0sVUFBVSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsYUFBYSxFQUFFLENBQUE7QUFDakQsT0FBSSxVQUFVLEdBQUcsVUFBVSxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQzNDLE9BQUksT0FBTyxZQUFBLENBQUE7QUFDWCxXQUFRLFdBQVc7QUFDbEIsU0FBSyxTQUFTO0FBQ2IsWUFBTyxHQUFHLFVBQVUsQ0FBQTtBQUNwQixXQUFLO0FBQUEsQUFDTixTQUFLLEtBQUs7QUFDVCxZQUFPLEdBQUcsVUFBVSxDQUFDLGtCQUFrQixFQUFFLENBQUMsT0FBTyxFQUFFLENBQUE7QUFDbkQsV0FBSztBQUFBLEFBQ04sU0FBSyxRQUFRO0FBQ1osWUFBTyxHQUFHLFVBQVUsQ0FBQyxxQkFBcUIsRUFBRSxDQUFDLFNBQVMsRUFBRSxDQUFBO0FBQ3hELFdBQUs7QUFBQSxBQUNOLFNBQUssTUFBTTtBQUNWLFlBQU8sR0FBRyxVQUFVLENBQUMsbUJBQW1CLEVBQUUsQ0FBQyxTQUFTLEVBQUUsQ0FBQTtBQUN0RCxXQUFLO0FBQUEsQUFDTixTQUFLLE9BQU87QUFDWCxZQUFPLEdBQUcsVUFBVSxDQUFDLG9CQUFvQixFQUFFLENBQUMsVUFBVSxFQUFFLENBQUE7QUFDeEQsV0FBSztBQUFBLEFBQ04sU0FBSyxhQUFhO0FBQ2pCLFlBQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQ3hELFdBQUs7QUFBQSxBQUNOLFNBQUssV0FBVztBQUNmLFlBQU8sR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLFdBQVcsRUFBRSxDQUFDLGFBQWEsRUFBRSxDQUFBO0FBQ3RELFdBQUs7QUFBQSxBQUNOLFNBQUssWUFBWTtBQUNoQixZQUFPLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxZQUFZLEVBQUUsQ0FBQyxhQUFhLEVBQUUsQ0FBQTtBQUN2RCxXQUFLO0FBQUEsQUFDTjtBQUNDLFdBQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLEdBQUcsV0FBVyxDQUFDLENBQUE7QUFBQSxJQUN2RDtBQUNELFFBQUssSUFBTSxJQUFJLElBQUksSUFBSSxDQUFDLGFBQWEsRUFBRTtBQUN0QyxRQUFJLENBQUMsSUFBSSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsT0FBTyxFQUFFLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDM0M7QUFDRCxPQUFJLDZCQUFpQixVQUFVLENBQUMsRUFBRTtBQUNqQyxRQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRTs7Ozs7O0FBTXpDLFVBQUssSUFBTSxJQUFJLElBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLEVBQUUsRUFBRTtBQUM3QyxVQUFJLElBQUksS0FBSyxVQUFVLENBQUMsSUFBSSxFQUFFO0FBQzdCLFdBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtBQUN6QixhQUFLO09BQ0w7TUFDRDtLQUNEO0FBQ0QsY0FBVSxDQUFDLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQyxLQUFLLEVBQUUsQ0FBQTtBQUNwQyxjQUFVLENBQUMsSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsQ0FBQTtJQUN6QyxNQUFNLElBQUksVUFBVSxZQUFZLFdBQVcsRUFBRTtBQUM3QyxjQUFVLENBQUMsS0FBSyxFQUFFLENBQUE7SUFDbEIsTUFBTSxJQUFJLE9BQU8sVUFBVSxDQUFDLFVBQVUsS0FBSyxVQUFVLEVBQUU7QUFDdkQsY0FBVSxHQUFHLFVBQVUsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtBQUNwQyxjQUFVLENBQUMsS0FBSyxFQUFFLENBQUE7SUFDbEI7R0FDRDs7O09BanBCbUIsZUFBRztBQUN0QixPQUFJLENBQUMsSUFBSSxDQUFDLHdCQUF3QixDQUFDLEVBQUU7QUFDcEMsUUFBSSxDQUFDLHdCQUF3QixDQUFDLEdBQUcsSUFBSSxrQkFBa0IsQ0FBQyx3QkFBd0IsQ0FBQyxDQUFBO0lBQ2pGO0FBQ0QsVUFBTyxJQUFJLENBQUMsd0JBQXdCLENBQUMsQ0FBQTtHQUNyQzs7O1FBWkksa0JBQWtCOzs7Ozs7aUJBMnBCZixNQUFNOzs7O0FBRVIsU0FBUyxXQUFXLEdBQUk7QUFDOUIsUUFBTyxrQkFBa0IsQ0FBQyxRQUFRLENBQUE7Q0FDbEM7O0FBRU0sU0FBUyxRQUFRLENBQUUsS0FBSyxFQUFFO0FBQ2hDLFFBQU8sa0JBQWtCLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtDQUNsRDs7QUFFTSxTQUFTLFVBQVUsR0FBSTtBQUM3QixRQUFPLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxVQUFVLEVBQUUsQ0FBQTtDQUMvQzs7QUFFTSxTQUFTLHlCQUF5QixDQUFFLGVBQWUsRUFBRSxlQUFlLEVBQUU7QUFDNUUsUUFBTyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMseUJBQXlCLENBQzNELGVBQWUsRUFDZixlQUFlLENBQ2YsQ0FBQTtDQUNEOztBQUVNLFNBQVMsdUJBQXVCLEdBQUk7QUFDMUMsUUFBTyxrQkFBa0IsQ0FBQyxRQUFRLENBQUMsdUJBQXVCLEVBQUUsQ0FBQTtDQUM1RDs7QUFFTSxTQUFTLDJCQUEyQixHQUFJO0FBQzlDLFFBQU8sa0JBQWtCLENBQUMsUUFBUSxDQUFDLDJCQUEyQixFQUFFLENBQUE7Q0FDaEU7O0FBRU0sU0FBUyxzQkFBc0IsR0FBSTtBQUN6QyxRQUFPLGtCQUFrQixDQUFDLFFBQVEsQ0FBQyxzQkFBc0IsRUFBRSxDQUFBO0NBQzNEIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL3gtdGVybWluYWwuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiogQGJhYmVsICovXG4vKiogQG1vZHVsZSB4LXRlcm1pbmFsICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTcgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAyMDE3LTIwMTggQW5kcmVzIE1lamlhIDxhbWVqaWEwMDRAZ21haWwuY29tPi4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBVemlUZWNoIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgYnVzLXN0b3AgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mIHRoaXNcbiAqIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZVxuICogd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LFxuICogbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0b1xuICogcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLlxuICpcbiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1MgT1IgSU1QTElFRCxcbiAqIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBXG4gKiBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUXG4gKiBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT05cbiAqIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRVxuICogU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4gKi9cblxuaW1wb3J0IHsgQ29tcG9zaXRlRGlzcG9zYWJsZSB9IGZyb20gJ2F0b20nXG5cbmltcG9ydCB7IENPTkZJR19EQVRBIH0gZnJvbSAnLi9jb25maWcnXG5pbXBvcnQgeyByZWNhbGN1bGF0ZUFjdGl2ZSB9IGZyb20gJy4vdXRpbHMnXG5pbXBvcnQgeyBYVGVybWluYWxFbGVtZW50IH0gZnJvbSAnLi9lbGVtZW50J1xuaW1wb3J0IHsgWFRlcm1pbmFsTW9kZWwsIGlzWFRlcm1pbmFsTW9kZWwgfSBmcm9tICcuL21vZGVsJ1xuaW1wb3J0IHsgWF9URVJNSU5BTF9CQVNFX1VSSSwgWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24gfSBmcm9tICcuL3Byb2ZpbGVzJ1xuaW1wb3J0IHsgWFRlcm1pbmFsUHJvZmlsZU1lbnVFbGVtZW50IH0gZnJvbSAnLi9wcm9maWxlLW1lbnUtZWxlbWVudCdcbmltcG9ydCB7IFhUZXJtaW5hbFByb2ZpbGVNZW51TW9kZWwgfSBmcm9tICcuL3Byb2ZpbGUtbWVudS1tb2RlbCdcbmltcG9ydCB7IFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVFbGVtZW50IH0gZnJvbSAnLi9kZWxldGUtcHJvZmlsZS1lbGVtZW50J1xuaW1wb3J0IHsgWFRlcm1pbmFsRGVsZXRlUHJvZmlsZU1vZGVsIH0gZnJvbSAnLi9kZWxldGUtcHJvZmlsZS1tb2RlbCdcbmltcG9ydCB7IFhUZXJtaW5hbE92ZXJ3cml0ZVByb2ZpbGVFbGVtZW50IH0gZnJvbSAnLi9vdmVyd3JpdGUtcHJvZmlsZS1lbGVtZW50J1xuaW1wb3J0IHsgWFRlcm1pbmFsT3ZlcndyaXRlUHJvZmlsZU1vZGVsIH0gZnJvbSAnLi9vdmVyd3JpdGUtcHJvZmlsZS1tb2RlbCdcbmltcG9ydCB7IFhUZXJtaW5hbFNhdmVQcm9maWxlRWxlbWVudCB9IGZyb20gJy4vc2F2ZS1wcm9maWxlLWVsZW1lbnQnXG5pbXBvcnQgeyBYVGVybWluYWxTYXZlUHJvZmlsZU1vZGVsIH0gZnJvbSAnLi9zYXZlLXByb2ZpbGUtbW9kZWwnXG5cbmltcG9ydCB7IFVSTCB9IGZyb20gJ3doYXR3Zy11cmwnXG5cbmNvbnN0IFhUZXJtaW5hbFNpbmdsZXRvblN5bWJvbCA9IFN5bWJvbCgnWFRlcm1pbmFsU2luZ2xldG9uIHNlbnRpbmVsJylcblxuY2xhc3MgWFRlcm1pbmFsU2luZ2xldG9uIHtcblx0Y29uc3RydWN0b3IgKHN5bWJvbENoZWNrKSB7XG5cdFx0aWYgKFhUZXJtaW5hbFNpbmdsZXRvblN5bWJvbCAhPT0gc3ltYm9sQ2hlY2spIHtcblx0XHRcdHRocm93IG5ldyBFcnJvcignWFRlcm1pbmFsU2luZ2xldG9uIGNhbm5vdCBiZSBpbnN0YW50aWF0ZWQgZGlyZWN0bHkuJylcblx0XHR9XG5cdH1cblxuXHRzdGF0aWMgZ2V0IGluc3RhbmNlICgpIHtcblx0XHRpZiAoIXRoaXNbWFRlcm1pbmFsU2luZ2xldG9uU3ltYm9sXSkge1xuXHRcdFx0dGhpc1tYVGVybWluYWxTaW5nbGV0b25TeW1ib2xdID0gbmV3IFhUZXJtaW5hbFNpbmdsZXRvbihYVGVybWluYWxTaW5nbGV0b25TeW1ib2wpXG5cdFx0fVxuXHRcdHJldHVybiB0aGlzW1hUZXJtaW5hbFNpbmdsZXRvblN5bWJvbF1cblx0fVxuXG5cdGFjdGl2YXRlIChzdGF0ZSkge1xuXHRcdC8vIExvYWQgcHJvZmlsZXMgY29uZmlndXJhdGlvbi5cblx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uID0gWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24uaW5zdGFuY2VcblxuXHRcdC8vIFJlc2V0IGJhc2UgcHJvZmlsZSBpbiBjYXNlIHRoaXMgcGFja2FnZSB3YXMgZGVhY3RpdmF0ZWQgdGhlblxuXHRcdC8vIHJlYWN0aXZhdGVkLlxuXHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24ucmVzZXRCYXNlUHJvZmlsZSgpXG5cblx0XHQvLyBEaXNwb3NhYmxlcyBmb3IgdGhpcyBwbHVnaW4uXG5cdFx0dGhpcy5kaXNwb3NhYmxlcyA9IG5ldyBDb21wb3NpdGVEaXNwb3NhYmxlKClcblxuXHRcdC8vIFNldCBob2xkaW5nIGFsbCB0ZXJtaW5hbHMgYXZhaWxhYmxlIGF0IGFueSBtb21lbnQuXG5cdFx0dGhpcy50ZXJtaW5hbHNfc2V0ID0gbmV3IFNldCgpXG5cblx0XHQvLyBNb25pdG9yIGZvciBjaGFuZ2VzIHRvIGFsbCBjb25maWcgdmFsdWVzLlxuXHRcdGZvciAoY29uc3QgZGF0YSBvZiBDT05GSUdfREFUQSkge1xuXHRcdFx0dGhpcy5kaXNwb3NhYmxlcy5hZGQoYXRvbS5jb25maWcub25EaWRDaGFuZ2UoZGF0YS5rZXlQYXRoLCAoeyBuZXdWYWx1ZSwgb2xkVmFsdWUgfSkgPT4ge1xuXHRcdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLnJlc2V0QmFzZVByb2ZpbGUoKVxuXHRcdFx0fSkpXG5cdFx0fVxuXHRcdC8vIE1vbml0b3IgZm9yIGVkaXRvci5mb250RmFtaWx5IGNoYW5nZXMgZm9yIHRoZSB1c2VFZGl0b3JGb250IHNldHRpbmcuXG5cdFx0dGhpcy5kaXNwb3NhYmxlcy5hZGQoYXRvbS5jb25maWcub25EaWRDaGFuZ2UoJ2VkaXRvci5mb250RmFtaWx5JywgKHsgbmV3VmFsdWUsIG9sZFZhbHVlIH0pID0+IHtcblx0XHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24ucmVzZXRCYXNlUHJvZmlsZSgpXG5cdFx0fSkpXG5cblx0XHR0aGlzLmRpc3Bvc2FibGVzLmFkZChcblx0XHRcdC8vIFJlZ2lzdGVyIHZpZXcgcHJvdmlkZXIgZm9yIHRlcm1pbmFsIGVtdWxhdG9yIGl0ZW0uXG5cdFx0XHRhdG9tLnZpZXdzLmFkZFZpZXdQcm92aWRlcihYVGVybWluYWxNb2RlbCwgKGF0b21YdGVybU1vZGVsKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGF0b21YdGVybUVsZW1lbnQgPSBuZXcgWFRlcm1pbmFsRWxlbWVudCgpXG5cdFx0XHRcdGF0b21YdGVybUVsZW1lbnQuaW5pdGlhbGl6ZShhdG9tWHRlcm1Nb2RlbClcblx0XHRcdFx0cmV0dXJuIGF0b21YdGVybUVsZW1lbnRcblx0XHRcdH0pLFxuXHRcdFx0Ly8gUmVnaXN0ZXIgdmlldyBwcm92aWRlciBmb3IgdGVybWluYWwgZW11bGF0b3IgcHJvZmlsZSBtZW51IGl0ZW0uXG5cdFx0XHRhdG9tLnZpZXdzLmFkZFZpZXdQcm92aWRlcihYVGVybWluYWxQcm9maWxlTWVudU1vZGVsLCAoYXRvbVh0ZXJtUHJvZmlsZU1lbnVNb2RlbCkgPT4ge1xuXHRcdFx0XHRjb25zdCBhdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnQgPSBuZXcgWFRlcm1pbmFsUHJvZmlsZU1lbnVFbGVtZW50KClcblx0XHRcdFx0YXRvbVh0ZXJtUHJvZmlsZU1lbnVFbGVtZW50LmluaXRpYWxpemUoYXRvbVh0ZXJtUHJvZmlsZU1lbnVNb2RlbClcblx0XHRcdFx0cmV0dXJuIGF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudFxuXHRcdFx0fSksXG5cdFx0XHQvLyBSZWdpc3RlciB2aWV3IHByb2ZpbGUgZm9yIG1vZGFsIGl0ZW1zLlxuXHRcdFx0YXRvbS52aWV3cy5hZGRWaWV3UHJvdmlkZXIoWFRlcm1pbmFsRGVsZXRlUHJvZmlsZU1vZGVsLCAoYXRvbVh0ZXJtRGVsZXRlUHJvZmlsZU1vZGVsKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGF0b21YdGVybURlbGV0ZVByb2ZpbGVFbGVtZW50ID0gbmV3IFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVFbGVtZW50KClcblx0XHRcdFx0YXRvbVh0ZXJtRGVsZXRlUHJvZmlsZUVsZW1lbnQuaW5pdGlhbGl6ZShhdG9tWHRlcm1EZWxldGVQcm9maWxlTW9kZWwpXG5cdFx0XHRcdHJldHVybiBhdG9tWHRlcm1EZWxldGVQcm9maWxlRWxlbWVudFxuXHRcdFx0fSksXG5cdFx0XHRhdG9tLnZpZXdzLmFkZFZpZXdQcm92aWRlcihYVGVybWluYWxPdmVyd3JpdGVQcm9maWxlTW9kZWwsIChhdG9tWHRlcm1PdmVyd3JpdGVQcm9maWxlTW9kZWwpID0+IHtcblx0XHRcdFx0Y29uc3QgYXRvbVh0ZXJtT3ZlcndyaXRlUHJvZmlsZUVsZW1lbnQgPSBuZXcgWFRlcm1pbmFsT3ZlcndyaXRlUHJvZmlsZUVsZW1lbnQoKVxuXHRcdFx0XHRhdG9tWHRlcm1PdmVyd3JpdGVQcm9maWxlRWxlbWVudC5pbml0aWFsaXplKGF0b21YdGVybU92ZXJ3cml0ZVByb2ZpbGVNb2RlbClcblx0XHRcdFx0cmV0dXJuIGF0b21YdGVybU92ZXJ3cml0ZVByb2ZpbGVFbGVtZW50XG5cdFx0XHR9KSxcblx0XHRcdGF0b20udmlld3MuYWRkVmlld1Byb3ZpZGVyKFhUZXJtaW5hbFNhdmVQcm9maWxlTW9kZWwsIChhdG9tWHRlcm1TYXZlUHJvZmlsZU1vZGVsKSA9PiB7XG5cdFx0XHRcdGNvbnN0IGF0b21YdGVybVNhdmVQcm9maWxlRWxlbWVudCA9IG5ldyBYVGVybWluYWxTYXZlUHJvZmlsZUVsZW1lbnQoKVxuXHRcdFx0XHRhdG9tWHRlcm1TYXZlUHJvZmlsZUVsZW1lbnQuaW5pdGlhbGl6ZShhdG9tWHRlcm1TYXZlUHJvZmlsZU1vZGVsKVxuXHRcdFx0XHRyZXR1cm4gYXRvbVh0ZXJtU2F2ZVByb2ZpbGVFbGVtZW50XG5cdFx0XHR9KSxcblxuXHRcdFx0Ly8gQWRkIG9wZW5lciBmb3IgdGVybWluYWwgZW11bGF0b3IgaXRlbS5cblx0XHRcdGF0b20ud29ya3NwYWNlLmFkZE9wZW5lcigodXJpKSA9PiB7XG5cdFx0XHRcdGlmICh1cmkuc3RhcnRzV2l0aChYX1RFUk1JTkFMX0JBU0VfVVJJKSkge1xuXHRcdFx0XHRcdGNvbnN0IGl0ZW0gPSBuZXcgWFRlcm1pbmFsTW9kZWwoe1xuXHRcdFx0XHRcdFx0dXJpLFxuXHRcdFx0XHRcdFx0dGVybWluYWxzX3NldDogdGhpcy50ZXJtaW5hbHNfc2V0LFxuXHRcdFx0XHRcdH0pXG5cdFx0XHRcdFx0cmV0dXJuIGl0ZW1cblx0XHRcdFx0fVxuXHRcdFx0fSksXG5cblx0XHRcdC8vIFNldCBjYWxsYmFjayB0byBydW4gb24gY3VycmVudCBhbmQgZnV0dXJlIHBhbmVzLlxuXHRcdFx0YXRvbS53b3Jrc3BhY2Uub2JzZXJ2ZVBhbmVzKChwYW5lKSA9PiB7XG5cdFx0XHRcdC8vIEluIGNhbGxiYWNrLCBzZXQgYW5vdGhlciBjYWxsYmFjayB0byBydW4gb24gY3VycmVudCBhbmQgZnV0dXJlIGl0ZW1zLlxuXHRcdFx0XHR0aGlzLmRpc3Bvc2FibGVzLmFkZChwYW5lLm9ic2VydmVJdGVtcygoaXRlbSkgPT4ge1xuXHRcdFx0XHRcdC8vIEluIGNhbGxiYWNrLCBzZXQgY3VycmVudCBwYW5lIGZvciB0ZXJtaW5hbCBpdGVtcy5cblx0XHRcdFx0XHRpZiAoaXNYVGVybWluYWxNb2RlbChpdGVtKSkge1xuXHRcdFx0XHRcdFx0aXRlbS5zZXROZXdQYW5lKHBhbmUpXG5cdFx0XHRcdFx0fVxuXHRcdFx0XHRcdHJlY2FsY3VsYXRlQWN0aXZlKHRoaXMudGVybWluYWxzX3NldClcblx0XHRcdFx0fSkpXG5cdFx0XHRcdHJlY2FsY3VsYXRlQWN0aXZlKHRoaXMudGVybWluYWxzX3NldClcblx0XHRcdH0pLFxuXG5cdFx0XHQvLyBBZGQgY2FsbGJhY2tzIHRvIHJ1biBmb3IgY3VycmVudCBhbmQgZnV0dXJlIGFjdGl2ZSBpdGVtcyBvbiBhY3RpdmUgcGFuZXMuXG5cdFx0XHRhdG9tLndvcmtzcGFjZS5vYnNlcnZlQWN0aXZlUGFuZUl0ZW0oKGl0ZW0pID0+IHtcblx0XHRcdFx0Ly8gSW4gY2FsbGJhY2ssIGZvY3VzIHNwZWNpZmljYWxseSBvbiB0ZXJtaW5hbCB3aGVuIGl0ZW0gaXMgdGVybWluYWwgaXRlbS5cblx0XHRcdFx0aWYgKGlzWFRlcm1pbmFsTW9kZWwoaXRlbSkpIHtcblx0XHRcdFx0XHRpdGVtLmZvY3VzT25UZXJtaW5hbCgpXG5cdFx0XHRcdH1cblx0XHRcdFx0cmVjYWxjdWxhdGVBY3RpdmUodGhpcy50ZXJtaW5hbHNfc2V0KVxuXHRcdFx0fSksXG5cblx0XHRcdGF0b20ud29ya3NwYWNlLmdldFJpZ2h0RG9jaygpLm9ic2VydmVWaXNpYmxlKCh2aXNpYmxlKSA9PiB7XG5cdFx0XHRcdGlmICh2aXNpYmxlKSB7XG5cdFx0XHRcdFx0Y29uc3QgaXRlbSA9IGF0b20ud29ya3NwYWNlLmdldFJpZ2h0RG9jaygpLmdldEFjdGl2ZVBhbmVJdGVtKClcblx0XHRcdFx0XHRpZiAoaXNYVGVybWluYWxNb2RlbChpdGVtKSkge1xuXHRcdFx0XHRcdFx0aXRlbS5mb2N1c09uVGVybWluYWwoKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWNhbGN1bGF0ZUFjdGl2ZSh0aGlzLnRlcm1pbmFsc19zZXQpXG5cdFx0XHR9KSxcblxuXHRcdFx0YXRvbS53b3Jrc3BhY2UuZ2V0TGVmdERvY2soKS5vYnNlcnZlVmlzaWJsZSgodmlzaWJsZSkgPT4ge1xuXHRcdFx0XHRpZiAodmlzaWJsZSkge1xuXHRcdFx0XHRcdGNvbnN0IGl0ZW0gPSBhdG9tLndvcmtzcGFjZS5nZXRMZWZ0RG9jaygpLmdldEFjdGl2ZVBhbmVJdGVtKClcblx0XHRcdFx0XHRpZiAoaXNYVGVybWluYWxNb2RlbChpdGVtKSkge1xuXHRcdFx0XHRcdFx0aXRlbS5mb2N1c09uVGVybWluYWwoKVxuXHRcdFx0XHRcdH1cblx0XHRcdFx0fVxuXHRcdFx0XHRyZWNhbGN1bGF0ZUFjdGl2ZSh0aGlzLnRlcm1pbmFsc19zZXQpXG5cdFx0XHR9KSxcblxuXHRcdFx0YXRvbS53b3Jrc3BhY2UuZ2V0Qm90dG9tRG9jaygpLm9ic2VydmVWaXNpYmxlKCh2aXNpYmxlKSA9PiB7XG5cdFx0XHRcdGlmICh2aXNpYmxlKSB7XG5cdFx0XHRcdFx0Y29uc3QgaXRlbSA9IGF0b20ud29ya3NwYWNlLmdldEJvdHRvbURvY2soKS5nZXRBY3RpdmVQYW5lSXRlbSgpXG5cdFx0XHRcdFx0aWYgKGlzWFRlcm1pbmFsTW9kZWwoaXRlbSkpIHtcblx0XHRcdFx0XHRcdGl0ZW0uZm9jdXNPblRlcm1pbmFsKClcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdFx0cmVjYWxjdWxhdGVBY3RpdmUodGhpcy50ZXJtaW5hbHNfc2V0KVxuXHRcdFx0fSksXG5cblx0XHRcdC8vIEFkZCBjb21tYW5kcy5cblx0XHRcdGF0b20uY29tbWFuZHMuYWRkKCdhdG9tLXdvcmtzcGFjZScsIHtcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbic6ICgpID0+IHRoaXMub3Blbihcblx0XHRcdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdlbmVyYXRlTmV3VXJpKCksXG5cdFx0XHRcdFx0dGhpcy5hZGREZWZhdWx0UG9zaXRpb24oKSxcblx0XHRcdFx0KSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1jZW50ZXInOiAoKSA9PiB0aGlzLm9wZW5JbkNlbnRlck9yRG9jayhhdG9tLndvcmtzcGFjZSksXG5cdFx0XHRcdCd4LXRlcm1pbmFsOm9wZW4tc3BsaXQtdXAnOiAoKSA9PiB0aGlzLm9wZW4oXG5cdFx0XHRcdFx0dGhpcy5wcm9maWxlc1NpbmdsZXRvbi5nZW5lcmF0ZU5ld1VyaSgpLFxuXHRcdFx0XHRcdHsgc3BsaXQ6ICd1cCcgfSxcblx0XHRcdFx0KSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1zcGxpdC1kb3duJzogKCkgPT4gdGhpcy5vcGVuKFxuXHRcdFx0XHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2VuZXJhdGVOZXdVcmkoKSxcblx0XHRcdFx0XHR7IHNwbGl0OiAnZG93bicgfSxcblx0XHRcdFx0KSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1zcGxpdC1sZWZ0JzogKCkgPT4gdGhpcy5vcGVuKFxuXHRcdFx0XHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24uZ2VuZXJhdGVOZXdVcmkoKSxcblx0XHRcdFx0XHR7IHNwbGl0OiAnbGVmdCcgfSxcblx0XHRcdFx0KSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1zcGxpdC1yaWdodCc6ICgpID0+IHRoaXMub3Blbihcblx0XHRcdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdlbmVyYXRlTmV3VXJpKCksXG5cdFx0XHRcdFx0eyBzcGxpdDogJ3JpZ2h0JyB9LFxuXHRcdFx0XHQpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpvcGVuLXNwbGl0LWJvdHRvbS1kb2NrJzogKCkgPT4gdGhpcy5vcGVuSW5DZW50ZXJPckRvY2soYXRvbS53b3Jrc3BhY2UuZ2V0Qm90dG9tRG9jaygpKSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1zcGxpdC1sZWZ0LWRvY2snOiAoKSA9PiB0aGlzLm9wZW5JbkNlbnRlck9yRG9jayhhdG9tLndvcmtzcGFjZS5nZXRMZWZ0RG9jaygpKSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1zcGxpdC1yaWdodC1kb2NrJzogKCkgPT4gdGhpcy5vcGVuSW5DZW50ZXJPckRvY2soYXRvbS53b3Jrc3BhY2UuZ2V0UmlnaHREb2NrKCkpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDp0b2dnbGUtcHJvZmlsZS1tZW51JzogKCkgPT4gdGhpcy50b2dnbGVQcm9maWxlTWVudSgpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpyZW9yZ2FuaXplJzogKCkgPT4gdGhpcy5yZW9yZ2FuaXplKCdjdXJyZW50JyksXG5cdFx0XHRcdCd4LXRlcm1pbmFsOnJlb3JnYW5pemUtdG9wJzogKCkgPT4gdGhpcy5yZW9yZ2FuaXplKCd0b3AnKSxcblx0XHRcdFx0J3gtdGVybWluYWw6cmVvcmdhbml6ZS1ib3R0b20nOiAoKSA9PiB0aGlzLnJlb3JnYW5pemUoJ2JvdHRvbScpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpyZW9yZ2FuaXplLWxlZnQnOiAoKSA9PiB0aGlzLnJlb3JnYW5pemUoJ2xlZnQnKSxcblx0XHRcdFx0J3gtdGVybWluYWw6cmVvcmdhbml6ZS1yaWdodCc6ICgpID0+IHRoaXMucmVvcmdhbml6ZSgncmlnaHQnKSxcblx0XHRcdFx0J3gtdGVybWluYWw6cmVvcmdhbml6ZS1ib3R0b20tZG9jayc6ICgpID0+IHRoaXMucmVvcmdhbml6ZSgnYm90dG9tLWRvY2snKSxcblx0XHRcdFx0J3gtdGVybWluYWw6cmVvcmdhbml6ZS1sZWZ0LWRvY2snOiAoKSA9PiB0aGlzLnJlb3JnYW5pemUoJ2xlZnQtZG9jaycpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpyZW9yZ2FuaXplLXJpZ2h0LWRvY2snOiAoKSA9PiB0aGlzLnJlb3JnYW5pemUoJ3JpZ2h0LWRvY2snKSxcblx0XHRcdFx0J3gtdGVybWluYWw6Y2xvc2UtYWxsJzogKCkgPT4gdGhpcy5leGl0QWxsVGVybWluYWxzKCksXG5cdFx0XHRcdCd4LXRlcm1pbmFsOmluc2VydC1zZWxlY3RlZC10ZXh0JzogKCkgPT4gdGhpcy5pbnNlcnRTZWxlY3Rpb24oKSxcblx0XHRcdFx0J3gtdGVybWluYWw6cnVuLXNlbGVjdGVkLXRleHQnOiAoKSA9PiB0aGlzLnJ1blNlbGVjdGlvbigpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpmb2N1cyc6ICgpID0+IHRoaXMuZm9jdXMoKSxcblx0XHRcdH0pLFxuXHRcdFx0YXRvbS5jb21tYW5kcy5hZGQoJ2F0b20tdGV4dC1lZGl0b3IsIC50cmVlLXZpZXcsIC50YWItYmFyJywge1xuXHRcdFx0XHQneC10ZXJtaW5hbDpvcGVuLWNvbnRleHQtbWVudSc6IHtcblx0XHRcdFx0XHRoaWRkZW5JbkNvbW1hbmRQYWxldHRlOiB0cnVlLFxuXHRcdFx0XHRcdGRpZERpc3BhdGNoOiAoeyB0YXJnZXQgfSkgPT4gdGhpcy5vcGVuKFxuXHRcdFx0XHRcdFx0dGhpcy5wcm9maWxlc1NpbmdsZXRvbi5nZW5lcmF0ZU5ld1VyaSgpLFxuXHRcdFx0XHRcdFx0dGhpcy5hZGREZWZhdWx0UG9zaXRpb24oeyB0YXJnZXQgfSksXG5cdFx0XHRcdFx0KSxcblx0XHRcdFx0fSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1jZW50ZXItY29udGV4dC1tZW51Jzoge1xuXHRcdFx0XHRcdGhpZGRlbkluQ29tbWFuZFBhbGV0dGU6IHRydWUsXG5cdFx0XHRcdFx0ZGlkRGlzcGF0Y2g6ICh7IHRhcmdldCB9KSA9PiB0aGlzLm9wZW5JbkNlbnRlck9yRG9jayhcblx0XHRcdFx0XHRcdGF0b20ud29ya3NwYWNlLFxuXHRcdFx0XHRcdFx0eyB0YXJnZXQgfSxcblx0XHRcdFx0XHQpLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHQneC10ZXJtaW5hbDpvcGVuLXNwbGl0LXVwLWNvbnRleHQtbWVudSc6IHtcblx0XHRcdFx0XHRoaWRkZW5JbkNvbW1hbmRQYWxldHRlOiB0cnVlLFxuXHRcdFx0XHRcdGRpZERpc3BhdGNoOiAoeyB0YXJnZXQgfSkgPT4gdGhpcy5vcGVuKFxuXHRcdFx0XHRcdFx0dGhpcy5wcm9maWxlc1NpbmdsZXRvbi5nZW5lcmF0ZU5ld1VyaSgpLFxuXHRcdFx0XHRcdFx0eyBzcGxpdDogJ3VwJywgdGFyZ2V0IH0sXG5cdFx0XHRcdFx0KSxcblx0XHRcdFx0fSxcblx0XHRcdFx0J3gtdGVybWluYWw6b3Blbi1zcGxpdC1kb3duLWNvbnRleHQtbWVudSc6IHtcblx0XHRcdFx0XHRoaWRkZW5JbkNvbW1hbmRQYWxldHRlOiB0cnVlLFxuXHRcdFx0XHRcdGRpZERpc3BhdGNoOiAoeyB0YXJnZXQgfSkgPT4gdGhpcy5vcGVuKFxuXHRcdFx0XHRcdFx0dGhpcy5wcm9maWxlc1NpbmdsZXRvbi5nZW5lcmF0ZU5ld1VyaSgpLFxuXHRcdFx0XHRcdFx0eyBzcGxpdDogJ2Rvd24nLCB0YXJnZXQgfSxcblx0XHRcdFx0XHQpLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHQneC10ZXJtaW5hbDpvcGVuLXNwbGl0LWxlZnQtY29udGV4dC1tZW51Jzoge1xuXHRcdFx0XHRcdGhpZGRlbkluQ29tbWFuZFBhbGV0dGU6IHRydWUsXG5cdFx0XHRcdFx0ZGlkRGlzcGF0Y2g6ICh7IHRhcmdldCB9KSA9PiB0aGlzLm9wZW4oXG5cdFx0XHRcdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdlbmVyYXRlTmV3VXJpKCksXG5cdFx0XHRcdFx0XHR7IHNwbGl0OiAnbGVmdCcsIHRhcmdldCB9LFxuXHRcdFx0XHRcdCksXG5cdFx0XHRcdH0sXG5cdFx0XHRcdCd4LXRlcm1pbmFsOm9wZW4tc3BsaXQtcmlnaHQtY29udGV4dC1tZW51Jzoge1xuXHRcdFx0XHRcdGhpZGRlbkluQ29tbWFuZFBhbGV0dGU6IHRydWUsXG5cdFx0XHRcdFx0ZGlkRGlzcGF0Y2g6ICh7IHRhcmdldCB9KSA9PiB0aGlzLm9wZW4oXG5cdFx0XHRcdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdlbmVyYXRlTmV3VXJpKCksXG5cdFx0XHRcdFx0XHR7IHNwbGl0OiAncmlnaHQnLCB0YXJnZXQgfSxcblx0XHRcdFx0XHQpLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHQneC10ZXJtaW5hbDpvcGVuLXNwbGl0LWJvdHRvbS1kb2NrLWNvbnRleHQtbWVudSc6IHtcblx0XHRcdFx0XHRoaWRkZW5JbkNvbW1hbmRQYWxldHRlOiB0cnVlLFxuXHRcdFx0XHRcdGRpZERpc3BhdGNoOiAoeyB0YXJnZXQgfSkgPT4gdGhpcy5vcGVuSW5DZW50ZXJPckRvY2soXG5cdFx0XHRcdFx0XHRhdG9tLndvcmtzcGFjZS5nZXRCb3R0b21Eb2NrKCksXG5cdFx0XHRcdFx0XHR7IHRhcmdldCB9LFxuXHRcdFx0XHRcdCksXG5cdFx0XHRcdH0sXG5cdFx0XHRcdCd4LXRlcm1pbmFsOm9wZW4tc3BsaXQtbGVmdC1kb2NrLWNvbnRleHQtbWVudSc6IHtcblx0XHRcdFx0XHRoaWRkZW5JbkNvbW1hbmRQYWxldHRlOiB0cnVlLFxuXHRcdFx0XHRcdGRpZERpc3BhdGNoOiAoeyB0YXJnZXQgfSkgPT4gdGhpcy5vcGVuSW5DZW50ZXJPckRvY2soXG5cdFx0XHRcdFx0XHRhdG9tLndvcmtzcGFjZS5nZXRMZWZ0RG9jaygpLFxuXHRcdFx0XHRcdFx0eyB0YXJnZXQgfSxcblx0XHRcdFx0XHQpLFxuXHRcdFx0XHR9LFxuXHRcdFx0XHQneC10ZXJtaW5hbDpvcGVuLXNwbGl0LXJpZ2h0LWRvY2stY29udGV4dC1tZW51Jzoge1xuXHRcdFx0XHRcdGhpZGRlbkluQ29tbWFuZFBhbGV0dGU6IHRydWUsXG5cdFx0XHRcdFx0ZGlkRGlzcGF0Y2g6ICh7IHRhcmdldCB9KSA9PiB0aGlzLm9wZW5JbkNlbnRlck9yRG9jayhcblx0XHRcdFx0XHRcdGF0b20ud29ya3NwYWNlLmdldFJpZ2h0RG9jaygpLFxuXHRcdFx0XHRcdFx0eyB0YXJnZXQgfSxcblx0XHRcdFx0XHQpLFxuXHRcdFx0XHR9LFxuXHRcdFx0fSksXG5cdFx0XHRhdG9tLmNvbW1hbmRzLmFkZCgneC10ZXJtaW5hbCcsIHtcblx0XHRcdFx0J3gtdGVybWluYWw6Y2xvc2UnOiAoKSA9PiB0aGlzLmNsb3NlKCksXG5cdFx0XHRcdCd4LXRlcm1pbmFsOnJlc3RhcnQnOiAoKSA9PiB0aGlzLnJlc3RhcnQoKSxcblx0XHRcdFx0J3gtdGVybWluYWw6Y29weSc6ICgpID0+IHRoaXMuY29weSgpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpwYXN0ZSc6ICgpID0+IHRoaXMucGFzdGUoKSxcblx0XHRcdFx0J3gtdGVybWluYWw6dW5mb2N1cyc6ICgpID0+IHRoaXMudW5mb2N1cygpLFxuXHRcdFx0XHQneC10ZXJtaW5hbDpjbGVhcic6ICgpID0+IHRoaXMuY2xlYXIoKSxcblx0XHRcdH0pLFxuXHRcdClcblx0fVxuXG5cdGRlYWN0aXZhdGUgKCkge1xuXHRcdHRoaXMuZXhpdEFsbFRlcm1pbmFscygpXG5cdFx0dGhpcy5kaXNwb3NhYmxlcy5kaXNwb3NlKClcblx0fVxuXG5cdGRlc2VyaWFsaXplWFRlcm1pbmFsTW9kZWwgKHNlcmlhbGl6ZWRNb2RlbCwgYXRvbUVudmlyb25tZW50KSB7XG5cdFx0Y29uc3QgcGFjayA9IGF0b20ucGFja2FnZXMuZW5hYmxlUGFja2FnZSgneC10ZXJtaW5hbCcpXG5cdFx0cGFjay5wcmVsb2FkKClcblx0XHRwYWNrLmFjdGl2YXRlTm93KClcblx0XHRjb25zdCBhbGxvd1JlbGF1bmNoaW5nVGVybWluYWxzT25TdGFydHVwID0gYXRvbS5jb25maWcuZ2V0KCd4LXRlcm1pbmFsLnRlcm1pbmFsU2V0dGluZ3MuYWxsb3dSZWxhdW5jaGluZ1Rlcm1pbmFsc09uU3RhcnR1cCcpXG5cdFx0aWYgKCFhbGxvd1JlbGF1bmNoaW5nVGVybWluYWxzT25TdGFydHVwKSB7XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cdFx0Y29uc3QgdXJsID0gbmV3IFVSTChzZXJpYWxpemVkTW9kZWwudXJpKVxuXHRcdGNvbnN0IHJlbGF1bmNoVGVybWluYWxPblN0YXJ0dXAgPSB1cmwuc2VhcmNoUGFyYW1zLmdldCgncmVsYXVuY2hUZXJtaW5hbE9uU3RhcnR1cCcpXG5cdFx0aWYgKHJlbGF1bmNoVGVybWluYWxPblN0YXJ0dXAgPT09ICdmYWxzZScpIHtcblx0XHRcdHJldHVyblxuXHRcdH1cblx0XHRyZXR1cm4gbmV3IFhUZXJtaW5hbE1vZGVsKHtcblx0XHRcdHVyaTogdXJsLmhyZWYsXG5cdFx0XHR0ZXJtaW5hbHNfc2V0OiB0aGlzLnRlcm1pbmFsc19zZXQsXG5cdFx0fSlcblx0fVxuXG5cdG9wZW5JbkNlbnRlck9yRG9jayAoY2VudGVyT3JEb2NrLCBvcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBwYW5lID0gY2VudGVyT3JEb2NrLmdldEFjdGl2ZVBhbmUoKVxuXHRcdGlmIChwYW5lKSB7XG5cdFx0XHRvcHRpb25zLnBhbmUgPSBwYW5lXG5cdFx0fVxuXHRcdHJldHVybiB0aGlzLm9wZW4oXG5cdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdlbmVyYXRlTmV3VXJpKCksXG5cdFx0XHRvcHRpb25zLFxuXHRcdClcblx0fVxuXG5cdGdldFBhdGggKHRhcmdldCkge1xuXHRcdGlmICghdGFyZ2V0KSB7XG5cdFx0XHRjb25zdCBwYXRocyA9IGF0b20ucHJvamVjdC5nZXRQYXRocygpXG5cdFx0XHRpZiAocGF0aHMgJiYgcGF0aHMubGVuZ3RoID4gMCkge1xuXHRcdFx0XHRyZXR1cm4gcGF0aHNbMF1cblx0XHRcdH1cblx0XHRcdHJldHVybiBudWxsXG5cdFx0fVxuXG5cdFx0Y29uc3QgdHJlZVZpZXcgPSB0YXJnZXQuY2xvc2VzdCgnLnRyZWUtdmlldycpXG5cdFx0aWYgKHRyZWVWaWV3KSB7XG5cdFx0XHQvLyBjYWxsZWQgZnJvbSB0cmVldmlld1xuXHRcdFx0Y29uc3Qgc2VsZWN0ZWQgPSB0cmVlVmlldy5xdWVyeVNlbGVjdG9yKCcuc2VsZWN0ZWQgPiAubGlzdC1pdGVtID4gLm5hbWUsIC5zZWxlY3RlZCA+IC5uYW1lJylcblx0XHRcdGlmIChzZWxlY3RlZCkge1xuXHRcdFx0XHRyZXR1cm4gc2VsZWN0ZWQuZGF0YXNldC5wYXRoXG5cdFx0XHR9XG5cdFx0XHRyZXR1cm4gbnVsbFxuXHRcdH1cblxuXHRcdGNvbnN0IHRhYiA9IHRhcmdldC5jbG9zZXN0KCcudGFiLWJhciA+IC50YWInKVxuXHRcdGlmICh0YWIpIHtcblx0XHRcdC8vIGNhbGxlZCBmcm9tIHRhYlxuXHRcdFx0Y29uc3QgdGl0bGUgPSB0YWIucXVlcnlTZWxlY3RvcignLnRpdGxlJylcblx0XHRcdGlmICh0aXRsZSAmJiB0aXRsZS5kYXRhc2V0LnBhdGgpIHtcblx0XHRcdFx0cmV0dXJuIHRpdGxlLmRhdGFzZXQucGF0aFxuXHRcdFx0fVxuXHRcdFx0cmV0dXJuIG51bGxcblx0XHR9XG5cblx0XHRjb25zdCB0ZXh0RWRpdG9yID0gdGFyZ2V0LmNsb3Nlc3QoJ2F0b20tdGV4dC1lZGl0b3InKVxuXHRcdGlmICh0ZXh0RWRpdG9yICYmIHR5cGVvZiB0ZXh0RWRpdG9yLmdldE1vZGVsID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHQvLyBjYWxsZWQgZnJvbSBhdG9tLXRleHQtZWRpdG9yXG5cdFx0XHRjb25zdCBtb2RlbCA9IHRleHRFZGl0b3IuZ2V0TW9kZWwoKVxuXHRcdFx0aWYgKG1vZGVsICYmIHR5cGVvZiBtb2RlbC5nZXRQYXRoID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRcdHJldHVybiBtb2RlbC5nZXRQYXRoKClcblx0XHRcdH1cblx0XHRcdHJldHVybiBudWxsXG5cdFx0fVxuXG5cdFx0cmV0dXJuIG51bGxcblx0fVxuXG5cdHJlZml0QWxsVGVybWluYWxzICgpIHtcblx0XHRjb25zdCBjdXJyZW50QWN0aXZlUGFuZSA9IGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVBhbmUoKVxuXHRcdGNvbnN0IGN1cnJlbnRBY3RpdmVJdGVtID0gY3VycmVudEFjdGl2ZVBhbmUuZ2V0QWN0aXZlSXRlbSgpXG5cdFx0Zm9yIChjb25zdCB0ZXJtaW5hbCBvZiB0aGlzLnRlcm1pbmFsc19zZXQpIHtcblx0XHRcdC8vIFRvIHJlZml0LCBzaW1wbHkgYnJpbmcgdGhlIHRlcm1pbmFsIGluIGZvY3VzIGluIG9yZGVyIGZvciB0aGVcblx0XHRcdC8vIHJlc2l6ZSBldmVudCB0byByZWZpdCB0aGUgdGVybWluYWwuXG5cdFx0XHRjb25zdCBwYW5lQWN0aXZlSXRlbSA9IHRlcm1pbmFsLnBhbmUuZ2V0QWN0aXZlSXRlbSgpXG5cdFx0XHR0ZXJtaW5hbC5wYW5lLmdldEVsZW1lbnQoKS5mb2N1cygpXG5cdFx0XHR0ZXJtaW5hbC5wYW5lLnNldEFjdGl2ZUl0ZW0odGVybWluYWwpXG5cdFx0XHR0ZXJtaW5hbC5wYW5lLnNldEFjdGl2ZUl0ZW0ocGFuZUFjdGl2ZUl0ZW0pXG5cdFx0fVxuXHRcdGN1cnJlbnRBY3RpdmVQYW5lLmdldEVsZW1lbnQoKS5mb2N1cygpXG5cdFx0Y3VycmVudEFjdGl2ZVBhbmUuc2V0QWN0aXZlSXRlbShjdXJyZW50QWN0aXZlSXRlbSlcblx0fVxuXG5cdGV4aXRBbGxUZXJtaW5hbHMgKCkge1xuXHRcdGZvciAoY29uc3QgdGVybWluYWwgb2YgdGhpcy50ZXJtaW5hbHNfc2V0KSB7XG5cdFx0XHR0ZXJtaW5hbC5leGl0KClcblx0XHR9XG5cdH1cblxuXHRnZXRTZWxlY3RlZFRleHQgKCkge1xuXHRcdGNvbnN0IGVkaXRvciA9IGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVRleHRFZGl0b3IoKVxuXHRcdGlmICghZWRpdG9yKSB7XG5cdFx0XHRyZXR1cm4gJydcblx0XHR9XG5cblx0XHRsZXQgc2VsZWN0ZWRUZXh0ID0gJydcblx0XHRjb25zdCBzZWxlY3Rpb24gPSBlZGl0b3IuZ2V0U2VsZWN0ZWRUZXh0KClcblx0XHRpZiAoc2VsZWN0aW9uKSB7XG5cdFx0XHRzZWxlY3RlZFRleHQgPSBzZWxlY3Rpb24ucmVwbGFjZSgvW1xcclxcbl0rJC8sICcnKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBjdXJzb3IgPSBlZGl0b3IuZ2V0Q3Vyc29yQnVmZmVyUG9zaXRpb24oKVxuXHRcdFx0aWYgKGN1cnNvcikge1xuXHRcdFx0XHRjb25zdCBsaW5lID0gZWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KGN1cnNvci5yb3cpXG5cdFx0XHRcdHNlbGVjdGVkVGV4dCA9IGxpbmVcblx0XHRcdFx0ZWRpdG9yLm1vdmVEb3duKDEpXG5cdFx0XHR9XG5cdFx0fVxuXG5cdFx0cmV0dXJuIHNlbGVjdGVkVGV4dFxuXHR9XG5cblx0Z2V0QWN0aXZlVGVybWluYWwgKCkge1xuXHRcdGNvbnN0IHRlcm1pbmFscyA9IFsuLi50aGlzLnRlcm1pbmFsc19zZXRdXG5cdFx0cmV0dXJuIHRlcm1pbmFscy5maW5kKHQgPT4gdC5pc0FjdGl2ZVRlcm1pbmFsKCkpXG5cdH1cblxuXHRwZXJmb3JtT25BY3RpdmVUZXJtaW5hbCAob3BlcmF0aW9uKSB7XG5cdFx0Y29uc3QgdGVybWluYWwgPSB0aGlzLmdldEFjdGl2ZVRlcm1pbmFsKClcblx0XHRpZiAodGVybWluYWwpIHtcblx0XHRcdG9wZXJhdGlvbih0ZXJtaW5hbClcblx0XHR9XG5cdH1cblxuXHRpbnNlcnRTZWxlY3Rpb24gKCkge1xuXHRcdGNvbnN0IHNlbGVjdGlvbiA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KClcblx0XHRpZiAoc2VsZWN0aW9uKSB7XG5cdFx0XHR0aGlzLnBlcmZvcm1PbkFjdGl2ZVRlcm1pbmFsKHQgPT4gdC5wYXN0ZVRvVGVybWluYWwoc2VsZWN0aW9uKSlcblx0XHR9XG5cdH1cblxuXHRydW5TZWxlY3Rpb24gKCkge1xuXHRcdGNvbnN0IHNlbGVjdGlvbiA9IHRoaXMuZ2V0U2VsZWN0ZWRUZXh0KClcblx0XHRpZiAoc2VsZWN0aW9uKSB7XG5cdFx0XHR0aGlzLnBlcmZvcm1PbkFjdGl2ZVRlcm1pbmFsKHQgPT4gdC5ydW5Db21tYW5kKHNlbGVjdGlvbikpXG5cdFx0fVxuXHR9XG5cblx0YXN5bmMgb3BlbiAodXJpLCBvcHRpb25zID0ge30pIHtcblx0XHRjb25zdCB1cmwgPSBuZXcgVVJMKHVyaSlcblx0XHRpZiAodXJsLnNlYXJjaFBhcmFtcy5nZXQoJ3JlbGF1bmNoVGVybWluYWxPblN0YXJ0dXAnKSA9PT0gbnVsbCkge1xuXHRcdFx0aWYgKCF0aGlzLnByb2ZpbGVzU2luZ2xldG9uLmdldEJhc2VQcm9maWxlKCkucmVsYXVuY2hUZXJtaW5hbE9uU3RhcnR1cCkge1xuXHRcdFx0XHR1cmwuc2VhcmNoUGFyYW1zLnNldCgncmVsYXVuY2hUZXJtaW5hbE9uU3RhcnR1cCcsIGZhbHNlKVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdGlmIChvcHRpb25zLnRhcmdldCkge1xuXHRcdFx0Y29uc3QgdGFyZ2V0ID0gdGhpcy5nZXRQYXRoKG9wdGlvbnMudGFyZ2V0KVxuXHRcdFx0aWYgKHRhcmdldCkge1xuXHRcdFx0XHR1cmwuc2VhcmNoUGFyYW1zLnNldCgnY3dkJywgdGFyZ2V0KVxuXHRcdFx0fVxuXHRcdH1cblxuXHRcdHJldHVybiBhdG9tLndvcmtzcGFjZS5vcGVuKHVybC5ocmVmLCBvcHRpb25zKVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlcnZpY2UgZnVuY3Rpb24gd2hpY2ggaXMgYSB3cmFwcGVyIGFyb3VuZCAnYXRvbS53b3Jrc3BhY2Uub3BlbigpJy4gVGhlXG5cdCAqIG9ubHkgZGlmZmVyZW5jZSB3aXRoIHRoaXMgZnVuY3Rpb24gZnJvbSAnYXRvbS53b3Jrc3BhY2Uub3BlbigpJyBpcyB0aGF0IGl0XG5cdCAqIGFjY2VwdHMgYSBwcm9maWxlIE9iamVjdCBhcyB0aGUgZmlyc3QgYXJndW1lbnQuXG5cdCAqXG5cdCAqIEBhc3luY1xuXHQgKiBAZnVuY3Rpb25cblx0ICogQHBhcmFtIHtPYmplY3R9IHByb2ZpbGUgUHJvZmlsZSBkYXRhIHRvIHVzZSB3aGVuIG9wZW5pbmcgdGVybWluYWwuXG5cdCAqIEBwYXJhbSB7T2JqZWN0fSBvcHRpb25zIE9wdGlvbnMgdG8gcGFzcyB0byBjYWxsIHRvICdhdG9tLndvcmtzcGFjZS5vcGVuKCknLlxuXHQgKiBAcmV0dXJuIHtYVGVybWluYWxNb2RlbH0gSW5zdGFuY2Ugb2YgWFRlcm1pbmFsTW9kZWwuXG5cdCAqL1xuXHRhc3luYyBvcGVuVGVybWluYWwgKHByb2ZpbGUsIG9wdGlvbnMgPSB7fSkge1xuXHRcdG9wdGlvbnMgPSB0aGlzLmFkZERlZmF1bHRQb3NpdGlvbihvcHRpb25zKVxuXHRcdHJldHVybiB0aGlzLm9wZW4oXG5cdFx0XHRYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbi5pbnN0YW5jZS5nZW5lcmF0ZU5ld1VybEZyb21Qcm9maWxlRGF0YShwcm9maWxlKSxcblx0XHRcdG9wdGlvbnMsXG5cdFx0KVxuXHR9XG5cblx0LyoqXG5cdCAqIFNlcnZpY2UgZnVuY3Rpb24gd2hpY2ggb3BlbnMgYSB0ZXJtaW5hbCBhbmQgcnVucyB0aGUgY29tbWFuZHMuXG5cdCAqXG5cdCAqIEBhc3luY1xuXHQgKiBAZnVuY3Rpb25cblx0ICogQHBhcmFtIHtzdHJpbmdbXX0gY29tbWFuZHMgQ29tbWFuZHMgdG8gcnVuIGluIHRoZSB0ZXJtaW5hbC5cblx0ICogQHJldHVybiB7WFRlcm1pbmFsTW9kZWx9IEluc3RhbmNlIG9mIFhUZXJtaW5hbE1vZGVsLlxuXHQgKi9cblx0YXN5bmMgcnVuQ29tbWFuZHMgKGNvbW1hbmRzKSB7XG5cdFx0bGV0IHRlcm1pbmFsXG5cdFx0aWYgKGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLnJ1bkluQWN0aXZlJykpIHtcblx0XHRcdHRlcm1pbmFsID0gdGhpcy5nZXRBY3RpdmVUZXJtaW5hbCgpXG5cdFx0fVxuXG5cdFx0aWYgKCF0ZXJtaW5hbCkge1xuXHRcdFx0Y29uc3Qgb3B0aW9ucyA9IHRoaXMuYWRkRGVmYXVsdFBvc2l0aW9uKClcblx0XHRcdHRlcm1pbmFsID0gYXdhaXQgdGhpcy5vcGVuKFxuXHRcdFx0XHRYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbi5pbnN0YW5jZS5nZW5lcmF0ZU5ld1VyaSgpLFxuXHRcdFx0XHRvcHRpb25zLFxuXHRcdFx0KVxuXHRcdH1cblxuXHRcdGF3YWl0IHRlcm1pbmFsLmVsZW1lbnQuaW5pdGlhbGl6ZWRQcm9taXNlXG5cdFx0Zm9yIChjb25zdCBjb21tYW5kIG9mIGNvbW1hbmRzKSB7XG5cdFx0XHR0ZXJtaW5hbC5ydW5Db21tYW5kKGNvbW1hbmQpXG5cdFx0fVxuXHR9XG5cblx0YWRkRGVmYXVsdFBvc2l0aW9uIChvcHRpb25zID0ge30pIHtcblx0XHRjb25zdCBwb3NpdGlvbiA9IGF0b20uY29uZmlnLmdldCgneC10ZXJtaW5hbC50ZXJtaW5hbFNldHRpbmdzLmRlZmF1bHRPcGVuUG9zaXRpb24nKVxuXHRcdHN3aXRjaCAocG9zaXRpb24pIHtcblx0XHRcdGNhc2UgJ0NlbnRlcic6IHtcblx0XHRcdFx0Y29uc3QgcGFuZSA9IGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVBhbmUoKVxuXHRcdFx0XHRpZiAocGFuZSAmJiAhKCdwYW5lJyBpbiBvcHRpb25zKSkge1xuXHRcdFx0XHRcdG9wdGlvbnMucGFuZSA9IHBhbmVcblx0XHRcdFx0fVxuXHRcdFx0XHRicmVha1xuXHRcdFx0fVxuXHRcdFx0Y2FzZSAnU3BsaXQgVXAnOlxuXHRcdFx0XHRpZiAoISgnc3BsaXQnIGluIG9wdGlvbnMpKSB7XG5cdFx0XHRcdFx0b3B0aW9ucy5zcGxpdCA9ICd1cCdcblx0XHRcdFx0fVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnU3BsaXQgRG93bic6XG5cdFx0XHRcdGlmICghKCdzcGxpdCcgaW4gb3B0aW9ucykpIHtcblx0XHRcdFx0XHRvcHRpb25zLnNwbGl0ID0gJ2Rvd24nXG5cdFx0XHRcdH1cblx0XHRcdFx0YnJlYWtcblx0XHRcdGNhc2UgJ1NwbGl0IExlZnQnOlxuXHRcdFx0XHRpZiAoISgnc3BsaXQnIGluIG9wdGlvbnMpKSB7XG5cdFx0XHRcdFx0b3B0aW9ucy5zcGxpdCA9ICdsZWZ0J1xuXHRcdFx0XHR9XG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdTcGxpdCBSaWdodCc6XG5cdFx0XHRcdGlmICghKCdzcGxpdCcgaW4gb3B0aW9ucykpIHtcblx0XHRcdFx0XHRvcHRpb25zLnNwbGl0ID0gJ3JpZ2h0J1xuXHRcdFx0XHR9XG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdCb3R0b20gRG9jayc6IHtcblx0XHRcdFx0Y29uc3QgcGFuZSA9IGF0b20ud29ya3NwYWNlLmdldEJvdHRvbURvY2soKS5nZXRBY3RpdmVQYW5lKClcblx0XHRcdFx0aWYgKHBhbmUgJiYgISgncGFuZScgaW4gb3B0aW9ucykpIHtcblx0XHRcdFx0XHRvcHRpb25zLnBhbmUgPSBwYW5lXG5cdFx0XHRcdH1cblx0XHRcdFx0YnJlYWtcblx0XHRcdH1cblx0XHRcdGNhc2UgJ0xlZnQgRG9jayc6IHtcblx0XHRcdFx0Y29uc3QgcGFuZSA9IGF0b20ud29ya3NwYWNlLmdldExlZnREb2NrKCkuZ2V0QWN0aXZlUGFuZSgpXG5cdFx0XHRcdGlmIChwYW5lICYmICEoJ3BhbmUnIGluIG9wdGlvbnMpKSB7XG5cdFx0XHRcdFx0b3B0aW9ucy5wYW5lID0gcGFuZVxuXHRcdFx0XHR9XG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0XHRjYXNlICdSaWdodCBEb2NrJzoge1xuXHRcdFx0XHRjb25zdCBwYW5lID0gYXRvbS53b3Jrc3BhY2UuZ2V0UmlnaHREb2NrKCkuZ2V0QWN0aXZlUGFuZSgpXG5cdFx0XHRcdGlmIChwYW5lICYmICEoJ3BhbmUnIGluIG9wdGlvbnMpKSB7XG5cdFx0XHRcdFx0b3B0aW9ucy5wYW5lID0gcGFuZVxuXHRcdFx0XHR9XG5cdFx0XHRcdGJyZWFrXG5cdFx0XHR9XG5cdFx0fVxuXHRcdHJldHVybiBvcHRpb25zXG5cdH1cblxuXHQvKipcblx0ICogRnVuY3Rpb24gcHJvdmlkaW5nIHNlcnZpY2UgZnVuY3Rpb25zIG9mZmVyZWQgYnkgJ2F0b20teHRlcm0nIHNlcnZpY2UuXG5cdCAqXG5cdCAqIEBmdW5jdGlvblxuXHQgKiBAcmV0dXJucyB7T2JqZWN0fSBPYmplY3QgaG9sZGluZyBzZXJ2aWNlIGZ1bmN0aW9ucy5cblx0ICovXG5cdHByb3ZpZGVBdG9tWHRlcm1TZXJ2aWNlICgpIHtcblx0XHRyZXR1cm4ge1xuXHRcdFx0b3BlblRlcm1pbmFsOiBhc3luYyAoLi4uYXJncykgPT4ge1xuXHRcdFx0XHRyZXR1cm4gdGhpcy5vcGVuVGVybWluYWwoLi4uYXJncylcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEZ1bmN0aW9uIHByb3ZpZGluZyBzZXJ2aWNlIGZ1bmN0aW9ucyBvZmZlcmVkIGJ5ICdwbGF0Zm9ybWlvSURFVGVybWluYWwnIHNlcnZpY2UuXG5cdCAqXG5cdCAqIEBmdW5jdGlvblxuXHQgKiBAcmV0dXJucyB7T2JqZWN0fSBPYmplY3QgaG9sZGluZyBzZXJ2aWNlIGZ1bmN0aW9ucy5cblx0ICovXG5cdHByb3ZpZGVQbGF0Zm9ybUlPSURFU2VydmljZSAoKSB7XG5cdFx0cmV0dXJuIHtcblx0XHRcdHVwZGF0ZVByb2Nlc3NFbnYgKHZhcnMpIHtcblx0XHRcdFx0Zm9yIChjb25zdCBuYW1lIGluIHZhcnMpIHtcblx0XHRcdFx0XHRwcm9jZXNzLmVudltuYW1lXSA9IHZhcnNbbmFtZV1cblx0XHRcdFx0fVxuXHRcdFx0fSxcblx0XHRcdHJ1bjogKGNvbW1hbmRzKSA9PiB7XG5cdFx0XHRcdHJldHVybiB0aGlzLnJ1bkNvbW1hbmRzKGNvbW1hbmRzKVxuXHRcdFx0fSxcblx0XHRcdGdldFRlcm1pbmFsVmlld3M6ICgpID0+IHtcblx0XHRcdFx0cmV0dXJuIHRoaXMudGVybWluYWxzX3NldFxuXHRcdFx0fSxcblx0XHRcdG9wZW46ICgpID0+IHtcblx0XHRcdFx0cmV0dXJuIHRoaXMub3BlblRlcm1pbmFsKClcblx0XHRcdH0sXG5cdFx0fVxuXHR9XG5cblx0LyoqXG5cdCAqIEZ1bmN0aW9uIHByb3ZpZGluZyBzZXJ2aWNlIGZ1bmN0aW9ucyBvZmZlcmVkIGJ5ICd0ZXJtaW5hbCcgc2VydmljZS5cblx0ICpcblx0ICogQGZ1bmN0aW9uXG5cdCAqIEByZXR1cm5zIHtPYmplY3R9IE9iamVjdCBob2xkaW5nIHNlcnZpY2UgZnVuY3Rpb25zLlxuXHQgKi9cblx0cHJvdmlkZVRlcm1pbmFsU2VydmljZSAoKSB7XG5cdFx0Ly8gZm9yIG5vdyBpdCBpcyB0aGUgc2FtZSBhcyBwbGF0Zm9ybWlvSURFVGVybWluYWwgc2VydmljZVxuXHRcdHJldHVybiB0aGlzLnByb3ZpZGVQbGF0Zm9ybUlPSURFU2VydmljZSgpXG5cdH1cblxuXHRjbG9zZSAoKSB7XG5cdFx0dGhpcy5wZXJmb3JtT25BY3RpdmVUZXJtaW5hbCh0ID0+IHQuZXhpdCgpKVxuXHR9XG5cblx0cmVzdGFydCAoKSB7XG5cdFx0dGhpcy5wZXJmb3JtT25BY3RpdmVUZXJtaW5hbCh0ID0+IHQucmVzdGFydFB0eVByb2Nlc3MoKSlcblx0fVxuXG5cdGNvcHkgKCkge1xuXHRcdHRoaXMucGVyZm9ybU9uQWN0aXZlVGVybWluYWwodCA9PiBhdG9tLmNsaXBib2FyZC53cml0ZSh0LmNvcHlGcm9tVGVybWluYWwoKSkpXG5cdH1cblxuXHRwYXN0ZSAoKSB7XG5cdFx0dGhpcy5wZXJmb3JtT25BY3RpdmVUZXJtaW5hbCh0ID0+IHQucGFzdGVUb1Rlcm1pbmFsKGF0b20uY2xpcGJvYXJkLnJlYWQoKSkpXG5cdH1cblxuXHR1bmZvY3VzICgpIHtcblx0XHRhdG9tLnZpZXdzLmdldFZpZXcoYXRvbS53b3Jrc3BhY2UpLmZvY3VzKClcblx0fVxuXG5cdGNsZWFyICgpIHtcblx0XHR0aGlzLnBlcmZvcm1PbkFjdGl2ZVRlcm1pbmFsKHQgPT4gdC5jbGVhcigpKVxuXHR9XG5cblx0Zm9jdXMgKCkge1xuXHRcdGlmICh0aGlzLnRlcm1pbmFsc19zZXQuc2l6ZSA9PT0gMCkge1xuXHRcdFx0dGhpcy5vcGVuVGVybWluYWwoKVxuXHRcdH0gZWxzZSB7XG5cdFx0XHRjb25zdCBhY3RpdmVUZXJtaW5hbCA9IFsuLi50aGlzLnRlcm1pbmFsc19zZXRdLmZpbmQodCA9PiB0LmFjdGl2ZUluZGV4ID09PSAwKVxuXHRcdFx0YWN0aXZlVGVybWluYWwuZm9jdXNPblRlcm1pbmFsKHRydWUpXG5cdFx0fVxuXHR9XG5cblx0dG9nZ2xlUHJvZmlsZU1lbnUgKCkge1xuXHRcdGNvbnN0IGl0ZW0gPSBhdG9tLndvcmtzcGFjZS5nZXRBY3RpdmVQYW5lSXRlbSgpXG5cdFx0aWYgKGlzWFRlcm1pbmFsTW9kZWwoaXRlbSkpIHtcblx0XHRcdGl0ZW0udG9nZ2xlUHJvZmlsZU1lbnUoKVxuXHRcdH1cblx0fVxuXG5cdHJlb3JnYW5pemUgKG9yaWVudGF0aW9uKSB7XG5cdFx0aWYgKHRoaXMudGVybWluYWxzX3NldC5zaXplID09PSAwKSB7XG5cdFx0XHRyZXR1cm5cblx0XHR9XG5cdFx0Y29uc3QgYWN0aXZlUGFuZSA9IGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVBhbmUoKVxuXHRcdGxldCBhY3RpdmVJdGVtID0gYWN0aXZlUGFuZS5nZXRBY3RpdmVJdGVtKClcblx0XHRsZXQgbmV3UGFuZVxuXHRcdHN3aXRjaCAob3JpZW50YXRpb24pIHtcblx0XHRcdGNhc2UgJ2N1cnJlbnQnOlxuXHRcdFx0XHRuZXdQYW5lID0gYWN0aXZlUGFuZVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAndG9wJzpcblx0XHRcdFx0bmV3UGFuZSA9IGFjdGl2ZVBhbmUuZmluZFRvcG1vc3RTaWJsaW5nKCkuc3BsaXRVcCgpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdib3R0b20nOlxuXHRcdFx0XHRuZXdQYW5lID0gYWN0aXZlUGFuZS5maW5kQm90dG9tbW9zdFNpYmxpbmcoKS5zcGxpdERvd24oKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnbGVmdCc6XG5cdFx0XHRcdG5ld1BhbmUgPSBhY3RpdmVQYW5lLmZpbmRMZWZ0bW9zdFNpYmxpbmcoKS5zcGxpdExlZnQoKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAncmlnaHQnOlxuXHRcdFx0XHRuZXdQYW5lID0gYWN0aXZlUGFuZS5maW5kUmlnaHRtb3N0U2libGluZygpLnNwbGl0UmlnaHQoKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnYm90dG9tLWRvY2snOlxuXHRcdFx0XHRuZXdQYW5lID0gYXRvbS53b3Jrc3BhY2UuZ2V0Qm90dG9tRG9jaygpLmdldEFjdGl2ZVBhbmUoKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0Y2FzZSAnbGVmdC1kb2NrJzpcblx0XHRcdFx0bmV3UGFuZSA9IGF0b20ud29ya3NwYWNlLmdldExlZnREb2NrKCkuZ2V0QWN0aXZlUGFuZSgpXG5cdFx0XHRcdGJyZWFrXG5cdFx0XHRjYXNlICdyaWdodC1kb2NrJzpcblx0XHRcdFx0bmV3UGFuZSA9IGF0b20ud29ya3NwYWNlLmdldFJpZ2h0RG9jaygpLmdldEFjdGl2ZVBhbmUoKVxuXHRcdFx0XHRicmVha1xuXHRcdFx0ZGVmYXVsdDpcblx0XHRcdFx0dGhyb3cgbmV3IEVycm9yKCdVbmtub3duIG9yaWVudGF0aW9uOiAnICsgb3JpZW50YXRpb24pXG5cdFx0fVxuXHRcdGZvciAoY29uc3QgaXRlbSBvZiB0aGlzLnRlcm1pbmFsc19zZXQpIHtcblx0XHRcdGl0ZW0ucGFuZS5tb3ZlSXRlbVRvUGFuZShpdGVtLCBuZXdQYW5lLCAtMSlcblx0XHR9XG5cdFx0aWYgKGlzWFRlcm1pbmFsTW9kZWwoYWN0aXZlSXRlbSkpIHtcblx0XHRcdGlmIChhdG9tLndvcmtzcGFjZS5nZXRQYW5lcygpLmxlbmd0aCA+IDEpIHtcblx0XHRcdFx0Ly8gV2hlbiByZW9yZ2FuaXppbmcgc3RpbGwgbGVhdmVzIG1vcmUgdGhhbiBvbmUgcGFuZSBpbiB0aGVcblx0XHRcdFx0Ly8gd29ya3NwYWNlLCBhbm90aGVyIHBhbmUgdGhhdCBkb2Vzbid0IGluY2x1ZGUgdGhlIG5ld2x5XG5cdFx0XHRcdC8vIHJlb3JnYW5pemVkIHRlcm1pbmFsIHRhYnMgbmVlZHMgdG8gYmUgZm9jdXNlZCBpbiBvcmRlciBmb3Jcblx0XHRcdFx0Ly8gdGhlIHRlcm1pbmFsIHZpZXdzIHRvIGdldCBwcm9wZXJseSByZXNpemVkIGluIHRoZSBuZXcgcGFuZS5cblx0XHRcdFx0Ly8gQWxsIHRoaXMgaXMgeWV0IGFub3RoZXIgcXVpcmsuXG5cdFx0XHRcdGZvciAoY29uc3QgcGFuZSBvZiBhdG9tLndvcmtzcGFjZS5nZXRQYW5lcygpKSB7XG5cdFx0XHRcdFx0aWYgKHBhbmUgIT09IGFjdGl2ZUl0ZW0ucGFuZSkge1xuXHRcdFx0XHRcdFx0cGFuZS5nZXRFbGVtZW50KCkuZm9jdXMoKVxuXHRcdFx0XHRcdFx0YnJlYWtcblx0XHRcdFx0XHR9XG5cdFx0XHRcdH1cblx0XHRcdH1cblx0XHRcdGFjdGl2ZUl0ZW0ucGFuZS5nZXRFbGVtZW50KCkuZm9jdXMoKVxuXHRcdFx0YWN0aXZlSXRlbS5wYW5lLnNldEFjdGl2ZUl0ZW0oYWN0aXZlSXRlbSlcblx0XHR9IGVsc2UgaWYgKGFjdGl2ZUl0ZW0gaW5zdGFuY2VvZiBIVE1MRWxlbWVudCkge1xuXHRcdFx0YWN0aXZlSXRlbS5mb2N1cygpXG5cdFx0fSBlbHNlIGlmICh0eXBlb2YgYWN0aXZlSXRlbS5nZXRFbGVtZW50ID09PSAnZnVuY3Rpb24nKSB7XG5cdFx0XHRhY3RpdmVJdGVtID0gYWN0aXZlSXRlbS5nZXRFbGVtZW50KClcblx0XHRcdGFjdGl2ZUl0ZW0uZm9jdXMoKVxuXHRcdH1cblx0fVxufVxuXG5leHBvcnQgeyBjb25maWcgfSBmcm9tICcuL2NvbmZpZydcblxuZXhwb3J0IGZ1bmN0aW9uIGdldEluc3RhbmNlICgpIHtcblx0cmV0dXJuIFhUZXJtaW5hbFNpbmdsZXRvbi5pbnN0YW5jZVxufVxuXG5leHBvcnQgZnVuY3Rpb24gYWN0aXZhdGUgKHN0YXRlKSB7XG5cdHJldHVybiBYVGVybWluYWxTaW5nbGV0b24uaW5zdGFuY2UuYWN0aXZhdGUoc3RhdGUpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBkZWFjdGl2YXRlICgpIHtcblx0cmV0dXJuIFhUZXJtaW5hbFNpbmdsZXRvbi5pbnN0YW5jZS5kZWFjdGl2YXRlKClcbn1cblxuZXhwb3J0IGZ1bmN0aW9uIGRlc2VyaWFsaXplWFRlcm1pbmFsTW9kZWwgKHNlcmlhbGl6ZWRNb2RlbCwgYXRvbUVudmlyb25tZW50KSB7XG5cdHJldHVybiBYVGVybWluYWxTaW5nbGV0b24uaW5zdGFuY2UuZGVzZXJpYWxpemVYVGVybWluYWxNb2RlbChcblx0XHRzZXJpYWxpemVkTW9kZWwsXG5cdFx0YXRvbUVudmlyb25tZW50LFxuXHQpXG59XG5cbmV4cG9ydCBmdW5jdGlvbiBwcm92aWRlQXRvbVh0ZXJtU2VydmljZSAoKSB7XG5cdHJldHVybiBYVGVybWluYWxTaW5nbGV0b24uaW5zdGFuY2UucHJvdmlkZUF0b21YdGVybVNlcnZpY2UoKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcHJvdmlkZVBsYXRmb3JtSU9JREVTZXJ2aWNlICgpIHtcblx0cmV0dXJuIFhUZXJtaW5hbFNpbmdsZXRvbi5pbnN0YW5jZS5wcm92aWRlUGxhdGZvcm1JT0lERVNlcnZpY2UoKVxufVxuXG5leHBvcnQgZnVuY3Rpb24gcHJvdmlkZVRlcm1pbmFsU2VydmljZSAoKSB7XG5cdHJldHVybiBYVGVybWluYWxTaW5nbGV0b24uaW5zdGFuY2UucHJvdmlkZVRlcm1pbmFsU2VydmljZSgpXG59XG4iXX0=