'use babel';
var fs = require('fs');
var pathUtils = require('path');
var os = require('os');
var minimatch = require('minimatch');
var autocomplete = require('./autocomplete');
var keywordsRepo = require('./keywords');
var robotParser = require('./parse-robot');
var libdocParser = require('./parse-libdoc');
var libManager = require('./library-manager');
var common = require('./common');
var status = require('./status');

var CFG_KEY = 'autocomplete-robot-framework';
var MAX_FILE_SIZE = 1024 * 1024;
var MAX_KEYWORDS_SUGGESTIONS_CAP = 100;
var PYTHON_LIBDOC_DIR = pathUtils.join(os.tmpdir(), 'robot-lib-cache'); // Place to store imported Python libdoc files

var FALLBACK_LIBRARY_DIR = pathUtils.join(__dirname, '../fallback-libraries');

// Used to avoid multiple concurrent reloadings
var scheduleReload = false;

function isRobotFile(fileContent, filePath, settings) {
  var ext = pathUtils.extname(filePath);
  if (ext.toLowerCase() === '.robot') {
    return true;
  }
  if (settings.robotExtensions.includes(ext.toLowerCase()) && robotParser.isRobot(fileContent)) {
    return true;
  }
  return false;
};

function isLibdocXmlFile(fileContent, filePath) {
  var ext = pathUtils.extname(filePath);
  return ext.toLowerCase() === '.xml' && libdocParser.isLibdoc(fileContent);
};

function readdir(path) {
  return new Promise(function (resolve, reject) {
    var callback = function callback(err, files) {
      if (err) {
        return reject(err);
      } else {
        return resolve(files);
      }
    };
    return fs.readdir(path, callback);
  });
}

function scanDirectory(path, settings) {
  return readdir(path).then(function (result) {
    var promise = Promise.resolve();
    // Chain promises to avoid freezing atom ui

    var _loop = function (_name) {
      promise = promise.then(function () {
        return processFile(path, _name, fs.lstatSync(path + '/' + _name), settings);
      });
    };

    for (var _name of result) {
      _loop(_name);
    }
    return promise;
  });
}

function processFile(path, name, stat, settings) {
  if (settings.excludeDirectories) {
    var matched = settings.excludeDirectories.filter(function (pattern) {
      return minimatch(name, pattern);
    });
    if (matched.length > 0) {
      return Promise.resolve();
    }
  }
  var fullPath = path + '/' + name;
  var ext = pathUtils.extname(fullPath);
  if (stat.isDirectory()) {
    return scanDirectory(fullPath, settings);
  }
  if (stat.isFile() && stat.size < settings.maxFileSize) {
    var fileContent = fs.readFileSync(fullPath).toString();
    if (isRobotFile(fileContent, fullPath, settings)) {
      var parsedRobotInfo = robotParser.parse(fileContent);
      keywordsRepo.addResource(parsedRobotInfo, fullPath);
      return Promise.resolve();
    }
    if (settings.processLibdocFiles && isLibdocXmlFile(fileContent, fullPath)) {
      libManager.addFallbackLibraries([fullPath]);
      return Promise.resolve();
    }
  }
  return Promise.resolve();
}

function readConfig() {
  var settings = {
    robotExtensions: ['.robot', '.txt', '.resource'],
    debug: undefined, // True/false for verbose console output
    maxFileSize: undefined, // Files bigger than this will not be loaded in memory
    maxKeywordsSuggestionsCap: undefined, // Maximum number of suggested keywords
    excludeDirectories: undefined, // Directories not to be scanned
    removeDotNotation: undefined, // Avoid dot notation in suggestions, ie. BuiltIn.convhex will be suggested as "Convert To Hex" instead of "BuiltIn.Convert To Hex"
    showArguments: undefined, // Shows keyword arguments in suggestions
    suggestArguments: undefined, // Add arguments after keyword name when suggesting
    includeDefaultArguments: undefined, // Include default keyword arguments (ie. level=INFO) among sugested arguments
    processLibdocFiles: undefined, // Process '.xml' files representing libdoc definitions
    showLibrarySuggestions: undefined, // Suggest library names
    internalScopeModifier: undefined, // If used, internal scope modifier will suggest only keywords from local resource
    pythonExecutable: undefined };
  // Python command name or path
  provider.settings = settings;

  // hidden settings
  settings.internalScopeModifier = atom.config.get(CFG_KEY + '.internalScopeModifier') || 'this';
  settings.showArguments = atom.config.get(CFG_KEY + '.showArguments') || false;
  settings.maxFileSize = atom.config.get(CFG_KEY + '.maxFileSize') || MAX_FILE_SIZE;
  settings.maxKeywordsSuggestionsCap = atom.config.get(CFG_KEY + '.maxKeywordsSuggestionsCap') || MAX_KEYWORDS_SUGGESTIONS_CAP;

  settings.debug = atom.config.get(CFG_KEY + '.debug');
  settings.suggestArguments = atom.config.get(CFG_KEY + '.suggestArguments');
  settings.includeDefaultArguments = atom.config.get(CFG_KEY + '.includeDefaultArguments');
  settings.argumentSeparator = atom.config.get(CFG_KEY + '.argumentSeparator');
  settings.excludeDirectories = atom.config.get(CFG_KEY + '.excludeDirectories');
  settings.removeDotNotation = atom.config.get(CFG_KEY + '.removeDotNotation');
  settings.processLibdocFiles = atom.config.get(CFG_KEY + '.processLibdocFiles');
  settings.showLibrarySuggestions = atom.config.get(CFG_KEY + '.showLibrarySuggestions');
  settings.pythonExecutable = atom.config.get(CFG_KEY + '.pythonExecutable');
};

// Some library names contain characters forbidden in config property names, such as '.'.
// This function removes offending characters.
function escapeLibraryName(libraryName) {
  return libraryName.replace(/\./, '');
}

function projectDirectoryExists(filePath) {
  try {
    return fs.statSync(filePath).isDirectory();
  } catch (err) {
    return false;
  }
}

function fileExists(filePath) {
  try {
    return fs.statSync(filePath).isFile();
  } catch (err) {
    return false;
  }
};

function getFallbackLibraryPaths(fallbackLibraryDir) {
  try {
    return fs.readdirSync(fallbackLibraryDir).map(function (fileName) {
      return pathUtils.join(fallbackLibraryDir, fileName);
    });
  } catch (error) {
    console.error(error.stack ? error.stack : error);
    return [];
  }
}

function processAllImportsFirstPass() {
  var missingRessourcePaths = keywordsRepo.resolveAllImports();
  return missingRessourcePaths;
}

function processResourceImportsFirstPass(resourceKey) {
  var resource = keywordsRepo.resourcesMap[resourceKey];
  if (resource) {
    var missingRessourcePaths = keywordsRepo.resolveImports(resource);
    return missingRessourcePaths;
  } else {
    return new Set();
  }
}

function processImportsSecondPass(missingRessourcePaths) {
  var newResources = 0;
  missingRessourcePaths.forEach(function (importedPath) {
    console.log('importedPath: ' + importedPath);
    var fileContent = fs.readFileSync(importedPath).toString();
    if (isRobotFile(fileContent, importedPath, provider.settings)) {
      var parsedRobotInfo = robotParser.parse(fileContent);
      keywordsRepo.addResource(parsedRobotInfo, importedPath);
      newResources++;
    }
  });
  if (newResources > 0) {
    keywordsRepo.resolveAllImports();
  }
}

function reloadAutocompleteData() {
  if (provider.loading) {
    if (provider.settings.debug) {
      console.log('Schedule loading autocomplete data');
    }
    scheduleReload = true;
    return Promise.resolve({ status: 'scheduled' });
  } else {
    if (provider.settings.debug) {
      console.log('Loading autocomplete data');
    }
    provider.loading = true;
    libManager.reset();
    var promise = Promise.resolve();
    // Chain promises to avoid freezing atom ui due to too many concurrent processes

    var _loop2 = function (path) {
      if (projectDirectoryExists(path) && provider.robotProjectPaths[path].status === 'project-initial') {
        (function () {
          var projectName = pathUtils.basename(path);
          if (provider.settings.debug) {
            console.log('Loading project ' + projectName);
          }
          if (provider.settings.debug) {
            console.time('Robot project ' + projectName + ' loading time:');
          }
          provider.robotProjectPaths[path].status = 'project-loading';
          keywordsRepo.reset(path);
          promise = promise.then(function () {
            return scanDirectory(path, provider.settings).then(function () {
              if (provider.settings.debug) {
                console.log('Project ' + projectName + ' loaded');
              }
              if (provider.settings.debug) {
                console.timeEnd('Robot project ' + projectName + ' loading time:');
              }
              provider.robotProjectPaths[path].status = 'project-loaded';
            });
          });
        })();
      }
    };

    for (var path in provider.robotProjectPaths) {
      _loop2(path);
    }
    return promise.then(function () {
      if (provider.settings.debug) {
        console.log('Resolving imports...');
      }
      if (provider.settings.debug) {
        console.time('Imports resolved in');
      }
      var missingRessourcePaths = processAllImportsFirstPass();
      processImportsSecondPass(missingRessourcePaths);
      if (provider.settings.debug) {
        console.timeEnd('Imports resolved in');
      }
    }).then(function () {
      if (provider.settings.debug) {
        console.log('Importing libraries...');
      }
      var fallbackLibrariesPaths = getFallbackLibraryPaths(FALLBACK_LIBRARY_DIR);
      libManager.addFallbackLibraries(fallbackLibrariesPaths);
      return libManager.importLibraries(PYTHON_LIBDOC_DIR, provider.settings.pythonExecutable);
    }).then(function () {
      if (provider.settings.debug) {
        console.log('Autocomplete data loaded');
      }
      provider.loading = false;
      if (scheduleReload) {
        scheduleReload = false;
        return reloadAutocompleteData();
      } else {
        return Promise.resolve({ status: 'reloaded' });
      }
    })['catch'](function (error) {
      console.error('Error occurred while reloading robot autocomplete data: ' + (error.stack ? error.stack : error));
      provider.loading = false;
      if (scheduleReload) {
        scheduleReload = false;
        return reloadAutocompleteData();
      } else {
        return Promise.resolve({ status: 'error', message: error.toString(), stack: error.stack });
      }
    });
  }
};

// true/false when new libraries have been added since last edit.
function isLibraryInfoUpdatedForEditor(oldLibraries, newLibraries) {
  oldLibraries = oldLibraries.map(function (library) {
    return library.name;
  });
  newLibraries = newLibraries.map(function (library) {
    return library.name;
  });
  return !common.eqSet(new Set(oldLibraries), new Set(newLibraries));
};

function reloadAutocompleteDataForEditor(editor, useBuffer, settings) {
  var path = editor.getPath();
  if (!path) {
    return;
  }
  var dirPath = pathUtils.dirname(path);
  if (fileExists(path) && pathUtils.normalize(dirPath) !== PYTHON_LIBDOC_DIR) {
    var fileContent = useBuffer ? editor.getBuffer().getText() : fs.readFileSync(path).toString();
    if (isRobotFile(fileContent, path, settings)) {
      var parsedRobotInfo = robotParser.parse(fileContent);
      var resourceKey = common.getResourceKey(path);
      var oldLibraries = keywordsRepo.resourcesMap[resourceKey] ? keywordsRepo.resourcesMap[resourceKey].imports.libraries : [];
      keywordsRepo.addResource(parsedRobotInfo, path);
      var missingRessourcePaths = processResourceImportsFirstPass(resourceKey);
      processImportsSecondPass(missingRessourcePaths);
      var newLibraries = keywordsRepo.resourcesMap[resourceKey].imports.libraries;
      var libraryInfoUpdated = isLibraryInfoUpdatedForEditor(oldLibraries, newLibraries);
      if (libraryInfoUpdated) {
        libManager.importLibraries(PYTHON_LIBDOC_DIR, provider.settings.pythonExecutable);
      }
    } else {
      keywordsRepo.reset(path);
    }
  }
};

// Opens a new project for given editor if none is already opened for it.
// Project opening is handled asynchronously.
// Returns a promise holding 'opened' value after project have been opened.
// Returns a promise holding 'alreadyopen' value if project is already opened
// Returns a promise holding 'norobot' value editor does not represent a robot file.
function openRobotProjectPathForEditor(editor, settings) {
  var editorPath = editor.getPath();
  if (!editorPath) {
    return Promise.resolve('norobot');
  }
  var dirPath = pathUtils.dirname(editorPath);
  if (pathUtils.normalize(dirPath) !== PYTHON_LIBDOC_DIR) {
    var text = editor.getBuffer().getText();
    var ext = pathUtils.extname(editorPath);
    var isRobot = isRobotFile(text, editorPath, settings);
    if (isRobot) {
      var robotProjectPathsUpdated = false;
      for (var projectPath of getAtomProjectPathsForEditor(editor)) {
        if (!provider.robotProjectPaths[projectPath]) {
          // New robot project detected
          provider.robotProjectPaths[projectPath] = { status: 'project-initial' };
          robotProjectPathsUpdated = true;
        }
      }
      if (robotProjectPathsUpdated) {
        return reloadAutocompleteData().then(function () {
          return 'opened';
        });
      } else {
        return Promise.resolve('alreadyopen');
      }
    } else {
      return Promise.resolve('norobot');
    }
  } else {
    return Promise.resolve('norobot');
  }
};

// Removes paths that are no longer opened in Atom tree view
function cleanRobotProjectPaths() {
  var atomPaths = atom.project.getDirectories().map(function (directory) {
    return directory.path;
  });
  for (var path in provider.robotProjectPaths) {
    if (!atomPaths.includes(path)) {
      delete provider.robotProjectPaths[path];
      keywordsRepo.reset(path);
      if (provider.settings.debug) {
        console.log('Removed previously indexed robot projec: \'' + path + '\'');
      }
    }
  }
};

function getAtomProjectPathsForEditor(editor) {
  var res = [];
  var editorPath = editor.getPath();
  for (var projectDirectory of atom.project.getDirectories()) {
    if (projectDirectory.contains(editorPath)) {
      res.push(projectDirectory.getPath());
    }
  }
  return res;
};

// Normally autocomplete-plus considers '.' as delimiter when building prefixes.
// ie. for 'HttpLibrary.HTTP' it reports only 'HTTP' as prefix.
// This method considers everything until it meets a robot syntax separator (multiple spaces, tabs, ...).
function getPrefix(editor, bufferPosition) {
  var line = editor.lineTextForBufferRow(bufferPosition.row);
  var textBeforeCursor = line.substr(0, bufferPosition.column);
  var normalized = textBeforeCursor.replace(/[ \t]{2,}/g, '\t');
  var reversed = normalized.split("").reverse().join("");
  var reversedPrefixMatch = /^[^\t]+/.exec(reversed);
  if (reversedPrefixMatch) {
    return reversedPrefixMatch[0].split("").reverse().join("");
  } else {
    return '';
  }
};

var bddPrefixRegex = /^(given|when|then|and|but) /i;
function processBddPrefixes(prefix) {
  var prefixes = [prefix];
  var match = bddPrefixRegex.exec(prefix);
  if (match) {
    prefixes.push(prefix.substring(match[0].length, prefix.length));
  }
  return prefixes;
}

var provider = {
  settings: {},
  selector: '.text.robot',
  disableForSelector: '.comment, .variable, .punctuation, .string, .storage',
  loading: undefined, // Set to 'true' during autocomplete data async loading
  pathsChangedSubscription: undefined,
  // List of projects that contain robot files. Initially empty, will be completed
  // once user starts editing files.
  robotProjectPaths: undefined,
  getSuggestions: function getSuggestions(_ref) {
    var editor = _ref.editor;
    var bufferPosition = _ref.bufferPosition;
    var scopeDescriptor = _ref.scopeDescriptor;
    var prefix = _ref.prefix;

    prefix = getPrefix(editor, bufferPosition);
    prefixes = processBddPrefixes(prefix);
    return new Promise(function (resolve) {
      var allSuggestions = [];
      var path = editor && editor.buffer && editor.buffer.file ? editor.buffer.file.path : undefined;
      for (pref of prefixes) {
        var suggestions = autocomplete.getSuggestions(pref, path, provider.settings);
        allSuggestions = allSuggestions.concat(suggestions);
      }
      return resolve(allSuggestions);
    });
  },
  unload: function unload() {
    return this.pathsChangedSubscription.dispose();
  },
  load: function load() {
    var _this = this;

    this.robotProjectPaths = {};
    // Configuration
    readConfig();
    atom.config.onDidChange(CFG_KEY, function (_ref2) {
      var newValue = _ref2.newValue;
      var oldValue = _ref2.oldValue;

      readConfig();
      for (var path in provider.robotProjectPaths) {
        provider.robotProjectPaths[path].status = 'project-initial';
      }
      reloadAutocompleteData();
    });

    // React on editor changes
    atom.workspace.observeTextEditors(function (editor) {
      var projectOpenStatus = openRobotProjectPathForEditor(editor, provider.settings);
      projectOpenStatus.then(function (info) {
        if (info === 'opened' || info === 'alreadyopen') {
          (function () {
            var editorSaveSubscription = editor.onDidSave(function (event) {
              return reloadAutocompleteDataForEditor(editor, true, provider.settings);
            });
            var editorStopChangingSubscription = editor.onDidStopChanging(function (event) {
              return reloadAutocompleteDataForEditor(editor, true, provider.settings);
            });
            var editorDestroySubscription = editor.onDidDestroy(function () {
              reloadAutocompleteDataForEditor(editor, false, provider.settings);
              editorSaveSubscription.dispose();
              editorStopChangingSubscription.dispose();
              editorDestroySubscription.dispose();
            });
          })();
        }
      });
    });

    // React on project paths changes
    this.pathsChangedSubscription = atom.project.onDidChangePaths(function (projectPaths) {
      return cleanRobotProjectPaths();
    });

    // Atom commands
    atom.commands.add('atom-text-editor', 'Robot Framework:Print autocomplete debug info', function () {
      provider.printDebugInfo();
      atom.notifications.addSuccess('Debug info printed in Developer Tools console');
    });
    atom.commands.add('atom-text-editor', 'Robot Framework:Reload autocomplete data', function () {
      if (provider.loading) {
        atom.notifications.addWarning('Autocomplete data loading is currently in progress.', { dismissable: true });
        return;
      }
      keywordsRepo.reset();
      libManager.reset();
      for (var path in provider.robotProjectPaths) {
        provider.robotProjectPaths[path].status = 'project-initial';
      }
      reloadAutocompleteData().then(function (result) {
        if (result.status === 'scheduled') {
          atom.notifications.addWarning('Autocomplete data loading is currently in progress.', { dismissable: true });
        } else if (result.status === 'reloaded') {
          atom.notifications.addSuccess('Data reloaded');
        } else if (result.status === 'error') {
          atom.notifications.addError('Error occurred during data reloading', { detail: result.message, stack: result.stack, dismissable: true });
        }
      });
    });
    atom.commands.add('atom-text-editor', 'Robot Framework:Show autocomplete status', function () {
      editor = atom.workspace.getActiveTextEditor();
      if (editor) {
        status.renderStatus(editor.getPath(), _this.settings);
      }
    });
  },

  printDebugInfo: function printDebugInfo() {
    console.log('Detected robot projects: ' + JSON.stringify(provider.robotProjectPaths));
    keywordsRepo.printDebugInfo({
      showRobotFiles: true,
      showLibdocFiles: true,
      showAllSuggestions: true
    });
    libManager.printDebugInfo();
  }
};

module.exports = provider;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1yb2JvdC1mcmFtZXdvcmsvbGliL2F1dG9jb21wbGV0ZS1wbHVzLXByb3ZpZGVyLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiJBQUFBLFdBQVcsQ0FBQTtBQUNYLElBQU0sRUFBRSxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQTtBQUN4QixJQUFNLFNBQVMsR0FBRyxPQUFPLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDakMsSUFBTSxFQUFFLEdBQUcsT0FBTyxDQUFDLElBQUksQ0FBQyxDQUFBO0FBQ3hCLElBQU0sU0FBUyxHQUFHLE9BQU8sQ0FBQyxXQUFXLENBQUMsQ0FBQTtBQUN0QyxJQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsQ0FBQTtBQUM5QyxJQUFNLFlBQVksR0FBRyxPQUFPLENBQUMsWUFBWSxDQUFDLENBQUE7QUFDMUMsSUFBTSxXQUFXLEdBQUcsT0FBTyxDQUFDLGVBQWUsQ0FBQyxDQUFBO0FBQzVDLElBQU0sWUFBWSxHQUFHLE9BQU8sQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFBO0FBQzlDLElBQU0sVUFBVSxHQUFHLE9BQU8sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFBO0FBQy9DLElBQU0sTUFBTSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUNsQyxJQUFNLE1BQU0sR0FBRyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUE7O0FBR2xDLElBQU0sT0FBTyxHQUFHLDhCQUE4QixDQUFDO0FBQy9DLElBQU0sYUFBYSxHQUFHLElBQUksR0FBRyxJQUFJLENBQUM7QUFDbEMsSUFBTSw0QkFBNEIsR0FBRyxHQUFHLENBQUM7QUFDekMsSUFBTSxpQkFBaUIsR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxNQUFNLEVBQUUsRUFBRSxpQkFBaUIsQ0FBQyxDQUFDOztBQUV6RSxJQUFNLG9CQUFvQixHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxFQUFFLHVCQUF1QixDQUFDLENBQUM7OztBQUloRixJQUFJLGNBQWMsR0FBRyxLQUFLLENBQUM7O0FBRTNCLFNBQVMsV0FBVyxDQUFDLFdBQVcsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFO0FBQ3BELE1BQUksR0FBRyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdEMsTUFBSSxHQUFHLENBQUMsV0FBVyxFQUFFLEtBQUssUUFBUSxFQUFFO0FBQ2xDLFdBQU8sSUFBSSxDQUFDO0dBQ2I7QUFDRCxNQUFJLFFBQVEsQ0FBQyxlQUFlLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxJQUFJLFdBQVcsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLEVBQUU7QUFDNUYsV0FBTyxJQUFJLENBQUM7R0FDYjtBQUNELFNBQU8sS0FBSyxDQUFDO0NBQ2QsQ0FBQzs7QUFFRixTQUFTLGVBQWUsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFFO0FBQzlDLE1BQUksR0FBRyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDdEMsU0FBTyxHQUFHLENBQUMsV0FBVyxFQUFFLEtBQUssTUFBTSxJQUFJLFlBQVksQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUFDLENBQUM7Q0FDM0UsQ0FBQzs7QUFFRixTQUFTLE9BQU8sQ0FBQyxJQUFJLEVBQUM7QUFDcEIsU0FBTyxJQUFJLE9BQU8sQ0FBQyxVQUFTLE9BQU8sRUFBRSxNQUFNLEVBQUU7QUFDM0MsUUFBSSxRQUFRLEdBQUcsU0FBWCxRQUFRLENBQVksR0FBRyxFQUFFLEtBQUssRUFBRTtBQUNsQyxVQUFJLEdBQUcsRUFBRTtBQUNQLGVBQU8sTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO09BQ3BCLE1BQU07QUFDTCxlQUFPLE9BQU8sQ0FBQyxLQUFLLENBQUMsQ0FBQztPQUN2QjtLQUNGLENBQUM7QUFDRixXQUFPLEVBQUUsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0dBQ25DLENBQUMsQ0FBQTtDQUNIOztBQUVELFNBQVMsYUFBYSxDQUFDLElBQUksRUFBRSxRQUFRLEVBQUM7QUFDcEMsU0FBTyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUMsSUFBSSxDQUFDLFVBQVMsTUFBTSxFQUFFO0FBQ3pDLFFBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7OzBCQUV2QixLQUFJO0FBQ1gsYUFBTyxHQUFHLE9BQU8sQ0FBQyxJQUFJLENBQUM7ZUFBTSxXQUFXLENBQUMsSUFBSSxFQUFFLEtBQUksRUFBRSxFQUFFLENBQUMsU0FBUyxDQUFJLElBQUksU0FBSSxLQUFJLENBQUcsRUFBRSxRQUFRLENBQUM7T0FBQSxDQUFDLENBQUE7OztBQURsRyxTQUFLLElBQUksS0FBSSxJQUFJLE1BQU0sRUFBRTtZQUFoQixLQUFJO0tBRVo7QUFDRCxXQUFPLE9BQU8sQ0FBQztHQUNoQixDQUFDLENBQUM7Q0FDSjs7QUFFRCxTQUFTLFdBQVcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUU7QUFDL0MsTUFBRyxRQUFRLENBQUMsa0JBQWtCLEVBQUM7QUFDN0IsUUFBTSxPQUFPLEdBQUcsUUFBUSxDQUFDLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxVQUFBLE9BQU87YUFBSSxTQUFTLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztLQUFBLENBQUMsQ0FBQTtBQUN2RixRQUFHLE9BQU8sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFDO0FBQ3BCLGFBQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0tBQzFCO0dBQ0Y7QUFDRCxNQUFJLFFBQVEsR0FBTSxJQUFJLFNBQUksSUFBSSxBQUFFLENBQUM7QUFDakMsTUFBSSxHQUFHLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN0QyxNQUFJLElBQUksQ0FBQyxXQUFXLEVBQUUsRUFBRTtBQUN0QixXQUFPLGFBQWEsQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7R0FDMUM7QUFDRCxNQUFJLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxJQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQyxXQUFXLEVBQUU7QUFDckQsUUFBSSxXQUFXLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQztBQUN2RCxRQUFJLFdBQVcsQ0FBQyxXQUFXLEVBQUUsUUFBUSxFQUFFLFFBQVEsQ0FBQyxFQUFFO0FBQ2hELFVBQUksZUFBZSxHQUFHLFdBQVcsQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDLENBQUM7QUFDckQsa0JBQVksQ0FBQyxXQUFXLENBQUMsZUFBZSxFQUFFLFFBQVEsQ0FBQyxDQUFDO0FBQ3BELGFBQU8sT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDO0tBQzFCO0FBQ0QsUUFBSSxRQUFRLENBQUMsa0JBQWtCLElBQUksZUFBZSxDQUFDLFdBQVcsRUFBRSxRQUFRLENBQUMsRUFBRTtBQUN6RSxnQkFBVSxDQUFDLG9CQUFvQixDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtBQUMzQyxhQUFPLE9BQU8sQ0FBQyxPQUFPLEVBQUUsQ0FBQztLQUMxQjtHQUNGO0FBQ0QsU0FBTyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7Q0FDMUI7O0FBRUQsU0FBUyxVQUFVLEdBQUU7QUFDbkIsTUFBSSxRQUFRLEdBQUc7QUFDYixtQkFBZSxFQUFFLENBQUMsUUFBUSxFQUFFLE1BQU0sRUFBRSxXQUFXLENBQUM7QUFDaEQsU0FBSyxFQUFFLFNBQVM7QUFDaEIsZUFBVyxFQUFFLFNBQVM7QUFDdEIsNkJBQXlCLEVBQUUsU0FBUztBQUNwQyxzQkFBa0IsRUFBRSxTQUFTO0FBQzdCLHFCQUFpQixFQUFFLFNBQVM7QUFDNUIsaUJBQWEsRUFBRSxTQUFTO0FBQ3hCLG9CQUFnQixFQUFFLFNBQVM7QUFDM0IsMkJBQXVCLEVBQUUsU0FBUztBQUNsQyxzQkFBa0IsRUFBRSxTQUFTO0FBQzdCLDBCQUFzQixFQUFFLFNBQVM7QUFDakMseUJBQXFCLEVBQUUsU0FBUztBQUNoQyxvQkFBZ0IsRUFBRSxTQUFTLEVBQzVCLENBQUM7O0FBQ0YsVUFBUSxDQUFDLFFBQVEsR0FBRyxRQUFRLENBQUM7OztBQUc3QixVQUFRLENBQUMscUJBQXFCLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUksT0FBTyw0QkFBeUIsSUFBSSxNQUFNLENBQUM7QUFDL0YsVUFBUSxDQUFDLGFBQWEsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBSSxPQUFPLG9CQUFpQixJQUFJLEtBQUssQ0FBQztBQUM5RSxVQUFRLENBQUMsV0FBVyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sa0JBQWUsSUFBSSxhQUFhLENBQUM7QUFDbEYsVUFBUSxDQUFDLHlCQUF5QixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sZ0NBQTZCLElBQUksNEJBQTRCLENBQUM7O0FBRTdILFVBQVEsQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUksT0FBTyxZQUFTLENBQUM7QUFDckQsVUFBUSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sdUJBQW9CLENBQUM7QUFDM0UsVUFBUSxDQUFDLHVCQUF1QixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sOEJBQTJCLENBQUM7QUFDekYsVUFBUSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sd0JBQXFCLENBQUM7QUFDN0UsVUFBUSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8seUJBQXNCLENBQUM7QUFDL0UsVUFBUSxDQUFDLGlCQUFpQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sd0JBQXFCLENBQUM7QUFDN0UsVUFBUSxDQUFDLGtCQUFrQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8seUJBQXNCLENBQUM7QUFDL0UsVUFBUSxDQUFDLHNCQUFzQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sNkJBQTBCLENBQUM7QUFDdkYsVUFBUSxDQUFDLGdCQUFnQixHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFJLE9BQU8sdUJBQW9CLENBQUM7Q0FDNUUsQ0FBQzs7OztBQUlGLFNBQVMsaUJBQWlCLENBQUMsV0FBVyxFQUFDO0FBQ3JDLFNBQU8sV0FBVyxDQUFDLE9BQU8sQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLENBQUM7Q0FDdEM7O0FBRUQsU0FBUyxzQkFBc0IsQ0FBQyxRQUFRLEVBQUU7QUFDeEMsTUFBSTtBQUNGLFdBQU8sRUFBRSxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxXQUFXLEVBQUUsQ0FBQztHQUM1QyxDQUFDLE9BQU8sR0FBRyxFQUFFO0FBQ1osV0FBTyxLQUFLLENBQUM7R0FDZDtDQUNGOztBQUVELFNBQVMsVUFBVSxDQUFDLFFBQVEsRUFBRTtBQUM1QixNQUFJO0FBQ0YsV0FBTyxFQUFFLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDO0dBQ3ZDLENBQUMsT0FBTyxHQUFHLEVBQUU7QUFDWixXQUFPLEtBQUssQ0FBQztHQUNkO0NBQ0YsQ0FBQzs7QUFFRixTQUFTLHVCQUF1QixDQUFDLGtCQUFrQixFQUFDO0FBQ2xELE1BQUc7QUFDRCxXQUFPLEVBQUUsQ0FBQyxXQUFXLENBQUMsa0JBQWtCLENBQUMsQ0FBQyxHQUFHLENBQUMsVUFBQSxRQUFRO2FBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxrQkFBa0IsRUFBRSxRQUFRLENBQUM7S0FBQSxDQUFDLENBQUE7R0FDeEcsQ0FBQyxPQUFNLEtBQUssRUFBQztBQUNaLFdBQU8sQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEtBQUssR0FBRyxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxDQUFBO0FBQ2hELFdBQU8sRUFBRSxDQUFBO0dBQ1Y7Q0FDRjs7QUFFRCxTQUFTLDBCQUEwQixHQUFFO0FBQ25DLE1BQU0scUJBQXFCLEdBQUcsWUFBWSxDQUFDLGlCQUFpQixFQUFFLENBQUE7QUFDOUQsU0FBTyxxQkFBcUIsQ0FBQTtDQUM3Qjs7QUFFRCxTQUFTLCtCQUErQixDQUFDLFdBQVcsRUFBQztBQUNuRCxNQUFNLFFBQVEsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQ3ZELE1BQUcsUUFBUSxFQUFDO0FBQ1YsUUFBTSxxQkFBcUIsR0FBRyxZQUFZLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFBO0FBQ25FLFdBQU8scUJBQXFCLENBQUE7R0FDN0IsTUFBSztBQUNKLFdBQU8sSUFBSSxHQUFHLEVBQUUsQ0FBQTtHQUNqQjtDQUNGOztBQUVELFNBQVMsd0JBQXdCLENBQUMscUJBQXFCLEVBQUM7QUFDdEQsTUFBSSxZQUFZLEdBQUcsQ0FBQyxDQUFBO0FBQ3BCLHVCQUFxQixDQUFDLE9BQU8sQ0FBQyxVQUFBLFlBQVksRUFBSTtBQUM1QyxXQUFPLENBQUMsR0FBRyxvQkFBa0IsWUFBWSxDQUFHLENBQUM7QUFDN0MsUUFBTSxXQUFXLEdBQUcsRUFBRSxDQUFDLFlBQVksQ0FBQyxZQUFZLENBQUMsQ0FBQyxRQUFRLEVBQUUsQ0FBQTtBQUM1RCxRQUFJLFdBQVcsQ0FBQyxXQUFXLEVBQUUsWUFBWSxFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUMsRUFBRTtBQUM3RCxVQUFNLGVBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3ZELGtCQUFZLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxZQUFZLENBQUMsQ0FBQztBQUN4RCxrQkFBWSxFQUFFLENBQUE7S0FDZjtHQUNGLENBQUMsQ0FBQTtBQUNGLE1BQUcsWUFBWSxHQUFDLENBQUMsRUFBQztBQUNoQixnQkFBWSxDQUFDLGlCQUFpQixFQUFFLENBQUE7R0FDakM7Q0FDRjs7QUFFRCxTQUFTLHNCQUFzQixHQUFHO0FBQ2hDLE1BQUksUUFBUSxDQUFDLE9BQU8sRUFBRTtBQUNwQixRQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFO0FBQUUsYUFBTyxDQUFDLEdBQUcsQ0FBQyxvQ0FBb0MsQ0FBQyxDQUFDO0tBQUU7QUFDbkYsa0JBQWMsR0FBRyxJQUFJLENBQUM7QUFDdEIsV0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLEVBQUMsTUFBTSxFQUFFLFdBQVcsRUFBQyxDQUFDLENBQUE7R0FDOUMsTUFBTTtBQUNMLFFBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUU7QUFBRSxhQUFPLENBQUMsR0FBRyxDQUFDLDJCQUEyQixDQUFDLENBQUM7S0FBRTtBQUMxRSxZQUFRLENBQUMsT0FBTyxHQUFHLElBQUksQ0FBQztBQUN4QixjQUFVLENBQUMsS0FBSyxFQUFFLENBQUE7QUFDbEIsUUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sRUFBRSxDQUFDOzs7MkJBRXZCLElBQUk7QUFDWCxVQUFJLHNCQUFzQixDQUFDLElBQUksQ0FBQyxJQUFJLFFBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEtBQUssaUJBQWlCLEVBQUU7O0FBQ2pHLGNBQUksV0FBVyxHQUFHLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDM0MsY0FBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRTtBQUFFLG1CQUFPLENBQUMsR0FBRyxzQkFBb0IsV0FBVyxDQUFHLENBQUM7V0FBRTtBQUMvRSxjQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFO0FBQUUsbUJBQU8sQ0FBQyxJQUFJLG9CQUFrQixXQUFXLG9CQUFpQixDQUFDO1dBQUU7QUFDNUYsa0JBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7QUFDNUQsc0JBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekIsaUJBQU8sR0FBRyxPQUFPLENBQUMsSUFBSSxDQUFDO21CQUN2QixhQUFhLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxJQUFJLENBQUMsWUFBVztBQUNyRCxrQkFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRTtBQUFFLHVCQUFPLENBQUMsR0FBRyxjQUFZLFdBQVcsYUFBVSxDQUFDO2VBQUU7QUFDOUUsa0JBQUksUUFBUSxDQUFDLFFBQVEsQ0FBQyxLQUFLLEVBQUU7QUFBRSx1QkFBTyxDQUFDLE9BQU8sb0JBQWtCLFdBQVcsb0JBQWlCLENBQUM7ZUFBRTtBQUMvRixzQkFBUSxDQUFDLGlCQUFpQixDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxnQkFBZ0IsQ0FBQzthQUM1RCxDQUFDO1dBQUEsQ0FDSCxDQUFDOztPQUNIOzs7QUFkRCxTQUFLLElBQUksSUFBSSxJQUFJLFFBQVEsQ0FBQyxpQkFBaUIsRUFBRTthQUFwQyxJQUFJO0tBZWQ7QUFDRCxXQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsWUFBTTtBQUN4QixVQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFO0FBQUUsZUFBTyxDQUFDLEdBQUcsQ0FBQyxzQkFBc0IsQ0FBQyxDQUFDO09BQUU7QUFDckUsVUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRTtBQUFFLGVBQU8sQ0FBQyxJQUFJLHVCQUF1QixDQUFDO09BQUU7QUFDckUsVUFBTSxxQkFBcUIsR0FBRywwQkFBMEIsRUFBRSxDQUFBO0FBQzFELDhCQUF3QixDQUFDLHFCQUFxQixDQUFDLENBQUE7QUFDL0MsVUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRTtBQUFFLGVBQU8sQ0FBQyxPQUFPLHVCQUF1QixDQUFDO09BQUU7S0FDekUsQ0FBQyxDQUNELElBQUksQ0FBQyxZQUFNO0FBQ1YsVUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRTtBQUFFLGVBQU8sQ0FBQyxHQUFHLENBQUMsd0JBQXdCLENBQUMsQ0FBQztPQUFFO0FBQ3ZFLFVBQU0sc0JBQXNCLEdBQUcsdUJBQXVCLENBQUMsb0JBQW9CLENBQUMsQ0FBQTtBQUM1RSxnQkFBVSxDQUFDLG9CQUFvQixDQUFDLHNCQUFzQixDQUFDLENBQUE7QUFDdkQsYUFBTyxVQUFVLENBQUMsZUFBZSxDQUFDLGlCQUFpQixFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUMsZ0JBQWdCLENBQUMsQ0FBQztLQUMxRixDQUFDLENBQ0QsSUFBSSxDQUFDLFlBQU07QUFDVixVQUFJLFFBQVEsQ0FBQyxRQUFRLENBQUMsS0FBSyxFQUFFO0FBQUUsZUFBTyxDQUFDLEdBQUcsQ0FBQywwQkFBMEIsQ0FBQyxDQUFDO09BQUU7QUFDekUsY0FBUSxDQUFDLE9BQU8sR0FBRyxLQUFLLENBQUM7QUFDekIsVUFBSSxjQUFjLEVBQUU7QUFDbEIsc0JBQWMsR0FBRyxLQUFLLENBQUM7QUFDdkIsZUFBTyxzQkFBc0IsRUFBRSxDQUFDO09BQ2pDLE1BQUs7QUFDSixlQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBQyxNQUFNLEVBQUUsVUFBVSxFQUFDLENBQUMsQ0FBQTtPQUM3QztLQUNGLENBQUMsU0FDSSxDQUFDLFVBQUMsS0FBSyxFQUFLO0FBQ2hCLGFBQU8sQ0FBQyxLQUFLLCtEQUE0RCxLQUFLLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFBLENBQUcsQ0FBQztBQUM5RyxjQUFRLENBQUMsT0FBTyxHQUFHLEtBQUssQ0FBQztBQUN6QixVQUFJLGNBQWMsRUFBRTtBQUNsQixzQkFBYyxHQUFHLEtBQUssQ0FBQztBQUN2QixlQUFPLHNCQUFzQixFQUFFLENBQUM7T0FDakMsTUFBSztBQUNKLGVBQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFDLE1BQU0sRUFBRSxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxRQUFRLEVBQUUsRUFBRSxLQUFLLEVBQUUsS0FBSyxDQUFDLEtBQUssRUFBQyxDQUFDLENBQUE7T0FDekY7S0FDRixDQUFDLENBQUM7R0FDSjtDQUNBLENBQUM7OztBQUdGLFNBQVMsNkJBQTZCLENBQUMsWUFBWSxFQUFFLFlBQVksRUFBRTtBQUNqRSxjQUFZLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxVQUFBLE9BQU87V0FBSSxPQUFPLENBQUMsSUFBSTtHQUFBLENBQUMsQ0FBQztBQUN6RCxjQUFZLEdBQUcsWUFBWSxDQUFDLEdBQUcsQ0FBQyxVQUFBLE9BQU87V0FBSSxPQUFPLENBQUMsSUFBSTtHQUFBLENBQUMsQ0FBQztBQUN6RCxTQUFPLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUMsRUFBRSxJQUFJLEdBQUcsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDO0NBQ3BFLENBQUM7O0FBRUYsU0FBUywrQkFBK0IsQ0FBQyxNQUFNLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRTtBQUNwRSxNQUFJLElBQUksR0FBRyxNQUFNLENBQUMsT0FBTyxFQUFFLENBQUM7QUFDNUIsTUFBSSxDQUFDLElBQUksRUFBRTtBQUNULFdBQU87R0FDUjtBQUNELE1BQUksT0FBTyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDdEMsTUFBSSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksU0FBUyxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsS0FBRyxpQkFBaUIsRUFBRTtBQUN4RSxRQUFJLFdBQVcsR0FBRyxTQUFTLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sRUFBRSxHQUFHLEVBQUUsQ0FBQyxZQUFZLENBQUMsSUFBSSxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUM7QUFDOUYsUUFBSSxXQUFXLENBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxRQUFRLENBQUMsRUFBRTtBQUM1QyxVQUFJLGVBQWUsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQyxDQUFDO0FBQ3JELFVBQUksV0FBVyxHQUFHLE1BQU0sQ0FBQyxjQUFjLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDOUMsVUFBSSxZQUFZLEdBQUcsWUFBWSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsR0FBRyxZQUFZLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxTQUFTLEdBQUcsRUFBRSxDQUFDO0FBQzFILGtCQUFZLENBQUMsV0FBVyxDQUFDLGVBQWUsRUFBRSxJQUFJLENBQUMsQ0FBQztBQUNoRCxVQUFNLHFCQUFxQixHQUFHLCtCQUErQixDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQzFFLDhCQUF3QixDQUFDLHFCQUFxQixDQUFDLENBQUE7QUFDL0MsVUFBSSxZQUFZLEdBQUcsWUFBWSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0FBQzVFLFVBQUksa0JBQWtCLEdBQUcsNkJBQTZCLENBQUMsWUFBWSxFQUFFLFlBQVksQ0FBQyxDQUFDO0FBQ25GLFVBQUksa0JBQWtCLEVBQUU7QUFDdEIsa0JBQVUsQ0FBQyxlQUFlLENBQUMsaUJBQWlCLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxnQkFBZ0IsQ0FBQyxDQUFDO09BQ25GO0tBQ0YsTUFBTTtBQUNMLGtCQUFZLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFDO0tBQzFCO0dBQ0Y7Q0FDRixDQUFDOzs7Ozs7O0FBT0YsU0FBUyw2QkFBNkIsQ0FBQyxNQUFNLEVBQUUsUUFBUSxFQUFFO0FBQ3ZELE1BQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUNsQyxNQUFJLENBQUMsVUFBVSxFQUFFO0FBQ2YsV0FBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0dBQ2xDO0FBQ0QsTUFBSSxPQUFPLEdBQUcsU0FBUyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUM1QyxNQUFJLFNBQVMsQ0FBQyxTQUFTLENBQUMsT0FBTyxDQUFDLEtBQUcsaUJBQWlCLEVBQUU7QUFDcEQsUUFBSSxJQUFJLEdBQUcsTUFBTSxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ3hDLFFBQUksR0FBRyxHQUFHLFNBQVMsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7QUFDeEMsUUFBSSxPQUFPLEdBQUcsV0FBVyxDQUFDLElBQUksRUFBRSxVQUFVLEVBQUUsUUFBUSxDQUFDLENBQUM7QUFDdEQsUUFBRyxPQUFPLEVBQUM7QUFDVCxVQUFJLHdCQUF3QixHQUFHLEtBQUssQ0FBQTtBQUNwQyxXQUFLLElBQUksV0FBVyxJQUFJLDRCQUE0QixDQUFDLE1BQU0sQ0FBQyxFQUFFO0FBQzVELFlBQUksQ0FBQyxRQUFRLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLEVBQUU7O0FBRTVDLGtCQUFRLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLEdBQUcsRUFBQyxNQUFNLEVBQUUsaUJBQWlCLEVBQUMsQ0FBQztBQUN0RSxrQ0FBd0IsR0FBRyxJQUFJLENBQUE7U0FDaEM7T0FDRjtBQUNELFVBQUcsd0JBQXdCLEVBQUM7QUFDMUIsZUFBTyxzQkFBc0IsRUFBRSxDQUFDLElBQUksQ0FBQztpQkFBSSxRQUFRO1NBQUEsQ0FBQyxDQUFBO09BQ25ELE1BQUs7QUFDSixlQUFPLE9BQU8sQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLENBQUE7T0FDdEM7S0FDRixNQUFLO0FBQ0osYUFBTyxPQUFPLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxDQUFBO0tBQ2xDO0dBQ0YsTUFBSztBQUNKLFdBQU8sT0FBTyxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsQ0FBQTtHQUNsQztDQUNGLENBQUM7OztBQUdGLFNBQVMsc0JBQXNCLEdBQUc7QUFDaEMsTUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsQ0FBQyxHQUFHLENBQUUsVUFBQSxTQUFTO1dBQUksU0FBUyxDQUFDLElBQUk7R0FBQSxDQUFDLENBQUM7QUFDaEYsT0FBSyxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsaUJBQWlCLEVBQUU7QUFDM0MsUUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEVBQUU7QUFDN0IsYUFBTyxRQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDeEMsa0JBQVksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDekIsVUFBSSxRQUFRLENBQUMsUUFBUSxDQUFDLEtBQUssRUFBRTtBQUFFLGVBQU8sQ0FBQyxHQUFHLGlEQUE4QyxJQUFJLFFBQUksQ0FBQztPQUFFO0tBQ3BHO0dBQ0Y7Q0FDRixDQUFDOztBQUdGLFNBQVMsNEJBQTRCLENBQUMsTUFBTSxFQUFFO0FBQzVDLE1BQUksR0FBRyxHQUFHLEVBQUUsQ0FBQztBQUNiLE1BQUksVUFBVSxHQUFHLE1BQU0sQ0FBQyxPQUFPLEVBQUUsQ0FBQztBQUNsQyxPQUFLLElBQUksZ0JBQWdCLElBQUksSUFBSSxDQUFDLE9BQU8sQ0FBQyxjQUFjLEVBQUUsRUFBRTtBQUMxRCxRQUFJLGdCQUFnQixDQUFDLFFBQVEsQ0FBQyxVQUFVLENBQUMsRUFBRTtBQUN6QyxTQUFHLENBQUMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE9BQU8sRUFBRSxDQUFDLENBQUM7S0FDdEM7R0FDRjtBQUNELFNBQU8sR0FBRyxDQUFDO0NBQ1osQ0FBQzs7Ozs7QUFNRixTQUFTLFNBQVMsQ0FBQyxNQUFNLEVBQUUsY0FBYyxFQUFFO0FBQ3pDLE1BQUksSUFBSSxHQUFHLE1BQU0sQ0FBQyxvQkFBb0IsQ0FBQyxjQUFjLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDM0QsTUFBSSxnQkFBZ0IsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsRUFBRSxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDN0QsTUFBSSxVQUFVLEdBQUcsZ0JBQWdCLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQztBQUM5RCxNQUFJLFFBQVEsR0FBRyxVQUFVLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxDQUFDLE9BQU8sRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztBQUN2RCxNQUFJLG1CQUFtQixHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbkQsTUFBRyxtQkFBbUIsRUFBRTtBQUN0QixXQUFPLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7R0FDNUQsTUFBTTtBQUNMLFdBQU8sRUFBRSxDQUFDO0dBQ1g7Q0FDRixDQUFDOztBQUVGLElBQU0sY0FBYyxHQUFHLDhCQUE4QixDQUFBO0FBQ3JELFNBQVMsa0JBQWtCLENBQUMsTUFBTSxFQUFFO0FBQ2xDLE1BQU0sUUFBUSxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUE7QUFDekIsTUFBTSxLQUFLLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQTtBQUN6QyxNQUFHLEtBQUssRUFBRTtBQUNSLFlBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO0dBQ2hFO0FBQ0QsU0FBTyxRQUFRLENBQUE7Q0FDaEI7O0FBRUQsSUFBSSxRQUFRLEdBQUc7QUFDYixVQUFRLEVBQUcsRUFBRTtBQUNiLFVBQVEsRUFBRSxhQUFhO0FBQ3ZCLG9CQUFrQixFQUFFLHNEQUFzRDtBQUMxRSxTQUFPLEVBQUUsU0FBUztBQUNsQiwwQkFBd0IsRUFBRSxTQUFTOzs7QUFHbkMsbUJBQWlCLEVBQUUsU0FBUztBQUM1QixnQkFBYyxFQUFBLHdCQUFDLElBQWlELEVBQUU7UUFBbEQsTUFBTSxHQUFQLElBQWlELENBQWhELE1BQU07UUFBRSxjQUFjLEdBQXZCLElBQWlELENBQXhDLGNBQWM7UUFBRSxlQUFlLEdBQXhDLElBQWlELENBQXhCLGVBQWU7UUFBRSxNQUFNLEdBQWhELElBQWlELENBQVAsTUFBTTs7QUFDN0QsVUFBTSxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsY0FBYyxDQUFDLENBQUM7QUFDM0MsWUFBUSxHQUFHLGtCQUFrQixDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBQ3JDLFdBQU8sSUFBSSxPQUFPLENBQUMsVUFBUyxPQUFPLEVBQUU7QUFDbkMsVUFBSSxjQUFjLEdBQUcsRUFBRSxDQUFBO0FBQ3ZCLFVBQUksSUFBSSxHQUFHLEFBQUMsTUFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNLElBQUksTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEdBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxHQUFDLFNBQVMsQ0FBQTtBQUM1RixXQUFJLElBQUksSUFBSSxRQUFRLEVBQUU7QUFDcEIsWUFBTSxXQUFXLEdBQUcsWUFBWSxDQUFDLGNBQWMsQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUMvRSxzQkFBYyxHQUFHLGNBQWMsQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUE7T0FDcEQ7QUFDRCxhQUFPLE9BQU8sQ0FBQyxjQUFjLENBQUMsQ0FBQztLQUNoQyxDQUFDLENBQUM7R0FDSjtBQUNELFFBQU0sRUFBQSxrQkFBRztBQUNQLFdBQU8sSUFBSSxDQUFDLHdCQUF3QixDQUFDLE9BQU8sRUFBRSxDQUFDO0dBQ2hEO0FBQ0QsTUFBSSxFQUFBLGdCQUFHOzs7QUFDTCxRQUFJLENBQUMsaUJBQWlCLEdBQUcsRUFBRSxDQUFDOztBQUU1QixjQUFVLEVBQUUsQ0FBQztBQUNiLFFBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxVQUFTLEtBQW9CLEVBQUM7VUFBcEIsUUFBUSxHQUFULEtBQW9CLENBQW5CLFFBQVE7VUFBRSxRQUFRLEdBQW5CLEtBQW9CLENBQVQsUUFBUTs7QUFDM0QsZ0JBQVUsRUFBRSxDQUFDO0FBQ2IsV0FBSyxJQUFJLElBQUksSUFBSSxRQUFRLENBQUMsaUJBQWlCLEVBQUU7QUFDM0MsZ0JBQVEsQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsaUJBQWlCLENBQUM7T0FDN0Q7QUFDRCw0QkFBc0IsRUFBRSxDQUFDO0tBQzFCLENBQUMsQ0FBQzs7O0FBR0gsUUFBSSxDQUFDLFNBQVMsQ0FBQyxrQkFBa0IsQ0FBQyxVQUFTLE1BQU0sRUFBRTtBQUNqRCxVQUFNLGlCQUFpQixHQUFHLDZCQUE2QixDQUFDLE1BQU0sRUFBRSxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbkYsdUJBQWlCLENBQUMsSUFBSSxDQUFDLFVBQUMsSUFBSSxFQUFJO0FBQzlCLFlBQUcsSUFBSSxLQUFHLFFBQVEsSUFBSSxJQUFJLEtBQUcsYUFBYSxFQUFDOztBQUN6QyxnQkFBSSxzQkFBc0IsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLFVBQUEsS0FBSztxQkFBSSwrQkFBK0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUM7YUFBQSxDQUFDLENBQUM7QUFDekgsZ0JBQUksOEJBQThCLEdBQUcsTUFBTSxDQUFDLGlCQUFpQixDQUFDLFVBQUEsS0FBSztxQkFBSSwrQkFBK0IsQ0FBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLFFBQVEsQ0FBQyxRQUFRLENBQUM7YUFBQSxDQUFDLENBQUM7QUFDekksZ0JBQUkseUJBQXlCLEdBQUcsTUFBTSxDQUFDLFlBQVksQ0FBQyxZQUFXO0FBQzdELDZDQUErQixDQUFDLE1BQU0sRUFBRSxLQUFLLEVBQUUsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ2xFLG9DQUFzQixDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ2pDLDRDQUE4QixDQUFDLE9BQU8sRUFBRSxDQUFDO0FBQ3pDLHVDQUF5QixDQUFDLE9BQU8sRUFBRSxDQUFDO2FBQ3JDLENBQUMsQ0FBQzs7U0FDSjtPQUNGLENBQUMsQ0FBQTtLQUNILENBQUMsQ0FBQzs7O0FBR0gsUUFBSSxDQUFDLHdCQUF3QixHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsZ0JBQWdCLENBQUMsVUFBQSxZQUFZO2FBQUksc0JBQXNCLEVBQUU7S0FBQSxDQUFDLENBQUM7OztBQUd4RyxRQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxrQkFBa0IsRUFBRSwrQ0FBK0MsRUFBRSxZQUFPO0FBQzVGLGNBQVEsQ0FBQyxjQUFjLEVBQUUsQ0FBQTtBQUN6QixVQUFJLENBQUMsYUFBYSxDQUFDLFVBQVUsQ0FBQywrQ0FBK0MsQ0FBQyxDQUFBO0tBQy9FLENBQUMsQ0FBQTtBQUNGLFFBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLDBDQUEwQyxFQUFFLFlBQU07QUFDdEYsVUFBSSxRQUFRLENBQUMsT0FBTyxFQUFFO0FBQ3BCLFlBQUksQ0FBQyxhQUFhLENBQUMsVUFBVSxDQUFDLHFEQUFxRCxFQUFFLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUE7QUFDekcsZUFBTTtPQUNQO0FBQ0Qsa0JBQVksQ0FBQyxLQUFLLEVBQUUsQ0FBQTtBQUNwQixnQkFBVSxDQUFDLEtBQUssRUFBRSxDQUFBO0FBQ2xCLFdBQUssSUFBSSxJQUFJLElBQUksUUFBUSxDQUFDLGlCQUFpQixFQUFFO0FBQzNDLGdCQUFRLENBQUMsaUJBQWlCLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLGlCQUFpQixDQUFDO09BQzdEO0FBQ0QsNEJBQXNCLEVBQUUsQ0FDdkIsSUFBSSxDQUFDLFVBQUMsTUFBTSxFQUFLO0FBQ2hCLFlBQUcsTUFBTSxDQUFDLE1BQU0sS0FBSyxXQUFXLEVBQUM7QUFDL0IsY0FBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMscURBQXFELEVBQUUsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQTtTQUMxRyxNQUFNLElBQUcsTUFBTSxDQUFDLE1BQU0sS0FBSyxVQUFVLEVBQUM7QUFDckMsY0FBSSxDQUFDLGFBQWEsQ0FBQyxVQUFVLENBQUMsZUFBZSxDQUFDLENBQUE7U0FDL0MsTUFBTSxJQUFHLE1BQU0sQ0FBQyxNQUFNLEtBQUssT0FBTyxFQUFDO0FBQ2xDLGNBQUksQ0FBQyxhQUFhLENBQUMsUUFBUSx5Q0FFekIsRUFBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxXQUFXLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQTtTQUNwRTtPQUNGLENBQUMsQ0FBQTtLQUNILENBQUMsQ0FBQTtBQUNGLFFBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLGtCQUFrQixFQUFFLDBDQUEwQyxFQUFFLFlBQU07QUFDdEYsWUFBTSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsbUJBQW1CLEVBQUUsQ0FBQTtBQUM3QyxVQUFHLE1BQU0sRUFBQztBQUNSLGNBQU0sQ0FBQyxZQUFZLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxFQUFFLE1BQUssUUFBUSxDQUFDLENBQUE7T0FDckQ7S0FDRixDQUFDLENBQUE7R0FDSDs7QUFFRCxnQkFBYyxFQUFBLDBCQUFHO0FBQ2YsV0FBTyxDQUFDLEdBQUcsK0JBQTZCLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLGlCQUFpQixDQUFDLENBQUcsQ0FBQztBQUN0RixnQkFBWSxDQUFDLGNBQWMsQ0FBQztBQUMxQixvQkFBYyxFQUFFLElBQUk7QUFDcEIscUJBQWUsRUFBRSxJQUFJO0FBQ3JCLHdCQUFrQixFQUFFLElBQUk7S0FDekIsQ0FBQyxDQUFDO0FBQ0gsY0FBVSxDQUFDLGNBQWMsRUFBRSxDQUFDO0dBQzdCO0NBQ0YsQ0FBQzs7QUFFRixNQUFNLENBQUMsT0FBTyxHQUFHLFFBQVEsQ0FBQSIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy9hdXRvY29tcGxldGUtcm9ib3QtZnJhbWV3b3JrL2xpYi9hdXRvY29tcGxldGUtcGx1cy1wcm92aWRlci5qcyIsInNvdXJjZXNDb250ZW50IjpbIid1c2UgYmFiZWwnXHJcbmNvbnN0IGZzID0gcmVxdWlyZSgnZnMnKVxyXG5jb25zdCBwYXRoVXRpbHMgPSByZXF1aXJlKCdwYXRoJylcclxuY29uc3Qgb3MgPSByZXF1aXJlKCdvcycpXHJcbmNvbnN0IG1pbmltYXRjaCA9IHJlcXVpcmUoJ21pbmltYXRjaCcpXHJcbmNvbnN0IGF1dG9jb21wbGV0ZSA9IHJlcXVpcmUoJy4vYXV0b2NvbXBsZXRlJylcclxuY29uc3Qga2V5d29yZHNSZXBvID0gcmVxdWlyZSgnLi9rZXl3b3JkcycpXHJcbmNvbnN0IHJvYm90UGFyc2VyID0gcmVxdWlyZSgnLi9wYXJzZS1yb2JvdCcpXHJcbmNvbnN0IGxpYmRvY1BhcnNlciA9IHJlcXVpcmUoJy4vcGFyc2UtbGliZG9jJylcclxuY29uc3QgbGliTWFuYWdlciA9IHJlcXVpcmUoJy4vbGlicmFyeS1tYW5hZ2VyJylcclxuY29uc3QgY29tbW9uID0gcmVxdWlyZSgnLi9jb21tb24nKVxyXG5jb25zdCBzdGF0dXMgPSByZXF1aXJlKCcuL3N0YXR1cycpXHJcblxyXG5cclxuY29uc3QgQ0ZHX0tFWSA9ICdhdXRvY29tcGxldGUtcm9ib3QtZnJhbWV3b3JrJztcclxuY29uc3QgTUFYX0ZJTEVfU0laRSA9IDEwMjQgKiAxMDI0O1xyXG5jb25zdCBNQVhfS0VZV09SRFNfU1VHR0VTVElPTlNfQ0FQID0gMTAwO1xyXG5jb25zdCBQWVRIT05fTElCRE9DX0RJUiA9IHBhdGhVdGlscy5qb2luKG9zLnRtcGRpcigpLCAncm9ib3QtbGliLWNhY2hlJyk7IC8vIFBsYWNlIHRvIHN0b3JlIGltcG9ydGVkIFB5dGhvbiBsaWJkb2MgZmlsZXNcclxuXHJcbmNvbnN0IEZBTExCQUNLX0xJQlJBUllfRElSID0gcGF0aFV0aWxzLmpvaW4oX19kaXJuYW1lLCAnLi4vZmFsbGJhY2stbGlicmFyaWVzJyk7XHJcblxyXG5cclxuLy8gVXNlZCB0byBhdm9pZCBtdWx0aXBsZSBjb25jdXJyZW50IHJlbG9hZGluZ3NcclxubGV0IHNjaGVkdWxlUmVsb2FkID0gZmFsc2U7XHJcblxyXG5mdW5jdGlvbiBpc1JvYm90RmlsZShmaWxlQ29udGVudCwgZmlsZVBhdGgsIHNldHRpbmdzKSB7XHJcbiAgbGV0IGV4dCA9IHBhdGhVdGlscy5leHRuYW1lKGZpbGVQYXRoKTtcclxuICBpZiAoZXh0LnRvTG93ZXJDYXNlKCkgPT09ICcucm9ib3QnKSB7XHJcbiAgICByZXR1cm4gdHJ1ZTtcclxuICB9XHJcbiAgaWYgKHNldHRpbmdzLnJvYm90RXh0ZW5zaW9ucy5pbmNsdWRlcyhleHQudG9Mb3dlckNhc2UoKSkgJiYgcm9ib3RQYXJzZXIuaXNSb2JvdChmaWxlQ29udGVudCkpIHtcclxuICAgIHJldHVybiB0cnVlO1xyXG4gIH1cclxuICByZXR1cm4gZmFsc2U7XHJcbn07XHJcblxyXG5mdW5jdGlvbiBpc0xpYmRvY1htbEZpbGUoZmlsZUNvbnRlbnQsIGZpbGVQYXRoKSB7XHJcbiAgbGV0IGV4dCA9IHBhdGhVdGlscy5leHRuYW1lKGZpbGVQYXRoKTtcclxuICByZXR1cm4gZXh0LnRvTG93ZXJDYXNlKCkgPT09ICcueG1sJyAmJiBsaWJkb2NQYXJzZXIuaXNMaWJkb2MoZmlsZUNvbnRlbnQpO1xyXG59O1xyXG5cclxuZnVuY3Rpb24gcmVhZGRpcihwYXRoKXtcclxuICByZXR1cm4gbmV3IFByb21pc2UoZnVuY3Rpb24ocmVzb2x2ZSwgcmVqZWN0KSB7XHJcbiAgICBsZXQgY2FsbGJhY2sgPSBmdW5jdGlvbihlcnIsIGZpbGVzKSB7XHJcbiAgICAgIGlmIChlcnIpIHtcclxuICAgICAgICByZXR1cm4gcmVqZWN0KGVycik7XHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgcmV0dXJuIHJlc29sdmUoZmlsZXMpO1xyXG4gICAgICB9XHJcbiAgICB9O1xyXG4gICAgcmV0dXJuIGZzLnJlYWRkaXIocGF0aCwgY2FsbGJhY2spO1xyXG4gIH0pXHJcbn1cclxuXHJcbmZ1bmN0aW9uIHNjYW5EaXJlY3RvcnkocGF0aCwgc2V0dGluZ3Mpe1xyXG4gIHJldHVybiByZWFkZGlyKHBhdGgpLnRoZW4oZnVuY3Rpb24ocmVzdWx0KSB7XHJcbiAgICBsZXQgcHJvbWlzZSA9IFByb21pc2UucmVzb2x2ZSgpO1xyXG4gICAgLy8gQ2hhaW4gcHJvbWlzZXMgdG8gYXZvaWQgZnJlZXppbmcgYXRvbSB1aVxyXG4gICAgZm9yIChsZXQgbmFtZSBvZiByZXN1bHQpIHtcclxuICAgICAgcHJvbWlzZSA9IHByb21pc2UudGhlbigoKSA9PiBwcm9jZXNzRmlsZShwYXRoLCBuYW1lLCBmcy5sc3RhdFN5bmMoYCR7cGF0aH0vJHtuYW1lfWApLCBzZXR0aW5ncykpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gcHJvbWlzZTtcclxuICB9KTtcclxufVxyXG5cclxuZnVuY3Rpb24gcHJvY2Vzc0ZpbGUocGF0aCwgbmFtZSwgc3RhdCwgc2V0dGluZ3MpIHtcclxuICBpZihzZXR0aW5ncy5leGNsdWRlRGlyZWN0b3JpZXMpe1xyXG4gICAgY29uc3QgbWF0Y2hlZCA9IHNldHRpbmdzLmV4Y2x1ZGVEaXJlY3Rvcmllcy5maWx0ZXIocGF0dGVybiA9PiBtaW5pbWF0Y2gobmFtZSwgcGF0dGVybikpXHJcbiAgICBpZihtYXRjaGVkLmxlbmd0aCA+IDApe1xyXG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIGxldCBmdWxsUGF0aCA9IGAke3BhdGh9LyR7bmFtZX1gO1xyXG4gIGxldCBleHQgPSBwYXRoVXRpbHMuZXh0bmFtZShmdWxsUGF0aCk7XHJcbiAgaWYgKHN0YXQuaXNEaXJlY3RvcnkoKSkge1xyXG4gICAgcmV0dXJuIHNjYW5EaXJlY3RvcnkoZnVsbFBhdGgsIHNldHRpbmdzKTtcclxuICB9XHJcbiAgaWYgKHN0YXQuaXNGaWxlKCkgJiYgc3RhdC5zaXplIDwgc2V0dGluZ3MubWF4RmlsZVNpemUpIHtcclxuICAgIGxldCBmaWxlQ29udGVudCA9IGZzLnJlYWRGaWxlU3luYyhmdWxsUGF0aCkudG9TdHJpbmcoKTtcclxuICAgIGlmIChpc1JvYm90RmlsZShmaWxlQ29udGVudCwgZnVsbFBhdGgsIHNldHRpbmdzKSkge1xyXG4gICAgICB2YXIgcGFyc2VkUm9ib3RJbmZvID0gcm9ib3RQYXJzZXIucGFyc2UoZmlsZUNvbnRlbnQpO1xyXG4gICAgICBrZXl3b3Jkc1JlcG8uYWRkUmVzb3VyY2UocGFyc2VkUm9ib3RJbmZvLCBmdWxsUGF0aCk7XHJcbiAgICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcclxuICAgIH1cclxuICAgIGlmIChzZXR0aW5ncy5wcm9jZXNzTGliZG9jRmlsZXMgJiYgaXNMaWJkb2NYbWxGaWxlKGZpbGVDb250ZW50LCBmdWxsUGF0aCkpIHtcclxuICAgICAgbGliTWFuYWdlci5hZGRGYWxsYmFja0xpYnJhcmllcyhbZnVsbFBhdGhdKVxyXG4gICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiBQcm9taXNlLnJlc29sdmUoKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcmVhZENvbmZpZygpe1xyXG4gIGxldCBzZXR0aW5ncyA9IHtcclxuICAgIHJvYm90RXh0ZW5zaW9uczogWycucm9ib3QnLCAnLnR4dCcsICcucmVzb3VyY2UnXSxcclxuICAgIGRlYnVnOiB1bmRlZmluZWQsICAgICAgICAgICAgICAvLyBUcnVlL2ZhbHNlIGZvciB2ZXJib3NlIGNvbnNvbGUgb3V0cHV0XHJcbiAgICBtYXhGaWxlU2l6ZTogdW5kZWZpbmVkLCAgICAgICAgLy8gRmlsZXMgYmlnZ2VyIHRoYW4gdGhpcyB3aWxsIG5vdCBiZSBsb2FkZWQgaW4gbWVtb3J5XHJcbiAgICBtYXhLZXl3b3Jkc1N1Z2dlc3Rpb25zQ2FwOiB1bmRlZmluZWQsICAvLyBNYXhpbXVtIG51bWJlciBvZiBzdWdnZXN0ZWQga2V5d29yZHNcclxuICAgIGV4Y2x1ZGVEaXJlY3RvcmllczogdW5kZWZpbmVkLCAvLyBEaXJlY3RvcmllcyBub3QgdG8gYmUgc2Nhbm5lZFxyXG4gICAgcmVtb3ZlRG90Tm90YXRpb246IHVuZGVmaW5lZCwgICAvLyBBdm9pZCBkb3Qgbm90YXRpb24gaW4gc3VnZ2VzdGlvbnMsIGllLiBCdWlsdEluLmNvbnZoZXggd2lsbCBiZSBzdWdnZXN0ZWQgYXMgXCJDb252ZXJ0IFRvIEhleFwiIGluc3RlYWQgb2YgXCJCdWlsdEluLkNvbnZlcnQgVG8gSGV4XCJcclxuICAgIHNob3dBcmd1bWVudHM6IHVuZGVmaW5lZCwgICAgICAvLyBTaG93cyBrZXl3b3JkIGFyZ3VtZW50cyBpbiBzdWdnZXN0aW9uc1xyXG4gICAgc3VnZ2VzdEFyZ3VtZW50czogdW5kZWZpbmVkLCAgICAgIC8vIEFkZCBhcmd1bWVudHMgYWZ0ZXIga2V5d29yZCBuYW1lIHdoZW4gc3VnZ2VzdGluZ1xyXG4gICAgaW5jbHVkZURlZmF1bHRBcmd1bWVudHM6IHVuZGVmaW5lZCwgICAgICAvLyBJbmNsdWRlIGRlZmF1bHQga2V5d29yZCBhcmd1bWVudHMgKGllLiBsZXZlbD1JTkZPKSBhbW9uZyBzdWdlc3RlZCBhcmd1bWVudHNcclxuICAgIHByb2Nlc3NMaWJkb2NGaWxlczogdW5kZWZpbmVkLCAvLyBQcm9jZXNzICcueG1sJyBmaWxlcyByZXByZXNlbnRpbmcgbGliZG9jIGRlZmluaXRpb25zXHJcbiAgICBzaG93TGlicmFyeVN1Z2dlc3Rpb25zOiB1bmRlZmluZWQsIC8vIFN1Z2dlc3QgbGlicmFyeSBuYW1lc1xyXG4gICAgaW50ZXJuYWxTY29wZU1vZGlmaWVyOiB1bmRlZmluZWQsIC8vIElmIHVzZWQsIGludGVybmFsIHNjb3BlIG1vZGlmaWVyIHdpbGwgc3VnZ2VzdCBvbmx5IGtleXdvcmRzIGZyb20gbG9jYWwgcmVzb3VyY2VcclxuICAgIHB5dGhvbkV4ZWN1dGFibGU6IHVuZGVmaW5lZCwgIC8vIFB5dGhvbiBjb21tYW5kIG5hbWUgb3IgcGF0aFxyXG4gIH07XHJcbiAgcHJvdmlkZXIuc2V0dGluZ3MgPSBzZXR0aW5ncztcclxuXHJcbiAgLy8gaGlkZGVuIHNldHRpbmdzXHJcbiAgc2V0dGluZ3MuaW50ZXJuYWxTY29wZU1vZGlmaWVyID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LmludGVybmFsU2NvcGVNb2RpZmllcmApIHx8ICd0aGlzJztcclxuICBzZXR0aW5ncy5zaG93QXJndW1lbnRzID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LnNob3dBcmd1bWVudHNgKSB8fCBmYWxzZTtcclxuICBzZXR0aW5ncy5tYXhGaWxlU2l6ZSA9IGF0b20uY29uZmlnLmdldChgJHtDRkdfS0VZfS5tYXhGaWxlU2l6ZWApIHx8IE1BWF9GSUxFX1NJWkU7XHJcbiAgc2V0dGluZ3MubWF4S2V5d29yZHNTdWdnZXN0aW9uc0NhcCA9IGF0b20uY29uZmlnLmdldChgJHtDRkdfS0VZfS5tYXhLZXl3b3Jkc1N1Z2dlc3Rpb25zQ2FwYCkgfHwgTUFYX0tFWVdPUkRTX1NVR0dFU1RJT05TX0NBUDtcclxuXHJcbiAgc2V0dGluZ3MuZGVidWcgPSBhdG9tLmNvbmZpZy5nZXQoYCR7Q0ZHX0tFWX0uZGVidWdgKTtcclxuICBzZXR0aW5ncy5zdWdnZXN0QXJndW1lbnRzID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LnN1Z2dlc3RBcmd1bWVudHNgKTtcclxuICBzZXR0aW5ncy5pbmNsdWRlRGVmYXVsdEFyZ3VtZW50cyA9IGF0b20uY29uZmlnLmdldChgJHtDRkdfS0VZfS5pbmNsdWRlRGVmYXVsdEFyZ3VtZW50c2ApO1xyXG4gIHNldHRpbmdzLmFyZ3VtZW50U2VwYXJhdG9yID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LmFyZ3VtZW50U2VwYXJhdG9yYCk7XHJcbiAgc2V0dGluZ3MuZXhjbHVkZURpcmVjdG9yaWVzID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LmV4Y2x1ZGVEaXJlY3Rvcmllc2ApO1xyXG4gIHNldHRpbmdzLnJlbW92ZURvdE5vdGF0aW9uID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LnJlbW92ZURvdE5vdGF0aW9uYCk7XHJcbiAgc2V0dGluZ3MucHJvY2Vzc0xpYmRvY0ZpbGVzID0gYXRvbS5jb25maWcuZ2V0KGAke0NGR19LRVl9LnByb2Nlc3NMaWJkb2NGaWxlc2ApO1xyXG4gIHNldHRpbmdzLnNob3dMaWJyYXJ5U3VnZ2VzdGlvbnMgPSBhdG9tLmNvbmZpZy5nZXQoYCR7Q0ZHX0tFWX0uc2hvd0xpYnJhcnlTdWdnZXN0aW9uc2ApO1xyXG4gIHNldHRpbmdzLnB5dGhvbkV4ZWN1dGFibGUgPSBhdG9tLmNvbmZpZy5nZXQoYCR7Q0ZHX0tFWX0ucHl0aG9uRXhlY3V0YWJsZWApO1xyXG59O1xyXG5cclxuLy8gU29tZSBsaWJyYXJ5IG5hbWVzIGNvbnRhaW4gY2hhcmFjdGVycyBmb3JiaWRkZW4gaW4gY29uZmlnIHByb3BlcnR5IG5hbWVzLCBzdWNoIGFzICcuJy5cclxuLy8gVGhpcyBmdW5jdGlvbiByZW1vdmVzIG9mZmVuZGluZyBjaGFyYWN0ZXJzLlxyXG5mdW5jdGlvbiBlc2NhcGVMaWJyYXJ5TmFtZShsaWJyYXJ5TmFtZSl7XHJcbiAgcmV0dXJuIGxpYnJhcnlOYW1lLnJlcGxhY2UoL1xcLi8sICcnKTtcclxufVxyXG5cclxuZnVuY3Rpb24gcHJvamVjdERpcmVjdG9yeUV4aXN0cyhmaWxlUGF0aCkge1xyXG4gIHRyeSB7XHJcbiAgICByZXR1cm4gZnMuc3RhdFN5bmMoZmlsZVBhdGgpLmlzRGlyZWN0b3J5KCk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBmaWxlRXhpc3RzKGZpbGVQYXRoKSB7XHJcbiAgdHJ5IHtcclxuICAgIHJldHVybiBmcy5zdGF0U3luYyhmaWxlUGF0aCkuaXNGaWxlKCk7XHJcbiAgfSBjYXRjaCAoZXJyKSB7XHJcbiAgICByZXR1cm4gZmFsc2U7XHJcbiAgfVxyXG59O1xyXG5cclxuZnVuY3Rpb24gZ2V0RmFsbGJhY2tMaWJyYXJ5UGF0aHMoZmFsbGJhY2tMaWJyYXJ5RGlyKXtcclxuICB0cnl7XHJcbiAgICByZXR1cm4gZnMucmVhZGRpclN5bmMoZmFsbGJhY2tMaWJyYXJ5RGlyKS5tYXAoZmlsZU5hbWUgPT4gcGF0aFV0aWxzLmpvaW4oZmFsbGJhY2tMaWJyYXJ5RGlyLCBmaWxlTmFtZSkpXHJcbiAgfSBjYXRjaChlcnJvcil7XHJcbiAgICBjb25zb2xlLmVycm9yKGVycm9yLnN0YWNrID8gZXJyb3Iuc3RhY2sgOiBlcnJvcilcclxuICAgIHJldHVybiBbXVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcHJvY2Vzc0FsbEltcG9ydHNGaXJzdFBhc3MoKXtcclxuICBjb25zdCBtaXNzaW5nUmVzc291cmNlUGF0aHMgPSBrZXl3b3Jkc1JlcG8ucmVzb2x2ZUFsbEltcG9ydHMoKVxyXG4gIHJldHVybiBtaXNzaW5nUmVzc291cmNlUGF0aHNcclxufVxyXG5cclxuZnVuY3Rpb24gcHJvY2Vzc1Jlc291cmNlSW1wb3J0c0ZpcnN0UGFzcyhyZXNvdXJjZUtleSl7XHJcbiAgY29uc3QgcmVzb3VyY2UgPSBrZXl3b3Jkc1JlcG8ucmVzb3VyY2VzTWFwW3Jlc291cmNlS2V5XVxyXG4gIGlmKHJlc291cmNlKXtcclxuICAgIGNvbnN0IG1pc3NpbmdSZXNzb3VyY2VQYXRocyA9IGtleXdvcmRzUmVwby5yZXNvbHZlSW1wb3J0cyhyZXNvdXJjZSlcclxuICAgIHJldHVybiBtaXNzaW5nUmVzc291cmNlUGF0aHNcclxuICB9IGVsc2V7XHJcbiAgICByZXR1cm4gbmV3IFNldCgpXHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBwcm9jZXNzSW1wb3J0c1NlY29uZFBhc3MobWlzc2luZ1Jlc3NvdXJjZVBhdGhzKXtcclxuICBsZXQgbmV3UmVzb3VyY2VzID0gMFxyXG4gIG1pc3NpbmdSZXNzb3VyY2VQYXRocy5mb3JFYWNoKGltcG9ydGVkUGF0aCA9PiB7XHJcbiAgICBjb25zb2xlLmxvZyhgaW1wb3J0ZWRQYXRoOiAke2ltcG9ydGVkUGF0aH1gKTtcclxuICAgIGNvbnN0IGZpbGVDb250ZW50ID0gZnMucmVhZEZpbGVTeW5jKGltcG9ydGVkUGF0aCkudG9TdHJpbmcoKVxyXG4gICAgaWYgKGlzUm9ib3RGaWxlKGZpbGVDb250ZW50LCBpbXBvcnRlZFBhdGgsIHByb3ZpZGVyLnNldHRpbmdzKSkge1xyXG4gICAgICBjb25zdCBwYXJzZWRSb2JvdEluZm8gPSByb2JvdFBhcnNlci5wYXJzZShmaWxlQ29udGVudCk7XHJcbiAgICAgIGtleXdvcmRzUmVwby5hZGRSZXNvdXJjZShwYXJzZWRSb2JvdEluZm8sIGltcG9ydGVkUGF0aCk7XHJcbiAgICAgIG5ld1Jlc291cmNlcysrXHJcbiAgICB9XHJcbiAgfSlcclxuICBpZihuZXdSZXNvdXJjZXM+MCl7XHJcbiAgICBrZXl3b3Jkc1JlcG8ucmVzb2x2ZUFsbEltcG9ydHMoKVxyXG4gIH1cclxufVxyXG5cclxuZnVuY3Rpb24gcmVsb2FkQXV0b2NvbXBsZXRlRGF0YSgpIHtcclxuICBpZiAocHJvdmlkZXIubG9hZGluZykge1xyXG4gICAgaWYgKHByb3ZpZGVyLnNldHRpbmdzLmRlYnVnKSB7IGNvbnNvbGUubG9nKCdTY2hlZHVsZSBsb2FkaW5nIGF1dG9jb21wbGV0ZSBkYXRhJyk7IH1cclxuICAgIHNjaGVkdWxlUmVsb2FkID0gdHJ1ZTtcclxuICAgIHJldHVybiBQcm9taXNlLnJlc29sdmUoe3N0YXR1czogJ3NjaGVkdWxlZCd9KVxyXG4gIH0gZWxzZSB7XHJcbiAgICBpZiAocHJvdmlkZXIuc2V0dGluZ3MuZGVidWcpIHsgY29uc29sZS5sb2coJ0xvYWRpbmcgYXV0b2NvbXBsZXRlIGRhdGEnKTsgfVxyXG4gICAgcHJvdmlkZXIubG9hZGluZyA9IHRydWU7XHJcbiAgICBsaWJNYW5hZ2VyLnJlc2V0KClcclxuICAgIGxldCBwcm9taXNlID0gUHJvbWlzZS5yZXNvbHZlKCk7XHJcbiAgICAvLyBDaGFpbiBwcm9taXNlcyB0byBhdm9pZCBmcmVlemluZyBhdG9tIHVpIGR1ZSB0byB0b28gbWFueSBjb25jdXJyZW50IHByb2Nlc3Nlc1xyXG4gICAgZm9yIChsZXQgcGF0aCBpbiBwcm92aWRlci5yb2JvdFByb2plY3RQYXRocykge1xyXG4gICAgICBpZiAocHJvamVjdERpcmVjdG9yeUV4aXN0cyhwYXRoKSAmJiBwcm92aWRlci5yb2JvdFByb2plY3RQYXRoc1twYXRoXS5zdGF0dXMgPT09ICdwcm9qZWN0LWluaXRpYWwnKSB7XHJcbiAgICAgICAgbGV0IHByb2plY3ROYW1lID0gcGF0aFV0aWxzLmJhc2VuYW1lKHBhdGgpO1xyXG4gICAgICAgIGlmIChwcm92aWRlci5zZXR0aW5ncy5kZWJ1ZykgeyBjb25zb2xlLmxvZyhgTG9hZGluZyBwcm9qZWN0ICR7cHJvamVjdE5hbWV9YCk7IH1cclxuICAgICAgICBpZiAocHJvdmlkZXIuc2V0dGluZ3MuZGVidWcpIHsgY29uc29sZS50aW1lKGBSb2JvdCBwcm9qZWN0ICR7cHJvamVjdE5hbWV9IGxvYWRpbmcgdGltZTpgKTsgfVxyXG4gICAgICAgIHByb3ZpZGVyLnJvYm90UHJvamVjdFBhdGhzW3BhdGhdLnN0YXR1cyA9ICdwcm9qZWN0LWxvYWRpbmcnO1xyXG4gICAgICAgIGtleXdvcmRzUmVwby5yZXNldChwYXRoKTtcclxuICAgICAgICBwcm9taXNlID0gcHJvbWlzZS50aGVuKCgpID0+XHJcbiAgICAgICAgc2NhbkRpcmVjdG9yeShwYXRoLCBwcm92aWRlci5zZXR0aW5ncykudGhlbihmdW5jdGlvbigpIHtcclxuICAgICAgICAgIGlmIChwcm92aWRlci5zZXR0aW5ncy5kZWJ1ZykgeyBjb25zb2xlLmxvZyhgUHJvamVjdCAke3Byb2plY3ROYW1lfSBsb2FkZWRgKTsgfVxyXG4gICAgICAgICAgaWYgKHByb3ZpZGVyLnNldHRpbmdzLmRlYnVnKSB7IGNvbnNvbGUudGltZUVuZChgUm9ib3QgcHJvamVjdCAke3Byb2plY3ROYW1lfSBsb2FkaW5nIHRpbWU6YCk7IH1cclxuICAgICAgICAgIHByb3ZpZGVyLnJvYm90UHJvamVjdFBhdGhzW3BhdGhdLnN0YXR1cyA9ICdwcm9qZWN0LWxvYWRlZCc7XHJcbiAgICAgICAgfSlcclxuICAgICAgKTtcclxuICAgIH1cclxuICB9XHJcbiAgcmV0dXJuIHByb21pc2UudGhlbigoKSA9PiB7XHJcbiAgICBpZiAocHJvdmlkZXIuc2V0dGluZ3MuZGVidWcpIHsgY29uc29sZS5sb2coJ1Jlc29sdmluZyBpbXBvcnRzLi4uJyk7IH1cclxuICAgIGlmIChwcm92aWRlci5zZXR0aW5ncy5kZWJ1ZykgeyBjb25zb2xlLnRpbWUoYEltcG9ydHMgcmVzb2x2ZWQgaW5gKTsgfVxyXG4gICAgY29uc3QgbWlzc2luZ1Jlc3NvdXJjZVBhdGhzID0gcHJvY2Vzc0FsbEltcG9ydHNGaXJzdFBhc3MoKVxyXG4gICAgcHJvY2Vzc0ltcG9ydHNTZWNvbmRQYXNzKG1pc3NpbmdSZXNzb3VyY2VQYXRocylcclxuICAgIGlmIChwcm92aWRlci5zZXR0aW5ncy5kZWJ1ZykgeyBjb25zb2xlLnRpbWVFbmQoYEltcG9ydHMgcmVzb2x2ZWQgaW5gKTsgfVxyXG4gIH0pXHJcbiAgLnRoZW4oKCkgPT4ge1xyXG4gICAgaWYgKHByb3ZpZGVyLnNldHRpbmdzLmRlYnVnKSB7IGNvbnNvbGUubG9nKCdJbXBvcnRpbmcgbGlicmFyaWVzLi4uJyk7IH1cclxuICAgIGNvbnN0IGZhbGxiYWNrTGlicmFyaWVzUGF0aHMgPSBnZXRGYWxsYmFja0xpYnJhcnlQYXRocyhGQUxMQkFDS19MSUJSQVJZX0RJUilcclxuICAgIGxpYk1hbmFnZXIuYWRkRmFsbGJhY2tMaWJyYXJpZXMoZmFsbGJhY2tMaWJyYXJpZXNQYXRocylcclxuICAgIHJldHVybiBsaWJNYW5hZ2VyLmltcG9ydExpYnJhcmllcyhQWVRIT05fTElCRE9DX0RJUiwgcHJvdmlkZXIuc2V0dGluZ3MucHl0aG9uRXhlY3V0YWJsZSk7XHJcbiAgfSlcclxuICAudGhlbigoKSA9PiB7XHJcbiAgICBpZiAocHJvdmlkZXIuc2V0dGluZ3MuZGVidWcpIHsgY29uc29sZS5sb2coJ0F1dG9jb21wbGV0ZSBkYXRhIGxvYWRlZCcpOyB9XHJcbiAgICBwcm92aWRlci5sb2FkaW5nID0gZmFsc2U7XHJcbiAgICBpZiAoc2NoZWR1bGVSZWxvYWQpIHtcclxuICAgICAgc2NoZWR1bGVSZWxvYWQgPSBmYWxzZTtcclxuICAgICAgcmV0dXJuIHJlbG9hZEF1dG9jb21wbGV0ZURhdGEoKTtcclxuICAgIH0gZWxzZXtcclxuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7c3RhdHVzOiAncmVsb2FkZWQnfSlcclxuICAgIH1cclxuICB9KVxyXG4gIC5jYXRjaCgoZXJyb3IpID0+IHtcclxuICAgIGNvbnNvbGUuZXJyb3IoYEVycm9yIG9jY3VycmVkIHdoaWxlIHJlbG9hZGluZyByb2JvdCBhdXRvY29tcGxldGUgZGF0YTogJHtlcnJvci5zdGFjayA/IGVycm9yLnN0YWNrIDogZXJyb3J9YCk7XHJcbiAgICBwcm92aWRlci5sb2FkaW5nID0gZmFsc2U7XHJcbiAgICBpZiAoc2NoZWR1bGVSZWxvYWQpIHtcclxuICAgICAgc2NoZWR1bGVSZWxvYWQgPSBmYWxzZTtcclxuICAgICAgcmV0dXJuIHJlbG9hZEF1dG9jb21wbGV0ZURhdGEoKTtcclxuICAgIH0gZWxzZXtcclxuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSh7c3RhdHVzOiAnZXJyb3InLCBtZXNzYWdlOiBlcnJvci50b1N0cmluZygpLCBzdGFjazogZXJyb3Iuc3RhY2t9KVxyXG4gICAgfVxyXG4gIH0pO1xyXG59XHJcbn07XHJcblxyXG4vLyB0cnVlL2ZhbHNlIHdoZW4gbmV3IGxpYnJhcmllcyBoYXZlIGJlZW4gYWRkZWQgc2luY2UgbGFzdCBlZGl0LlxyXG5mdW5jdGlvbiBpc0xpYnJhcnlJbmZvVXBkYXRlZEZvckVkaXRvcihvbGRMaWJyYXJpZXMsIG5ld0xpYnJhcmllcykge1xyXG4gIG9sZExpYnJhcmllcyA9IG9sZExpYnJhcmllcy5tYXAobGlicmFyeSA9PiBsaWJyYXJ5Lm5hbWUpO1xyXG4gIG5ld0xpYnJhcmllcyA9IG5ld0xpYnJhcmllcy5tYXAobGlicmFyeSA9PiBsaWJyYXJ5Lm5hbWUpO1xyXG4gIHJldHVybiAhY29tbW9uLmVxU2V0KG5ldyBTZXQob2xkTGlicmFyaWVzKSwgbmV3IFNldChuZXdMaWJyYXJpZXMpKTtcclxufTtcclxuXHJcbmZ1bmN0aW9uIHJlbG9hZEF1dG9jb21wbGV0ZURhdGFGb3JFZGl0b3IoZWRpdG9yLCB1c2VCdWZmZXIsIHNldHRpbmdzKSB7XHJcbiAgbGV0IHBhdGggPSBlZGl0b3IuZ2V0UGF0aCgpO1xyXG4gIGlmICghcGF0aCkge1xyXG4gICAgcmV0dXJuO1xyXG4gIH1cclxuICBsZXQgZGlyUGF0aCA9IHBhdGhVdGlscy5kaXJuYW1lKHBhdGgpO1xyXG4gIGlmIChmaWxlRXhpc3RzKHBhdGgpICYmIHBhdGhVdGlscy5ub3JtYWxpemUoZGlyUGF0aCkhPT1QWVRIT05fTElCRE9DX0RJUikge1xyXG4gICAgbGV0IGZpbGVDb250ZW50ID0gdXNlQnVmZmVyID8gZWRpdG9yLmdldEJ1ZmZlcigpLmdldFRleHQoKSA6IGZzLnJlYWRGaWxlU3luYyhwYXRoKS50b1N0cmluZygpO1xyXG4gICAgaWYgKGlzUm9ib3RGaWxlKGZpbGVDb250ZW50LCBwYXRoLCBzZXR0aW5ncykpIHtcclxuICAgICAgdmFyIHBhcnNlZFJvYm90SW5mbyA9IHJvYm90UGFyc2VyLnBhcnNlKGZpbGVDb250ZW50KTtcclxuICAgICAgbGV0IHJlc291cmNlS2V5ID0gY29tbW9uLmdldFJlc291cmNlS2V5KHBhdGgpO1xyXG4gICAgICBsZXQgb2xkTGlicmFyaWVzID0ga2V5d29yZHNSZXBvLnJlc291cmNlc01hcFtyZXNvdXJjZUtleV0gPyBrZXl3b3Jkc1JlcG8ucmVzb3VyY2VzTWFwW3Jlc291cmNlS2V5XS5pbXBvcnRzLmxpYnJhcmllcyA6IFtdO1xyXG4gICAgICBrZXl3b3Jkc1JlcG8uYWRkUmVzb3VyY2UocGFyc2VkUm9ib3RJbmZvLCBwYXRoKTtcclxuICAgICAgY29uc3QgbWlzc2luZ1Jlc3NvdXJjZVBhdGhzID0gcHJvY2Vzc1Jlc291cmNlSW1wb3J0c0ZpcnN0UGFzcyhyZXNvdXJjZUtleSlcclxuICAgICAgcHJvY2Vzc0ltcG9ydHNTZWNvbmRQYXNzKG1pc3NpbmdSZXNzb3VyY2VQYXRocylcclxuICAgICAgbGV0IG5ld0xpYnJhcmllcyA9IGtleXdvcmRzUmVwby5yZXNvdXJjZXNNYXBbcmVzb3VyY2VLZXldLmltcG9ydHMubGlicmFyaWVzO1xyXG4gICAgICBsZXQgbGlicmFyeUluZm9VcGRhdGVkID0gaXNMaWJyYXJ5SW5mb1VwZGF0ZWRGb3JFZGl0b3Iob2xkTGlicmFyaWVzLCBuZXdMaWJyYXJpZXMpO1xyXG4gICAgICBpZiAobGlicmFyeUluZm9VcGRhdGVkKSB7XHJcbiAgICAgICAgbGliTWFuYWdlci5pbXBvcnRMaWJyYXJpZXMoUFlUSE9OX0xJQkRPQ19ESVIsIHByb3ZpZGVyLnNldHRpbmdzLnB5dGhvbkV4ZWN1dGFibGUpO1xyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBrZXl3b3Jkc1JlcG8ucmVzZXQocGF0aCk7XHJcbiAgICB9XHJcbiAgfVxyXG59O1xyXG5cclxuLy8gT3BlbnMgYSBuZXcgcHJvamVjdCBmb3IgZ2l2ZW4gZWRpdG9yIGlmIG5vbmUgaXMgYWxyZWFkeSBvcGVuZWQgZm9yIGl0LlxyXG4vLyBQcm9qZWN0IG9wZW5pbmcgaXMgaGFuZGxlZCBhc3luY2hyb25vdXNseS5cclxuLy8gUmV0dXJucyBhIHByb21pc2UgaG9sZGluZyAnb3BlbmVkJyB2YWx1ZSBhZnRlciBwcm9qZWN0IGhhdmUgYmVlbiBvcGVuZWQuXHJcbi8vIFJldHVybnMgYSBwcm9taXNlIGhvbGRpbmcgJ2FscmVhZHlvcGVuJyB2YWx1ZSBpZiBwcm9qZWN0IGlzIGFscmVhZHkgb3BlbmVkXHJcbi8vIFJldHVybnMgYSBwcm9taXNlIGhvbGRpbmcgJ25vcm9ib3QnIHZhbHVlIGVkaXRvciBkb2VzIG5vdCByZXByZXNlbnQgYSByb2JvdCBmaWxlLlxyXG5mdW5jdGlvbiBvcGVuUm9ib3RQcm9qZWN0UGF0aEZvckVkaXRvcihlZGl0b3IsIHNldHRpbmdzKSB7XHJcbiAgbGV0IGVkaXRvclBhdGggPSBlZGl0b3IuZ2V0UGF0aCgpO1xyXG4gIGlmICghZWRpdG9yUGF0aCkge1xyXG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgnbm9yb2JvdCcpXHJcbiAgfVxyXG4gIGxldCBkaXJQYXRoID0gcGF0aFV0aWxzLmRpcm5hbWUoZWRpdG9yUGF0aCk7XHJcbiAgaWYgKHBhdGhVdGlscy5ub3JtYWxpemUoZGlyUGF0aCkhPT1QWVRIT05fTElCRE9DX0RJUikge1xyXG4gICAgbGV0IHRleHQgPSBlZGl0b3IuZ2V0QnVmZmVyKCkuZ2V0VGV4dCgpO1xyXG4gICAgbGV0IGV4dCA9IHBhdGhVdGlscy5leHRuYW1lKGVkaXRvclBhdGgpO1xyXG4gICAgbGV0IGlzUm9ib3QgPSBpc1JvYm90RmlsZSh0ZXh0LCBlZGl0b3JQYXRoLCBzZXR0aW5ncyk7XHJcbiAgICBpZihpc1JvYm90KXtcclxuICAgICAgbGV0IHJvYm90UHJvamVjdFBhdGhzVXBkYXRlZCA9IGZhbHNlXHJcbiAgICAgIGZvciAobGV0IHByb2plY3RQYXRoIG9mIGdldEF0b21Qcm9qZWN0UGF0aHNGb3JFZGl0b3IoZWRpdG9yKSkge1xyXG4gICAgICAgIGlmICghcHJvdmlkZXIucm9ib3RQcm9qZWN0UGF0aHNbcHJvamVjdFBhdGhdKSB7XHJcbiAgICAgICAgICAvLyBOZXcgcm9ib3QgcHJvamVjdCBkZXRlY3RlZFxyXG4gICAgICAgICAgcHJvdmlkZXIucm9ib3RQcm9qZWN0UGF0aHNbcHJvamVjdFBhdGhdID0ge3N0YXR1czogJ3Byb2plY3QtaW5pdGlhbCd9O1xyXG4gICAgICAgICAgcm9ib3RQcm9qZWN0UGF0aHNVcGRhdGVkID0gdHJ1ZVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBpZihyb2JvdFByb2plY3RQYXRoc1VwZGF0ZWQpe1xyXG4gICAgICAgIHJldHVybiByZWxvYWRBdXRvY29tcGxldGVEYXRhKCkudGhlbigoKT0+J29wZW5lZCcpXHJcbiAgICAgIH0gZWxzZXtcclxuICAgICAgICByZXR1cm4gUHJvbWlzZS5yZXNvbHZlKCdhbHJlYWR5b3BlbicpXHJcbiAgICAgIH1cclxuICAgIH0gZWxzZXtcclxuICAgICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgnbm9yb2JvdCcpXHJcbiAgICB9XHJcbiAgfSBlbHNle1xyXG4gICAgcmV0dXJuIFByb21pc2UucmVzb2x2ZSgnbm9yb2JvdCcpXHJcbiAgfVxyXG59O1xyXG5cclxuLy8gUmVtb3ZlcyBwYXRocyB0aGF0IGFyZSBubyBsb25nZXIgb3BlbmVkIGluIEF0b20gdHJlZSB2aWV3XHJcbmZ1bmN0aW9uIGNsZWFuUm9ib3RQcm9qZWN0UGF0aHMoKSB7XHJcbiAgbGV0IGF0b21QYXRocyA9IGF0b20ucHJvamVjdC5nZXREaXJlY3RvcmllcygpLm1hcCggZGlyZWN0b3J5ID0+IGRpcmVjdG9yeS5wYXRoKTtcclxuICBmb3IgKGxldCBwYXRoIGluIHByb3ZpZGVyLnJvYm90UHJvamVjdFBhdGhzKSB7XHJcbiAgICBpZiAoIWF0b21QYXRocy5pbmNsdWRlcyhwYXRoKSkge1xyXG4gICAgICBkZWxldGUgcHJvdmlkZXIucm9ib3RQcm9qZWN0UGF0aHNbcGF0aF07XHJcbiAgICAgIGtleXdvcmRzUmVwby5yZXNldChwYXRoKTtcclxuICAgICAgaWYgKHByb3ZpZGVyLnNldHRpbmdzLmRlYnVnKSB7IGNvbnNvbGUubG9nKGBSZW1vdmVkIHByZXZpb3VzbHkgaW5kZXhlZCByb2JvdCBwcm9qZWM6ICcke3BhdGh9J2ApOyB9XHJcbiAgICB9XHJcbiAgfVxyXG59O1xyXG5cclxuXHJcbmZ1bmN0aW9uIGdldEF0b21Qcm9qZWN0UGF0aHNGb3JFZGl0b3IoZWRpdG9yKSB7XHJcbiAgbGV0IHJlcyA9IFtdO1xyXG4gIGxldCBlZGl0b3JQYXRoID0gZWRpdG9yLmdldFBhdGgoKTtcclxuICBmb3IgKGxldCBwcm9qZWN0RGlyZWN0b3J5IG9mIGF0b20ucHJvamVjdC5nZXREaXJlY3RvcmllcygpKSB7XHJcbiAgICBpZiAocHJvamVjdERpcmVjdG9yeS5jb250YWlucyhlZGl0b3JQYXRoKSkge1xyXG4gICAgICByZXMucHVzaChwcm9qZWN0RGlyZWN0b3J5LmdldFBhdGgoKSk7XHJcbiAgICB9XHJcbiAgfVxyXG4gIHJldHVybiByZXM7XHJcbn07XHJcblxyXG5cclxuLy8gTm9ybWFsbHkgYXV0b2NvbXBsZXRlLXBsdXMgY29uc2lkZXJzICcuJyBhcyBkZWxpbWl0ZXIgd2hlbiBidWlsZGluZyBwcmVmaXhlcy5cclxuLy8gaWUuIGZvciAnSHR0cExpYnJhcnkuSFRUUCcgaXQgcmVwb3J0cyBvbmx5ICdIVFRQJyBhcyBwcmVmaXguXHJcbi8vIFRoaXMgbWV0aG9kIGNvbnNpZGVycyBldmVyeXRoaW5nIHVudGlsIGl0IG1lZXRzIGEgcm9ib3Qgc3ludGF4IHNlcGFyYXRvciAobXVsdGlwbGUgc3BhY2VzLCB0YWJzLCAuLi4pLlxyXG5mdW5jdGlvbiBnZXRQcmVmaXgoZWRpdG9yLCBidWZmZXJQb3NpdGlvbikge1xyXG4gIGxldCBsaW5lID0gZWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KGJ1ZmZlclBvc2l0aW9uLnJvdyk7XHJcbiAgbGV0IHRleHRCZWZvcmVDdXJzb3IgPSBsaW5lLnN1YnN0cigwLCBidWZmZXJQb3NpdGlvbi5jb2x1bW4pO1xyXG4gIGxldCBub3JtYWxpemVkID0gdGV4dEJlZm9yZUN1cnNvci5yZXBsYWNlKC9bIFxcdF17Mix9L2csICdcXHQnKTtcclxuICBsZXQgcmV2ZXJzZWQgPSBub3JtYWxpemVkLnNwbGl0KFwiXCIpLnJldmVyc2UoKS5qb2luKFwiXCIpO1xyXG4gIGxldCByZXZlcnNlZFByZWZpeE1hdGNoID0gL15bXlxcdF0rLy5leGVjKHJldmVyc2VkKTtcclxuICBpZihyZXZlcnNlZFByZWZpeE1hdGNoKSB7XHJcbiAgICByZXR1cm4gcmV2ZXJzZWRQcmVmaXhNYXRjaFswXS5zcGxpdChcIlwiKS5yZXZlcnNlKCkuam9pbihcIlwiKTtcclxuICB9IGVsc2Uge1xyXG4gICAgcmV0dXJuICcnO1xyXG4gIH1cclxufTtcclxuXHJcbmNvbnN0IGJkZFByZWZpeFJlZ2V4ID0gL14oZ2l2ZW58d2hlbnx0aGVufGFuZHxidXQpIC9pXHJcbmZ1bmN0aW9uIHByb2Nlc3NCZGRQcmVmaXhlcyhwcmVmaXgpIHtcclxuICBjb25zdCBwcmVmaXhlcyA9IFtwcmVmaXhdXHJcbiAgY29uc3QgbWF0Y2ggPSBiZGRQcmVmaXhSZWdleC5leGVjKHByZWZpeClcclxuICBpZihtYXRjaCkge1xyXG4gICAgcHJlZml4ZXMucHVzaChwcmVmaXguc3Vic3RyaW5nKG1hdGNoWzBdLmxlbmd0aCwgcHJlZml4Lmxlbmd0aCkpXHJcbiAgfVxyXG4gIHJldHVybiBwcmVmaXhlc1xyXG59XHJcblxyXG52YXIgcHJvdmlkZXIgPSB7XHJcbiAgc2V0dGluZ3MgOiB7fSxcclxuICBzZWxlY3RvcjogJy50ZXh0LnJvYm90JyxcclxuICBkaXNhYmxlRm9yU2VsZWN0b3I6ICcuY29tbWVudCwgLnZhcmlhYmxlLCAucHVuY3R1YXRpb24sIC5zdHJpbmcsIC5zdG9yYWdlJyxcclxuICBsb2FkaW5nOiB1bmRlZmluZWQsICAgIC8vIFNldCB0byAndHJ1ZScgZHVyaW5nIGF1dG9jb21wbGV0ZSBkYXRhIGFzeW5jIGxvYWRpbmdcclxuICBwYXRoc0NoYW5nZWRTdWJzY3JpcHRpb246IHVuZGVmaW5lZCxcclxuICAvLyBMaXN0IG9mIHByb2plY3RzIHRoYXQgY29udGFpbiByb2JvdCBmaWxlcy4gSW5pdGlhbGx5IGVtcHR5LCB3aWxsIGJlIGNvbXBsZXRlZFxyXG4gIC8vIG9uY2UgdXNlciBzdGFydHMgZWRpdGluZyBmaWxlcy5cclxuICByb2JvdFByb2plY3RQYXRoczogdW5kZWZpbmVkLFxyXG4gIGdldFN1Z2dlc3Rpb25zKHtlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uLCBzY29wZURlc2NyaXB0b3IsIHByZWZpeH0pIHtcclxuICAgIHByZWZpeCA9IGdldFByZWZpeChlZGl0b3IsIGJ1ZmZlclBvc2l0aW9uKTtcclxuICAgIHByZWZpeGVzID0gcHJvY2Vzc0JkZFByZWZpeGVzKHByZWZpeClcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShmdW5jdGlvbihyZXNvbHZlKSB7XHJcbiAgICAgIGxldCBhbGxTdWdnZXN0aW9ucyA9IFtdXHJcbiAgICAgIGxldCBwYXRoID0gKGVkaXRvciAmJiBlZGl0b3IuYnVmZmVyICYmIGVkaXRvci5idWZmZXIuZmlsZSk/ZWRpdG9yLmJ1ZmZlci5maWxlLnBhdGg6dW5kZWZpbmVkXHJcbiAgICAgIGZvcihwcmVmIG9mIHByZWZpeGVzKSB7XHJcbiAgICAgICAgY29uc3Qgc3VnZ2VzdGlvbnMgPSBhdXRvY29tcGxldGUuZ2V0U3VnZ2VzdGlvbnMocHJlZiwgcGF0aCwgcHJvdmlkZXIuc2V0dGluZ3MpO1xyXG4gICAgICAgIGFsbFN1Z2dlc3Rpb25zID0gYWxsU3VnZ2VzdGlvbnMuY29uY2F0KHN1Z2dlc3Rpb25zKVxyXG4gICAgICB9XHJcbiAgICAgIHJldHVybiByZXNvbHZlKGFsbFN1Z2dlc3Rpb25zKTtcclxuICAgIH0pO1xyXG4gIH0sXHJcbiAgdW5sb2FkKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGF0aHNDaGFuZ2VkU3Vic2NyaXB0aW9uLmRpc3Bvc2UoKTtcclxuICB9LFxyXG4gIGxvYWQoKSB7XHJcbiAgICB0aGlzLnJvYm90UHJvamVjdFBhdGhzID0ge307XHJcbiAgICAvLyBDb25maWd1cmF0aW9uXHJcbiAgICByZWFkQ29uZmlnKCk7XHJcbiAgICBhdG9tLmNvbmZpZy5vbkRpZENoYW5nZShDRkdfS0VZLCBmdW5jdGlvbih7bmV3VmFsdWUsIG9sZFZhbHVlfSl7XHJcbiAgICAgIHJlYWRDb25maWcoKTtcclxuICAgICAgZm9yIChsZXQgcGF0aCBpbiBwcm92aWRlci5yb2JvdFByb2plY3RQYXRocykge1xyXG4gICAgICAgIHByb3ZpZGVyLnJvYm90UHJvamVjdFBhdGhzW3BhdGhdLnN0YXR1cyA9ICdwcm9qZWN0LWluaXRpYWwnO1xyXG4gICAgICB9XHJcbiAgICAgIHJlbG9hZEF1dG9jb21wbGV0ZURhdGEoKTtcclxuICAgIH0pO1xyXG5cclxuICAgIC8vIFJlYWN0IG9uIGVkaXRvciBjaGFuZ2VzXHJcbiAgICBhdG9tLndvcmtzcGFjZS5vYnNlcnZlVGV4dEVkaXRvcnMoZnVuY3Rpb24oZWRpdG9yKSB7XHJcbiAgICAgIGNvbnN0IHByb2plY3RPcGVuU3RhdHVzID0gb3BlblJvYm90UHJvamVjdFBhdGhGb3JFZGl0b3IoZWRpdG9yLCBwcm92aWRlci5zZXR0aW5ncyk7XHJcbiAgICAgIHByb2plY3RPcGVuU3RhdHVzLnRoZW4oKGluZm8pID0+e1xyXG4gICAgICAgIGlmKGluZm89PT0nb3BlbmVkJyB8fCBpbmZvPT09J2FscmVhZHlvcGVuJyl7XHJcbiAgICAgICAgICBsZXQgZWRpdG9yU2F2ZVN1YnNjcmlwdGlvbiA9IGVkaXRvci5vbkRpZFNhdmUoZXZlbnQgPT4gcmVsb2FkQXV0b2NvbXBsZXRlRGF0YUZvckVkaXRvcihlZGl0b3IsIHRydWUsIHByb3ZpZGVyLnNldHRpbmdzKSk7XHJcbiAgICAgICAgICBsZXQgZWRpdG9yU3RvcENoYW5naW5nU3Vic2NyaXB0aW9uID0gZWRpdG9yLm9uRGlkU3RvcENoYW5naW5nKGV2ZW50ID0+IHJlbG9hZEF1dG9jb21wbGV0ZURhdGFGb3JFZGl0b3IoZWRpdG9yLCB0cnVlLCBwcm92aWRlci5zZXR0aW5ncykpO1xyXG4gICAgICAgICAgbGV0IGVkaXRvckRlc3Ryb3lTdWJzY3JpcHRpb24gPSBlZGl0b3Iub25EaWREZXN0cm95KGZ1bmN0aW9uKCkge1xyXG4gICAgICAgICAgICByZWxvYWRBdXRvY29tcGxldGVEYXRhRm9yRWRpdG9yKGVkaXRvciwgZmFsc2UsIHByb3ZpZGVyLnNldHRpbmdzKTtcclxuICAgICAgICAgICAgZWRpdG9yU2F2ZVN1YnNjcmlwdGlvbi5kaXNwb3NlKCk7XHJcbiAgICAgICAgICAgIGVkaXRvclN0b3BDaGFuZ2luZ1N1YnNjcmlwdGlvbi5kaXNwb3NlKCk7XHJcbiAgICAgICAgICAgIGVkaXRvckRlc3Ryb3lTdWJzY3JpcHRpb24uZGlzcG9zZSgpO1xyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSk7XHJcblxyXG4gICAgLy8gUmVhY3Qgb24gcHJvamVjdCBwYXRocyBjaGFuZ2VzXHJcbiAgICB0aGlzLnBhdGhzQ2hhbmdlZFN1YnNjcmlwdGlvbiA9IGF0b20ucHJvamVjdC5vbkRpZENoYW5nZVBhdGhzKHByb2plY3RQYXRocyA9PiBjbGVhblJvYm90UHJvamVjdFBhdGhzKCkpO1xyXG5cclxuICAgIC8vIEF0b20gY29tbWFuZHNcclxuICAgIGF0b20uY29tbWFuZHMuYWRkKCdhdG9tLXRleHQtZWRpdG9yJywgJ1JvYm90IEZyYW1ld29yazpQcmludCBhdXRvY29tcGxldGUgZGVidWcgaW5mbycsICgpID0+ICB7XHJcbiAgICAgIHByb3ZpZGVyLnByaW50RGVidWdJbmZvKClcclxuICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZFN1Y2Nlc3MoJ0RlYnVnIGluZm8gcHJpbnRlZCBpbiBEZXZlbG9wZXIgVG9vbHMgY29uc29sZScpXHJcbiAgICB9KVxyXG4gICAgYXRvbS5jb21tYW5kcy5hZGQoJ2F0b20tdGV4dC1lZGl0b3InLCAnUm9ib3QgRnJhbWV3b3JrOlJlbG9hZCBhdXRvY29tcGxldGUgZGF0YScsICgpID0+IHtcclxuICAgICAgaWYgKHByb3ZpZGVyLmxvYWRpbmcpIHtcclxuICAgICAgICBhdG9tLm5vdGlmaWNhdGlvbnMuYWRkV2FybmluZygnQXV0b2NvbXBsZXRlIGRhdGEgbG9hZGluZyBpcyBjdXJyZW50bHkgaW4gcHJvZ3Jlc3MuJywge2Rpc21pc3NhYmxlOiB0cnVlfSlcclxuICAgICAgICByZXR1cm5cclxuICAgICAgfVxyXG4gICAgICBrZXl3b3Jkc1JlcG8ucmVzZXQoKVxyXG4gICAgICBsaWJNYW5hZ2VyLnJlc2V0KClcclxuICAgICAgZm9yIChsZXQgcGF0aCBpbiBwcm92aWRlci5yb2JvdFByb2plY3RQYXRocykge1xyXG4gICAgICAgIHByb3ZpZGVyLnJvYm90UHJvamVjdFBhdGhzW3BhdGhdLnN0YXR1cyA9ICdwcm9qZWN0LWluaXRpYWwnO1xyXG4gICAgICB9XHJcbiAgICAgIHJlbG9hZEF1dG9jb21wbGV0ZURhdGEoKVxyXG4gICAgICAudGhlbigocmVzdWx0KSA9PiB7XHJcbiAgICAgICAgaWYocmVzdWx0LnN0YXR1cyA9PT0gJ3NjaGVkdWxlZCcpe1xyXG4gICAgICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZFdhcm5pbmcoJ0F1dG9jb21wbGV0ZSBkYXRhIGxvYWRpbmcgaXMgY3VycmVudGx5IGluIHByb2dyZXNzLicsIHtkaXNtaXNzYWJsZTogdHJ1ZX0pXHJcbiAgICAgICAgfSBlbHNlIGlmKHJlc3VsdC5zdGF0dXMgPT09ICdyZWxvYWRlZCcpe1xyXG4gICAgICAgICAgYXRvbS5ub3RpZmljYXRpb25zLmFkZFN1Y2Nlc3MoJ0RhdGEgcmVsb2FkZWQnKVxyXG4gICAgICAgIH0gZWxzZSBpZihyZXN1bHQuc3RhdHVzID09PSAnZXJyb3InKXtcclxuICAgICAgICAgIGF0b20ubm90aWZpY2F0aW9ucy5hZGRFcnJvcihcclxuICAgICAgICAgICAgYEVycm9yIG9jY3VycmVkIGR1cmluZyBkYXRhIHJlbG9hZGluZ2AsXHJcbiAgICAgICAgICAgIHtkZXRhaWw6IHJlc3VsdC5tZXNzYWdlLCBzdGFjazogcmVzdWx0LnN0YWNrLCBkaXNtaXNzYWJsZTogdHJ1ZX0pXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG4gICAgfSlcclxuICAgIGF0b20uY29tbWFuZHMuYWRkKCdhdG9tLXRleHQtZWRpdG9yJywgJ1JvYm90IEZyYW1ld29yazpTaG93IGF1dG9jb21wbGV0ZSBzdGF0dXMnLCAoKSA9PiB7XHJcbiAgICAgIGVkaXRvciA9IGF0b20ud29ya3NwYWNlLmdldEFjdGl2ZVRleHRFZGl0b3IoKVxyXG4gICAgICBpZihlZGl0b3Ipe1xyXG4gICAgICAgIHN0YXR1cy5yZW5kZXJTdGF0dXMoZWRpdG9yLmdldFBhdGgoKSwgdGhpcy5zZXR0aW5ncylcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9LFxyXG5cclxuICBwcmludERlYnVnSW5mbygpIHtcclxuICAgIGNvbnNvbGUubG9nKGBEZXRlY3RlZCByb2JvdCBwcm9qZWN0czogJHtKU09OLnN0cmluZ2lmeShwcm92aWRlci5yb2JvdFByb2plY3RQYXRocyl9YCk7XHJcbiAgICBrZXl3b3Jkc1JlcG8ucHJpbnREZWJ1Z0luZm8oe1xyXG4gICAgICBzaG93Um9ib3RGaWxlczogdHJ1ZSxcclxuICAgICAgc2hvd0xpYmRvY0ZpbGVzOiB0cnVlLFxyXG4gICAgICBzaG93QWxsU3VnZ2VzdGlvbnM6IHRydWVcclxuICAgIH0pO1xyXG4gICAgbGliTWFuYWdlci5wcmludERlYnVnSW5mbygpO1xyXG4gIH1cclxufTtcclxuXHJcbm1vZHVsZS5leHBvcnRzID0gcHJvdmlkZXJcclxuIl19