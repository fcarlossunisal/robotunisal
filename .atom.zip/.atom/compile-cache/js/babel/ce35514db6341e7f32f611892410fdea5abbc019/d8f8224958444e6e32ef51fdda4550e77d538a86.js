Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _profiles = require('./profiles');

var XTerminalOverwriteProfileModel = (function () {
	function XTerminalOverwriteProfileModel(atomXtermSaveProfileModel) {
		_classCallCheck(this, XTerminalOverwriteProfileModel);

		this.atomXtermSaveProfileModel = atomXtermSaveProfileModel;
		this.atomXtermProfileMenuElement = this.atomXtermSaveProfileModel.atomXtermProfileMenuElement;
		this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;
		this.element = null;
		this.panel = atom.workspace.addModalPanel({
			item: this,
			visible: false
		});
	}

	_createClass(XTerminalOverwriteProfileModel, [{
		key: 'getTitle',
		value: function getTitle() {
			return 'X Terminal Overwrite Profile Model';
		}
	}, {
		key: 'getElement',
		value: function getElement() {
			return this.element;
		}
	}, {
		key: 'setElement',
		value: function setElement(element) {
			this.element = element;
		}
	}, {
		key: 'close',
		value: function close(newProfile, profileChanges) {
			var rePrompt = arguments.length <= 2 || arguments[2] === undefined ? false : arguments[2];

			if (!this.panel.isVisible()) {
				return;
			}
			this.panel.hide();
			if (rePrompt) {
				this.atomXtermSaveProfileModel.promptForNewProfileName(newProfile, profileChanges);
			}
		}
	}, {
		key: 'promptOverwrite',
		value: function promptOverwrite(profileName, newProfile, profileChanges) {
			var _this = this;

			this.panel.show();
			var confirmHandler = _asyncToGenerator(function* (event) {
				yield _this.profilesSingleton.setProfile(profileName, newProfile);
				_this.profilesSingleton.reloadProfiles();
				yield _this.profilesSingleton.profilesLoadPromise;
				_this.close(newProfile, profileChanges);
				_this.atomXtermProfileMenuElement.applyProfileChanges(profileChanges);
			});
			var cancelHandler = function cancelHandler(event) {
				_this.close(newProfile, profileChanges, true);
			};
			this.getElement().setNewPrompt(profileName, confirmHandler, cancelHandler);
		}
	}]);

	return XTerminalOverwriteProfileModel;
})();

exports.XTerminalOverwriteProfileModel = XTerminalOverwriteProfileModel;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL292ZXJ3cml0ZS1wcm9maWxlLW1vZGVsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0JBcUIyQyxZQUFZOztJQUVqRCw4QkFBOEI7QUFDdkIsVUFEUCw4QkFBOEIsQ0FDdEIseUJBQXlCLEVBQUU7d0JBRG5DLDhCQUE4Qjs7QUFFbEMsTUFBSSxDQUFDLHlCQUF5QixHQUFHLHlCQUF5QixDQUFBO0FBQzFELE1BQUksQ0FBQywyQkFBMkIsR0FBRyxJQUFJLENBQUMseUJBQXlCLENBQUMsMkJBQTJCLENBQUE7QUFDN0YsTUFBSSxDQUFDLGlCQUFpQixHQUFHLHFDQUEyQixRQUFRLENBQUE7QUFDNUQsTUFBSSxDQUFDLE9BQU8sR0FBRyxJQUFJLENBQUE7QUFDbkIsTUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLGFBQWEsQ0FBQztBQUN6QyxPQUFJLEVBQUUsSUFBSTtBQUNWLFVBQU8sRUFBRSxLQUFLO0dBQ2QsQ0FBQyxDQUFBO0VBQ0Y7O2NBVkksOEJBQThCOztTQVkxQixvQkFBRztBQUNYLFVBQU8sb0NBQW9DLENBQUE7R0FDM0M7OztTQUVVLHNCQUFHO0FBQ2IsVUFBTyxJQUFJLENBQUMsT0FBTyxDQUFBO0dBQ25COzs7U0FFVSxvQkFBQyxPQUFPLEVBQUU7QUFDcEIsT0FBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUE7R0FDdEI7OztTQUVLLGVBQUMsVUFBVSxFQUFFLGNBQWMsRUFBb0I7T0FBbEIsUUFBUSx5REFBRyxLQUFLOztBQUNsRCxPQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLEVBQUUsRUFBRTtBQUM1QixXQUFNO0lBQ047QUFDRCxPQUFJLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxDQUFBO0FBQ2pCLE9BQUksUUFBUSxFQUFFO0FBQ2IsUUFBSSxDQUFDLHlCQUF5QixDQUFDLHVCQUF1QixDQUFDLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQTtJQUNsRjtHQUNEOzs7U0FFZSx5QkFBQyxXQUFXLEVBQUUsVUFBVSxFQUFFLGNBQWMsRUFBRTs7O0FBQ3pELE9BQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUE7QUFDakIsT0FBTSxjQUFjLHFCQUFHLFdBQU8sS0FBSyxFQUFLO0FBQ3ZDLFVBQU0sTUFBSyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsV0FBVyxFQUFFLFVBQVUsQ0FBQyxDQUFBO0FBQ2hFLFVBQUssaUJBQWlCLENBQUMsY0FBYyxFQUFFLENBQUE7QUFDdkMsVUFBTSxNQUFLLGlCQUFpQixDQUFDLG1CQUFtQixDQUFBO0FBQ2hELFVBQUssS0FBSyxDQUFDLFVBQVUsRUFBRSxjQUFjLENBQUMsQ0FBQTtBQUN0QyxVQUFLLDJCQUEyQixDQUFDLG1CQUFtQixDQUFDLGNBQWMsQ0FBQyxDQUFBO0lBQ3BFLENBQUEsQ0FBQTtBQUNELE9BQU0sYUFBYSxHQUFHLFNBQWhCLGFBQWEsQ0FBSSxLQUFLLEVBQUs7QUFDaEMsVUFBSyxLQUFLLENBQUMsVUFBVSxFQUFFLGNBQWMsRUFBRSxJQUFJLENBQUMsQ0FBQTtJQUM1QyxDQUFBO0FBQ0QsT0FBSSxDQUFDLFVBQVUsRUFBRSxDQUFDLFlBQVksQ0FDN0IsV0FBVyxFQUNYLGNBQWMsRUFDZCxhQUFhLENBQ2IsQ0FBQTtHQUNEOzs7UUFuREksOEJBQThCOzs7UUF1RG5DLDhCQUE4QixHQUE5Qiw4QkFBOEIiLCJmaWxlIjoiZmlsZTovLy9DOi9Vc2Vycy9GcmFuY2lzY28vLmF0b20vcGFja2FnZXMveC10ZXJtaW5hbC9zcmMvb3ZlcndyaXRlLXByb2ZpbGUtbW9kZWwuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvKiogQGJhYmVsICovXG4vKlxuICogQ29weXJpZ2h0IDIwMTcgQW1hem9uLmNvbSwgSW5jLiBvciBpdHMgYWZmaWxpYXRlcy4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAyMDE3LTIwMTggQW5kcmVzIE1lamlhIDxhbWVqaWEwMDRAZ21haWwuY29tPi4gQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBVemlUZWNoIEFsbCBSaWdodHMgUmVzZXJ2ZWQuXG4gKiBDb3B5cmlnaHQgKGMpIDIwMjAgYnVzLXN0b3AgQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqXG4gKiBQZXJtaXNzaW9uIGlzIGhlcmVieSBncmFudGVkLCBmcmVlIG9mIGNoYXJnZSwgdG8gYW55IHBlcnNvbiBvYnRhaW5pbmcgYSBjb3B5IG9mIHRoaXNcbiAqIHNvZnR3YXJlIGFuZCBhc3NvY2lhdGVkIGRvY3VtZW50YXRpb24gZmlsZXMgKHRoZSBcIlNvZnR3YXJlXCIpLCB0byBkZWFsIGluIHRoZSBTb2Z0d2FyZVxuICogd2l0aG91dCByZXN0cmljdGlvbiwgaW5jbHVkaW5nIHdpdGhvdXQgbGltaXRhdGlvbiB0aGUgcmlnaHRzIHRvIHVzZSwgY29weSwgbW9kaWZ5LFxuICogbWVyZ2UsIHB1Ymxpc2gsIGRpc3RyaWJ1dGUsIHN1YmxpY2Vuc2UsIGFuZC9vciBzZWxsIGNvcGllcyBvZiB0aGUgU29mdHdhcmUsIGFuZCB0b1xuICogcGVybWl0IHBlcnNvbnMgdG8gd2hvbSB0aGUgU29mdHdhcmUgaXMgZnVybmlzaGVkIHRvIGRvIHNvLlxuICpcbiAqIFRIRSBTT0ZUV0FSRSBJUyBQUk9WSURFRCBcIkFTIElTXCIsIFdJVEhPVVQgV0FSUkFOVFkgT0YgQU5ZIEtJTkQsIEVYUFJFU1MgT1IgSU1QTElFRCxcbiAqIElOQ0xVRElORyBCVVQgTk9UIExJTUlURUQgVE8gVEhFIFdBUlJBTlRJRVMgT0YgTUVSQ0hBTlRBQklMSVRZLCBGSVRORVNTIEZPUiBBXG4gKiBQQVJUSUNVTEFSIFBVUlBPU0UgQU5EIE5PTklORlJJTkdFTUVOVC4gSU4gTk8gRVZFTlQgU0hBTEwgVEhFIEFVVEhPUlMgT1IgQ09QWVJJR0hUXG4gKiBIT0xERVJTIEJFIExJQUJMRSBGT1IgQU5ZIENMQUlNLCBEQU1BR0VTIE9SIE9USEVSIExJQUJJTElUWSwgV0hFVEhFUiBJTiBBTiBBQ1RJT05cbiAqIE9GIENPTlRSQUNULCBUT1JUIE9SIE9USEVSV0lTRSwgQVJJU0lORyBGUk9NLCBPVVQgT0YgT1IgSU4gQ09OTkVDVElPTiBXSVRIIFRIRVxuICogU09GVFdBUkUgT1IgVEhFIFVTRSBPUiBPVEhFUiBERUFMSU5HUyBJTiBUSEUgU09GVFdBUkUuXG4gKi9cblxuaW1wb3J0IHsgWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24gfSBmcm9tICcuL3Byb2ZpbGVzJ1xuXG5jbGFzcyBYVGVybWluYWxPdmVyd3JpdGVQcm9maWxlTW9kZWwge1xuXHRjb25zdHJ1Y3RvciAoYXRvbVh0ZXJtU2F2ZVByb2ZpbGVNb2RlbCkge1xuXHRcdHRoaXMuYXRvbVh0ZXJtU2F2ZVByb2ZpbGVNb2RlbCA9IGF0b21YdGVybVNhdmVQcm9maWxlTW9kZWxcblx0XHR0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudCA9IHRoaXMuYXRvbVh0ZXJtU2F2ZVByb2ZpbGVNb2RlbC5hdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnRcblx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uID0gWFRlcm1pbmFsUHJvZmlsZXNTaW5nbGV0b24uaW5zdGFuY2Vcblx0XHR0aGlzLmVsZW1lbnQgPSBudWxsXG5cdFx0dGhpcy5wYW5lbCA9IGF0b20ud29ya3NwYWNlLmFkZE1vZGFsUGFuZWwoe1xuXHRcdFx0aXRlbTogdGhpcyxcblx0XHRcdHZpc2libGU6IGZhbHNlLFxuXHRcdH0pXG5cdH1cblxuXHRnZXRUaXRsZSAoKSB7XG5cdFx0cmV0dXJuICdYIFRlcm1pbmFsIE92ZXJ3cml0ZSBQcm9maWxlIE1vZGVsJ1xuXHR9XG5cblx0Z2V0RWxlbWVudCAoKSB7XG5cdFx0cmV0dXJuIHRoaXMuZWxlbWVudFxuXHR9XG5cblx0c2V0RWxlbWVudCAoZWxlbWVudCkge1xuXHRcdHRoaXMuZWxlbWVudCA9IGVsZW1lbnRcblx0fVxuXG5cdGNsb3NlIChuZXdQcm9maWxlLCBwcm9maWxlQ2hhbmdlcywgcmVQcm9tcHQgPSBmYWxzZSkge1xuXHRcdGlmICghdGhpcy5wYW5lbC5pc1Zpc2libGUoKSkge1xuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXHRcdHRoaXMucGFuZWwuaGlkZSgpXG5cdFx0aWYgKHJlUHJvbXB0KSB7XG5cdFx0XHR0aGlzLmF0b21YdGVybVNhdmVQcm9maWxlTW9kZWwucHJvbXB0Rm9yTmV3UHJvZmlsZU5hbWUobmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpXG5cdFx0fVxuXHR9XG5cblx0cHJvbXB0T3ZlcndyaXRlIChwcm9maWxlTmFtZSwgbmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMpIHtcblx0XHR0aGlzLnBhbmVsLnNob3coKVxuXHRcdGNvbnN0IGNvbmZpcm1IYW5kbGVyID0gYXN5bmMgKGV2ZW50KSA9PiB7XG5cdFx0XHRhd2FpdCB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLnNldFByb2ZpbGUocHJvZmlsZU5hbWUsIG5ld1Byb2ZpbGUpXG5cdFx0XHR0aGlzLnByb2ZpbGVzU2luZ2xldG9uLnJlbG9hZFByb2ZpbGVzKClcblx0XHRcdGF3YWl0IHRoaXMucHJvZmlsZXNTaW5nbGV0b24ucHJvZmlsZXNMb2FkUHJvbWlzZVxuXHRcdFx0dGhpcy5jbG9zZShuZXdQcm9maWxlLCBwcm9maWxlQ2hhbmdlcylcblx0XHRcdHRoaXMuYXRvbVh0ZXJtUHJvZmlsZU1lbnVFbGVtZW50LmFwcGx5UHJvZmlsZUNoYW5nZXMocHJvZmlsZUNoYW5nZXMpXG5cdFx0fVxuXHRcdGNvbnN0IGNhbmNlbEhhbmRsZXIgPSAoZXZlbnQpID0+IHtcblx0XHRcdHRoaXMuY2xvc2UobmV3UHJvZmlsZSwgcHJvZmlsZUNoYW5nZXMsIHRydWUpXG5cdFx0fVxuXHRcdHRoaXMuZ2V0RWxlbWVudCgpLnNldE5ld1Byb21wdChcblx0XHRcdHByb2ZpbGVOYW1lLFxuXHRcdFx0Y29uZmlybUhhbmRsZXIsXG5cdFx0XHRjYW5jZWxIYW5kbGVyLFxuXHRcdClcblx0fVxufVxuXG5leHBvcnQge1xuXHRYVGVybWluYWxPdmVyd3JpdGVQcm9maWxlTW9kZWwsXG59XG4iXX0=