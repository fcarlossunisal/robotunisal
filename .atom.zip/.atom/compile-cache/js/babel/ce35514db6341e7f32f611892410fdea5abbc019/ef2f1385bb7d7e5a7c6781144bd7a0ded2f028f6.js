Object.defineProperty(exports, '__esModule', {
	value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _asyncToGenerator(fn) { return function () { var gen = fn.apply(this, arguments); return new Promise(function (resolve, reject) { var callNext = step.bind(null, 'next'); var callThrow = step.bind(null, 'throw'); function step(key, arg) { try { var info = gen[key](arg); var value = info.value; } catch (error) { reject(error); return; } if (info.done) { resolve(value); } else { Promise.resolve(value).then(callNext, callThrow); } } callNext(); }); }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

/** @babel */
/*
 * Copyright 2017 Amazon.com, Inc. or its affiliates. All Rights Reserved.
 * Copyright 2017-2018 Andres Mejia <amejia004@gmail.com>. All Rights Reserved.
 * Copyright (c) 2020 UziTech All Rights Reserved.
 * Copyright (c) 2020 bus-stop All Rights Reserved.
 *
 * Permission is hereby granted, free of charge, to any person obtaining a copy of this
 * software and associated documentation files (the "Software"), to deal in the Software
 * without restriction, including without limitation the rights to use, copy, modify,
 * merge, publish, distribute, sublicense, and/or sell copies of the Software, and to
 * permit persons to whom the Software is furnished to do so.
 *
 * THE SOFTWARE IS PROVIDED "AS IS", WITHOUT WARRANTY OF ANY KIND, EXPRESS OR IMPLIED,
 * INCLUDING BUT NOT LIMITED TO THE WARRANTIES OF MERCHANTABILITY, FITNESS FOR A
 * PARTICULAR PURPOSE AND NONINFRINGEMENT. IN NO EVENT SHALL THE AUTHORS OR COPYRIGHT
 * HOLDERS BE LIABLE FOR ANY CLAIM, DAMAGES OR OTHER LIABILITY, WHETHER IN AN ACTION
 * OF CONTRACT, TORT OR OTHERWISE, ARISING FROM, OUT OF OR IN CONNECTION WITH THE
 * SOFTWARE OR THE USE OR OTHER DEALINGS IN THE SOFTWARE.
 */

var _profiles = require('./profiles');

var XTerminalDeleteProfileModel = (function () {
	function XTerminalDeleteProfileModel(atomXtermProfileMenuElement) {
		_classCallCheck(this, XTerminalDeleteProfileModel);

		this.atomXtermProfileMenuElement = atomXtermProfileMenuElement;
		this.profilesSingleton = _profiles.XTerminalProfilesSingleton.instance;
		this.element = null;
		this.panel = atom.workspace.addModalPanel({
			item: this,
			visible: false
		});
	}

	_createClass(XTerminalDeleteProfileModel, [{
		key: 'getTitle',
		value: function getTitle() {
			return 'X Terminal Delete Profile Model';
		}
	}, {
		key: 'getElement',
		value: function getElement() {
			return this.element;
		}
	}, {
		key: 'setElement',
		value: function setElement(element) {
			this.element = element;
		}
	}, {
		key: 'close',
		value: function close() {
			if (!this.panel.isVisible()) {
				return;
			}
			this.panel.hide();
		}
	}, {
		key: 'promptDelete',
		value: function promptDelete(profileName) {
			var _this = this;

			this.panel.show();
			var confirmHandler = _asyncToGenerator(function* (event) {
				yield _this.profilesSingleton.deleteProfile(profileName);
				_this.profilesSingleton.reloadProfiles();
				yield _this.profilesSingleton.profilesLoadPromise;
				_this.close();
			});
			var cancelHandler = function cancelHandler(event) {
				_this.close();
			};
			this.getElement().setNewPrompt(profileName, confirmHandler, cancelHandler);
		}
	}]);

	return XTerminalDeleteProfileModel;
})();

exports.XTerminalDeleteProfileModel = XTerminalDeleteProfileModel;
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL3gtdGVybWluYWwvc3JjL2RlbGV0ZS1wcm9maWxlLW1vZGVsLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7d0JBcUIyQyxZQUFZOztJQUVqRCwyQkFBMkI7QUFDcEIsVUFEUCwyQkFBMkIsQ0FDbkIsMkJBQTJCLEVBQUU7d0JBRHJDLDJCQUEyQjs7QUFFL0IsTUFBSSxDQUFDLDJCQUEyQixHQUFHLDJCQUEyQixDQUFBO0FBQzlELE1BQUksQ0FBQyxpQkFBaUIsR0FBRyxxQ0FBMkIsUUFBUSxDQUFBO0FBQzVELE1BQUksQ0FBQyxPQUFPLEdBQUcsSUFBSSxDQUFBO0FBQ25CLE1BQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxhQUFhLENBQUM7QUFDekMsT0FBSSxFQUFFLElBQUk7QUFDVixVQUFPLEVBQUUsS0FBSztHQUNkLENBQUMsQ0FBQTtFQUNGOztjQVRJLDJCQUEyQjs7U0FXdkIsb0JBQUc7QUFDWCxVQUFPLGlDQUFpQyxDQUFBO0dBQ3hDOzs7U0FFVSxzQkFBRztBQUNiLFVBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQTtHQUNuQjs7O1NBRVUsb0JBQUMsT0FBTyxFQUFFO0FBQ3BCLE9BQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFBO0dBQ3RCOzs7U0FFSyxpQkFBRztBQUNSLE9BQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsRUFBRSxFQUFFO0FBQzVCLFdBQU07SUFDTjtBQUNELE9BQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUE7R0FDakI7OztTQUVZLHNCQUFDLFdBQVcsRUFBRTs7O0FBQzFCLE9BQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLENBQUE7QUFDakIsT0FBTSxjQUFjLHFCQUFHLFdBQU8sS0FBSyxFQUFLO0FBQ3ZDLFVBQU0sTUFBSyxpQkFBaUIsQ0FBQyxhQUFhLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDdkQsVUFBSyxpQkFBaUIsQ0FBQyxjQUFjLEVBQUUsQ0FBQTtBQUN2QyxVQUFNLE1BQUssaUJBQWlCLENBQUMsbUJBQW1CLENBQUE7QUFDaEQsVUFBSyxLQUFLLEVBQUUsQ0FBQTtJQUNaLENBQUEsQ0FBQTtBQUNELE9BQU0sYUFBYSxHQUFHLFNBQWhCLGFBQWEsQ0FBSSxLQUFLLEVBQUs7QUFDaEMsVUFBSyxLQUFLLEVBQUUsQ0FBQTtJQUNaLENBQUE7QUFDRCxPQUFJLENBQUMsVUFBVSxFQUFFLENBQUMsWUFBWSxDQUM3QixXQUFXLEVBQ1gsY0FBYyxFQUNkLGFBQWEsQ0FDYixDQUFBO0dBQ0Q7OztRQTlDSSwyQkFBMkI7OztRQWtEaEMsMkJBQTJCLEdBQTNCLDJCQUEyQiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy94LXRlcm1pbmFsL3NyYy9kZWxldGUtcHJvZmlsZS1tb2RlbC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8qKiBAYmFiZWwgKi9cbi8qXG4gKiBDb3B5cmlnaHQgMjAxNyBBbWF6b24uY29tLCBJbmMuIG9yIGl0cyBhZmZpbGlhdGVzLiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IDIwMTctMjAxOCBBbmRyZXMgTWVqaWEgPGFtZWppYTAwNEBnbWFpbC5jb20+LiBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICogQ29weXJpZ2h0IChjKSAyMDIwIFV6aVRlY2ggQWxsIFJpZ2h0cyBSZXNlcnZlZC5cbiAqIENvcHlyaWdodCAoYykgMjAyMCBidXMtc3RvcCBBbGwgUmlnaHRzIFJlc2VydmVkLlxuICpcbiAqIFBlcm1pc3Npb24gaXMgaGVyZWJ5IGdyYW50ZWQsIGZyZWUgb2YgY2hhcmdlLCB0byBhbnkgcGVyc29uIG9idGFpbmluZyBhIGNvcHkgb2YgdGhpc1xuICogc29mdHdhcmUgYW5kIGFzc29jaWF0ZWQgZG9jdW1lbnRhdGlvbiBmaWxlcyAodGhlIFwiU29mdHdhcmVcIiksIHRvIGRlYWwgaW4gdGhlIFNvZnR3YXJlXG4gKiB3aXRob3V0IHJlc3RyaWN0aW9uLCBpbmNsdWRpbmcgd2l0aG91dCBsaW1pdGF0aW9uIHRoZSByaWdodHMgdG8gdXNlLCBjb3B5LCBtb2RpZnksXG4gKiBtZXJnZSwgcHVibGlzaCwgZGlzdHJpYnV0ZSwgc3VibGljZW5zZSwgYW5kL29yIHNlbGwgY29waWVzIG9mIHRoZSBTb2Z0d2FyZSwgYW5kIHRvXG4gKiBwZXJtaXQgcGVyc29ucyB0byB3aG9tIHRoZSBTb2Z0d2FyZSBpcyBmdXJuaXNoZWQgdG8gZG8gc28uXG4gKlxuICogVEhFIFNPRlRXQVJFIElTIFBST1ZJREVEIFwiQVMgSVNcIiwgV0lUSE9VVCBXQVJSQU5UWSBPRiBBTlkgS0lORCwgRVhQUkVTUyBPUiBJTVBMSUVELFxuICogSU5DTFVESU5HIEJVVCBOT1QgTElNSVRFRCBUTyBUSEUgV0FSUkFOVElFUyBPRiBNRVJDSEFOVEFCSUxJVFksIEZJVE5FU1MgRk9SIEFcbiAqIFBBUlRJQ1VMQVIgUFVSUE9TRSBBTkQgTk9OSU5GUklOR0VNRU5ULiBJTiBOTyBFVkVOVCBTSEFMTCBUSEUgQVVUSE9SUyBPUiBDT1BZUklHSFRcbiAqIEhPTERFUlMgQkUgTElBQkxFIEZPUiBBTlkgQ0xBSU0sIERBTUFHRVMgT1IgT1RIRVIgTElBQklMSVRZLCBXSEVUSEVSIElOIEFOIEFDVElPTlxuICogT0YgQ09OVFJBQ1QsIFRPUlQgT1IgT1RIRVJXSVNFLCBBUklTSU5HIEZST00sIE9VVCBPRiBPUiBJTiBDT05ORUNUSU9OIFdJVEggVEhFXG4gKiBTT0ZUV0FSRSBPUiBUSEUgVVNFIE9SIE9USEVSIERFQUxJTkdTIElOIFRIRSBTT0ZUV0FSRS5cbiAqL1xuXG5pbXBvcnQgeyBYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbiB9IGZyb20gJy4vcHJvZmlsZXMnXG5cbmNsYXNzIFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVNb2RlbCB7XG5cdGNvbnN0cnVjdG9yIChhdG9tWHRlcm1Qcm9maWxlTWVudUVsZW1lbnQpIHtcblx0XHR0aGlzLmF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudCA9IGF0b21YdGVybVByb2ZpbGVNZW51RWxlbWVudFxuXHRcdHRoaXMucHJvZmlsZXNTaW5nbGV0b24gPSBYVGVybWluYWxQcm9maWxlc1NpbmdsZXRvbi5pbnN0YW5jZVxuXHRcdHRoaXMuZWxlbWVudCA9IG51bGxcblx0XHR0aGlzLnBhbmVsID0gYXRvbS53b3Jrc3BhY2UuYWRkTW9kYWxQYW5lbCh7XG5cdFx0XHRpdGVtOiB0aGlzLFxuXHRcdFx0dmlzaWJsZTogZmFsc2UsXG5cdFx0fSlcblx0fVxuXG5cdGdldFRpdGxlICgpIHtcblx0XHRyZXR1cm4gJ1ggVGVybWluYWwgRGVsZXRlIFByb2ZpbGUgTW9kZWwnXG5cdH1cblxuXHRnZXRFbGVtZW50ICgpIHtcblx0XHRyZXR1cm4gdGhpcy5lbGVtZW50XG5cdH1cblxuXHRzZXRFbGVtZW50IChlbGVtZW50KSB7XG5cdFx0dGhpcy5lbGVtZW50ID0gZWxlbWVudFxuXHR9XG5cblx0Y2xvc2UgKCkge1xuXHRcdGlmICghdGhpcy5wYW5lbC5pc1Zpc2libGUoKSkge1xuXHRcdFx0cmV0dXJuXG5cdFx0fVxuXHRcdHRoaXMucGFuZWwuaGlkZSgpXG5cdH1cblxuXHRwcm9tcHREZWxldGUgKHByb2ZpbGVOYW1lKSB7XG5cdFx0dGhpcy5wYW5lbC5zaG93KClcblx0XHRjb25zdCBjb25maXJtSGFuZGxlciA9IGFzeW5jIChldmVudCkgPT4ge1xuXHRcdFx0YXdhaXQgdGhpcy5wcm9maWxlc1NpbmdsZXRvbi5kZWxldGVQcm9maWxlKHByb2ZpbGVOYW1lKVxuXHRcdFx0dGhpcy5wcm9maWxlc1NpbmdsZXRvbi5yZWxvYWRQcm9maWxlcygpXG5cdFx0XHRhd2FpdCB0aGlzLnByb2ZpbGVzU2luZ2xldG9uLnByb2ZpbGVzTG9hZFByb21pc2Vcblx0XHRcdHRoaXMuY2xvc2UoKVxuXHRcdH1cblx0XHRjb25zdCBjYW5jZWxIYW5kbGVyID0gKGV2ZW50KSA9PiB7XG5cdFx0XHR0aGlzLmNsb3NlKClcblx0XHR9XG5cdFx0dGhpcy5nZXRFbGVtZW50KCkuc2V0TmV3UHJvbXB0KFxuXHRcdFx0cHJvZmlsZU5hbWUsXG5cdFx0XHRjb25maXJtSGFuZGxlcixcblx0XHRcdGNhbmNlbEhhbmRsZXIsXG5cdFx0KVxuXHR9XG59XG5cbmV4cG9ydCB7XG5cdFhUZXJtaW5hbERlbGV0ZVByb2ZpbGVNb2RlbCxcbn1cbiJdfQ==