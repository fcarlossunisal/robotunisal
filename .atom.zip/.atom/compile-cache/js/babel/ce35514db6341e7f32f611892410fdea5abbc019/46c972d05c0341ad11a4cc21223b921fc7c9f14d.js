Object.defineProperty(exports, '__esModule', {
  value: true
});
exports.resolve = resolve;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

/**
 * Returns resource or library path based on import path. If not found returns undefined.
 * Always returns normalized paths.
 * importPath - Library/Resource import path
 * currentDir - path of the file containing the impot
 */
'use babel';

function resolve(importPath, currentDir) {
  if (isPathComputed(importPath)) {
    return undefined;
  }
  if (_path2['default'].isAbsolute(importPath)) {
    return isFile(importPath) ? _path2['default'].normalize(importPath) : undefined;
  }

  // relative uncomputed path
  var absolutePath = _path2['default'].join(currentDir, importPath);
  return isFile(absolutePath) ? _path2['default'].normalize(absolutePath) : undefined;
}

/**
 * Returns true if path is computed from variables.
 */
function isPathComputed(path) {
  return path.search(/\$\{.*?\}/) != -1;
}

function isFile(path) {
  if (_fs2['default'].existsSync(path)) {
    return _fs2['default'].statSync(path).isFile();
  }
  return false;
}
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2F1dG9jb21wbGV0ZS1yb2JvdC1mcmFtZXdvcmsvbGliL3BhdGgtcmVzb2x2ZXIuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7OztvQkFDc0IsTUFBTTs7OztrQkFDYixJQUFJOzs7Ozs7Ozs7O0FBRm5CLFdBQVcsQ0FBQTs7QUFVSixTQUFTLE9BQU8sQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFDO0FBQzdDLE1BQUcsY0FBYyxDQUFDLFVBQVUsQ0FBQyxFQUFDO0FBQzVCLFdBQU8sU0FBUyxDQUFBO0dBQ2pCO0FBQ0QsTUFBRyxrQkFBVSxVQUFVLENBQUMsVUFBVSxDQUFDLEVBQUM7QUFDbEMsV0FBTyxNQUFNLENBQUMsVUFBVSxDQUFDLEdBQUMsa0JBQVUsU0FBUyxDQUFDLFVBQVUsQ0FBQyxHQUFDLFNBQVMsQ0FBQTtHQUNwRTs7O0FBR0QsTUFBTSxZQUFZLEdBQUcsa0JBQVUsSUFBSSxDQUFDLFVBQVUsRUFBRSxVQUFVLENBQUMsQ0FBQTtBQUMzRCxTQUFPLE1BQU0sQ0FBQyxZQUFZLENBQUMsR0FBQyxrQkFBVSxTQUFTLENBQUMsWUFBWSxDQUFDLEdBQUMsU0FBUyxDQUFBO0NBQ3hFOzs7OztBQUtELFNBQVMsY0FBYyxDQUFDLElBQUksRUFBQztBQUN6QixTQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUFDLElBQUUsQ0FBQyxDQUFDLENBQUE7Q0FDdEM7O0FBRUQsU0FBUyxNQUFNLENBQUMsSUFBSSxFQUFDO0FBQ25CLE1BQUcsZ0JBQUcsVUFBVSxDQUFDLElBQUksQ0FBQyxFQUFDO0FBQ3JCLFdBQU8sZ0JBQUcsUUFBUSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFBO0dBQ2xDO0FBQ0QsU0FBTyxLQUFLLENBQUE7Q0FDYiIsImZpbGUiOiJmaWxlOi8vL0M6L1VzZXJzL0ZyYW5jaXNjby8uYXRvbS9wYWNrYWdlcy9hdXRvY29tcGxldGUtcm9ib3QtZnJhbWV3b3JrL2xpYi9wYXRoLXJlc29sdmVyLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCdcbmltcG9ydCBwYXRoVXRpbHMgZnJvbSAncGF0aCdcbmltcG9ydCBmcyBmcm9tICdmcydcblxuLyoqXG4gKiBSZXR1cm5zIHJlc291cmNlIG9yIGxpYnJhcnkgcGF0aCBiYXNlZCBvbiBpbXBvcnQgcGF0aC4gSWYgbm90IGZvdW5kIHJldHVybnMgdW5kZWZpbmVkLlxuICogQWx3YXlzIHJldHVybnMgbm9ybWFsaXplZCBwYXRocy5cbiAqIGltcG9ydFBhdGggLSBMaWJyYXJ5L1Jlc291cmNlIGltcG9ydCBwYXRoXG4gKiBjdXJyZW50RGlyIC0gcGF0aCBvZiB0aGUgZmlsZSBjb250YWluaW5nIHRoZSBpbXBvdFxuICovXG5leHBvcnQgZnVuY3Rpb24gcmVzb2x2ZShpbXBvcnRQYXRoLCBjdXJyZW50RGlyKXtcbiAgaWYoaXNQYXRoQ29tcHV0ZWQoaW1wb3J0UGF0aCkpe1xuICAgIHJldHVybiB1bmRlZmluZWRcbiAgfVxuICBpZihwYXRoVXRpbHMuaXNBYnNvbHV0ZShpbXBvcnRQYXRoKSl7XG4gICAgcmV0dXJuIGlzRmlsZShpbXBvcnRQYXRoKT9wYXRoVXRpbHMubm9ybWFsaXplKGltcG9ydFBhdGgpOnVuZGVmaW5lZFxuICB9XG5cbiAgLy8gcmVsYXRpdmUgdW5jb21wdXRlZCBwYXRoXG4gIGNvbnN0IGFic29sdXRlUGF0aCA9IHBhdGhVdGlscy5qb2luKGN1cnJlbnREaXIsIGltcG9ydFBhdGgpXG4gIHJldHVybiBpc0ZpbGUoYWJzb2x1dGVQYXRoKT9wYXRoVXRpbHMubm9ybWFsaXplKGFic29sdXRlUGF0aCk6dW5kZWZpbmVkXG59XG5cbi8qKlxuICogUmV0dXJucyB0cnVlIGlmIHBhdGggaXMgY29tcHV0ZWQgZnJvbSB2YXJpYWJsZXMuXG4gKi9cbmZ1bmN0aW9uIGlzUGF0aENvbXB1dGVkKHBhdGgpe1xuICAgIHJldHVybiBwYXRoLnNlYXJjaCgvXFwkXFx7Lio/XFx9LykhPS0xXG59XG5cbmZ1bmN0aW9uIGlzRmlsZShwYXRoKXtcbiAgaWYoZnMuZXhpc3RzU3luYyhwYXRoKSl7XG4gICAgcmV0dXJuIGZzLnN0YXRTeW5jKHBhdGgpLmlzRmlsZSgpXG4gIH1cbiAgcmV0dXJuIGZhbHNlXG59XG4iXX0=