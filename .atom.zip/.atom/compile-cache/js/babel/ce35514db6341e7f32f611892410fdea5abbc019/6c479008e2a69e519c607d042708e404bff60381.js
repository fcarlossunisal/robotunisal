Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

var _atom = require('atom');

var _path = require('path');

var _path2 = _interopRequireDefault(_path);

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _common = require('./common');

var _common2 = _interopRequireDefault(_common);

// Matches something like 'BuiltIn.Should be equal'
'use babel';
var KEYWORD_REGEXP = /((.*)\.)?(.*)/;
var bddPrefixRegex = /^(given|when|then|and|but) /i;

function findKeywordAtPosition(line, column) {
  var cells = _common2['default'].splitCells(line);

  // Take care of bdd prefix
  if (cells.length > 0) {
    var firstCell = cells[0]; // only first cell can include bdd prefix
    var bddMatch = bddPrefixRegex.exec(firstCell);
    if (bddMatch) {
      cells.push(firstCell.substring(bddMatch[0].length, firstCell.length));
    }
  }
  var keywords = [];
  for (var cell of Array.from(cells)) {
    var startCol = line.indexOf(cell);
    var endCol = startCol + cell.length;
    if (column > startCol && column < endCol) {
      var match = KEYWORD_REGEXP.exec(cell);
      if (match) {
        var prefix = match[2];
        var keywordName = match[3];
        keywords.push({
          startCol: startCol,
          endCol: endCol,
          prefix: prefix,
          keywordName: keywordName
        });
      }
    }
  }
  return keywords;
};

// Finds keyword within specified python library.
// Returns Result: {line: num, column: num, path: ''} if found, otherwise undefined.
function getPythonLocation(keywordName, libraryPath) {
  var pythonContent = _fs2['default'].readFileSync(libraryPath).toString();
  var pyInfo = { found: false, line: undefined, column: undefined };
  var lineNo = 0;
  for (var line of pythonContent.split('\n')) {
    var pyKeywordName = keywordName.split(' ').join('_');
    var regexp = new RegExp('^[ \\t]*def[ \\t]+' + pyKeywordName + '[ \\t]*\\(', 'i');
    if (regexp.test(line)) {
      pyInfo.found = true;
      pyInfo.line = lineNo;
      pyInfo.column = 0;
      break;
    }
    lineNo++;
  }
  if (pyInfo.found) {
    return {
      path: libraryPath,
      line: pyInfo.line,
      column: pyInfo.column
    };
  } else {
    return undefined;
  }
}

// Returns location of the keyword.
// Result: {line: num, column: num, path: ''}
function getKeywordLocation(keyword, autocompleteRobotProvider) {
  var resource = undefined;
  if (keyword.resourceKey) {
    resource = autocompleteRobotProvider.getResourceByKey(keyword.resourceKey);
  } else {
    resource = keyword.resource; // Deprecated
  }
  var isPythonLibrary = resource.isLibrary && resource.libraryPath && resource.libraryPath.toLowerCase().endsWith('.py');
  var location = undefined;
  if (isPythonLibrary) {
    location = getPythonLocation(keyword.name, resource.libraryPath);
  }
  return location || {
    path: resource.path,
    line: keyword.startRowNo,
    column: keyword.startColNo
  };
}

function getKeywordFromImports(keywordInfo, imports, autocompleteRobotProvider) {
  var keywordName = keywordInfo.keywordName;
  var prefix = keywordInfo.prefix;
  var importedKeywords = [];
  for (var importedLibrary of [].concat(_toConsumableArray(imports.libraries), [{ name: 'BuiltIn' }])) {
    importedLibrary = autocompleteRobotProvider.getResourceByKey(importedLibrary.name.toLowerCase());
    if (!importedLibrary) {
      continue;
    }
    if (prefix && importedLibrary.name !== prefix) {
      continue;
    }
    for (var importedKeyword of importedLibrary.keywords) {
      if (importedKeyword.name === keywordName) {
        importedKeywords.push(importedKeyword);
        break;
      }
    }
  }
  var matchingImportedResources = new Set();
  for (var importedResource of imports.resources) {
    if (importedResource.resourceKey) {
      // accurate import
      var resource = autocompleteRobotProvider.getResourceByKey(importedResource.resourceKey);
      if (resource) {
        matchingImportedResources.add(resource);
      }
    } else {
      // approximate import
      var resourceKeys = autocompleteRobotProvider.getResourceKeys();
      for (var resourceKey of resourceKeys) {
        var resource = autocompleteRobotProvider.getResourceByKey(resourceKey);
        if (resource && resource.name === importedResource.name) {
          matchingImportedResources.add(resource);
        }
      }
    }
  }
  for (var importedResource of matchingImportedResources) {
    if (prefix && importedResource.name !== prefix) {
      continue;
    }
    for (var importedKeyword of importedResource.keywords) {
      if (importedKeyword.name === keywordName) {
        importedKeywords.push(importedKeyword);
        break;
      }
    }
  }

  return importedKeywords;
}

exports['default'] = {
  getKeywordSuggestions: function getKeywordSuggestions(textEditor, point, autocompleteRobotProvider) {
    // get list of matching keywords at cursor
    var line = textEditor.lineTextForBufferRow(point.row);
    var keywordInfoItems = findKeywordAtPosition(line, point.column);
    if (keywordInfoItems.length == 0) {
      return undefined;
    }

    var highlightedKeywords = [];
    // use imports to resolve highlighted keyword
    var activeResource = _common2['default'].getCurrentResource(textEditor.getPath(), autocompleteRobotProvider);
    if (activeResource) {
      for (keywordInfo of keywordInfoItems) {
        highlightedKeywords = highlightedKeywords.concat(getKeywordFromImports(keywordInfo, activeResource.imports, autocompleteRobotProvider));
      }
    }

    // disregard imports; search in all available keywords
    if (highlightedKeywords.length === 0) {
      for (keywordInfo of keywordInfoItems) {
        highlightedKeywords = highlightedKeywords.concat(autocompleteRobotProvider.getKeywordsByName(keywordInfo.keywordName));
      }
    }

    if (highlightedKeywords.length === 0) {
      return undefined;
    }

    // build hyperclick callback
    var callback = undefined;
    if (highlightedKeywords.length === 1) {
      (function () {
        var keyword = highlightedKeywords[0];
        callback = function () {
          var kloc = getKeywordLocation(keyword, autocompleteRobotProvider);
          atom.workspace.open(kloc.path, { initialLine: kloc.line, initialColumn: kloc.column }).then(function (editor) {
            return editor.scrollToCursorPosition({ center: true });
          })['catch'](function (error) {
            return console.log('Error opening editor: ' + error);
          });
        };
      })();
    } else {
      callback = [];

      var _loop = function (keyword) {
        var kloc = getKeywordLocation(keyword, autocompleteRobotProvider);
        callback.push({
          title: kloc.path,
          callback: function callback() {
            atom.workspace.open(kloc.path, { initialLine: kloc.line, initialColumn: kloc.column }).then(function (editor) {
              return editor.scrollToCursorPosition({ center: true });
            })['catch'](function (error) {
              return console.log('Error opening editor: ' + error);
            });
          }
        });
      };

      for (var keyword of Array.from(highlightedKeywords)) {
        _loop(keyword);
      }
    }

    return {
      range: new _atom.Range(new _atom.Point(point.row, keywordInfoItems[0].startCol), new _atom.Point(point.row, keywordInfoItems[0].endCol)),
      callback: callback
    };
  }
};
module.exports = exports['default'];
//# sourceMappingURL=data:application/json;charset=utf-8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2h5cGVyY2xpY2stcm9ib3QtZnJhbWV3b3JrL2xpYi9oeXBlcmNsaWNrLWtleXdvcmRzLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O29CQUM2QixNQUFNOztvQkFDYixNQUFNOzs7O2tCQUNiLElBQUk7Ozs7c0JBQ0EsVUFBVTs7Ozs7QUFKN0IsV0FBVyxDQUFBO0FBT1gsSUFBTSxjQUFjLEdBQUcsZUFBZSxDQUFBO0FBQ3RDLElBQU0sY0FBYyxHQUFHLDhCQUE4QixDQUFBOztBQUVyRCxTQUFTLHFCQUFxQixDQUFDLElBQUksRUFBRSxNQUFNLEVBQUU7QUFDM0MsTUFBSSxLQUFLLEdBQUcsb0JBQU8sVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDOzs7QUFHcEMsTUFBRyxLQUFLLENBQUMsTUFBTSxHQUFDLENBQUMsRUFBRTtBQUNqQixRQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDMUIsUUFBTSxRQUFRLEdBQUcsY0FBYyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQTtBQUMvQyxRQUFHLFFBQVEsRUFBRTtBQUNYLFdBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsTUFBTSxFQUFFLFNBQVMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFBO0tBQ3RFO0dBQ0Y7QUFDRCxNQUFNLFFBQVEsR0FBRyxFQUFFLENBQUE7QUFDbkIsT0FBSyxJQUFJLElBQUksSUFBSSxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFO0FBQ2xDLFFBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsUUFBSSxNQUFNLEdBQUcsUUFBUSxHQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDbEMsUUFBSSxBQUFDLE1BQU0sR0FBQyxRQUFRLElBQU0sTUFBTSxHQUFDLE1BQU0sQUFBQyxFQUFFO0FBQ3hDLFVBQU0sS0FBSyxHQUFHLGNBQWMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUE7QUFDdkMsVUFBRyxLQUFLLEVBQUM7QUFDUCxZQUFNLE1BQU0sR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7QUFDdkIsWUFBTSxXQUFXLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFBO0FBQzVCLGdCQUFRLENBQUMsSUFBSSxDQUFDO0FBQ1osa0JBQVEsRUFBUixRQUFRO0FBQ1IsZ0JBQU0sRUFBTixNQUFNO0FBQ04sZ0JBQU0sRUFBTixNQUFNO0FBQ04scUJBQVcsRUFBWCxXQUFXO1NBQ1osQ0FBQyxDQUFBO09BQ0g7S0FDRjtHQUNGO0FBQ0QsU0FBTyxRQUFRLENBQUE7Q0FDaEIsQ0FBQzs7OztBQUlGLFNBQVMsaUJBQWlCLENBQUMsV0FBVyxFQUFFLFdBQVcsRUFBQztBQUNsRCxNQUFNLGFBQWEsR0FBRyxnQkFBRyxZQUFZLENBQUMsV0FBVyxDQUFDLENBQUMsUUFBUSxFQUFFLENBQUE7QUFDN0QsTUFBSSxNQUFNLEdBQUcsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFNBQVMsRUFBQyxDQUFBO0FBQy9ELE1BQUksTUFBTSxHQUFHLENBQUMsQ0FBQztBQUNmLE9BQUksSUFBTSxJQUFJLElBQUksYUFBYSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQztBQUMxQyxRQUFNLGFBQWEsR0FBRyxXQUFXLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtBQUN0RCxRQUFNLE1BQU0sR0FBRyxJQUFJLE1BQU0sd0JBQXNCLGFBQWEsaUJBQWMsR0FBRyxDQUFDLENBQUE7QUFDOUUsUUFBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxFQUFDO0FBQ25CLFlBQU0sQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFBO0FBQ25CLFlBQU0sQ0FBQyxJQUFJLEdBQUcsTUFBTSxDQUFBO0FBQ3BCLFlBQU0sQ0FBQyxNQUFNLEdBQUcsQ0FBQyxDQUFBO0FBQ2pCLFlBQUs7S0FDTjtBQUNELFVBQU0sRUFBRSxDQUFBO0dBQ1Q7QUFDRCxNQUFHLE1BQU0sQ0FBQyxLQUFLLEVBQUU7QUFDZixXQUFPO0FBQ0wsVUFBSSxFQUFFLFdBQVc7QUFDakIsVUFBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQ2pCLFlBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtLQUN0QixDQUFBO0dBQ0YsTUFBTTtBQUNMLFdBQU8sU0FBUyxDQUFBO0dBQ2pCO0NBQ0Y7Ozs7QUFJRCxTQUFTLGtCQUFrQixDQUFDLE9BQU8sRUFBRSx5QkFBeUIsRUFBQztBQUM3RCxNQUFJLFFBQVEsWUFBQSxDQUFBO0FBQ1osTUFBRyxPQUFPLENBQUMsV0FBVyxFQUFDO0FBQ3JCLFlBQVEsR0FBRyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQyxPQUFPLENBQUMsV0FBVyxDQUFDLENBQUE7R0FDM0UsTUFBSztBQUNKLFlBQVEsR0FBRyxPQUFPLENBQUMsUUFBUSxDQUFBO0dBQzVCO0FBQ0QsTUFBTSxlQUFlLEdBQUcsUUFBUSxDQUFDLFNBQVMsSUFDckMsUUFBUSxDQUFDLFdBQVcsSUFDcEIsUUFBUSxDQUFDLFdBQVcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUE7QUFDdkQsTUFBSSxRQUFRLEdBQUcsU0FBUyxDQUFBO0FBQ3hCLE1BQUcsZUFBZSxFQUFDO0FBQ2pCLFlBQVEsR0FBRyxpQkFBaUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxFQUFFLFFBQVEsQ0FBQyxXQUFXLENBQUMsQ0FBQTtHQUNqRTtBQUNELFNBQU8sUUFBUSxJQUFJO0FBQ2pCLFFBQUksRUFBRSxRQUFRLENBQUMsSUFBSTtBQUNuQixRQUFJLEVBQUUsT0FBTyxDQUFDLFVBQVU7QUFDeEIsVUFBTSxFQUFFLE9BQU8sQ0FBQyxVQUFVO0dBQzNCLENBQUE7Q0FDRjs7QUFFRCxTQUFTLHFCQUFxQixDQUFDLFdBQVcsRUFBRSxPQUFPLEVBQUUseUJBQXlCLEVBQUM7QUFDN0UsTUFBTSxXQUFXLEdBQUcsV0FBVyxDQUFDLFdBQVcsQ0FBQTtBQUMzQyxNQUFNLE1BQU0sR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFBO0FBQ2pDLE1BQU0sZ0JBQWdCLEdBQUcsRUFBRSxDQUFBO0FBQzNCLE9BQUksSUFBSSxlQUFlLGlDQUFRLE9BQU8sQ0FBQyxTQUFTLElBQUUsRUFBQyxJQUFJLEVBQUMsU0FBUyxFQUFDLElBQUU7QUFDbEUsbUJBQWUsR0FBRyx5QkFBeUIsQ0FBQyxnQkFBZ0IsQ0FBQyxlQUFlLENBQUMsSUFBSSxDQUFDLFdBQVcsRUFBRSxDQUFDLENBQUE7QUFDaEcsUUFBRyxDQUFDLGVBQWUsRUFBQztBQUNsQixlQUFRO0tBQ1Q7QUFDRCxRQUFHLE1BQU0sSUFBSSxlQUFlLENBQUMsSUFBSSxLQUFHLE1BQU0sRUFBRTtBQUMxQyxlQUFRO0tBQ1Q7QUFDRCxTQUFJLElBQU0sZUFBZSxJQUFJLGVBQWUsQ0FBQyxRQUFRLEVBQUM7QUFDcEQsVUFBRyxlQUFlLENBQUMsSUFBSSxLQUFHLFdBQVcsRUFBQztBQUNwQyx3QkFBZ0IsQ0FBQyxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUE7QUFDdEMsY0FBSztPQUNOO0tBQ0Y7R0FDRjtBQUNELE1BQU0seUJBQXlCLEdBQUcsSUFBSSxHQUFHLEVBQUUsQ0FBQTtBQUMzQyxPQUFJLElBQUksZ0JBQWdCLElBQUksT0FBTyxDQUFDLFNBQVMsRUFBQztBQUM1QyxRQUFHLGdCQUFnQixDQUFDLFdBQVcsRUFBQzs7QUFFOUIsVUFBTSxRQUFRLEdBQUcseUJBQXlCLENBQUMsZ0JBQWdCLENBQUMsZ0JBQWdCLENBQUMsV0FBVyxDQUFDLENBQUE7QUFDekYsVUFBRyxRQUFRLEVBQUM7QUFDVixpQ0FBeUIsQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLENBQUE7T0FDeEM7S0FDRixNQUFLOztBQUVKLFVBQU0sWUFBWSxHQUFHLHlCQUF5QixDQUFDLGVBQWUsRUFBRSxDQUFBO0FBQ2hFLFdBQUksSUFBTSxXQUFXLElBQUksWUFBWSxFQUFDO0FBQ3BDLFlBQU0sUUFBUSxHQUFHLHlCQUF5QixDQUFDLGdCQUFnQixDQUFDLFdBQVcsQ0FBQyxDQUFBO0FBQ3hFLFlBQUcsUUFBUSxJQUFJLFFBQVEsQ0FBQyxJQUFJLEtBQUssZ0JBQWdCLENBQUMsSUFBSSxFQUFDO0FBQ3JELG1DQUF5QixDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtTQUN4QztPQUNGO0tBQ0Y7R0FDRjtBQUNELE9BQUksSUFBTSxnQkFBZ0IsSUFBSSx5QkFBeUIsRUFBQztBQUNwRCxRQUFHLE1BQU0sSUFBSSxnQkFBZ0IsQ0FBQyxJQUFJLEtBQUcsTUFBTSxFQUFFO0FBQzNDLGVBQVE7S0FDVDtBQUNELFNBQUksSUFBTSxlQUFlLElBQUksZ0JBQWdCLENBQUMsUUFBUSxFQUFDO0FBQ3JELFVBQUcsZUFBZSxDQUFDLElBQUksS0FBRyxXQUFXLEVBQUM7QUFDcEMsd0JBQWdCLENBQUMsSUFBSSxDQUFDLGVBQWUsQ0FBQyxDQUFBO0FBQ3RDLGNBQUs7T0FDTjtLQUNGO0dBQ0o7O0FBRUQsU0FBTyxnQkFBZ0IsQ0FBQTtDQUN4Qjs7cUJBRWM7QUFDYix1QkFBcUIsRUFBQSwrQkFBQyxVQUFVLEVBQUUsS0FBSyxFQUFFLHlCQUF5QixFQUFDOztBQUVqRSxRQUFNLElBQUksR0FBRyxVQUFVLENBQUMsb0JBQW9CLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3hELFFBQU0sZ0JBQWdCLEdBQUcscUJBQXFCLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUNuRSxRQUFJLGdCQUFnQixDQUFDLE1BQU0sSUFBSSxDQUFDLEVBQUU7QUFDaEMsYUFBTyxTQUFTLENBQUM7S0FDbEI7O0FBRUQsUUFBSSxtQkFBbUIsR0FBRyxFQUFFLENBQUE7O0FBRTVCLFFBQU0sY0FBYyxHQUFHLG9CQUFPLGtCQUFrQixDQUFDLFVBQVUsQ0FBQyxPQUFPLEVBQUUsRUFBRSx5QkFBeUIsQ0FBQyxDQUFBO0FBQ2pHLFFBQUcsY0FBYyxFQUFFO0FBQ2pCLFdBQUksV0FBVyxJQUFJLGdCQUFnQixFQUFFO0FBQ25DLDJCQUFtQixHQUFHLG1CQUFtQixDQUFDLE1BQU0sQ0FDNUMscUJBQXFCLENBQUMsV0FBVyxFQUFFLGNBQWMsQ0FBQyxPQUFPLEVBQUUseUJBQXlCLENBQUMsQ0FBQyxDQUFBO09BQzNGO0tBQ0Y7OztBQUdELFFBQUcsbUJBQW1CLENBQUMsTUFBTSxLQUFHLENBQUMsRUFBQztBQUNoQyxXQUFJLFdBQVcsSUFBSSxnQkFBZ0IsRUFBRTtBQUNuQywyQkFBbUIsR0FBRyxtQkFBbUIsQ0FBQyxNQUFNLENBQUMseUJBQXlCLENBQUMsaUJBQWlCLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxDQUFDLENBQUE7T0FDdkg7S0FDRjs7QUFFRCxRQUFJLG1CQUFtQixDQUFDLE1BQU0sS0FBRyxDQUFDLEVBQUU7QUFDbEMsYUFBTyxTQUFTLENBQUM7S0FDbEI7OztBQUdELFFBQUksUUFBUSxHQUFHLFNBQVMsQ0FBQztBQUN6QixRQUFHLG1CQUFtQixDQUFDLE1BQU0sS0FBRyxDQUFDLEVBQUU7O0FBQ2pDLFlBQU0sT0FBTyxHQUFHLG1CQUFtQixDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ3ZDLGdCQUFRLEdBQUcsWUFBTTtBQUNmLGNBQU0sSUFBSSxHQUFHLGtCQUFrQixDQUFDLE9BQU8sRUFBRSx5QkFBeUIsQ0FBQyxDQUFBO0FBQ25FLGNBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQ25GLElBQUksQ0FBQyxVQUFBLE1BQU07bUJBQUksTUFBTSxDQUFDLHNCQUFzQixDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDO1dBQUEsQ0FBQyxTQUN4RCxDQUFDLFVBQUEsS0FBSzttQkFBSSxPQUFPLENBQUMsR0FBRyw0QkFBMEIsS0FBSyxDQUFHO1dBQUEsQ0FBQyxDQUFBO1NBQy9ELENBQUE7O0tBQ0YsTUFBTTtBQUNMLGNBQVEsR0FBRyxFQUFFLENBQUM7OzRCQUNMLE9BQU87QUFDZCxZQUFNLElBQUksR0FBRyxrQkFBa0IsQ0FBQyxPQUFPLEVBQUUseUJBQXlCLENBQUMsQ0FBQTtBQUNuRSxnQkFBUSxDQUFDLElBQUksQ0FBQztBQUNaLGVBQUssRUFBRSxJQUFJLENBQUMsSUFBSTtBQUNoQixrQkFBUSxFQUFBLG9CQUFHO0FBQ1QsZ0JBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsRUFBQyxXQUFXLEVBQUUsSUFBSSxDQUFDLElBQUksRUFBRSxhQUFhLEVBQUUsSUFBSSxDQUFDLE1BQU0sRUFBQyxDQUFDLENBQ25GLElBQUksQ0FBQyxVQUFBLE1BQU07cUJBQUksTUFBTSxDQUFDLHNCQUFzQixDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDO2FBQUEsQ0FBQyxTQUN4RCxDQUFDLFVBQUEsS0FBSztxQkFBSSxPQUFPLENBQUMsR0FBRyw0QkFBMEIsS0FBSyxDQUFHO2FBQUEsQ0FBQyxDQUFBO1dBQy9EO1NBQ0YsQ0FBQyxDQUFBOzs7QUFUSixXQUFLLElBQUksT0FBTyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsbUJBQW1CLENBQUMsRUFBRTtjQUE1QyxPQUFPO09BVWY7S0FDRjs7QUFFRCxXQUFPO0FBQ0wsV0FBSyxFQUFFLGdCQUFVLGdCQUFVLEtBQUssQ0FBQyxHQUFHLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLEVBQUUsZ0JBQVUsS0FBSyxDQUFDLEdBQUcsRUFBRSxnQkFBZ0IsQ0FBQyxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN0SCxjQUFRLEVBQVIsUUFBUTtLQUNULENBQUM7R0FDSDtDQUNGIiwiZmlsZSI6ImZpbGU6Ly8vQzovVXNlcnMvRnJhbmNpc2NvLy5hdG9tL3BhY2thZ2VzL2h5cGVyY2xpY2stcm9ib3QtZnJhbWV3b3JrL2xpYi9oeXBlcmNsaWNrLWtleXdvcmRzLmpzIiwic291cmNlc0NvbnRlbnQiOlsiJ3VzZSBiYWJlbCdcclxuaW1wb3J0IHsgUG9pbnQsIFJhbmdlIH0gZnJvbSAnYXRvbSdcclxuaW1wb3J0IHBhdGhVdGlscyBmcm9tICdwYXRoJ1xyXG5pbXBvcnQgZnMgZnJvbSAnZnMnXHJcbmltcG9ydCBjb21tb24gZnJvbSAnLi9jb21tb24nXHJcblxyXG4vLyBNYXRjaGVzIHNvbWV0aGluZyBsaWtlICdCdWlsdEluLlNob3VsZCBiZSBlcXVhbCdcclxuY29uc3QgS0VZV09SRF9SRUdFWFAgPSAvKCguKilcXC4pPyguKikvXHJcbmNvbnN0IGJkZFByZWZpeFJlZ2V4ID0gL14oZ2l2ZW58d2hlbnx0aGVufGFuZHxidXQpIC9pXHJcblxyXG5mdW5jdGlvbiBmaW5kS2V5d29yZEF0UG9zaXRpb24obGluZSwgY29sdW1uKSB7XHJcbiAgbGV0IGNlbGxzID0gY29tbW9uLnNwbGl0Q2VsbHMobGluZSk7XHJcblxyXG4gIC8vIFRha2UgY2FyZSBvZiBiZGQgcHJlZml4XHJcbiAgaWYoY2VsbHMubGVuZ3RoPjApIHtcclxuICAgIGNvbnN0IGZpcnN0Q2VsbCA9IGNlbGxzWzBdICAvLyBvbmx5IGZpcnN0IGNlbGwgY2FuIGluY2x1ZGUgYmRkIHByZWZpeFxyXG4gICAgY29uc3QgYmRkTWF0Y2ggPSBiZGRQcmVmaXhSZWdleC5leGVjKGZpcnN0Q2VsbClcclxuICAgIGlmKGJkZE1hdGNoKSB7XHJcbiAgICAgIGNlbGxzLnB1c2goZmlyc3RDZWxsLnN1YnN0cmluZyhiZGRNYXRjaFswXS5sZW5ndGgsIGZpcnN0Q2VsbC5sZW5ndGgpKVxyXG4gICAgfVxyXG4gIH1cclxuICBjb25zdCBrZXl3b3JkcyA9IFtdXHJcbiAgZm9yIChsZXQgY2VsbCBvZiBBcnJheS5mcm9tKGNlbGxzKSkge1xyXG4gICAgbGV0IHN0YXJ0Q29sID0gbGluZS5pbmRleE9mKGNlbGwpO1xyXG4gICAgbGV0IGVuZENvbCA9IHN0YXJ0Q29sK2NlbGwubGVuZ3RoO1xyXG4gICAgaWYgKChjb2x1bW4+c3RhcnRDb2wpICYmIChjb2x1bW48ZW5kQ29sKSkge1xyXG4gICAgICBjb25zdCBtYXRjaCA9IEtFWVdPUkRfUkVHRVhQLmV4ZWMoY2VsbClcclxuICAgICAgaWYobWF0Y2gpe1xyXG4gICAgICAgIGNvbnN0IHByZWZpeCA9IG1hdGNoWzJdXG4gICAgICAgIGNvbnN0IGtleXdvcmROYW1lID0gbWF0Y2hbM11cclxuICAgICAgICBrZXl3b3Jkcy5wdXNoKHtcclxuICAgICAgICAgIHN0YXJ0Q29sLFxyXG4gICAgICAgICAgZW5kQ29sLFxyXG4gICAgICAgICAgcHJlZml4LFxyXG4gICAgICAgICAga2V5d29yZE5hbWVcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxuICByZXR1cm4ga2V5d29yZHNcclxufTtcclxuXHJcbi8vIEZpbmRzIGtleXdvcmQgd2l0aGluIHNwZWNpZmllZCBweXRob24gbGlicmFyeS5cclxuLy8gUmV0dXJucyBSZXN1bHQ6IHtsaW5lOiBudW0sIGNvbHVtbjogbnVtLCBwYXRoOiAnJ30gaWYgZm91bmQsIG90aGVyd2lzZSB1bmRlZmluZWQuXHJcbmZ1bmN0aW9uIGdldFB5dGhvbkxvY2F0aW9uKGtleXdvcmROYW1lLCBsaWJyYXJ5UGF0aCl7XHJcbiAgY29uc3QgcHl0aG9uQ29udGVudCA9IGZzLnJlYWRGaWxlU3luYyhsaWJyYXJ5UGF0aCkudG9TdHJpbmcoKVxyXG4gIGxldCBweUluZm8gPSB7Zm91bmQ6IGZhbHNlLCBsaW5lOiB1bmRlZmluZWQsIGNvbHVtbjogdW5kZWZpbmVkfVxyXG4gIGxldCBsaW5lTm8gPSAwO1xyXG4gIGZvcihjb25zdCBsaW5lIG9mIHB5dGhvbkNvbnRlbnQuc3BsaXQoJ1xcbicpKXtcclxuICAgIGNvbnN0IHB5S2V5d29yZE5hbWUgPSBrZXl3b3JkTmFtZS5zcGxpdCgnICcpLmpvaW4oJ18nKVxyXG4gICAgY29uc3QgcmVnZXhwID0gbmV3IFJlZ0V4cChgXlsgXFxcXHRdKmRlZlsgXFxcXHRdKyR7cHlLZXl3b3JkTmFtZX1bIFxcXFx0XSpcXFxcKGAsICdpJylcclxuICAgIGlmKHJlZ2V4cC50ZXN0KGxpbmUpKXtcclxuICAgICAgcHlJbmZvLmZvdW5kID0gdHJ1ZVxyXG4gICAgICBweUluZm8ubGluZSA9IGxpbmVOb1xyXG4gICAgICBweUluZm8uY29sdW1uID0gMFxyXG4gICAgICBicmVha1xyXG4gICAgfVxyXG4gICAgbGluZU5vKytcclxuICB9XHJcbiAgaWYocHlJbmZvLmZvdW5kKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICBwYXRoOiBsaWJyYXJ5UGF0aCxcclxuICAgICAgbGluZTogcHlJbmZvLmxpbmUsXHJcbiAgICAgIGNvbHVtbjogcHlJbmZvLmNvbHVtblxyXG4gICAgfVxyXG4gIH0gZWxzZSB7XHJcbiAgICByZXR1cm4gdW5kZWZpbmVkXHJcbiAgfVxyXG59XHJcblxyXG4vLyBSZXR1cm5zIGxvY2F0aW9uIG9mIHRoZSBrZXl3b3JkLlxyXG4vLyBSZXN1bHQ6IHtsaW5lOiBudW0sIGNvbHVtbjogbnVtLCBwYXRoOiAnJ31cclxuZnVuY3Rpb24gZ2V0S2V5d29yZExvY2F0aW9uKGtleXdvcmQsIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIpe1xyXG4gIGxldCByZXNvdXJjZVxyXG4gIGlmKGtleXdvcmQucmVzb3VyY2VLZXkpe1xyXG4gICAgcmVzb3VyY2UgPSBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyLmdldFJlc291cmNlQnlLZXkoa2V5d29yZC5yZXNvdXJjZUtleSlcclxuICB9IGVsc2V7XHJcbiAgICByZXNvdXJjZSA9IGtleXdvcmQucmVzb3VyY2UgIC8vIERlcHJlY2F0ZWRcclxuICB9XHJcbiAgY29uc3QgaXNQeXRob25MaWJyYXJ5ID0gcmVzb3VyY2UuaXNMaWJyYXJ5XHJcbiAgICAmJiByZXNvdXJjZS5saWJyYXJ5UGF0aFxyXG4gICAgJiYgcmVzb3VyY2UubGlicmFyeVBhdGgudG9Mb3dlckNhc2UoKS5lbmRzV2l0aCgnLnB5JylcclxuICBsZXQgbG9jYXRpb24gPSB1bmRlZmluZWRcclxuICBpZihpc1B5dGhvbkxpYnJhcnkpe1xyXG4gICAgbG9jYXRpb24gPSBnZXRQeXRob25Mb2NhdGlvbihrZXl3b3JkLm5hbWUsIHJlc291cmNlLmxpYnJhcnlQYXRoKVxyXG4gIH1cclxuICByZXR1cm4gbG9jYXRpb24gfHwge1xyXG4gICAgcGF0aDogcmVzb3VyY2UucGF0aCxcclxuICAgIGxpbmU6IGtleXdvcmQuc3RhcnRSb3dObyxcclxuICAgIGNvbHVtbjoga2V5d29yZC5zdGFydENvbE5vXHJcbiAgfVxyXG59XHJcblxyXG5mdW5jdGlvbiBnZXRLZXl3b3JkRnJvbUltcG9ydHMoa2V5d29yZEluZm8sIGltcG9ydHMsIGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIpe1xyXG4gIGNvbnN0IGtleXdvcmROYW1lID0ga2V5d29yZEluZm8ua2V5d29yZE5hbWVcclxuICBjb25zdCBwcmVmaXggPSBrZXl3b3JkSW5mby5wcmVmaXhcclxuICBjb25zdCBpbXBvcnRlZEtleXdvcmRzID0gW11cclxuICBmb3IobGV0IGltcG9ydGVkTGlicmFyeSBvZiBbLi4uaW1wb3J0cy5saWJyYXJpZXMsIHtuYW1lOidCdWlsdEluJ31dKXtcclxuICAgIGltcG9ydGVkTGlicmFyeSA9IGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VCeUtleShpbXBvcnRlZExpYnJhcnkubmFtZS50b0xvd2VyQ2FzZSgpKVxyXG4gICAgaWYoIWltcG9ydGVkTGlicmFyeSl7XHJcbiAgICAgIGNvbnRpbnVlXHJcbiAgICB9XHJcbiAgICBpZihwcmVmaXggJiYgaW1wb3J0ZWRMaWJyYXJ5Lm5hbWUhPT1wcmVmaXgpIHtcclxuICAgICAgY29udGludWVcclxuICAgIH1cclxuICAgIGZvcihjb25zdCBpbXBvcnRlZEtleXdvcmQgb2YgaW1wb3J0ZWRMaWJyYXJ5LmtleXdvcmRzKXtcclxuICAgICAgaWYoaW1wb3J0ZWRLZXl3b3JkLm5hbWU9PT1rZXl3b3JkTmFtZSl7XHJcbiAgICAgICAgaW1wb3J0ZWRLZXl3b3Jkcy5wdXNoKGltcG9ydGVkS2V5d29yZClcclxuICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG4gIGNvbnN0IG1hdGNoaW5nSW1wb3J0ZWRSZXNvdXJjZXMgPSBuZXcgU2V0KClcclxuICBmb3IobGV0IGltcG9ydGVkUmVzb3VyY2Ugb2YgaW1wb3J0cy5yZXNvdXJjZXMpe1xyXG4gICAgaWYoaW1wb3J0ZWRSZXNvdXJjZS5yZXNvdXJjZUtleSl7XHJcbiAgICAgIC8vIGFjY3VyYXRlIGltcG9ydFxyXG4gICAgICBjb25zdCByZXNvdXJjZSA9IGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VCeUtleShpbXBvcnRlZFJlc291cmNlLnJlc291cmNlS2V5KVxyXG4gICAgICBpZihyZXNvdXJjZSl7XHJcbiAgICAgICAgbWF0Y2hpbmdJbXBvcnRlZFJlc291cmNlcy5hZGQocmVzb3VyY2UpXHJcbiAgICAgIH1cclxuICAgIH0gZWxzZXtcclxuICAgICAgLy8gYXBwcm94aW1hdGUgaW1wb3J0XHJcbiAgICAgIGNvbnN0IHJlc291cmNlS2V5cyA9IGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0UmVzb3VyY2VLZXlzKClcclxuICAgICAgZm9yKGNvbnN0IHJlc291cmNlS2V5IG9mIHJlc291cmNlS2V5cyl7XHJcbiAgICAgICAgY29uc3QgcmVzb3VyY2UgPSBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyLmdldFJlc291cmNlQnlLZXkocmVzb3VyY2VLZXkpXHJcbiAgICAgICAgaWYocmVzb3VyY2UgJiYgcmVzb3VyY2UubmFtZSA9PT0gaW1wb3J0ZWRSZXNvdXJjZS5uYW1lKXtcclxuICAgICAgICAgIG1hdGNoaW5nSW1wb3J0ZWRSZXNvdXJjZXMuYWRkKHJlc291cmNlKVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgfVxyXG4gIH1cclxuICBmb3IoY29uc3QgaW1wb3J0ZWRSZXNvdXJjZSBvZiBtYXRjaGluZ0ltcG9ydGVkUmVzb3VyY2VzKXtcclxuICAgICAgaWYocHJlZml4ICYmIGltcG9ydGVkUmVzb3VyY2UubmFtZSE9PXByZWZpeCkge1xyXG4gICAgICAgIGNvbnRpbnVlXHJcbiAgICAgIH1cclxuICAgICAgZm9yKGNvbnN0IGltcG9ydGVkS2V5d29yZCBvZiBpbXBvcnRlZFJlc291cmNlLmtleXdvcmRzKXtcclxuICAgICAgICBpZihpbXBvcnRlZEtleXdvcmQubmFtZT09PWtleXdvcmROYW1lKXtcclxuICAgICAgICAgIGltcG9ydGVkS2V5d29yZHMucHVzaChpbXBvcnRlZEtleXdvcmQpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gIH1cclxuXHJcbiAgcmV0dXJuIGltcG9ydGVkS2V5d29yZHNcclxufVxyXG5cclxuZXhwb3J0IGRlZmF1bHQge1xyXG4gIGdldEtleXdvcmRTdWdnZXN0aW9ucyh0ZXh0RWRpdG9yLCBwb2ludCwgYXV0b2NvbXBsZXRlUm9ib3RQcm92aWRlcil7XHJcbiAgICAvLyBnZXQgbGlzdCBvZiBtYXRjaGluZyBrZXl3b3JkcyBhdCBjdXJzb3JcclxuICAgIGNvbnN0IGxpbmUgPSB0ZXh0RWRpdG9yLmxpbmVUZXh0Rm9yQnVmZmVyUm93KHBvaW50LnJvdyk7XHJcbiAgICBjb25zdCBrZXl3b3JkSW5mb0l0ZW1zID0gZmluZEtleXdvcmRBdFBvc2l0aW9uKGxpbmUsIHBvaW50LmNvbHVtbik7XHJcbiAgICBpZiAoa2V5d29yZEluZm9JdGVtcy5sZW5ndGggPT0gMCkge1xyXG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBoaWdobGlnaHRlZEtleXdvcmRzID0gW11cclxuICAgIC8vIHVzZSBpbXBvcnRzIHRvIHJlc29sdmUgaGlnaGxpZ2h0ZWQga2V5d29yZFxyXG4gICAgY29uc3QgYWN0aXZlUmVzb3VyY2UgPSBjb21tb24uZ2V0Q3VycmVudFJlc291cmNlKHRleHRFZGl0b3IuZ2V0UGF0aCgpLCBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyKVxyXG4gICAgaWYoYWN0aXZlUmVzb3VyY2UpIHtcclxuICAgICAgZm9yKGtleXdvcmRJbmZvIG9mIGtleXdvcmRJbmZvSXRlbXMpIHtcclxuICAgICAgICBoaWdobGlnaHRlZEtleXdvcmRzID0gaGlnaGxpZ2h0ZWRLZXl3b3Jkcy5jb25jYXQoXHJcbiAgICAgICAgICAgIGdldEtleXdvcmRGcm9tSW1wb3J0cyhrZXl3b3JkSW5mbywgYWN0aXZlUmVzb3VyY2UuaW1wb3J0cywgYXV0b2NvbXBsZXRlUm9ib3RQcm92aWRlcikpXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICAvLyBkaXNyZWdhcmQgaW1wb3J0czsgc2VhcmNoIGluIGFsbCBhdmFpbGFibGUga2V5d29yZHNcclxuICAgIGlmKGhpZ2hsaWdodGVkS2V5d29yZHMubGVuZ3RoPT09MCl7XHJcbiAgICAgIGZvcihrZXl3b3JkSW5mbyBvZiBrZXl3b3JkSW5mb0l0ZW1zKSB7XHJcbiAgICAgICAgaGlnaGxpZ2h0ZWRLZXl3b3JkcyA9IGhpZ2hsaWdodGVkS2V5d29yZHMuY29uY2F0KGF1dG9jb21wbGV0ZVJvYm90UHJvdmlkZXIuZ2V0S2V5d29yZHNCeU5hbWUoa2V5d29yZEluZm8ua2V5d29yZE5hbWUpKVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgaWYgKGhpZ2hsaWdodGVkS2V5d29yZHMubGVuZ3RoPT09MCkge1xyXG4gICAgICByZXR1cm4gdW5kZWZpbmVkO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIGJ1aWxkIGh5cGVyY2xpY2sgY2FsbGJhY2tcclxuICAgIGxldCBjYWxsYmFjayA9IHVuZGVmaW5lZDtcclxuICAgIGlmKGhpZ2hsaWdodGVkS2V5d29yZHMubGVuZ3RoPT09MSkge1xyXG4gICAgICBjb25zdCBrZXl3b3JkID0gaGlnaGxpZ2h0ZWRLZXl3b3Jkc1swXTtcclxuICAgICAgY2FsbGJhY2sgPSAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qga2xvYyA9IGdldEtleXdvcmRMb2NhdGlvbihrZXl3b3JkLCBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyKVxyXG4gICAgICAgIGF0b20ud29ya3NwYWNlLm9wZW4oa2xvYy5wYXRoLCB7aW5pdGlhbExpbmU6IGtsb2MubGluZSwgaW5pdGlhbENvbHVtbjoga2xvYy5jb2x1bW59KVxyXG4gICAgICAgIC50aGVuKGVkaXRvciA9PiBlZGl0b3Iuc2Nyb2xsVG9DdXJzb3JQb3NpdGlvbih7Y2VudGVyOiB0cnVlfSkpXHJcbiAgICAgICAgLmNhdGNoKGVycm9yID0+IGNvbnNvbGUubG9nKGBFcnJvciBvcGVuaW5nIGVkaXRvcjogJHtlcnJvcn1gKSlcclxuICAgICAgfVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgY2FsbGJhY2sgPSBbXTtcclxuICAgICAgZm9yIChsZXQga2V5d29yZCBvZiBBcnJheS5mcm9tKGhpZ2hsaWdodGVkS2V5d29yZHMpKSB7XHJcbiAgICAgICAgY29uc3Qga2xvYyA9IGdldEtleXdvcmRMb2NhdGlvbihrZXl3b3JkLCBhdXRvY29tcGxldGVSb2JvdFByb3ZpZGVyKVxyXG4gICAgICAgIGNhbGxiYWNrLnB1c2goe1xyXG4gICAgICAgICAgdGl0bGU6IGtsb2MucGF0aCxcclxuICAgICAgICAgIGNhbGxiYWNrKCkge1xyXG4gICAgICAgICAgICBhdG9tLndvcmtzcGFjZS5vcGVuKGtsb2MucGF0aCwge2luaXRpYWxMaW5lOiBrbG9jLmxpbmUsIGluaXRpYWxDb2x1bW46IGtsb2MuY29sdW1ufSlcclxuICAgICAgICAgICAgLnRoZW4oZWRpdG9yID0+IGVkaXRvci5zY3JvbGxUb0N1cnNvclBvc2l0aW9uKHtjZW50ZXI6IHRydWV9KSlcclxuICAgICAgICAgICAgLmNhdGNoKGVycm9yID0+IGNvbnNvbGUubG9nKGBFcnJvciBvcGVuaW5nIGVkaXRvcjogJHtlcnJvcn1gKSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmFuZ2U6IG5ldyBSYW5nZShuZXcgUG9pbnQocG9pbnQucm93LCBrZXl3b3JkSW5mb0l0ZW1zWzBdLnN0YXJ0Q29sKSwgbmV3IFBvaW50KHBvaW50LnJvdywga2V5d29yZEluZm9JdGVtc1swXS5lbmRDb2wpKSxcclxuICAgICAgY2FsbGJhY2tcclxuICAgIH07XHJcbiAgfVxyXG59O1xyXG4iXX0=