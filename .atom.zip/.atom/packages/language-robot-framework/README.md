language-robot-framework package
================================

[![Build Status](https://travis-ci.org/wingyplus/language-robot-framework.svg)](https://travis-ci.org/wingyplus/language-robot-framework)

Adds syntax highlighting and snippets to [Robot Framework](https://github.com/robotframework/robotframework) files in Atom.

Contributions are greatly appreciated. Please fork this repository and open a pull request to add snippets, make grammar tweaks, etc.

Thanks
------
[@roongr2k7 (Pitsanu Swangpheaw)](https://github.com/roongr2k7)
[@kenben (Quentin Nerden)](https://github.com/kenden)
