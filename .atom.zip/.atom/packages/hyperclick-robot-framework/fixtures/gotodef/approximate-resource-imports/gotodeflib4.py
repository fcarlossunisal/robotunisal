# This module will not be imported in any robot resource
def impkw():
    print('impkw4')
