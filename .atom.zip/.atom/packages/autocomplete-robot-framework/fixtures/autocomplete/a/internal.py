# This does not reside in pythonpath
def internal_python_kw():
    print('dox')
