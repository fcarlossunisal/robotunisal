print ('init1')
