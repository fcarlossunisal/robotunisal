ROBOT_LIBRARY_VERSION='1.2.3'

print ('init3')

def test_module_keyword(param1, param2):
    """
    Test module documentation
    """
    return 'result'

def _priv_keyword():
    print ('priv keyword')

def __priv_keyword_2():
    print ('priv keyword')
